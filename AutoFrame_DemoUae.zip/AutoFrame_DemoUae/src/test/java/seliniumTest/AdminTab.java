package seliniumTest;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.testng.annotations.Test;

import PageObjects.LoginPage;

public class AdminTab extends BaseTest{
	
	
	@SuppressWarnings("deprecation")
	@Test(priority =1)
	public void AddAdminTest() throws IOException, InterruptedException {
		FileInputStream file = new FileInputStream("C:\\Selenium\\WorkSpace\\AutoFrame\\src\\test\\resources\\data.properties");
		Properties data = new Properties();
		data.load(file);
		
		String tilte = page1.getInstance(LoginPage.class).getLoginPageTitle();
		System.out.println("login page title is: "+ tilte);
		AssertJUnit.assertEquals(tilte, data.getProperty("LoginPageTitle"));
		page1.getInstance(LoginPage.class).doLogin(data.getProperty("username"), data.getProperty("password"));
		page1.getInstance(LoginPage.class).tapOnAdminTab();
	//	page1.getInstance(Loginpage.class).
		System.out.println("Tappedon admin tab");
		page1.getInstance(LoginPage.class).clickadminSearchText();
		System.out.println("Clicked on search field");
		page1.getInstance(LoginPage.class).enteradminSearchText(data.getProperty("search"));
		System.out.println("Entered the search field with input data as: "+data.getProperty("search"));
		page1.getInstance(LoginPage.class).tapOnSearchButton();
		page1.getInstance(LoginPage.class).verifyTheTextRecordInTable();
		
		
	}

}
