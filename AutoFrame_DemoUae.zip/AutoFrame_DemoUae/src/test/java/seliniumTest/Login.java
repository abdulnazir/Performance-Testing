package seliniumTest;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.testng.annotations.Test;

import PageObjects.LoginPage;
import PageObjects.Page1;


public class Login extends BaseTest{
	
	
	@SuppressWarnings("deprecation")
	//@Test(priority =1)
	public void VerifyLoginPageTitleTest() throws IOException {
		FileInputStream file = new FileInputStream("C:\\Selenium\\WorkSpace\\AutoFrame\\src\\test\\resources\\data.properties");
		Properties data = new Properties();
		data.load(file);
		
		String tilte = page1.getInstance(LoginPage.class).getLoginPageTitle();
		System.out.println("login page title is: "+ tilte);
		AssertJUnit.assertEquals(tilte, data.getProperty("LoginPageTitle"));
		
	}
	@Test(priority =2)
	public void VerifyLoginandPageTitle() throws IOException{
		FileInputStream file = new FileInputStream("C:\\Selenium\\WorkSpace\\AutoFrame\\src\\test\\resources\\data.properties");
		Properties data = new Properties();
		data.load(file);
		
		String tilte = page1.getInstance(LoginPage.class).getLoginPageTitle();
		System.out.println("login page title is: "+ tilte);
		AssertJUnit.assertEquals(tilte, data.getProperty("LoginPageTitle"));
		page1.getInstance(LoginPage.class).doLogin(data.getProperty("username"), data.getProperty("password"));
		
	}
	
	

}
