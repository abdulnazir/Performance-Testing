package seliniumTest;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import PageObjects.Page1;

public class BaseTest {

	public WebDriver driver;
	public WebDriverWait wait;
	public Page1 page1;
		
	
	@BeforeMethod
	public void setUp() throws IOException {
			FileInputStream file = new FileInputStream("C:\\Selenium\\WorkSpace\\AutoFrame\\src\\test\\resources\\data.properties");
			Properties data = new Properties();
			data.load(file);
			
		System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\WorkSpace\\AutoFrame\\Drivers\\chromeDriver.exe");
		driver = new ChromeDriver();
		
		wait = new WebDriverWait(driver, 20);
		driver.manage().window().maximize();
		driver.get(data.getProperty("url"));
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		// call the page class
		page1 = new Page1(driver, wait);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='username']")));
	}
	
	@AfterMethod
	public void afterTest() {
		driver.quit();
	}
	
}
