package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class LoginPage extends BasePage{

	public LoginPage(WebDriver driver, WebDriverWait wait) {
		super(driver, wait);
	}

	//page locators
	By emailid = By.xpath("//input[@name='username']");
	By password = By.xpath("//input[@name='password']");
	By LoginButton = By.xpath("//button[@type='submit']");
	By adminTab = By.xpath("//*[@id=\"app\"]/div[1]/div[1]/aside/nav/div[2]/ul/li[1]/a/span");
	By Search = By.xpath("//div[2]/input['admin']");
	By tapOnSearchButton=By.xpath("//button[@type='submit']");
	By checkrecord=By.xpath("//div[@class='oxd-table-card']/div/div[2]/div");
	By JobTab=By.xpath("//*[contains(text(),'Job')]");  
	By JobTitles=By.xpath("//*[contains(text(),'Job Titles')]");
	By addJobTitles=By.xpath("//button[@class='oxd-button oxd-button--medium oxd-button--secondary']/i");
	// page actions or business logics
	By JobTilteInput = By.xpath("//div[@class='oxd-input-group oxd-input-field-bottom-space']/div[2]/input[1]");
	By saveButton=By.xpath("//button[@type='submit']");

	public String getLoginPageTitle() {
		return driver.getTitle();
	}

	public void doLogin(String username, String pwd) {

		sendKeys(emailid, username);
		sendKeys(password, pwd);
		click(LoginButton);
	}

	public void tapOnAdminTab() {

		click(adminTab);
	}

	public void clickadminSearchText() {

		click(Search);
	}
	
	public void enteradminSearchText(String find) {
		//click(Search);
		sendKeys(Search, find);
		
	}
	
	public void tapOnSearchButton() {
		click(tapOnSearchButton);
	}
	
	public void verifyTheTextRecordInTable() {
		getText(checkrecord);
		System.out.println("records was found :" + getText(checkrecord));
		Assert.assertEquals(getText(checkrecord), "Admin");// div[@class='oxd-table-card']/div[1]/div[2]/div
	}
	
	public void JobTab() {
		click(JobTab);
	}
	
	public void JobTtiltes() throws InterruptedException{
		click(JobTitles);
		Thread.sleep(2000);
	}
	
	public void tapAddButtonInJobTitles() {
		click(addJobTitles);
	}
	
	public void enterJobTitlesText(String find) throws InterruptedException {
		sendKeys(JobTilteInput, find);
		click(saveButton);
		Thread.sleep(2000);
	}

	

}
