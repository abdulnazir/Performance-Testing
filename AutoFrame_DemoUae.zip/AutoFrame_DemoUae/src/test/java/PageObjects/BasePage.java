package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BasePage extends Page1{
	

	public BasePage(WebDriver driver, WebDriverWait wait) {
		super(driver, wait);
	}
	
	// wrappers
	public void click(By locator) {
		driver.findElement(locator).click();
	}
	
	public void sendKeys(By locator, String  text) {
		driver.findElement(locator).sendKeys(text);
	}
	
	public String getText(By locator) {
		return driver.findElement(locator).getText();
	
	}

	public void selectdropdwon(By locator) {
		 driver.findElement(locator).click();
		// driver.findElement(locator).
		 
	}
}
