package seliniumTest;

import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import org.testng.AssertJUnit;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.testng.annotations.Test;

import PageObjects.LoginPage;
import seliniumTest.ExtendedReportwithTestNG;

public class AdminTab extends BaseTest{

	ExtentHtmlReporter htmlReporter1;
	ExtentReports extent;
	//public static ExtentReports extent;
	public static ExtentSparkReporter reporter;


	@SuppressWarnings("deprecation")
	public void setup () {

		htmlReporter1 = new ExtentHtmlReporter("orangereports1.html");
		// create ExtentReports and attach reporter(s)
		extent = new ExtentReports();
		extent.attachReporter(htmlReporter1);
	}

	@SuppressWarnings("deprecation")
	@Test(priority = 3)
	public void AddAdminTest() throws IOException, InterruptedException {


		extent =new ExtentReports();
		reporter = new ExtentSparkReporter("orangereports1.html");
		extent.attachReporter(reporter);

		FileInputStream file = new FileInputStream("C:\\Selenium\\WorkSpace\\AutoFrame\\src\\test\\resources\\data.properties");
		Properties data = new Properties();
		data.load(file);

		String tilte = page1.getInstance(LoginPage.class).getLoginPageTitle();
		System.out.println("login page title is: "+ tilte);
		AssertJUnit.assertEquals(tilte, data.getProperty("LoginPageTitle"));
		page1.getInstance(LoginPage.class).doLogin(data.getProperty("username"), data.getProperty("password"));
		page1.getInstance(LoginPage.class).tapOnAdminTab();
		//	page1.getInstance(Loginpage.class).
		System.out.println("Tappedon admin tab");
		page1.getInstance(LoginPage.class).clickadminSearchText();
		System.out.println("Clicked on search field");
		page1.getInstance(LoginPage.class).enteradminSearchText(data.getProperty("search"));
		System.out.println("Entered the search field with input data as: "+data.getProperty("search"));
		page1.getInstance(LoginPage.class).tapOnSearchButton();
		page1.getInstance(LoginPage.class).verifyTheTextRecordInTable();

		ExtentTest test1 = extent.createTest("AddAdminTest");
		test1.log(Status.INFO,"AddAdminTest method");
		test1.pass("pass");
		test1.addScreenCaptureFromPath("screenshot.png");


	}



}
