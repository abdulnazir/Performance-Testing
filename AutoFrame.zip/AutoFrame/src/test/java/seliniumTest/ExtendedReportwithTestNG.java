package seliniumTest;

import java.io.FileInputStream;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import PageObjects.LoginPage;
import PageObjects.Page1;

@SuppressWarnings("deprecation")
public class ExtendedReportwithTestNG {
	
	public WebDriver driver;
	public WebDriverWait wait;
	public Page1 page1;
		
	
	ExtentHtmlReporter htmlReporter;
	ExtentReports extent;
	//public static ExtentReports extent;
	public static ExtentSparkReporter reporter;

	@BeforeSuite
	public void setup() {
		
		htmlReporter = new ExtentHtmlReporter("orangereports.html");
		 // create ExtentReports and attach reporter(s)
		 extent = new ExtentReports();
		 extent.attachReporter(htmlReporter);
		}

	@Test
	public void test1() throws Exception {
		
		extent =new ExtentReports();
		reporter = new ExtentSparkReporter("orangereports.html");
		extent.attachReporter(reporter);
		
		// creates a toggle for the given test, adds all log events under it    
		/*
		 * ExtentTest test = extent.createTest("MyFirstTest", "Sample description");
		 * test.log(Status.INFO, "This step shows usage of log(status, details)");
		 * test.info("This step shows usage of info(details)");
		 */
        
        
        FileInputStream file = new FileInputStream("C:\\Selenium\\WorkSpace\\AutoFrame\\src\\test\\resources\\data.properties");
		Properties data = new Properties();
		data.load(file);
		
		System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\WorkSpace\\AutoFrame\\Drivers\\chromeDriver.exe");
		driver = new ChromeDriver();
		
		wait = new WebDriverWait(driver, 20);
		driver.manage().window().maximize();
		driver.get(data.getProperty("url"));
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		// call the page class
		page1 = new Page1(driver, wait);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		//wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='username']")));
		page1.getInstance(LoginPage.class).doLogin(data.getProperty("username"), data.getProperty("password"));
		
		ExtentTest test = extent.createTest("LoginTestCase");
		test.log(Status.INFO,"Login Testcase method");
		test.pass("pass");
        // log with snapshot
     //   test.fail("details", MediaEntityBuilder.createScreenCaptureFromPath("screenshot.png").build());
        // test with snapshot
        test.addScreenCaptureFromPath("screenshot.png");
        
        page1.getInstance(LoginPage.class).tapOnAdminTab();
		//	page1.getInstance(Loginpage.class).
		System.out.println("Tappedon admin tab");
		page1.getInstance(LoginPage.class).clickadminSearchText();
		System.out.println("Clicked on search field");
		page1.getInstance(LoginPage.class).enteradminSearchText(data.getProperty("search"));
		System.out.println("Entered the search field with input data as: "+data.getProperty("search"));
		page1.getInstance(LoginPage.class).tapOnSearchButton();
		page1.getInstance(LoginPage.class).verifyTheTextRecordInTable();
		
		ExtentTest test1 = extent.createTest("AdminTestCase");
		test1.log(Status.INFO,"Admin Testcase method");
		test1.pass("pass");
        // log with snapshot
     //   test.fail("details", MediaEntityBuilder.createScreenCaptureFromPath("screenshot.png").build());
        // test with snapshot
        test1.addScreenCaptureFromPath("screenshot.png");

		}
		/*
		 * @Test public void test2() throws Exception {
		 * 
		 * // creates a toggle for the given test, adds all log events under it
		 * ExtentTest test = extent.createTest("MysecondTest", "Sample description");
		 * test.log(Status.INFO, "This step shows usage of log(status, details)");
		 * test.info("This step shows usage of info(details)"); // log with snapshot
		 * test.pass("details",
		 * MediaEntityBuilder.createScreenCaptureFromPath("screenshot.png").build()); //
		 * test with snapshot test.addScreenCaptureFromPath("screenshot.png");
		 * 
		 * }
		 */
	
	@AfterSuite
	public void teardown() {
		
		ExtentTest test = extent.createTest("LogoutTestCase");
		test.log(Status.INFO,"Logout Testcase method");
		test.pass("pass");
		driver.quit();
		
		 // calling flush writes everything to the log file
        extent.flush();

	}

}