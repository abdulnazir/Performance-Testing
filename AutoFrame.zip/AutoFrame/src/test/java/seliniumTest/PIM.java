package seliniumTest;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.testng.annotations.Test;

import PageObjects.LoginPage;

public class PIM extends BaseTest{
	
	
	@SuppressWarnings("deprecation")
	@Test(priority = 4)
	public void AddPIMSelectTest() throws IOException, InterruptedException {
		FileInputStream file = new FileInputStream("C:\\Selenium\\WorkSpace\\AutoFrame\\src\\test\\resources\\data.properties");
		Properties data = new Properties();
		data.load(file);
		
		String tilte = page1.getInstance(LoginPage.class).getLoginPageTitle();
		System.out.println("login page title is: "+ tilte);
		AssertJUnit.assertEquals(tilte, data.getProperty("LoginPageTitle"));
		page1.getInstance(LoginPage.class).doLogin(data.getProperty("username"), data.getProperty("password"));
		page1.getInstance(LoginPage.class).tapPimmodule();
		System.out.println("Tappedon PIM tab");
		page1.getInstance(LoginPage.class).emmployeeSelect();
		page1.getInstance(LoginPage.class).selectFreelance();
		System.out.println("Selected the freelance from the list");
		page1.getInstance(LoginPage.class).pimemployeeSearch();
		System.out.println("Search listed for freelance");
	}

}
