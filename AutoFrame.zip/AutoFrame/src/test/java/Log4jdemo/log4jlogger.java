package Log4jdemo;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;


public class log4jlogger {

	private static Logger logger=LogManager.getLogger(log4jlogger.class);
	//private static Logger logger;
	
	 public static void startTestCase(String sTestCaseName){
		 	logger.info("*******************************************************************");	 
		 	logger.info("$$$$$$$$$$$$$$$$$$$$   "+sTestCaseName+ "       $$$$$$$$$$$$$$$$$$$");
		 	logger.info("*******************************************************************");
			}
	
	public static void endTestCase1(){
		 logger.info("$$$$$$$$$$$$$$$$$$$$      "+"E---N---D-"+"     $$$$$$$$$$$$$$$$$$$ ");
		}
			
	public static void main(String[] args) {
		
		System.out.println("\n    Hello world ...! \n");
		
		logger.trace("This is to trace the message");
		logger.info("THis is just for info");
		logger.error("This is an error message");
		logger.fatal("This is warning message");
		logger.debug("This is fatal message");
		
		System.out.println("\n   Completed");
	
	}

	 
}
