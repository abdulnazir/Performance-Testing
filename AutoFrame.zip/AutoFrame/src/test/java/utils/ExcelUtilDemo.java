/*
 * package utils;
 * 
 * public class ExcelUtilDemo {
 * 
 * public static void main(String[] args) {
 * 
 * String projectpath=System.getProperty("user.dir"); Excelutils excel = new
 * Excelutils(projectpath+"/Excel/Admin.xlsx","Sheet1"); excel.getRowcount();
 * excel.getCelldatastring(0, 0); excel.getCellDataNumber(1, 1);
 * 
 * }
 * 
 * }
 */