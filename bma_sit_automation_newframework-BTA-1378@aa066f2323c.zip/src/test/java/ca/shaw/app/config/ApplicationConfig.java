package ca.shaw.app.config;

import org.apache.commons.lang3.StringUtils;

public final class ApplicationConfig {
	private String KEYSTOREPATH = StringUtils.EMPTY;
	private String TRUSTSTOREPATH = StringUtils.EMPTY;
	private String KEYSTOREPW = StringUtils.EMPTY;
	private String TRUSTSTOREPW = StringUtils.EMPTY;
	private String KEYPASS = StringUtils.EMPTY;
	private String HTTPS_SERV_URL = StringUtils.EMPTY;
	private String trustAllCertificate = "false";// DEFAULT VALUE
	private String keystoreType = "JKS";// DEFAULT VALUE
	private String regex = StringUtils.EMPTY;
	private String keymanageralgorithm = StringUtils.EMPTY;
	private int mqreadinterval = 1;
	private int httpsfialureinterval = 5;
	private int prodissueinterval = 1;
	private static ApplicationConfig myinstance = null;
	private String driverName = StringUtils.EMPTY;
	private String hostName = StringUtils.EMPTY;
	private String port = StringUtils.EMPTY;
	private String servicename = StringUtils.EMPTY;
	private String username = StringUtils.EMPTY;
	private String password = StringUtils.EMPTY;
	private String URL_ACCOUNTMIGRATION = StringUtils.EMPTY;
	private String URL_FLEX = StringUtils.EMPTY;

	public String getURL_FLEX() {
		return URL_FLEX;
	}

	public void setURL_FLEX(String uRL_FLEX) {
		URL_FLEX = uRL_FLEX;
	}

	public static ApplicationConfig getInstance() {
		if (myinstance == null) {
			myinstance = new ApplicationConfig();
		}
		return myinstance;
	}

	public String getURL_ACCOUNTMIGRATION() {
		return URL_ACCOUNTMIGRATION;
	}

	public void setURL_ACCOUNTMIGRATION(String uRL_ACCOUNTMIGRATION) {
		URL_ACCOUNTMIGRATION = uRL_ACCOUNTMIGRATION;
	}

	private ApplicationConfig() {
	}

	public String getKEYSTOREPATH() {
		return KEYSTOREPATH;
	}

	public void setKEYSTOREPATH(String kEYSTOREPATH) {
		KEYSTOREPATH = kEYSTOREPATH;
	}

	public String getTRUSTSTOREPATH() {
		return TRUSTSTOREPATH;
	}

	public void setTRUSTSTOREPATH(String tRUSTSTOREPATH) {
		TRUSTSTOREPATH = tRUSTSTOREPATH;
	}

	public String getKEYSTOREPW() {
		return KEYSTOREPW;
	}

	public void setKEYSTOREPW(String kEYSTOREPW) {
		KEYSTOREPW = kEYSTOREPW;
	}

	public String getTRUSTSTOREPW() {
		return TRUSTSTOREPW;
	}

	public void setTRUSTSTOREPW(String tRUSTSTOREPW) {
		TRUSTSTOREPW = tRUSTSTOREPW;
	}

	public String getKEYPASS() {
		return KEYPASS;
	}

	public void setKEYPASS(String kEYPASS) {
		KEYPASS = kEYPASS;
	}

	public String getHTTPS_SERV_URL() {
		return HTTPS_SERV_URL;
	}

	public void setHTTPS_SERV_URL(String hTTPS_SERV_URL) {
		HTTPS_SERV_URL = hTTPS_SERV_URL;
	}

	public String getTrustAllCertificate() {
		return trustAllCertificate;
	}

	public void setTrustAllCertificate(String trustAllCertificate) {
		this.trustAllCertificate = trustAllCertificate;
	}

	public String getKeystoreType() {
		return keystoreType;
	}

	public void setKeystoreType(String keystoreType) {
		this.keystoreType = keystoreType;
	}

	public String getKeymanageralgorithm() {
		return keymanageralgorithm;
	}

	public void setKeymanageralgorithm(String keymanageralgorithm) {
		this.keymanageralgorithm = keymanageralgorithm;
	}

	public int getMqreadinterval() {
		return mqreadinterval;
	}

	public void setMqreadinterval(int mqreadinterval) {
		this.mqreadinterval = mqreadinterval;
	}

	public int getHttpsfialureinterval() {
		return httpsfialureinterval;
	}

	public void setHttpsfialureinterval(int httpsfialureinterval) {
		this.httpsfialureinterval = httpsfialureinterval;
	}

	public int getProdissueinterval() {
		return prodissueinterval;
	}

	public void setProdissueinterval(int prodissueinterval) {
		this.prodissueinterval = prodissueinterval;
	}

	public void setREGEX(String regex) {
		this.regex = regex;
	}

	public String getREGEX() {
		return this.regex;
	}

	public String getRegex() {
		return regex;
	}

	public void setRegex(String regex) {
		this.regex = regex;
	}

	public String getDriverName() {
		return driverName;
	}

	public void setDriverName(String driverName) {
		this.driverName = driverName;
	}

	public String getHostName() {
		return hostName;
	}

	public void setHostName(String hostName) {
		this.hostName = hostName;
	}

	public String getPort() {
		return port;
	}

	public void setPort(String port) {
		this.port = port;
	}

	public String getServicename() {
		return servicename;
	}

	public void setServicename(String servicename) {
		this.servicename = servicename;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public static ApplicationConfig getMyinstance() {
		return myinstance;
	}

	public static void setMyinstance(ApplicationConfig myinstance) {
		ApplicationConfig.myinstance = myinstance;
	}
}