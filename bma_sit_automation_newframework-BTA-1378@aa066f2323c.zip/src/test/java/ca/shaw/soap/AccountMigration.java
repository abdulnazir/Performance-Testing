package ca.shaw.soap;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.StringReader;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;

import ca.shaw.app.config.ApplicationConfig;
import ca.shaw.app.client.SSLClient;
import oracle.jdbc.pool.OracleDataSource;

public class AccountMigration {
          public static String migrateAccount(String accountNumber) {
	//public static void main(String[] args) {
		Configuration config = null;
		String currentPath = StringUtils.EMPTY;
		String accountNumberFromService = StringUtils.EMPTY;
		String accountIdFromCDI = StringUtils.EMPTY;
		try {
			// Load (String)configuration
			currentPath = System.getProperty("user.dir");
			System.out.println("Loading SSL and DB properties from location " + currentPath + "/" + "config.properties");
			
			config = new PropertiesConfiguration("src//test//resources//properties//config_preprod.properties");
			//config = new PropertiesConfiguration("src//test//resources//properties//config_181.properties");
		} catch (Exception e) {
			System.out.println("Exception in reading properties file : config.properties");
			e.printStackTrace();
			System.exit(-1);
		}
		
			ApplicationConfig ac = setSSLProperties(config);
			accountNumberFromService = accountMigrationCall(ac, currentPath, accountNumber);
			System.out.println("************ Extracted Response from Service Response ***************");
			System.out.println(accountNumberFromService);
			
		       return accountIdFromCDI;

	}


	private static String accountMigrationCall(ApplicationConfig config, String currentPath, String accountNumber) {
		try {
			SSLClient sslClient = SSLClient.getSSLClient();
			URL url = new URL(config.getURL_ACCOUNTMIGRATION());
			String method = "POST";

			// Replace the variables in xml
			LocalDateTime today = LocalDateTime.now();
			DateTimeFormatter zonedFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
			String dateForToday = zonedFormatter.format(today);
			String randomString = RandomStringUtils.randomNumeric(9);
			BufferedReader br = new BufferedReader(
				new FileReader(new File("src//test//resources//accountMigration.xml")));
			String message;
			StringBuilder sb = new StringBuilder();
			while ((message = br.readLine()) != null) {
				sb.append(message.trim());
			}
			String xmlDataAfterMod = sb.toString();
			xmlDataAfterMod = xmlDataAfterMod.replace("currentSystemDate", dateForToday);
			xmlDataAfterMod = xmlDataAfterMod.replace("currentRandomNumber", randomString);
			xmlDataAfterMod = xmlDataAfterMod.replace("accountNumberAccountMigration", accountNumber);
			System.out.println(
					"*****************************Request to the SOAP Service**********************************");
			System.out.println(xmlDataAfterMod);
			String msgtype = "application/soap+xml;charset=UTF-8;action=\"initialize\"";
			// A SOAP web service call
			String response = sslClient.sendRequest(url, method, xmlDataAfterMod, msgtype);
                        String resp = response.toString();
                        System.out.println("Response : "+resp);
			// Reading accountNumber from the response
			DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
			InputSource src = new InputSource();
			src.setCharacterStream(new StringReader(response.toString()));
			Document doc = builder.parse(src);
			accountNumber = doc.getElementsByTagName("ESILib:accountNumber").item(0).getTextContent();

		} catch (Exception e) {
			System.out.println("error while executing accountMigrationCall" + e.getCause().toString());
		}
		return accountNumber;
	}

	private static ApplicationConfig setSSLProperties(Configuration config) {
		ApplicationConfig ac = ApplicationConfig.getInstance();
		ac.setKEYSTOREPATH((String) config.getProperty("KEYSTOREPATH"));
		ac.setTRUSTSTOREPATH((String) config.getProperty("TRUSTSTOREPATH"));
		System.out.println(ac.getTRUSTSTOREPATH());
		ac.setKEYSTOREPW((String) config.getProperty("KEYSTOREPW"));
		ac.setTRUSTSTOREPW((String) config.getProperty("TRUSTSTOREPW"));
		ac.setKEYPASS((String) config.getProperty("KEYPASS"));
		ac.setKeystoreType((String) config.getProperty("keystoreType"));
		ac.setTrustAllCertificate((String) config.getProperty("trustAllCertificate"));
		ac.setKeymanageralgorithm((String) config.getProperty("keymanageralgorithm"));
		ac.setURL_ACCOUNTMIGRATION((String) config.getProperty("URL_ACCOUNTMIGRATION"));
		ac.setURL_FLEX((String) config.getProperty("URL_FLEX"));
		return ac;
	}

}