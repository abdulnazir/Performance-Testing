package api;

import io.restassured.RestAssured;
import io.restassured.config.SSLConfig;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import pageObjects.BaseUIPage;
import util.*;

import static io.restassured.RestAssured.given;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.security.KeyException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.KeyManagerFactory;

import org.apache.commons.lang.RandomStringUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class P150AccountDisconnect extends BaseUIPage {
	
	private WebDriver driver;
	public P150AccountDisconnect(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

  //  public static void main(String args[])
    public static int accountDisconnect(String accountNumber, String snumber) 
	    throws KeyException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException, IOException {
	
	
	    Response rs = postJsonPayload(accountNumber,snumber);
	    return rs.getStatusCode();
	 
    }

    public static Response postJsonPayload(String accNumber, String sernum)
	    throws KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException {

	KeyStore keyStore = null;
	SSLConfig config = null;
	String password = "ESISupport1!";

	try {
	    keyStore = KeyStore.getInstance("jks");
	    keyStore.load(new FileInputStream("C:\\Users\\shota\\certf\\esitestharness-tst.jks"),
		    password.toCharArray());

	} catch (Exception ex) {
	    System.out.println("Error while loading keystore >>>>>>>>>");
	    ex.printStackTrace();
	}

	if (keyStore != null) {

	    @SuppressWarnings("deprecation")
		org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(
		    keyStore, password);

	    // set the config in rest assured
	    config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();

	    RestAssured.config = RestAssured.config().sslConfig(config);
	}
	Map<String, String> reqheaders = new HashMap<String, String>();

	// reqheaders.put("Cache-Control","no-cache");
	reqheaders.put("X_SHAW_TRANSACTION_ID", "hbchhhhc");
	reqheaders.put("X_SHAW_ONBEHALFOF_ID", "Freedom"); 

	//String payload = "<Request xmlns=\"http://www.shaw.ca/esi/schema/customer/customeraccount_disconnect/v1\">\r\n"
		//+ "    <reasonCode>150</reasonCode>\r\n" + "</Request>\r\n";
	
	String payload = "<Request xmlns=\"http://www.shaw.ca/esi/schema/customer/customeraccount_disconnect/v1\">\r\n" + 
		"   <serialNumberList>\r\n" + 
		"      <serialNumber>snum</serialNumber>\r\n" + 
		"   </serialNumberList>\r\n" + 
		"   <locationId>FWKIOSK</locationId>\r\n" + 
		"   <reasonCode>150</reasonCode>\r\n" + 
		"</Request>";
	String xmlDataAfterMod = payload;
	xmlDataAfterMod = xmlDataAfterMod.replace("snum", sernum);
	String esi_url = prop.getProperty("ESI_URL");

	return RestAssured.given().contentType(ContentType.XML).headers(reqheaders).body(xmlDataAfterMod)
		.post(esi_url+"/service/v1/accounts/" + accNumber + "/disconnect");
    }

 

}

