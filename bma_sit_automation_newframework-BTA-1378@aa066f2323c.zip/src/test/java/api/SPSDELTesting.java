package api;

import java.util.HashMap;
import java.util.Map;

import org.junit.Assert;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import pageObjects.BaseUIPage;
import util.*;

public class SPSDELTesting extends BaseUIPage{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SPSDELvalidationXB6_XG1("03300020610");
	}

	public static void SPSDELvalidationXB6_XG1(String accountNumber) {
		String responseString = "";
		String host = "http://tstengsdmbl01.sjrb.ad:8001/SPS_DEL_Rest/DSREAD/1.1";
		RestAssured.baseURI = host;
		Map<String, String> qParam = new HashMap<String, String>();
		Map<String, String> headers = new HashMap<String, String>();

		qParam.put("idtype", "/Party/Person/Account/id");
		qParam.put("idvalue", accountNumber);
		qParam.put("xpath", "/Party/Person");
		qParam.put("rule", "FORCED_READ");
		RequestSpecification request = RestAssured.given().queryParams(qParam);
		Response response = request.get();
		System.out.println("Status code: " + response.getStatusCode());
		System.out.println("Status message " + response.body().asString());
		responseString = Integer.toString(response.getStatusCode());
		System.out.println(responseString);
		String accountstatuspath = "SPS_DELReadOutBody[0].DataSequence[0].SPS_DELData[0].Party[0].Person[0].Account[0].Status[0]";
		String accountstatus = response.xmlPath().get(accountstatuspath);
		System.out.println("Account Status in SPSDEL is " + accountstatus);
		String hsDatastatus = "SPS_DELReadOutBody[0].DataSequence[0].SPS_DELData[0].Party[0].Person[0].Account[0].Services[0].Service[0]."
				+ "Status[0]";
		String hsData = response.xmlPath().get(hsDatastatus);
		System.out.println("hsData Status in SPSDEL is " + hsData);
		Assert.assertEquals(hsData, "active");

		String wifistatus = "SPS_DELReadOutBody[0].DataSequence[0].SPS_DELData[0].Party[0].Person[0].Account[0].Services[0].Service[3].Status[0]";
		String wifi = response.xmlPath().get(wifistatus);
		System.out.println("wifi Status in SPSDEL is " + wifi);
		Assert.assertEquals(wifi, "active");

		
		String ppvstatus = "SPS_DELReadOutBody[0].DataSequence[0].SPS_DELData[0].Party[0].Person[0].Account[0].Services[0].Service[6].Status[0]";
		String ppv = response.xmlPath().get(ppvstatus);
		System.out.println("ppv Status in SPSDEL is " + ppv);
		Assert.assertEquals(ppv, "active");
		String qamtvstatus = "SPS_DELReadOutBody[0].DataSequence[0].SPS_DELData[0].Party[0].Person[0].Account[0].Services[0].Service[1].Status[0]";
		String qamtv = response.xmlPath().get(qamtvstatus);
		System.out.println("qamTv Status in SPSDEL is " + qamtv);
		Assert.assertEquals(qamtv, "active");
		
	}

}