package api;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.concurrent.TimeUnit;

import pageObjects.BaseUIPage;



public class JenkinsCLI extends BaseUIPage {

	public static void addEnvTimeToReport(String envNum) throws IOException, InterruptedException {
		String jenkins = "https://devcorek8sl050-001.matrix.sjrb.ad/testing";
		String userName = prop.getProperty("validation_user", "user_name_not_set");
		String password = prop.getProperty("validation_password", "password_not_set");
		String auth = userName + ":" + password;
		ProcessBuilder ps = new ProcessBuilder("java", "-jar", "jenkins-cli.jar", "-s", jenkins, "-webSocket", "-auth",
				auth, "build", "TIMESHIFTING/BRM 12c Check Time", "-s", "-v", "-p", "envNum=" + envNum);
		// From the DOC: Initially, this property is false, meaning that the
		// standard output and error output of a subprocess are sent to two
		// separate streams
		ps.redirectErrorStream(true);
		ps.redirectOutput(ProcessBuilder.Redirect.PIPE);
		Process pr = ps.start();
		BufferedReader in = new BufferedReader(new InputStreamReader(pr.getInputStream()));
		String line;
		while ((line = in.readLine()) != null) {
			if (line.contains("OEM server") || line.startsWith("BRM PVT") || line.startsWith("OEDB server")) {
				System.out.println(line);
				//addInfoInReport(line);
			}
		}
//		pr.waitFor();
		pr.waitFor(10, TimeUnit.MINUTES);
		in.close();
		return;
	}

	public static Boolean initiateTimeShift(String envNum, String numDays) throws IOException, InterruptedException {
		System.out.println("1 minute wait time for user to bail out of initiating timeshift step");
		Thread.sleep(60000);
		System.out.println("Initiating time shift of " + numDays + "day(s) on environment " + envNum);
		String jenkins = "https://devcorek8sl050-001.matrix.sjrb.ad/testing";
		String userName = prop.getProperty("validation_user", "user_name_not_set");
		String password = prop.getProperty("validation_password", "password_not_set");
		String auth = userName + ":" + password;
		ProcessBuilder ps = new ProcessBuilder("java", "-jar", "jenkins-cli.jar", "-s", jenkins, "-webSocket", "-auth",
				auth, "build", "TIMESHIFTING/New Timeshift for BRM 12c", "-s", "-v", "-p", "envNum=" + envNum, "-p",
				"numDays=" + numDays);
		// From the DOC: Initially, this property is false, meaning that the
		// standard output and error output of a subprocess are sent to two
		// separate streams
		ps.redirectErrorStream(true);
		// ps.redirectOutput(ProcessBuilder.Redirect.INHERIT);
		Process pr = ps.start();
		BufferedReader in = new BufferedReader(new InputStreamReader(pr.getInputStream()));
		String line;
		Boolean timeShiftStatus = false;

		while ((line = in.readLine()) != null) {
			if (line.contains("Finished: ")) {
				if (line.contains("SUCCESS")) {
					//addInfoInReport("Time Shift : " + line);
				} else {
					//addErrorInReport("Time Shift : " + line);
				}
				System.out.println(line);
			}
		}

		// pr.waitFor();
		pr.waitFor(40, TimeUnit.MINUTES);

		if (pr.exitValue() == 0) {
			//addInfoInReport(" ## TimeShift Success Status is " + timeShiftStatus);
			timeShiftStatus = true;
		} else {
			//addErrorInReport(" ## TimeShift Success Status is " + timeShiftStatus);
			timeShiftStatus = false;
		}

		in.close();
		System.out.println("Job Status = " + pr.exitValue());
		//addInfoInReport("Time Shift Job Status = " + pr.exitValue());
		addEnvTimeToReport(envNum);
		return timeShiftStatus;
	}

	public static Boolean executeCommandOnTS(String script_path_relative_to_bma_sit_automation)
			throws IOException, InterruptedException {
		ProcessBuilder ps = new ProcessBuilder("sh", "-c", script_path_relative_to_bma_sit_automation);
		// From the DOC: Initially, this property is false, meaning that the
		// standard output and error output of a subprocess are sent to two
		// separate streams
		ps.redirectErrorStream(true);
		ps.redirectOutput(ProcessBuilder.Redirect.PIPE);
		Process pr = ps.start();
		pr.waitFor(60, TimeUnit.SECONDS);
		BufferedReader in = new BufferedReader(new InputStreamReader(pr.getInputStream()));
		String line;
		Boolean executeStatus = true;
		while ((line = in.readLine()) != null) {
			// if (line.contains("OEM server") || line.startsWith("BRM PVT") ||
			// line.startsWith("OEDB server")) {
			// ...
			// }
			System.out.println(line);
			if (pr.exitValue() == 0) {
				executeStatus = true;
				//addInfoInReport(line);
			} else {
				executeStatus = false;
				//addErrorInReport(line);
			}
		}
		in.close();
		return executeStatus;
	}
}
