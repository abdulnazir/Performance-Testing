package api;

import io.restassured.RestAssured;
import io.restassured.config.SSLConfig;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import util.FakeHardwareGeneration;
import util.*;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.security.KeyException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.KeyManagerFactory;

import org.apache.commons.lang.RandomStringUtils;
import org.json.JSONException;
import org.json.JSONObject;

public class PCRApi {

  //  public static void main(String args[])
	   public static Map<String,String> pcrRun(String phoneNum, String serType)
	    throws KeyException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException, IOException {
	//String phoneNum = "4034752364";
	Response rs1 = postJsonPayload(phoneNum, serType);
	//Response rs1 = postJsonPayload(phoneNum, "Cable");
	System.out.println(rs1.getBody().prettyPrint());
	String accounNumber = rs1.jsonPath().getString("customerAccount.accountNumber");
	String billingStatus = rs1.jsonPath().getString("customerAccount.extendedProperties.values[0]");
	String customerName = rs1.jsonPath().getString("customerAccount.customers.customerProfile.partyProfile.individualSummary.individualNames.individualName.formattedName").substring(2).split("]")[0];
	String accounFinancialStatus = rs1.jsonPath().getString("customerAccount.accountFinancialSummary.accountFinancialStatus");
	String region = rs1.jsonPath().getString("customerAccount.extendedProperties.values[1]");
	String serviceType = rs1.jsonPath().getString("customerAccount.extendedProperties.values[2]");
	String BoR = rs1.jsonPath().getString("customerAccount.extendedProperties.values[3]");
	String SoR = rs1.jsonPath().getString("customerAccount.extendedProperties.values[4]");
	String newDeviceNotActive = rs1.jsonPath().getString("customerAccount.extendedProperties.values[7]");
	String newCustomer = rs1.jsonPath().getString("customerAccount.extendedProperties.values[8]");
	String recentChangeService = rs1.jsonPath().getString("customerAccount.extendedProperties.values[9]");
	String runningBalAmount = rs1.jsonPath().getString("customerAccount.accountFinancialSummary.runningBalance.amount");
	String runningBalUnits = rs1.jsonPath().getString("customerAccount.accountFinancialSummary.runningBalance.units");
	String lastPaymentDate = rs1.jsonPath().getString("customerAccount.accountFinancialSummary.latestPaymentActivity.lastPaymentDate");
	String faddressline1 = rs1.jsonPath().getString("customerAccount.customers.contactMediums.postalDeliveryAddress.formattedAddressLine1");
	String pin = rs1.jsonPath().getString("customerAccount.customers.partyProfile.individualIdentifications.pin");
	String localty = rs1.jsonPath().getString("customerAccount.customers.contactMediums.postalDeliveryAddress.locality").substring(2).split("]")[0];
	String postCode = rs1.jsonPath().getString("customerAccount.customers.contactMediums.postalDeliveryAddress.postCode").substring(2).split("]")[0];
	String delinquencyStatus = rs1.jsonPath().getString("customerAccount.extendedProperties.values[5]");
	String recentActivation = rs1.jsonPath().getString("customerAccount.extendedProperties.values[6]");
	//System.out.println(rs1.getBody().prettyPrint());
	Map<String, String> responseHash = new HashMap<String, String>();
	responseHash.put("accNum", accounNumber);
	responseHash.put("billStatus", billingStatus);
	responseHash.put("custName", customerName);
	responseHash.put("accFinStatus",accounFinancialStatus);
	responseHash.put("region",region);
	responseHash.put("serviceType",serviceType);
	responseHash.put("BoR",BoR);
	responseHash.put("SoR",SoR);
	responseHash.put("newDeviceNotActive",newDeviceNotActive);
	responseHash.put("newCustomer",newCustomer);
	responseHash.put("recentChangeService",recentChangeService);
	responseHash.put("runningBalAmount",runningBalAmount);
	responseHash.put("runningBalUnits",runningBalUnits);
	responseHash.put("lastPaymentDate",lastPaymentDate);
	responseHash.put("faddressline1",faddressline1);
	responseHash.put("localty",localty);
	responseHash.put("postCode",postCode);
	responseHash.put("delinquencyStatus",delinquencyStatus);
	responseHash.put("recentActivation",recentActivation);
	responseHash.put("pin",pin);
	responseHash.put("responseStatus",Integer.toString(rs1.getStatusCode()));
	String xmlresp = rs1.getBody().asString();
	String path = "test-output\\response.txt";
	File fout = new File(path);
	FileOutputStream fos = new FileOutputStream(fout);
	BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
	bw.write("######################");
	bw.write(xmlresp);
	bw.close();
	
	System.out.println(pin);
	

	 return responseHash;
    }

    public static Response postJsonPayload(String phoneNumber, String serType)
	    throws KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException {

	KeyStore keyStore = null;
	SSLConfig config = null;
	String password = "welcome1";

	try {
	    keyStore = KeyStore.getInstance("jks");
	  //  keyStore.load(new FileInputStream("C:\\Users\\npanwar\\Documents\\cert\\esitestharness-tst.jks"),
	    keyStore.load(new FileInputStream("C:\\preesi\\ppe\\perftest-pre-client.shaw.ca.jks"),
		    password.toCharArray());

	} catch (Exception ex) {
	    System.out.println("Error while loading keystore >>>>>>>>>");
	    ex.printStackTrace();
	}

	if (keyStore != null) {

	    @SuppressWarnings("deprecation")
		org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(
		    keyStore, password);

	    // set the config in rest assured
	    config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();

	    RestAssured.config = RestAssured.config().sslConfig(config);
	}
	Map<String, String> reqheaders = new HashMap<String, String>();

	 reqheaders.put("Accept","application/json");
	reqheaders.put("X_SHAW_REQUEST_ACTION", "search");
	reqheaders.put("X_SHAW_ONBEHALFOF_ID", "IVR");
	//String drakeUrl = TestBase.prop.getProperty("DRAKE_URL");
	String esiUrl = " https://devc01app06v.sjrb.ad:13743/service/v1/accounts?phonenumber="+phoneNumber+"&branch=CGY&servicetype="+serType+"&entities=customers,accountFinancialSummary,activations";
	System.out.println(esiUrl);
	return RestAssured.given().contentType(ContentType.JSON).headers(reqheaders)
		.get(esiUrl);
    }

}

