package api;

import io.restassured.RestAssured;
import io.restassured.config.SSLConfig;
import io.restassured.http.ContentType;
import io.restassured.path.xml.XmlPath;
import io.restassured.response.Response;
import pageObjects.BaseUIPage;
import util.ESIDBValidation;
import util.FakeHardwareGeneration;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.StringReader;
import java.security.KeyException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.KeyManagerFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class FESCustomerFind extends BaseUIPage{

  // public static void main(String args[]) throws KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException, ParserConfigurationException, SAXException, IOException {
	     public static Map<String,String> findCustomer(String accountNumber)
	    throws KeyException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException, IOException, ParserConfigurationException, SAXException {
	//String accountNumber = "03700006636";
	Response rs1 = postJsonPayload(accountNumber);
	//String respMsg = rs1.jsonPath().getString("response");
	//System.out.println(rs1.getBody().prettyPrint());
	rs1.getBody().prettyPrint();
//	String orchId = rs1.getHeader("X_shaw_service_orchestration_id"); 
//	System.out.println(rs1.getHeader("X_shaw_service_orchestration_id"));
	String xmlresp = rs1.getBody().asString();
	String path = "test-output\\response.txt";
	File fout = new File(path);
	FileOutputStream fos = new FileOutputStream(fout);
	BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
	System.out.println(xmlresp);
	bw.write(xmlresp);
	bw.close();
	DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
	InputSource src = new InputSource();
	src.setCharacterStream(new StringReader(xmlresp));
	Document doc = builder.parse(src);
	//String dE = doc.getElementsByTagName("find:item").item(2).getTextContent();
//	String aE = doc.getElementsByTagName("find:item").item(1).getTextContent();
	//System.out.println(aE);
//	String tV = doc.getElementsByTagName("find:item").item(3).getTextContent();
	String wcc = doc.getElementsByTagName("find:item").item(9).getTextContent();
	
	Map<String, String> responseHash = new HashMap<String, String>();
	//responseHash.put("accountEligibility", aE);
	//responseHash.put("discountEligibility", dE);
	//responseHash.put("tierValue", tV);
	//responseHash.put("orID",orchId);
	responseHash.put("wcc",wcc);
	String wccFromDb =
		ESIDBValidation.dbextract(accountNumber);
	System.out.println(wccFromDb);
	responseHash.put("wccDb",wccFromDb);
	return responseHash;
    }

    public static Response postJsonPayload(String accountNumber)
	    throws KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException {

	KeyStore keyStore = null;
	SSLConfig config = null;
	String password = "welcome1";

	try {
	    keyStore = KeyStore.getInstance("jks");
	    keyStore.load(new FileInputStream("C:\\Users\\npanwar\\Documents\\cert\\esitestharness-tst.jks"),
		    password.toCharArray());

	} catch (Exception ex) {
	    System.out.println("Error while loading keystore >>>>>>>>>");
	    ex.printStackTrace();
	}

	if (keyStore != null) {

	    org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(
		    keyStore, password);

	    // set the config in rest assured
	    config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();

	    RestAssured.config = RestAssured.config().sslConfig(config);
	}
	Map<String, String> reqheaders = new HashMap<String, String>();

	// reqheaders.put("Cache-Control","no-cache");
	reqheaders.put("X_shaw_onbehalfof_id", "ShawMobile");
	reqheaders.put("X_shaw_original_module_id", "corporate");
	reqheaders.put("X_shaw_request_action", "search");

	String payload = "<Request xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns=\"http://www.shaw.ca/esi/schema/customer/customer_find/v1\">\r\n" + 
		" <Customer>\r\n" + 
		"	<extendedProperties>\r\n" + 
		"		<extendedProperty>\r\n" + 
		"			<name>accountNumber</name>\r\n" + 
		"			<values>\r\n" + 
		"				<item>acnum</item>\r\n" + 
		"			</values>\r\n" + 
		"		</extendedProperty>\r\n" + 
		"		<extendedProperty>\r\n" + 
		"			<name>serviceSiteID</name>\r\n" + 
		"			<values>\r\n" + 
		"				<item></item>\r\n" + 
		"			</values>\r\n" + 
		"		</extendedProperty>\r\n" + 
		"		<extendedProperty>\r\n" + 
		"			<name>firstName</name>\r\n" + 
		"			<values>\r\n" + 
		"				<item></item>\r\n" + 
		"			</values>\r\n" + 
		"		</extendedProperty>\r\n" + 
		"		<extendedProperty>\r\n" + 
		"			<name>lastName</name>\r\n" + 
		"			<values>\r\n" + 
		"				<item>Tester</item>\r\n" + 
		"			</values>\r\n" + 
		"		</extendedProperty>\r\n" + 
		"		<extendedProperty>\r\n" + 
		"			<name>emailAddress</name>\r\n" + 
		"			<values>\r\n" + 
		"				<item></item>\r\n" + 
		"			</values>\r\n" + 
		"		</extendedProperty>\r\n" + 
		"		<extendedProperty>\r\n" + 
		"			<name>phoneNumber</name>\r\n" + 
		"			<values>\r\n" + 
		"				<item></item>\r\n" + 
		"			</values>\r\n" + 
		"		</extendedProperty>\r\n" + 
		"	</extendedProperties>\r\n" + 
		"</Customer>\r\n" + 
		"</Request>";

	String xmlDataAfterMod = payload;
	xmlDataAfterMod = xmlDataAfterMod.replace("acnum", accountNumber);
	String esi_url ="https://tstc01app25v.sjrb.ad:12543/service/sonic/customers/shawmobile"; //TestBase.prop.getProperty("ESI_URL");
	return RestAssured.given().contentType(ContentType.XML).headers(reqheaders).body(xmlDataAfterMod)
		.post(esi_url);//+"/service/sonic/customers/shawmobile");
    }

}
