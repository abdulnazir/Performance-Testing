package api;

import io.restassured.RestAssured;
import io.restassured.config.SSLConfig;
import io.restassured.http.ContentType;
import io.restassured.path.xml.XmlPath;
import io.restassured.response.Response;
import pageObjects.BaseUIPage;
import util.ESIDBValidation;
import util.FakeHardwareGeneration;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.StringReader;
import java.security.KeyException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.KeyManagerFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import apiUtils.BaseAPI;

public class AssociationService extends BaseAPI {

  //public static void main(String args[]) throws KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException, ParserConfigurationException, SAXException, IOException {
	     public static int associate(String accountNumber)
	   throws KeyException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException, IOException, ParserConfigurationException, SAXException {
	//String accountNumber = "03700006609";
		 String partnerServiceAccountNumber = RandomStringUtils.randomAlphabetic(8);
	Response rs1 = postJsonPayload(accountNumber,partnerServiceAccountNumber);
		System.out.println(rs1.getStatusCode());
	
	return rs1.getStatusCode() ;
    }

    public static Response postJsonPayload(String accNumber, String partnerServiceAccountNumber)
	    throws KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException {

	KeyStore keyStore = null;
	SSLConfig config = null;
	String password = "welcome1";

	try {
	    keyStore = KeyStore.getInstance("jks");
	    keyStore.load(new FileInputStream("C:\\Users\\npanwar\\Documents\\cert\\esitestharness-tst.jks"),
		    password.toCharArray());

	} catch (Exception ex) {
	    System.out.println("Error while loading keystore >>>>>>>>>");
	    ex.printStackTrace();
	}

	if (keyStore != null) {

	    org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(
		    keyStore, password);

	    // set the config in rest assured
	    config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();

	    RestAssured.config = RestAssured.config().sslConfig(config);
	}
	Map<String, String> reqheaders = new HashMap<String, String>();
	reqheaders.put("X_shaw_onbehalfof_id", "ShawMobile");
	reqheaders.put("X_shaw_original_module_id", "Corporate");
	reqheaders.put("X_shaw_request_action", "associate");


	String payload = "<Request xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"\r\n" + 
		"         xmlns=\"http://www.shaw.ca/esi/schema/customer/customeraccountassociation_create/v1\">\r\n" + 
		"	<CustomerAccountAssociation>\r\n" + 
		"		<extendedProperties>\r\n" + 
		"			<extendedProperty>\r\n" + 
		"				<name>accountNumber</name>\r\n" + 
		"				<values>\r\n" + 
		"					<item>acnum</item>\r\n" + 
		"				</values>\r\n" + 
		"			</extendedProperty>\r\n" + 
		"			<extendedProperty>\r\n" + 
		"				<name>partnerServiceAccountNumber</name>\r\n" + 
		"				<values>\r\n" + 
		"					<item>psaid</item>\r\n" + 
		"				</values>\r\n" + 
		"			</extendedProperty>\r\n" + 
		"			<extendedProperty>\r\n" + 
		"				<name>agentId</name>\r\n" + 
		"				<values>\r\n" + 
		"					<item>1212</item>\r\n" + 
		"				</values>\r\n" + 
		"			</extendedProperty>\r\n" + 
		"			<extendedProperty>\r\n" + 
		"				<name>storeLocationid</name>\r\n" + 
		"				<values>\r\n" + 
		"					<item>31</item>\r\n" + 
		"				</values>\r\n" + 
		"			</extendedProperty>\r\n" + 
		"			<extendedProperty>\r\n" + 
		"				<name>accountSubType</name>\r\n" + 
		"				<values>\r\n" + 
		"					<item>ShawMobile</item>\r\n" + 
		"				</values>\r\n" + 
		"			</extendedProperty>\r\n" + 
		"			<extendedProperty>\r\n" + 
		"				<name>associationAuthenticationStatus</name>\r\n" + 
		"				<values>\r\n" + 
		"					<item>Immediate-Associate</item>\r\n" + 
		"				</values>\r\n" + 
		"			</extendedProperty>\r\n" + 
		"			<extendedProperty>\r\n" + 
		"				<name>partnerCustomerNodeid</name>\r\n" + 
		"				<values>\r\n" + 
		"					<item>YYC73471</item>\r\n" + 
		"				</values>\r\n" + 
		"			</extendedProperty>\r\n" + 
		"			<extendedProperty>\r\n" + 
		"				<name>billCycleDate</name>\r\n" + 
		"				<values>\r\n" + 
		"					<item>3</item>\r\n" + 
		"				</values>\r\n" + 
		"			</extendedProperty>\r\n" + 
		"			<extendedProperty>\r\n" + 
		"				<name>discountStatus</name>\r\n" + 
		"				<values>\r\n" + 
		"					<item>Y</item>\r\n" + 
		"				</values>\r\n" + 
		"			</extendedProperty>\r\n" + 
		"		</extendedProperties>\r\n" + 
		"	</CustomerAccountAssociation>\r\n" + 
		"</Request>";

	String xmlDataAfterMod = payload;
	xmlDataAfterMod = xmlDataAfterMod.replace("acnum", accNumber);
	xmlDataAfterMod = xmlDataAfterMod.replace("psaid",partnerServiceAccountNumber);
	String esi_url ="https://tstc01app22v.sjrb.ad:12243/service/v1/accounts/shawmobile/association";
	return RestAssured.given().contentType(ContentType.XML).headers(reqheaders).body(xmlDataAfterMod)
		.post(esi_url);//+"/service/sonic/customers/shawmobile");
    }

}
