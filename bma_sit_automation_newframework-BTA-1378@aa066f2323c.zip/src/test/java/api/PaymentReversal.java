package api;

import com.github.markusbernhardt.proxy.ProxySearch;
import com.github.markusbernhardt.proxy.selector.fixed.FixedProxySelector;

import pageObjects.BaseUIPage;
import util.*;

import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthSchemeProvider;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.Credentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.AuthSchemes;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.auth.SPNegoSchemeFactory;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.DefaultProxyRoutePlanner;
import org.apache.http.util.EntityUtils;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import java.io.IOException;
import java.io.StringReader;
import java.net.ProxySelector;
import java.security.Principal;
import java.security.Security;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

/**
 * 
 * Notes: - You need to have valid /etc/krb5.conf in place - Make sure to change
 * principal in login.conf - Set proper username/password in
 * KerberosCallbackHandler
 *
 * @see KerberosCallBackHandler
 */
public class PaymentReversal extends BaseUIPage {

    private static final String PROXY_HOST = "LocalHost";
    private static final int PROXY_PORT = 8888;

    @SuppressWarnings("deprecation")
	public static int callServer(String url, String paymentId) throws IOException, SAXException, ParserConfigurationException {
	HttpClient httpclient = getHttpClient();

	try {

	    String body = "<reversal xmlns=\"http://services.shaw.ad/billing\">\r\n" + 
	    	"  <payment_reversal paymentId=\"reversalpaymentid\" reasonCode=\"2013\" />\r\n" + 
	    	"</reversal>";
	    String payload = body;
	    payload = payload.replace("reversalpaymentid", paymentId);
	    HttpPost httpPost = new HttpPost(url);
	    httpPost.setEntity(new StringEntity(payload));
	    httpPost.setHeader("X_SHAW_TRANSACTION_ID", "Shaw Trial");
	    httpPost.setHeader("X_SHAW_ORIGINATING_IP_ADDRESS", "Shaw Trial");
	    httpPost.setHeader("X_SHAW_ORIGINATING_HOST_NAME", "CGL108305");
	    httpPost.setHeader("X_SHAW_ORIGINAL_MODULE_ID", "Shaw Trial");
	    httpPost.setHeader("Content-Type", "application/vnd.shaw.billing+xml");
	    httpPost.setHeader("X_SHAW_ORIGINATING_USER_ID", "SJRB\\lruser003");
	   // httpPost.setHeader("X_SHAW_PAYMENT_CHANNEL", "6");
	   // httpPost.setHeader("X_SHAW_PAYMENT_LOCATION", "81");
	    HttpResponse response = httpclient.execute(httpPost);
	    HttpEntity entity = response.getEntity();

	    return response.getStatusLine().getStatusCode();

	} finally {
	    httpclient.getConnectionManager().shutdown();
	}

    }

    private static HttpClient getHttpClient() {

	Credentials use_jaas_creds = new Credentials() {
	    public String getPassword() {
		return null;
	    }

	    public Principal getUserPrincipal() {
		return null;
	    }
	};

	CredentialsProvider credsProvider = new BasicCredentialsProvider();
	credsProvider.setCredentials(new AuthScope(null, -1, null), use_jaas_creds);
	Registry<AuthSchemeProvider> authSchemeRegistry = RegistryBuilder.<AuthSchemeProvider>create()
		.register(AuthSchemes.SPNEGO, new SPNegoSchemeFactory(true)).build();
	CloseableHttpClient httpclient = HttpClients.custom()
		.setRoutePlanner(new DefaultProxyRoutePlanner(new HttpHost(PROXY_HOST, PROXY_PORT)))
		.setDefaultAuthSchemeRegistry(authSchemeRegistry).setDefaultCredentialsProvider(credsProvider).build();

	return httpclient;
    }

    public static void autoconfigureProxy() {
	final ProxySearch proxySearch = new ProxySearch();
	proxySearch.addStrategy(ProxySearch.Strategy.OS_DEFAULT);
	proxySearch.addStrategy(ProxySearch.Strategy.JAVA);
	proxySearch.addStrategy(ProxySearch.Strategy.ENV_VAR);
	ProxySelector.setDefault(new FixedProxySelector(PROXY_HOST, PROXY_PORT));
    }

  //  public static void main(String args[]) throws IOException, SAXException, ParserConfigurationException {
    public static int paymentReversal(String accountNumber) throws IOException, SAXException, ParserConfigurationException {
	System.setProperty("java.security.krb5.conf", "src\\test\\resources\\etc\\krb5.conf");
	System.setProperty("java.security.auth.login.config", "src\\test\\resources\\etc\\login.conf");
	System.setProperty("javax.security.auth.useSubjectCredsOnly", "false");
	System.setProperty("sun.security.krb5.debug", "true");
	System.setProperty("sun.security.jgss.debug", "true");
	Security.setProperty("auth.login.defaultCallbackHandler",
		"net.curiousprogrammer.auth.kerberos.example.KerberosCallBackHandler");
	Map<String, String> valueString = new HashMap<String, String>();
	autoconfigureProxy();
        String billingHost = prop.getProperty("BillingHost");
        String baseUrl = billingHost+"/billingservice/account/";
	String url = baseUrl+accountNumber+"/reversal";
	//String url = "http://pre-wsv-billingservice.sjrb.ad/billingservice/account/08800097332/reversal";
	//String accountNumber = "08800097332";
        String paymentId = PaymentHistory.getPaymentId(accountNumber);
	int reversalStatus=callServer(url,paymentId);
	 return reversalStatus;
    }

}
