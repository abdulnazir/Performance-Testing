package api;

import io.restassured.RestAssured;
import io.restassured.config.SSLConfig;
import io.restassured.http.ContentType;
import io.restassured.path.xml.XmlPath;
import io.restassured.response.Response;
import pageObjects.BaseUIPage;
import util.ESIDBValidation;
import util.FakeHardwareGeneration;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.StringReader;
import java.security.KeyException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.KeyManagerFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class DrakeApiDeviceActivation extends BaseUIPage {

 // public static void main(String args[]) throws KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException, ParserConfigurationException, SAXException, IOException {
	     public static int findCustomer(String altId, String macAddress)
	   throws KeyException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException, IOException, ParserConfigurationException, SAXException {
	
	Response rs1 = postJsonPayload(altId,macAddress);
		//Response rs1 = postJsonPayload("ySm54xzqXVlPfANBLgTY","181009A02702");
		
	//String respMsg = rs1.jsonPath().getString("response");
	System.out.println(altId);
	System.out.println(macAddress);
		System.out.println(rs1.getStatusCode());
	rs1.getBody().prettyPrint();
	
	//String orchId = rs1.getHeader("X_SHAW_REQUEST_TRACING"); 
	System.out.println(rs1.getHeaders());
	//System.out.println(rs1.getHeader("X_SHAW_REQUEST_TRACING"));
	//addInfoInReport("X_SHAW_REQUEST_TRACING" + orchId);
	String xmlresp = rs1.getBody().asString();
	String path = "test-output\\response.txt";
	File fout = new File(path);
	FileOutputStream fos = new FileOutputStream(fout);
	BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
	System.out.println(xmlresp);
	bw.write(xmlresp);
	bw.close();
	//DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
	//InputSource src = new InputSource();
	//src.setCharacterStream(new StringReader(xmlresp));
	//Document doc = builder.parse(src);
//	String dE = doc.getElementsByTagName("find:item").item(2).getTextContent();
//	String aE = doc.getElementsByTagName("find:item").item(1).getTextContent();
//	System.out.println(aE);
//	String tV = doc.getElementsByTagName("find:item").item(3).getTextContent();;
//	
	
	return rs1.getStatusCode() ;
    }

    public static Response postJsonPayload(String altId, String macAddress)
	    throws KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException {

	KeyStore keyStore = null;
	SSLConfig config = null;
	String password = "welcome1";

	try {
	    keyStore = KeyStore.getInstance("jks");
	    keyStore.load(new FileInputStream("C:\\Users\\npanwar\\Documents\\cert\\esitestharness-tst.jks"),
		    password.toCharArray());

	} catch (Exception ex) {
	    System.out.println("Error while loading keystore >>>>>>>>>");
	    ex.printStackTrace();
	}

	if (keyStore != null) {

	    org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(
		    keyStore, password);

	    // set the config in rest assured
	    config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();

	    RestAssured.config = RestAssured.config().sslConfig(config);
	}
	Map<String, String> reqheaders = new HashMap<String, String>();



	String payload = "{\r\n" + 
		"   \"sessionId\" : \"4d13bb46-68d9-44a4-841a-20b85df5dwall\"\r\n" + 
		"}";

	
	String esi_url ="https://tstc01app25v.sjrb.ad:12543/service/rpilfs/accounts/"+altId+"/devices/"+macAddress+"/xfi/activation/activate"; //TestBase.prop.getProperty("ESI_URL");
	return RestAssured.given().contentType(ContentType.JSON).headers(reqheaders).body(payload)
		.post(esi_url);//+"/service/sonic/customers/shawmobile");
    }

}