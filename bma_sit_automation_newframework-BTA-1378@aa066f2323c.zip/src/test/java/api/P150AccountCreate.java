package api;

import io.restassured.RestAssured;
import io.restassured.config.SSLConfig;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import pageObjects.BaseUIPage;
import util.*;

import static io.restassured.RestAssured.given;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.security.KeyException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.KeyManagerFactory;

import org.apache.commons.lang.RandomStringUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class P150AccountCreate extends BaseUIPage {
	private WebDriver driver;
	TestUtil utils;
	
	public P150AccountCreate(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

  //  public static void main(String args[])
    public static String createP150Account(String serial)
	    throws KeyException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException, IOException {
	
	  // String serialNum = "M109M000QC70000";
	   String account = RandomStringUtils.randomAlphabetic(8);
	    Response rs = postJsonPayload(serial,account);
	    System.out.println(rs.getBody().prettyPrint());
	    String accountNumber = rs.xmlPath().getString("//v11:id/text()");
	    String a = accountNumber.substring(accountNumber.length()-11);
	    System.out.println("account number : "+a);
	  
	return a;
    }

    public static Response postJsonPayload(String serialNum, String accountN)
    	    throws KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException {

    	KeyStore keyStore = null;
    	SSLConfig config = null;
    	String password = "ESISupport1!";

    	try {
    	    keyStore = KeyStore.getInstance("jks");
    	    keyStore.load(new FileInputStream("C:\\Users\\shota\\certf\\esitestharness-tst.jks"),
    		    password.toCharArray());
    	} catch (Exception ex) {
    	    System.out.println("Error while loading keystore >>>>>>>>>");
    	    ex.printStackTrace();
    	}

    	if (keyStore != null) {

    	    @SuppressWarnings("deprecation")
			org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(
    		    keyStore, password);

    	    // set the config in rest assured
    	    config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();

    	    RestAssured.config = RestAssured.config().sslConfig(config);
    	}
    	Map<String, String> reqheaders = new HashMap<String, String>();

    	// reqheaders.put("Cache-Control","no-cache");
    	reqheaders.put("X_SHAW_TRANSACTION_ID", "fgfdfsfsssr");
    	reqheaders.put("X_SHAW_ONBEHALFOF_ID", "Freedom"); 

    	String payload = "<Request\r\n" + 
    		"    xmlns=\"http://www.shaw.ca/esi/schema/customer/fes_productorder_submit/v1\">\r\n" + 
    		"    <customerAccount>\r\n" + 
    		"        <status>Pending</status>\r\n" + 
    		"        <accountClassification>Residential</accountClassification>\r\n" + 
    		"        <partnerAccount>\r\n" + 
    		"            <accountProperties>\r\n" + 
    		"                <accountNumber>ranaccnum</accountNumber>\r\n" + 
    		"            </accountProperties>\r\n" + 
    		"            <products>\r\n" + 
    		"                <product>\r\n" + 
    		"                    <service>\r\n" + 
    		"                        <id>65756858</id>\r\n" + 
    		"                    </service>\r\n" + 
    		"                </product>\r\n" + 
    		"            </products>\r\n" + 
    		"        </partnerAccount>\r\n" + 
    		"    </customerAccount>\r\n" + 
    		"    <searchCriteria>\r\n" + 
    		"        <serviceSite>\r\n" + 
    		"            <id>20017</id>\r\n" + 
    		"        </serviceSite>\r\n" + 
    		"    </searchCriteria>\r\n" + 
    		"    <customerProfile>\r\n" + 
    		"        <individualSummary>\r\n" + 
    		"            <individualName>\r\n" + 
    		"                <firstName>Test</firstName>\r\n" + 
    		"                <lastName>Test</lastName>\r\n" + 
    		"            </individualName>\r\n" + 
    		"            <individualIdentifications>\r\n" + 
    		"                <userCredential>\r\n" + 
    		"                    <pin>1855581</pin>\r\n" + 
    		"                    <hint>2665414</hint>\r\n" + 
    		"                </userCredential>\r\n" + 
    		"            </individualIdentifications>\r\n" + 
    		"           <contactMediums>\r\n" + 
    		"                <postalContact>\r\n" + 
    		"                    <type>Shipping</type>\r\n" + 
    		"                    <postalDeliveryAddress>\r\n" + 
    		"                        <formattedPostalDeliveryAddress>\r\n" + 
    		"                            <formattedAddressLine1>94 SIGNATURE HTS</formattedAddressLine1>\r\n" + 
    		"                            <formattedAddressLine2>SW</formattedAddressLine2>\r\n" + 
    		"                            <city>CALGARY</city>\r\n" + 
    		"                            <stateOrProvince>AB</stateOrProvince>\r\n" + 
    		"                            <postCode>T3H3B9</postCode>\r\n" + 
    		"                        </formattedPostalDeliveryAddress>\r\n" + 
    		"                    </postalDeliveryAddress>\r\n" + 
    		"                </postalContact>\r\n" + 
    		"                <postalContact>\r\n" + 
    		"                    <type>Billing</type>\r\n" + 
    		"                    <postalDeliveryAddress>\r\n" + 
    		"                        <id>20017</id>\r\n" + 
    		"                    </postalDeliveryAddress>\r\n" + 
    		"                </postalContact>\r\n" + 
    		"                <emailContact>\r\n" + 
    		"                    <emailAddress>nishu.panwar@sjrb.ca</emailAddress>\r\n" + 
    		"                    <emailClassification>eBill</emailClassification>\r\n" + 
    		"                </emailContact>\r\n" + 
    		"                <emailContact>\r\n" + 
    		"                    <emailAddress>nishu.panwar@sjrb.ca</emailAddress>\r\n" + 
    		"                    <emailClassification>Shipping</emailClassification>\r\n" + 
    		"                </emailContact>\r\n" + 
    		"                <emailContact>\r\n" + 
    		"                    <emailAddress>nishu.panwar@sjrb.ca</emailAddress>\r\n" + 
    		"                    <emailClassification>GeneralContact</emailClassification>\r\n" + 
    		"                </emailContact>\r\n" + 
    		"                <phoneContact>\r\n" + 
    		"                    <isPreferred>true</isPreferred>\r\n" + 
    		"                    <type>Home</type>\r\n" + 
    		"                    <phone>4031623671</phone>\r\n" + 
    		"                </phoneContact>\r\n" + 
    		"            </contactMediums>\r\n" + 
    		"        </individualSummary>\r\n" + 
    		"    </customerProfile>\r\n" + 
    		"    <productOrder>\r\n" + 
    		"        <customerOrderItems>\r\n" + 
    		"            <customerOrderItem>\r\n" + 
    		"                <product>\r\n" + 
    		"                    <id>9155153509313212081</id>\r\n" + 
    		"                    <productName>P150 Internet</productName>\r\n" + 
    		"                     <productCharacteristics>\r\n" + 
    		"                        <characteristic>\r\n" + 
    		"                            <characteristicName>Quantity</characteristicName>\r\n" + 
    		"                            <maxCardinality>1</maxCardinality>\r\n" + 
    		"                        </characteristic>\r\n" + 
    		"                    </productCharacteristics>\r\n" + 
    		"                    <productSpecification>\r\n" + 
    		"                        <lineOfBusiness>\r\n" + 
    		"                            <name>HighSpeedData</name>\r\n" + 
    		"                        </lineOfBusiness>\r\n" + 
    		"                    </productSpecification>\r\n" + 
    		"                </product>\r\n" + 
    		"                <product>\r\n" + 
    		"                    <id>9147984470013220650</id>\r\n" + 
    		"                    <!--Converged Hardware-->\r\n" + 
    		"                    <productCharacteristics>\r\n" + 
    		"                        <characteristic>\r\n" + 
    		"                            <characteristicName>Quantity</characteristicName>\r\n" + 
    		"                            <maxCardinality>1</maxCardinality>\r\n" + 
    		"                        </characteristic>\r\n" + 
    		"                    </productCharacteristics>\r\n" + 
    		"                    <bundledProducts>\r\n" + 
    		"                        <product>\r\n" + 
    		"                            <id>9147984470013220653</id>\r\n" + 
    		"                            <!--Hardware-->\r\n" + 
    		"                            <productCharacteristics>\r\n" + 
    		"                                <characteristic>\r\n" + 
    		"                                    <characteristicName>Quantity</characteristicName>\r\n" + 
    		"                                    <maxCardinality>1</maxCardinality>\r\n" + 
    		"                                </characteristic>\r\n" + 
    		"                            </productCharacteristics>\r\n" + 
    		"                            <bundledProducts>\r\n" + 
    		"                                <product>\r\n" + 
    		"                                    <id>9155413069013364419</id>\r\n" + 
    		"                                    <!--XB6 DOCSIS 3.1 WiFi Modem-->\r\n" + 
    		"                                    <productCharacteristics>\r\n" + 
    		"                                        <characteristic>\r\n" + 
    		"                                            <characteristicName>Quantity</characteristicName>\r\n" + 
    		"                                            <maxCardinality>1</maxCardinality>\r\n" + 
    		"                                        </characteristic>\r\n" + 
    		"                                    </productCharacteristics>\r\n" + 
    		"                                    <bundledProducts>\r\n" + 
    		"                                        <product>\r\n" + 
    		"                                            <id>9155413069013364421</id>\r\n" + 
    		"                                            <!--Rental XB6 DOCSIS 3.1 WiFi Modem-->\r\n" + 
    		"                                            <productType>Equipment</productType>\r\n" + 
    		"                                            <productSerialNumber>snum</productSerialNumber>\r\n" + 
    		"                                            <productCharacteristics>\r\n" + 
    		"                                                <characteristic>\r\n" + 
    		"                                                    <characteristicName>Quantity</characteristicName>\r\n" + 
    		"                                                    <maxCardinality>1</maxCardinality>\r\n" + 
    		"                                                </characteristic>\r\n" + 
    		"                                            </productCharacteristics>\r\n" + 
    		"                                            <bundledProducts>\r\n" + 
    		"                                                <product>\r\n" + 
    		"                                                    <id>9155413069013364426</id>\r\n" + 
    		"                                                    <!--Internet Service-->\r\n" + 
    		"                                                    <productCharacteristics>\r\n" + 
    		"                                                        <characteristic>\r\n" + 
    		"                                                            <characteristicName>Quantity</characteristicName>\r\n" + 
    		"                                                            <maxCardinality>1</maxCardinality>\r\n" + 
    		"                                                        </characteristic>\r\n" + 
    		"                                                    </productCharacteristics>\r\n" + 
    		"                                                </product>\r\n" + 
    		"                                            </bundledProducts>\r\n" + 
    		"                                        </product>\r\n" + 
    		"                                    </bundledProducts>\r\n" + 
    		"                                </product>\r\n" + 
    		"                            </bundledProducts>\r\n" + 
    		"                        </product>\r\n" + 
    		"                    </bundledProducts>\r\n" + 
    		"                </product>\r\n" + 
    		"            </customerOrderItem>\r\n" + 
    		"        </customerOrderItems>\r\n" + 
    		"        <salesProperties>\r\n" + 
    		"            <salesSource>Freedom</salesSource>\r\n" + 
    		"            <salesSourceId>230865</salesSourceId>\r\n" + 
    		"        </salesProperties>\r\n" + 
    		"    </productOrder>\r\n" + 
    		"    <genericCustomerFacingService>\r\n" + 
    		"        <startMode>Manually By Customer</startMode>\r\n" + 
    		"        <serviceCharacteristics>\r\n" + 
    		"            <specificationCharacteristic>\r\n" + 
    		"                <characteristicName>InstallationFee</characteristicName>\r\n" + 
    		"                <characteristicValue>\r\n" + 
    		"                    <value>0.0</value>\r\n" + 
    		"                </characteristicValue>\r\n" + 
    		"            </specificationCharacteristic>\r\n" + 
    		"        </serviceCharacteristics>\r\n" + 
    		"    </genericCustomerFacingService>\r\n" + 
    		"</Request>";
    	
    	String xmlDataAfterMod = payload;
    	xmlDataAfterMod = xmlDataAfterMod.replace("snum", serialNum);
    	xmlDataAfterMod = xmlDataAfterMod.replace("ranaccnum", accountN);
    	String esi_url = configprop.getProperty("ESI_URL");

    	return RestAssured.given().contentType(ContentType.XML).headers(reqheaders).body(xmlDataAfterMod)
    		.post(esi_url+"/service/v1/productorders");
    	
        }
    
    

   
}
