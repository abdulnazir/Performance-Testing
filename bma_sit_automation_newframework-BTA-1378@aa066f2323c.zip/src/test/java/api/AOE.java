package api;

import io.restassured.RestAssured;
import io.restassured.config.SSLConfig;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import pageObjects.BaseUIPage;
import util.*;

import static io.restassured.RestAssured.given;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.security.KeyException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.KeyManagerFactory;

import org.apache.commons.lang.RandomStringUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import apiUtils.BaseAPI;

public class AOE extends  BaseAPI {
	private WebDriver driver;
	TestUtil utils;
	
	public AOE(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
    //public static void main(String args[]) throws KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException {
    public static String createAOEAccount()
	    throws KeyException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException, IOException {
	
	 
	   String account = RandomStringUtils.randomAlphabetic(8);
	    Response rs = postJsonPayload();
	    System.out.println(rs.getStatusCode());
	    System.out.println(rs.headers());
	    String path = "test-output\\response.txt";
		File fout = new File(path);
		FileOutputStream fos = new FileOutputStream(fout);
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		bw.write(rs.getBody().prettyPrint());
		bw.close();
	    String accountNumber = rs.xmlPath().getString("//v11:id/text()");
	    String a = accountNumber.substring(accountNumber.length()-11);
	   System.out.println("account number : "+a);
	  
	return a;
    }

    public static Response postJsonPayload()
	    throws KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException {

	KeyStore keyStore = null;
	SSLConfig config = null;
	String password = "welcome1";

	try {
	    keyStore = KeyStore.getInstance("jks");
	    keyStore.load(new FileInputStream("C:\\Users\\shota\\certf\\esitestharness-tst.jks"),
		    password.toCharArray());

	} catch (Exception ex) {
	    System.out.println("Error while loading keystore >>>>>>>>>");
	    ex.printStackTrace();
	}

	if (keyStore != null) {

	    org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(
		    keyStore, password);

	    // set the config in rest assured
	    config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();

	    RestAssured.config = RestAssured.config().sslConfig(config);
	}
	Map<String, String> reqheaders = new HashMap<String, String>();

	// reqheaders.put("Cache-Control","no-cache");
	reqheaders.put("X_SHAW_TRANSACTION_ID", "abc_ttttss");
	reqheaders.put("X_SHAW_ONBEHALFOF_ID", "Digital-DSL"); 

	String payload = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n" + 
		"<!--rest Endpoint - https://tstc01app23v.sjrb.ad:12343//service/productorder/submit/v1-->\r\n" + 
		"<Request xmlns=\"http://www.shaw.ca/esi/schema/customer/fes_productorder_submit/v1\">\r\n" + 
		"   <customerAccount>\r\n" + 
		"      <status>Pending</status>\r\n" + 
		"      <accountClassification>Residential</accountClassification>\r\n" + 
		"   </customerAccount>\r\n" + 
		"   <searchCriteria>\r\n" + 
		"      <serviceSite>\r\n" + 
		"         <id>226459</id>\r\n" + 
		"      </serviceSite>\r\n" + 
		"   </searchCriteria>\r\n" + 
		"   <customerProfile>\r\n" + 
		"      <individualSummary>\r\n" + 
		"         <individualName>\r\n" + 
		"            <firstName>Dwfsffsdfefw</firstName>\r\n" + 
		"            <lastName>Rfdfsdffsf</lastName>\r\n" + 
		"         </individualName>\r\n" + 
		"         <individualIdentifications>\r\n" + 
		"            <userCredential>\r\n" + 
		"               <pin>183431</pin>\r\n" + 
		"               <hint>2334534</hint>\r\n" + 
		"            </userCredential>\r\n" + 
		"         </individualIdentifications>\r\n" + 
		"         <contactMediums>\r\n" + 
		"            <postalContact>\r\n" + 
		"               <type>Shipping</type>\r\n" + 
		"               <postalDeliveryAddress>\r\n" + 
		"                  <formattedPostalDeliveryAddress>\r\n" + 
		"                     <formattedAddressLine1>400 TARACOVE ESTATE DR</formattedAddressLine1>\r\n" + 
		"                     <formattedAddressLine2>NE</formattedAddressLine2>\r\n" + 
		"                     <city>Calgary</city>\r\n" + 
		"                     <stateOrProvince>Alberta</stateOrProvince>\r\n" + 
		"                     <postCode>T3J4S8</postCode>\r\n" + 
		"                  </formattedPostalDeliveryAddress>\r\n" + 
		"               </postalDeliveryAddress>\r\n" + 
		"            </postalContact>\r\n" + 
		"            <postalContact>\r\n" + 
		"               <type>Billing</type>\r\n" + 
		"               <postalDeliveryAddress>\r\n" + 
		"                  <id>226459</id>\r\n" + 
		"               </postalDeliveryAddress>\r\n" + 
		"            </postalContact>\r\n" + 
		"            <emailContact>\r\n" + 
		"               <emailAddress>ahmedullah.sharif@sjrb.ca</emailAddress>\r\n" + 
		"               <emailClassification>eBill</emailClassification>\r\n" + 
		"            </emailContact>\r\n" + 
		"            <emailContact>\r\n" + 
		"               <emailAddress>ahmedullah.sharif@sjrb.ca</emailAddress>\r\n" + 
		"               <emailClassification>Shipping</emailClassification>\r\n" + 
		"            </emailContact>\r\n" + 
		"			<emailContact>\r\n" + 
		"                    <emailAddress>ahmedullah.sharif@sjrb.ca</emailAddress>\r\n" + 
		"                    <emailClassification>GeneralContact</emailClassification>\r\n" + 
		"                </emailContact>\r\n" + 
		"            <phoneContact>\r\n" + 
		"               <isPreferred>true</isPreferred>\r\n" + 
		"               <type>Home</type>\r\n" + 
		"               <phone>4089764562</phone>\r\n" + 
		"            </phoneContact>\r\n" + 
		"         </contactMediums>\r\n" + 
		"      </individualSummary>\r\n" + 
		"   </customerProfile>\r\n" + 
		"   <productOrder>\r\n" + 
		"   <methodOfConfirmation>Email</methodOfConfirmation>\r\n" + 
		"       <acceptanceId>ahmedullah.sharif@sjrb.ca</acceptanceId>\r\n" + 
		"      <preferredDeliveryMethod>Send through Mail</preferredDeliveryMethod>\r\n" + 
		"      <customerOrderItems>\r\n" + 
		"         <customerOrderItem>\r\n" + 
		"            <product>\r\n" + 
		"               <id>9159387974413885668</id>\r\n" + 
		"               <productName>Internet 600 Unlimited</productName>\r\n" + 
		"               <productType>Equipment</productType>\r\n" + 
		"               <productSerialNumber />\r\n" + 
		"               <productCharacteristics>\r\n" + 
		"                  <characteristic>\r\n" + 
		"                     <characteristicName>Quantity</characteristicName>\r\n" + 
		"                     <maxCardinality>1</maxCardinality>\r\n" + 
		"                  </characteristic>\r\n" + 
		"               </productCharacteristics>\r\n" + 
		"               <productSpecification>\r\n" + 
		"                  <lineOfBusiness>\r\n" + 
		"                     <name>HighSpeedData</name>\r\n" + 
		"                  </lineOfBusiness>\r\n" + 
		"               </productSpecification>\r\n" + 
		"               <bundledProducts>\r\n" + 
		"                  <product>\r\n" + 
		"                     <id>9131174626013213130</id>\r\n" + 
		"                     <!--Hardware-->\r\n" + 
		"                     <productCharacteristics>\r\n" + 
		"                        <characteristic>\r\n" + 
		"                           <characteristicName>Quantity</characteristicName>\r\n" + 
		"                           <maxCardinality>1</maxCardinality>\r\n" + 
		"                        </characteristic>\r\n" + 
		"                     </productCharacteristics>\r\n" + 
		"                     <discount>\r\n" + 
		"                        <discountProdPriceAlteration>\r\n" + 
		"                           <id>9150496191113780932</id>\r\n" + 
		"                           <!-- modem discount-->\r\n" + 
		"                        </discountProdPriceAlteration>\r\n" + 
		"                     </discount>\r\n" + 
		"                  </product>\r\n" + 
		"                  <product>\r\n" + 
		"                     <id>9150472693413764542</id>\r\n" + 
		"                     <!--valueplan-->\r\n" + 
		"                     <productCharacteristics>\r\n" + 
		"                        <characteristic>\r\n" + 
		"                           <characteristicName>Quantity</characteristicName>\r\n" + 
		"                           <maxCardinality>1</maxCardinality>\r\n" + 
		"                        </characteristic>\r\n" + 
		"                     </productCharacteristics>\r\n" + 
		"                     <discount>\r\n" + 
		"                        <discountProdPriceAlteration>\r\n" + 
		"                           <id>9150496625313780945</id>\r\n" + 
		"                           <!--2yvp Agreement-->\r\n" + 
		"                           </discountProdPriceAlteration>\r\n" + 
		"						       <customerAgreement>\r\n" + 
		"                           <description>Internet</description>\r\n" + 
		"                           <agreementApprovals>\r\n" + 
		"                              <agreementApproval>\r\n" + 
		"                                 <id>ahmedullah.sharif@sjrb.ca</id>\r\n" + 
		"                                 <approvalMethod>Email</approvalMethod>\r\n" + 
		"                              </agreementApproval>\r\n" + 
		"                           </agreementApprovals>\r\n" + 
		"                        </customerAgreement>\r\n" + 
		"						\r\n" + 
		"                     </discount>\r\n" + 
		"					 \r\n" + 
		"                  </product>\r\n" + 
		"				  <product>\r\n" + 
		"                     <id>9159387974413885676</id>\r\n" + 
		"                     <!--valueplan-->\r\n" + 
		"                     <productCharacteristics>\r\n" + 
		"                        <characteristic>\r\n" + 
		"                           <characteristicName>Quantity</characteristicName>\r\n" + 
		"                           <maxCardinality>1</maxCardinality>\r\n" + 
		"                        </characteristic>\r\n" + 
		"                     </productCharacteristics>                     			 \r\n" + 
		"                 </product>\r\n" + 
		"               </bundledProducts>\r\n" + 
		"            </product>\r\n" + 
		"            <product>\r\n" + 
		"               <id>9147984470013220650</id>\r\n" + 
		"               <!--Converged Hardware-->\r\n" + 
		"               <productCharacteristics>\r\n" + 
		"                  <characteristic>\r\n" + 
		"                     <characteristicName>Quantity</characteristicName>\r\n" + 
		"                     <maxCardinality>1</maxCardinality>\r\n" + 
		"                  </characteristic>\r\n" + 
		"               </productCharacteristics>\r\n" + 
		"               <bundledProducts>\r\n" + 
		"                  <product>\r\n" + 
		"                     <id>9147984470013220653</id>\r\n" + 
		"                     <!--Hardware-->\r\n" + 
		"                     <productCharacteristics>\r\n" + 
		"                        <characteristic>\r\n" + 
		"                           <characteristicName>Quantity</characteristicName>\r\n" + 
		"                           <maxCardinality>1</maxCardinality>\r\n" + 
		"                        </characteristic>\r\n" + 
		"                     </productCharacteristics>\r\n" + 
		"                     <bundledProducts>\r\n" + 
		"                        <product>\r\n" + 
		"                           <id>9147984470013220655</id>\r\n" + 
		"                           <!--XB6 DOCSIS 3.1 WiFi Modem-->\r\n" + 
		"                           <productCharacteristics>\r\n" + 
		"                              <characteristic>\r\n" + 
		"                                 <characteristicName>Quantity</characteristicName>\r\n" + 
		"                                 <maxCardinality>1</maxCardinality>\r\n" + 
		"                              </characteristic>\r\n" + 
		"                           </productCharacteristics>\r\n" + 
		"                           <bundledProducts>\r\n" + 
		"                              <product>\r\n" + 
		"                                 <id>9147984470013220657</id>\r\n" + 
		"                                 <!--Rental XB6 DOCSIS 3.1 WiFi Modem-->\r\n" + 
		"                                 <productCharacteristics>\r\n" + 
		"                                    <characteristic>\r\n" + 
		"                                       <characteristicName>Quantity</characteristicName>\r\n" + 
		"                                       <maxCardinality>1</maxCardinality>\r\n" + 
		"                                    </characteristic>\r\n" + 
		"                                 </productCharacteristics>\r\n" + 
		"                                 <bundledProducts>\r\n" + 
		"                                    <product>\r\n" + 
		"                                       <id>9147984470013220661</id>\r\n" + 
		"                                       <!--Internet Service-->\r\n" + 
		"                                       <productCharacteristics>\r\n" + 
		"                                          <characteristic>\r\n" + 
		"                                             <characteristicName>Quantity</characteristicName>\r\n" + 
		"                                             <maxCardinality>1</maxCardinality>\r\n" + 
		"                                          </characteristic>\r\n" + 
		"                                       </productCharacteristics>\r\n" + 
		"                                    </product>\r\n" + 
		"                                 </bundledProducts>\r\n" + 
		"                              </product>\r\n" + 
		"                           </bundledProducts>\r\n" + 
		"                        </product>\r\n" + 
		"                     </bundledProducts>\r\n" + 
		"                  </product>\r\n" + 
		"               </bundledProducts>\r\n" + 
		"            </product>\r\n" + 
		"         </customerOrderItem>\r\n" + 
		"      </customerOrderItems>\r\n" + 
		"      <salesProperties>\r\n" + 
		"         <salesSource>CSR</salesSource>\r\n" + 
		"      </salesProperties>\r\n" + 
		"   </productOrder>\r\n" + 
		"   <genericCustomerFacingService>\r\n" + 
		"      <startMode>Manually By Customer</startMode>\r\n" + 
		"      <serviceCharacteristics>\r\n" + 
		"         <specificationCharacteristic>\r\n" + 
		"            <characteristicName>InstallationFee</characteristicName>\r\n" + 
		"            <characteristicValue>\r\n" + 
		"               <value>0.0</value>\r\n" + 
		"            </characteristicValue>\r\n" + 
		"         </specificationCharacteristic>\r\n" + 
		"      </serviceCharacteristics>\r\n" + 
		"   </genericCustomerFacingService>\r\n" + 
		"</Request>";
	
	String xmlDataAfterMod = payload;
	String esi_url = prop.getProperty("ESI_URL");

	//return RestAssured.given().contentType(ContentType.XML).headers(reqheaders).body(xmlDataAfterMod)
		//.post("https://tstc01app23v.sjrb.ad:12343/service/v1/productorders");
	
	return RestAssured.given().contentType(ContentType.XML).headers(reqheaders).body(xmlDataAfterMod)
		.post(esi_url+"/service/v1/productorders");
    }

   
}
