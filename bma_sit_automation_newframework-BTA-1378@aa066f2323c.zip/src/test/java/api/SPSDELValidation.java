package api;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import io.restassured.RestAssured;

//import io.restassured.path.xml.XmlPath;
import io.restassured.response.Response;
import io.restassured.internal.path.xml.NodeBase;
import io.restassured.internal.path.xml.NodeChildrenImpl;
import io.restassured.internal.path.xml.NodeImpl;
import io.restassured.path.xml.XmlPath;
import io.restassured.path.xml.element.Node;
import io.restassured.specification.RequestSpecification;
import pageObjects.BaseUIPage;
import util.*;

public class SPSDELValidation extends BaseUIPage {

	private static Response sendUIRRequest(String accountNumber) {

		String host = "https://tstuirdfl01-02.sjrb.ad:8002/SPS_DEL_Rest/DSREAD/1.1";
		if (prop.getProperty("matrix").equalsIgnoreCase("preprod")) {
			host = "https://preuirfed.sjrb.ad:8002/SPS_DEL_Rest/DSREAD/1.1";
		}
		RestAssured.baseURI = host;
		Map<String, String> qParam = new HashMap<String, String>();
		qParam.put("idtype", "/Party/Person/Account/id");
		qParam.put("idvalue", accountNumber);
		qParam.put("xpath", "/Party/Person");
		qParam.put("rule", "FORCED_READ");
		RequestSpecification request = RestAssured.given().relaxedHTTPSValidation().queryParams(qParam);
		Response response = request.get();
		return response;
	}

	public static boolean spsdelValidation(String accountNumber) throws IOException {
		return spsdelValidation(accountNumber, "Internet");
	}

	public static boolean spsdelValidation(String accountNumber, String lobs) throws IOException {
		Response response = sendUIRRequest(accountNumber);
		Boolean ppvStatus = false, wifiStatus = false, hsDataStatus = false, qamTvStatus = false, vodStatus = false,
				xfiStatus = false, fixedLineStatus = false, iptvStatus = false, iptvVodStatus = false, cdvrStatus = false;

		String fixedLineStatusString = response.xmlPath().getString("**.find { it.Type =='fixedLine'}");
		if (fixedLineStatusString != null)
			fixedLineStatus = fixedLineStatusString.contains("activefixedLine");

		String ppvStatusString = response.xmlPath().getString("**.find { it.Type =='ppv'}");
		if (ppvStatusString != null)
			ppvStatus = ppvStatusString.contains(accountNumber + "activeppv");

		String wifiStatusString = response.xmlPath().getString("**.find { it.Type =='wifi'}");
		if (wifiStatusString != null)
			wifiStatus = wifiStatusString.contains(accountNumber + "activewifi");

		String hsDataStatusString = response.xmlPath().getString("**.find { it.Type =='hsData'}");
		if (hsDataStatusString != null)
			hsDataStatus = hsDataStatusString.contains(accountNumber + "activehsData");

		String qamTvStatusString = response.xmlPath().getString("**.find { it.Type =='qamTv'}");
		if (qamTvStatusString != null)
			qamTvStatus = qamTvStatusString.contains(accountNumber + "activeqamTv");

		String vodStatusString = response.xmlPath().getString("**.find { it.Type =='vod'}");
		if (vodStatusString != null)
			vodStatus = vodStatusString.contains(accountNumber + "activevod");

		String xfiStatusString = response.xmlPath().getString("**.find { it.Type =='xfi'}");
		if (xfiStatusString != null)
			xfiStatus = xfiStatusString.contains(accountNumber + "activexfi");

		String iptvStatusString = response.xmlPath().getString("**.find { it.Type =='ipTv'}");
		if (iptvStatusString != null)
			iptvStatus = iptvStatusString.contains(accountNumber + "activeipTv");

		String iptvVodStatusString = response.xmlPath().getString("**.find { it.Type =='ipTvVod'}");
		if (iptvVodStatusString != null)
			iptvVodStatus = iptvVodStatusString.contains(accountNumber + "activeipTvVod");

		String cdvrStatusString = response.xmlPath().getString("**.find { it.Type =='cdvr'}");
		if (cdvrStatusString != null)
			cdvrStatus = cdvrStatusString.contains(accountNumber + "activecdvr");

		Map<String, String> responseHash = new HashMap<String, String>();
		Map<String, String> expectedHash = new HashMap<String, String>();
		List<String> validationKeys = null;

		for (String lob : lobs.toUpperCase().split(",")) {
			switch (lob) {
			case "HITRON":
			case "XB6":
			case "INTERNET":
				validationKeys = Arrays.asList(new String[] { "hsDataStatus", "wifiStatus" });
				responseHash.put("hsDataStatus", hsDataStatus.toString());
				responseHash.put("wifiStatus", wifiStatus.toString());
				break;
			case "DCX3400":
			case "DCX3510":
			case "DCX3200":
			case "DCT700":
			case "TV":
				validationKeys = Arrays.asList(new String[] { "ppvStatus", "qamTvStatus", "vodStatus" });
				responseHash.put("ppvStatus", ppvStatus.toString());
				responseHash.put("qamTvStatus", qamTvStatus.toString());
				responseHash.put("vodStatus", vodStatus.toString());
				break;
			case "PHONE":
				if (prop.getProperty("disablePhoneSteps", "false").equalsIgnoreCase("false")) {
					validationKeys = Arrays.asList(new String[] { "fixedLineStatus" });
					responseHash.put("fixedLineStatus", fixedLineStatus.toString());
					break;
				}
			case "XI6":
			case "XG1V3":
			case "XG1V4":
			case "XID":
				validationKeys = Arrays.asList(new String[] { "ppvStatus", "iptvStatus", "iptvVodStatus" });
				responseHash.put("ppvStatus", ppvStatus.toString());
				responseHash.put("iptvStatus", iptvStatus.toString());
				responseHash.put("iptvVodStatus", iptvVodStatus.toString());
				break;
			case "FlEXTV":
				validationKeys = Arrays.asList(new String[] { "ppvStatus", "iptvStatus", "iptvVodStatus" });
				responseHash.put("ppvStatus", ppvStatus.toString());
				responseHash.put("iptvStatus", iptvStatus.toString());
				responseHash.put("iptvVodStatus", iptvVodStatus.toString());
				responseHash.put("cdvr", cdvrStatus.toString());
				break;
			}
			for (String lval : validationKeys) {
				expectedHash.put(lval, "true");
			}
		}

		// addInfoInReport(response.prettyPrint());
		boolean hashEquals = (new ArrayList<>(responseHash.values()).equals(new ArrayList<>(expectedHash.values())));
		if (!hashEquals) {
			//addErrorInReport("The UIR response is not as expected " + responseHash.toString());
		} else {
			//addInfoInReport("The UIR response is as expected " + responseHash.toString());
		}
		spsdelResponseXML(accountNumber);
		return hashEquals;
	}

	public static String spsdelValidationBridge(String accountNumber) throws IOException {
		Response response = sendUIRRequest(accountNumber);
		String bridgestatuspath = "SPS_DELReadOutBody[0].DataSequence[0].SPS_DELData[0].Party[0].Person[0].Account[0].Devices[0].Device[0].DeviceInfos[0].DeviceInfo[2]";
		String bridgestatus = response.xmlPath().getString(bridgestatuspath);
		System.out.println(bridgestatus);
		spsdelResponseXML(accountNumber);
		return bridgestatus;
	}

	public static void spsdelResponseXML(String accountNumber) throws IOException {

		Response response = sendUIRRequest(accountNumber);
		String respBody = response.xmlPath().prettify();
		String path = "test-output\\spsdel_" + accountNumber + ".txt";
		File fout = new File(path);
		FileOutputStream fos = new FileOutputStream(fout);
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		System.out.println(respBody);
		bw.write(respBody);
		bw.close();
	}

}
