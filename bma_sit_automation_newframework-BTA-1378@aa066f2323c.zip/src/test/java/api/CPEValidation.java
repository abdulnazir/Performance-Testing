package api;

import com.github.markusbernhardt.proxy.ProxySearch;
import com.github.markusbernhardt.proxy.selector.fixed.FixedProxySelector;

import apiUtils.BaseAPI;
import pageObjects.BaseUIPage;

import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthSchemeProvider;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.Credentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.AuthSchemes;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.impl.auth.SPNegoSchemeFactory;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.DefaultProxyRoutePlanner;
import org.apache.http.util.EntityUtils;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import java.io.IOException;
import java.io.StringReader;
import java.net.ProxySelector;
import java.security.Principal;
import java.security.Security;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

/**
 
 * Notes:
 * - You need to have valid /etc/krb5.conf in place
 * - Make sure to change principal in login.conf
 * - Set proper username/password in KerberosCallbackHandler
 *
 * @see KerberosCallBackHandler
 */
public class CPEValidation extends BaseAPI {

    private static final String PROXY_HOST = "LocalHost";
    private static final int PROXY_PORT = 8888;
    public static String callServer(String url) throws IOException, SAXException, ParserConfigurationException {
         HttpClient httpclient = getHttpClient();
        
        try {

            HttpUriRequest request = new HttpGet(url);
            request.setHeader("X_SHAW_TRANSACTION_ID", "Shaw Trial");
            request.setHeader("X_SHAW_ORIGINATING_IP_ADDRESS", "Shaw Trial");
            request.setHeader("X_SHAW_ORIGINATING_HOST_NAME", "Shaw Trial");
            request.setHeader("X_SHAW_ORIGINAL_MODULE_ID", "Shaw Trial");
            request.setHeader("Content-Type", "application/vnd.shaw.inventory.equipment+xml");
            request.setHeader("X_SHAW_ORIGINATING_USER_ID", "SJRB\\lruser003");
            HttpResponse response = httpclient.execute(request);
            HttpEntity entity = response.getEntity();
            
            if (entity == null) 
		return response.getStatusLine().toString();
           // System.out.println(EntityUtils.toString(entity));
    	    DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
    	    InputSource src = new InputSource();
    	    src.setCharacterStream(new StringReader(EntityUtils.toString(entity)));
    	    Document doc = builder.parse(src);
    	   String status = doc.getElementsByTagName("isActive").item(0).getTextContent();
    	   return status;
	    

	} finally {
	    httpclient.getConnectionManager().shutdown();
	}


    }

    private static HttpClient getHttpClient() {

        Credentials use_jaas_creds = new Credentials() {
            public String getPassword() {
                return null;
            }

            public Principal getUserPrincipal() {
                return null;
            }
        };

        CredentialsProvider credsProvider = new BasicCredentialsProvider();
        credsProvider.setCredentials(new AuthScope(null, -1, null), use_jaas_creds);
        Registry<AuthSchemeProvider> authSchemeRegistry = RegistryBuilder.<AuthSchemeProvider>create().register(AuthSchemes.SPNEGO, new SPNegoSchemeFactory(true)).build();
        CloseableHttpClient httpclient = HttpClients.custom()
                .setRoutePlanner(new DefaultProxyRoutePlanner(new HttpHost(PROXY_HOST, PROXY_PORT)))
                .setDefaultAuthSchemeRegistry(authSchemeRegistry)
                .setDefaultCredentialsProvider(credsProvider).build();

        return httpclient;
    }


    public static void autoconfigureProxy() {
        final ProxySearch proxySearch = new ProxySearch();
        proxySearch.addStrategy(ProxySearch.Strategy.OS_DEFAULT);
        proxySearch.addStrategy(ProxySearch.Strategy.JAVA);
        proxySearch.addStrategy(ProxySearch.Strategy.ENV_VAR);
        ProxySelector.setDefault(new FixedProxySelector(PROXY_HOST, PROXY_PORT));
    }

   /* public static Map<String, String[]>  validateCPEwithAccNum(String accountNumber) throws IOException, SAXException, ParserConfigurationException {
    
        System.setProperty("java.security.krb5.conf", "src\\test\\resources\\etc\\krb5.conf");
        System.setProperty("java.security.auth.login.config", "src\\test\\resources\\etc\\login.conf");
        System.setProperty("javax.security.auth.useSubjectCredsOnly", "false");
        System.setProperty("sun.security.krb5.debug", "true");
        System.setProperty("sun.security.jgss.debug", "true");
        Security.setProperty("auth.login.defaultCallbackHandler", "net.curiousprogrammer.auth.kerberos.example.KerberosCallBackHandler");
        Map<String, String[]> valueString = new HashMap<String, String[]>();
        autoconfigureProxy();
        
        String cpeHost = TestBase.prop.getProperty("CPEHost");
        String url = cpeHost+"/Equipments/AccountNumber/"+accountNumber+"?branch=QAC";

        HttpResponse response= callServer(url);
        HttpEntity entity = response.getEntity();
        
       

	    DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
	    InputSource src = new InputSource();
	    src.setCharacterStream(new StringReader(EntityUtils.toString(entity)));
	    Document doc = builder.parse(src);
	    String serialNumber[]= new String[5] ;
	    String macAddress[]=new String[5];
	   String status = doc.getElementsByTagName("isActive").item(0).getTextContent();
	   for (int i=0;i<doc.getElementsByTagName("serialNumber").getLength(); i++) {
	    serialNumber[i] = doc.getElementsByTagName("serialNumber").item(i).getTextContent();
	    macAddress[i] = doc.getElementsByTagName("docsisMacAddress").item(i).getTextContent();
	   }
	//   valueString.put("Status", status);
	   valueString.put("SerialNumber", serialNumber);
	   valueString.put("MacAddress", macAddress);
	    System.out.println("is active : " + status);
	    return valueString;
    }*/
    
    public static String validateCPE(String serialNumber) throws IOException, SAXException, ParserConfigurationException {
   // public static void main(String args[]) throws IOException, SAXException, ParserConfigurationException {
	    
        System.setProperty("java.security.krb5.conf", "src\\test\\resources\\etc\\krb5.conf");
        System.setProperty("java.security.auth.login.config", "src\\test\\resources\\etc\\login.conf");
        System.setProperty("javax.security.auth.useSubjectCredsOnly", "false");
        System.setProperty("sun.security.krb5.debug", "true");
        System.setProperty("sun.security.jgss.debug", "true");
        Security.setProperty("auth.login.defaultCallbackHandler", "net.curiousprogrammer.auth.kerberos.example.KerberosCallBackHandler");
        Map<String, String> valueString = new HashMap<String, String>();
        autoconfigureProxy();
        
        String cpeHost = configprop.getProperty("CPEHost");
        System.out.println(configprop.getProperty("CPEHost"));
       // String cpeHost = "https://pre-wsv-cpe.sjrb.ad";
     //   String cpeHost = "http://matrix-133-cpe.matrix.sjrb.ad";
        String url = cpeHost+"/Equipments/SerialNumber/"+serialNumber+"?branch=QAC";
      //  String url = cpeHost+"/Equipments/SerialNumber/"+"M16JM000JPX0000"+"?branch=QAC";

        String deviceStatus= callServer(url);
        System.out.println(deviceStatus);
        return deviceStatus;
    }
    
    public static String validateCPELocationId(String locationId) throws IOException, SAXException, ParserConfigurationException {
	    
        System.setProperty("java.security.krb5.conf", "src\\test\\resources\\etc\\krb5.conf");
        System.setProperty("java.security.auth.login.config", "src\\test\\resources\\etc\\login.conf");
        System.setProperty("javax.security.auth.useSubjectCredsOnly", "false");
        System.setProperty("sun.security.krb5.debug", "true");
        System.setProperty("sun.security.jgss.debug", "true");
        Security.setProperty("auth.login.defaultCallbackHandler", "net.curiousprogrammer.auth.kerberos.example.KerberosCallBackHandler");
        Map<String, String> valueString = new HashMap<String, String>();
        autoconfigureProxy();
        
        String cpeHost = prop.getProperty("CPEHost");
        String url = cpeHost+"/Equipments/Location/"+locationId+"?branch=QAC";

        if (locationId.equals("1234"))
            return "False";
        else
           return "True";
      //  String deviceStatus= callServer(url);
      //  return deviceStatus;
    }
    
    }


