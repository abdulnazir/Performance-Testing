package api;

import io.restassured.RestAssured;
import io.restassured.config.SSLConfig;
import io.restassured.http.ContentType;
import io.restassured.path.xml.XmlPath;
import io.restassured.response.Response;
import pageObjects.BaseUIPage;
import util.ESIDBValidation;
import util.FakeHardwareGeneration;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.StringReader;
import java.security.KeyException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.KeyManagerFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.http.util.EntityUtils;
//import org.json.JSONException;
//import org.json.JSONObject;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import apiUtils.BaseAPI;

public class AllIPCalls extends BaseAPI {

  // public static void main(String args[]) throws KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException, ParserConfigurationException, SAXException, IOException {
	     public static int runCalls(String serialNumber, String meth )
	    throws KeyException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException, IOException, ParserConfigurationException, SAXException {
	//String accountNumber = "03700005991";
		 Response rs = null;
		 if (meth.equalsIgnoreCase("post"))
	 rs = postJsonPayload(serialNumber);
		 else if(meth.equalsIgnoreCase("get")) 
	 rs = getCall(serialNumber);
		 else
	 rs = delCall(serialNumber);
	String respMsg = rs.jsonPath().getString("response");
	System.out.println(rs.getBody().prettyPrint());
	rs.getBody().prettyPrint();
	String path = "test-output\\response.txt";
	File fout = new File(path);
	FileOutputStream fos = new FileOutputStream(fout);
	BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
	System.out.println(respMsg);
	bw.write(rs.getBody().prettyPrint());
	bw.close();
	
	
	
	return rs.getStatusCode() ;
    }

    public static Response postJsonPayload(String serialNumber)
	    throws KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException {

	KeyStore keyStore = null;
	SSLConfig config = null;
	String password = "welcome1";

	try {
	    keyStore = KeyStore.getInstance("jks");
	    keyStore.load(new FileInputStream("C:\\Users\\npanwar\\Documents\\cert\\esitestharness-tst.jks"),
		    password.toCharArray());

	} catch (Exception ex) {
	    System.out.println("Error while loading keystore >>>>>>>>>");
	    ex.printStackTrace();
	}

	if (keyStore != null) {

	    @SuppressWarnings("deprecation")
		org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(
		    keyStore, password);

	    // set the config in rest assured
	    config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();

	    RestAssured.config = RestAssured.config().sslConfig(config);
	}
	Map<String, String> reqheaders = new HashMap<String, String>();



	String payload = "{\r\n" + 
		"	\"parameters\": [\r\n" + 
		"		{\r\n" + 
		"			\"FAIL\": \"ManagementServerUrl\",\r\n" + 
		"			\"key\": \"InternetGatewayDevice.ManagementServer.URL\",\r\n" + 
		"			\"value\": \"http://acsurl.com:8080/dps/tr069\"\r\n" + 
		"		},\r\n" + 
		"		{\r\n" + 
		"			\"name\": \"DeviceInfoManufacturer\",\r\n" + 
		"			\"key\": \"InternetGatewayDevice.DeviceInfo.Manufacturer\",\r\n" + 
		"			\"value\": \"Cisco Systems\"\r\n" + 
		"		}\r\n" + 
		"	]\r\n" + 
		"}";
	String esi_url ="https://tstc01app25v.sjrb.ad:12543/service/primehome/netmap/device/SerialNumberStb=75K2C489D932660/parameters"; //TestBase.prop.getProperty("ESI_URL");
	return RestAssured.given().contentType(ContentType.JSON).headers(reqheaders).body(payload)
		.post(esi_url);//+"/service/sonic/customers/shawmobile");
    }
    public static Response getCall(String serialNumber)
	    throws KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException {

	KeyStore keyStore = null;
	SSLConfig config = null;
	String password = "welcome1";

	try {
	    keyStore = KeyStore.getInstance("jks");
	    keyStore.load(new FileInputStream("C:\\Users\\npanwar\\Documents\\cert\\esitestharness-tst.jks"),
		    password.toCharArray());

	} catch (Exception ex) {
	    System.out.println("Error while loading keystore >>>>>>>>>");
	    ex.printStackTrace();
	}

	if (keyStore != null) {

	    org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(
		    keyStore, password);

	    // set the config in rest assured
	    config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();

	    RestAssured.config = RestAssured.config().sslConfig(config);
	}
	Map<String, String> reqheaders = new HashMap<String, String>();



	
	String esi_url ="https://tstc01app25v.sjrb.ad:12543/service/primehome/netmap/device/SerialNumberGw=75K2C489D932660/parameters/Device.WiFi.SSID.10105.SSID?staleness=0"; //TestBase.prop.getProperty("ESI_URL");
	return RestAssured.given().contentType(ContentType.JSON).headers(reqheaders)
		.get(esi_url);//+"/service/sonic/customers/shawmobile");
    }
    
    public static Response delCall(String serialNumber)
	    throws KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException {

	KeyStore keyStore = null;
	SSLConfig config = null;
	String password = "welcome1";

	try {
	    keyStore = KeyStore.getInstance("jks");
	    keyStore.load(new FileInputStream("C:\\Users\\npanwar\\Documents\\cert\\esitestharness-tst.jks"),
		    password.toCharArray());

	} catch (Exception ex) {
	    System.out.println("Error while loading keystore >>>>>>>>>");
	    ex.printStackTrace();
	}

	if (keyStore != null) {

	    org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(
		    keyStore, password);

	    // set the config in rest assured
	    config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();

	    RestAssured.config = RestAssured.config().sslConfig(config);
	}
	Map<String, String> reqheaders = new HashMap<String, String>();



	
	String esi_url ="https://tstc01app25v.sjrb.ad:12543/service/primehome/devices/SerialNumberGw=M15DM000NN80000?remove_devices=true"; //TestBase.prop.getProperty("ESI_URL");
	return RestAssured.given().contentType(ContentType.JSON).headers(reqheaders)
		.delete(esi_url);//+"/service/sonic/customers/shawmobile");
    }

}
