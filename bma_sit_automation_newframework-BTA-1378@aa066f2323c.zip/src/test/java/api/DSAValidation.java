package api;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;



import io.restassured.RestAssured;

//import io.restassured.path.xml.XmlPath;
import io.restassured.response.Response;
import io.restassured.internal.path.xml.NodeBase;
import io.restassured.internal.path.xml.NodeChildrenImpl;
import io.restassured.internal.path.xml.NodeImpl;
import io.restassured.path.json.JsonPath;
import io.restassured.path.xml.XmlPath;
import io.restassured.path.xml.element.Node;
import io.restassured.specification.RequestSpecification;
import pageObjects.BaseUIPage;


public class DSAValidation extends BaseUIPage {

	public DSAValidation(WebDriver driver) {

		PageFactory.initElements(driver, this);
	}
	//public static void main(String[] args) {
		
	public static int validateDSA(String macAddress) {
	
		String responseString="";
		//String macAddress = "200220A00115";
		//String basehost="https://app10.so.cg.pre.oss.mlb.inet:8443/dsa/rest/api/devices/";
      String basehost="https://cca-app.pre.oss.inet/dsa/rest/api/devices/";//https://cca-app.pre.oss.inet/dsa/rest/static/dsa.html
		String host = basehost + macAddress;
		System.out.println(host);
		RestAssured.baseURI = host;
		
		String userName =prop.getProperty("validation_user", "user_name_not_set");
		String password = prop.getProperty("validation_password", "password_not_set");
		RequestSpecification request = RestAssured.given().auth().basic(userName, password).relaxedHTTPSValidation();
		Response response =request.get();
		System.out.println("Status code: " + response.getStatusCode());
		System.out.println("Status message " + response.body().asString());
		responseString=Integer.toString(response.getStatusCode());
		System.out.println(responseString);
		//String cmts = response.jsonPath().get("properties.cmts_ip");
		int statusCode = response.getStatusCode();
		//System.out.println(cmts);
		return statusCode;
		
		
}
	
	public static String validateDSAforBridge(String macAddress, String accountNumber) throws IOException {
		String basehost = "https://app10.so.cg.pre.oss.mlb.inet:8443/dsa/rest/api/devices/";
		String host = basehost + macAddress;
		System.out.println(host);
		RestAssured.baseURI = host;

		String userName = prop.getProperty("validation_user", "user_name_not_set");
		String password = prop.getProperty("validation_password", "password_not_set");
		RequestSpecification request = RestAssured.given().auth().basic(userName, password).relaxedHTTPSValidation();
		Response response = request.get();
		String respMsg = response.jsonPath().getString("properties.service_id");
		
		String path = "test-output\\dsa_" + accountNumber + ".txt";
		File fout = new File(path);
		FileOutputStream fos = new FileOutputStream(fout);
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		bw.write(response.getBody().prettyPrint());
		bw.close();
		
		System.out.println(respMsg);
		String msg[] = respMsg.split("=");
		System.out.println(msg[1]);
		return msg[1];

		 }
}
