
package api;

import com.github.markusbernhardt.proxy.ProxySearch;
import com.github.markusbernhardt.proxy.selector.fixed.FixedProxySelector;

import pageObjects.BaseUIPage;
import util.*;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthSchemeProvider;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.Credentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.AuthSchemes;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.auth.SPNegoSchemeFactory;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.DefaultProxyRoutePlanner;
import org.apache.http.util.EntityUtils;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import java.io.IOException;
import java.io.StringReader;
import java.net.ProxySelector;
import java.security.Principal;
import java.security.Security;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

/**
 * 
 * Notes: - You need to have valid /etc/krb5.conf in place - Make sure to change
 * principal in login.conf - Set proper username/password in
 * KerberosCallbackHandler
 *
 * @see KerberosCallBackHandler
 */
public class ReturnHardware extends BaseUIPage {

    private static final String PROXY_HOST = "LocalHost";
    private static final int PROXY_PORT = 8888;
    
    @SuppressWarnings("deprecation")
	public static int callServer(String url, String serialNumber) throws IOException, SAXException, ParserConfigurationException {
	HttpClient httpclient = getHttpClient();

	try {
	    //String serialNumber = "M122M0006;

	    String body = "<HardwareReturned xmlns=\"http://services.sjrb.ad/order\">\r\n" + 
	    		"    <serialNumber>numid</serialNumber>\r\n" + 
	    		"    <warehouseId>5649</warehouseId>\r\n" + 
	    		"</HardwareReturned>";
	    String payload = body;
	    payload = payload.replace("numid", serialNumber);
	    HttpPut httpPut = new HttpPut(url);
	    httpPut.setEntity(new StringEntity(payload));
	    httpPut.setHeader("Content-Type", "application/vnd.shaw.order+xml");
	    httpPut.setHeader("X_SHAW_TRANSACTION_ID", "Shaw Trial");
	    httpPut.setHeader("X_SHAW_ORIGINATING_IP_ADDRESS", "Shaw Trial");
	    httpPut.setHeader("X_SHAW_ORIGINATING_HOST_NAME", "CGL108305");
	    httpPut.setHeader("X_SHAW_ORIGINAL_MODULE_ID", "Shaw Trial");
	    httpPut.setHeader("X_SHAW_ORIGINATING_USER_ID", "SJRB\\lruser003");
	    
	    HttpResponse response = httpclient.execute(httpPut);
	    HttpEntity entity = response.getEntity();
	    return response.getStatusLine().getStatusCode();

	} finally {
	    httpclient.getConnectionManager().shutdown();
	}
	

    }

    private static HttpClient getHttpClient() {

	Credentials use_jaas_creds = new Credentials() {
	    public String getPassword() {
		return null;
	    }

	    public Principal getUserPrincipal() {
		return null;
	    }
	};

	CredentialsProvider credsProvider = new BasicCredentialsProvider();
	credsProvider.setCredentials(new AuthScope(null, -1, null), use_jaas_creds);
	Registry<AuthSchemeProvider> authSchemeRegistry = RegistryBuilder.<AuthSchemeProvider>create()
		.register(AuthSchemes.SPNEGO, new SPNegoSchemeFactory(true)).build();
	CloseableHttpClient httpclient = HttpClients.custom()
		.setRoutePlanner(new DefaultProxyRoutePlanner(new HttpHost(PROXY_HOST, PROXY_PORT)))
		.setDefaultAuthSchemeRegistry(authSchemeRegistry).setDefaultCredentialsProvider(credsProvider).build();

	return httpclient;
    }

    public static void autoconfigureProxy() {
	final ProxySearch proxySearch = new ProxySearch();
	proxySearch.addStrategy(ProxySearch.Strategy.OS_DEFAULT);
	proxySearch.addStrategy(ProxySearch.Strategy.JAVA);
	proxySearch.addStrategy(ProxySearch.Strategy.ENV_VAR);
	ProxySelector.setDefault(new FixedProxySelector(PROXY_HOST, PROXY_PORT));
    }

    public static int hardwareReturn(String serialNumber) throws IOException, SAXException, ParserConfigurationException {
	//public static void main(String args[]) throws IOException, SAXException, ParserConfigurationException {
	System.setProperty("java.security.krb5.conf", "src\\test\\resources\\etc\\krb5.conf");
	System.setProperty("java.security.auth.login.config", "src\\test\\resources\\etc\\login.conf");
	System.setProperty("javax.security.auth.useSubjectCredsOnly", "false");
	System.setProperty("sun.security.krb5.debug", "true");
	System.setProperty("sun.security.jgss.debug", "true");
	Security.setProperty("auth.login.defaultCallbackHandler",
		"net.curiousprogrammer.auth.kerberos.example.KerberosCallBackHandler");
	ArrayList<String>valueString = new ArrayList<String>();
	autoconfigureProxy();
	//String url = "http://oeservice.oss.lab/services/omservice/hardwareReturned/disconnectedDevices";
	//String url = "http://tclcooeml181-01.matrix.sjrb.ad:7001/services/omservice/hardwareReturned/disconnectedDevices";
	
	String url = "http://tstcoreoeml133.matrix.sjrb.ad:7001/services/omservice/hardwareReturned/disconnectedDevices";
	int returnHardwareStatus=callServer(url,serialNumber);
	System.out.println(returnHardwareStatus);
	 return returnHardwareStatus;
    }

}
