package api;

import io.restassured.RestAssured;
import io.restassured.config.SSLConfig;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import pageObjects.BaseUIPage;
import util.FakeHardwareGeneration;
import util.*;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.KeyException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.KeyManagerFactory;

import org.apache.commons.lang.RandomStringUtils;
import org.json.JSONException;
import org.json.JSONObject;

public class MacAddressToDrake extends BaseUIPage{

   // public static void main(String args[])
	     public static int mapMacToDrake(String macAddress)
	    throws KeyException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException, IOException {
	//String macAddress = "001DCF47CD71";
		 String macAddresswithColon = FakeHardwareGeneration.convertMacAddress(macAddress);
	Response rs1 = postJsonPayload(macAddress);
	Response rs2 = postJsonPayload(macAddresswithColon);
	//String respMsg = rs1.jsonPath().getString("response");
	System.out.println(rs1.getBody().prettyPrint());
	
	System.out.println(rs1.getStatusCode());
	System.out.println(rs2.getStatusCode());
	

	 return rs1.getStatusCode();
    }

    public static Response postJsonPayload(String macAddress)
	    throws KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException {

	KeyStore keyStore = null;
	SSLConfig config = null;
	String password = "welcome1";

	try {
	    keyStore = KeyStore.getInstance("jks");
	    keyStore.load(new FileInputStream("C:\\Users\\npanwar\\Documents\\cert\\esitestharness-tst.jks"),
		    password.toCharArray());

	} catch (Exception ex) {
	    System.out.println("Error while loading keystore >>>>>>>>>");
	    ex.printStackTrace();
	}

	if (keyStore != null) {

	    @SuppressWarnings("deprecation")
		org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(
		    keyStore, password);

	    // set the config in rest assured
	    config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();

	    RestAssured.config = RestAssured.config().sslConfig(config);
	}
	Map<String, String> reqheaders = new HashMap<String, String>();

	// reqheaders.put("Cache-Control","no-cache");
	reqheaders.put("Content-Type", "application/json");
	reqheaders.put("Host", "tst02eoag.dmz.pre:8444");

	String payload = "{\r\n" + "   \"macs\":{\r\n" + "      \"macAdd\":{\r\n" + "         \"DMZURL\":\"dmurl\",\r\n"
		+ "         \"InternetURL\":\"iurl\"\r\n" + "      }\r\n" + "   }\r\n" + "}";

	String xmlDataAfterMod = payload;
	//String dmzUrl = TestBase.prop.getProperty("DMZ_URL");
	String dmzUrl = "tst02eoag-05.dmz.pre:8443";
	
	//String internetUrl = TestBase.prop.getProperty("INTERNET_URL");
	String internetUrl = "tst02eoag-05.dmz.pre:443";
	xmlDataAfterMod = xmlDataAfterMod.replace("dmurl", dmzUrl);
	xmlDataAfterMod = xmlDataAfterMod.replace("iurl", internetUrl);
	xmlDataAfterMod = xmlDataAfterMod.replace("macAdd", macAddress);
	//String drakeUrl = TestBase.prop.getProperty("DRAKE_URL");
	String drakeUrl = "https://tst02eoag.dmz.pre:8444/service/mapping/macs";
	return RestAssured.given().contentType(ContentType.JSON).headers(reqheaders).body(xmlDataAfterMod)
		.put(drakeUrl);
    }

}
