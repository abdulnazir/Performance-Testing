package api;

import io.restassured.RestAssured;
import io.restassured.config.SSLConfig;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import static io.restassured.RestAssured.given;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.security.KeyException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.KeyManagerFactory;

import org.apache.commons.lang.RandomStringUtils;
import org.json.JSONException;
import org.json.JSONObject;

import com.microsoft.alm.storage.StorageProvider;

public class PhoneDisconnection {

    public static void main(String args[])
	    throws KeyException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException, IOException {
	
	ArrayList<String> discStatus = new ArrayList<String>();
	String outputFile = "C:\\Users\\spaliwal\\Documents\\TN_CleanUp\\AccountDisconnectStatus_181.txt";
	String inputFile = "C:\\Users\\spaliwal\\Documents\\TN_CleanUp\\AccountNumberForDisconnect.txt";
	ArrayList<String> accountNumbers = getTnFromFile(inputFile);
	//ArrayList<String> accountNumbers = new ArrayList<String>();
	//accountNumbers.add("03700002603");
	for (int i = 0; i < accountNumbers.size(); i++) {
	    Response rs = postJsonPayload(accountNumbers.get(i));
	    if (rs.getStatusCode() == 200) {
		System.out.println(accountNumbers.get(i) + ": Success");
		discStatus.add(accountNumbers.get(i) + ": Success");
	    } else if (rs.getStatusCode() == 404) {
		System.out.println(accountNumbers.get(i) + ": Account Not Found");
		discStatus.add(accountNumbers.get(i) + ": Account Not Found");
	    } else if (rs.getStatusCode() == 401) {
		System.out.println(accountNumbers.get(i) + ": Authentication Error");
		discStatus.add(accountNumbers.get(i) + ": Authentication Error");
	    } else {
		System.out.println(accountNumbers.get(i) + ": Error  " +rs.asString());
		discStatus.add(accountNumbers.get(i) + ": Error");
	    }

	}
	addTextToFile(discStatus, outputFile);
	System.out.println(System.getProperty("user.credentials"));
	StorageProvider.getCredentialStorage(true, com.microsoft.alm.storage.StorageProvider.SecureOption.PREFER).get("SJRB\\spaliwal");
    }

    public static Response postJsonPayload(String accNumber)
	    throws KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException {

	KeyStore keyStore = null;
	SSLConfig config = null;
	String password = "ESISupport1!";
	//String password = "ESIBMASupport1";

	try {
	    keyStore = KeyStore.getInstance("jks");
	    keyStore.load(new FileInputStream("C:\\Users\\spaliwal\\Documents\\Certs\\esitestharness.jks"),
		    password.toCharArray());
		    
		//    keyStore.load(new FileInputStream("C:\\preesi\\esitestharness-pre.jks"),
			//    password.toCharArray());

	} catch (Exception ex) {
	    System.out.println("Error while loading keystore >>>>>>>>>");
	    ex.printStackTrace();
	}

	if (keyStore != null) {

	    org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(
		    keyStore, password);

	    // set the config in rest assured
	    config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();

	    RestAssured.config = RestAssured.config().sslConfig(config);
	}
	Map<String, String> reqheaders = new HashMap<String, String>();

	// reqheaders.put("Cache-Control","no-cache");
	reqheaders.put("X_SHAW_TRANSACTION_ID", "hbchhhhc");
	reqheaders.put("X_SHAW_ONBEHALFOF_ID", "Freedom"); 

	String payload = "<Request xmlns=\"http://www.shaw.ca/esi/schema/customer/customeraccount_disconnect/v1\">\r\n"
		+ "    <reasonCode>150</reasonCode>\r\n" + "</Request>\r\n";

	return RestAssured.given().contentType(ContentType.XML).headers(reqheaders).body(payload)
		.post("https://tstc01app24v.sjrb.ad:12443/service/v1/accounts/" + accNumber + "/disconnect");
	//return RestAssured.given().contentType(ContentType.XML).headers(reqheaders).body(payload)
		//.post("https://prec01appl01v.sjrb.ad:11143/service/v1/accounts/" + accNumber + "/disconnect");
    }

    public static void addTextToFile(ArrayList<String> text, String filepath) throws IOException {
	// String path = "test-output\\" + filename.replace(" ", "-")+".txt";
	File fout = new File(filepath);
	FileOutputStream fos = new FileOutputStream(fout);
	BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
	for (int i = 0; i < text.size(); i++) {
	    bw.write(text.get(i));
	    bw.newLine();
	}

	bw.close();
    }
    
    public static ArrayList<String> getTnFromFile(String path) throws IOException{
	//String path = "C:\\FakeHardware\\TN.txt";
	 File fout = new File(path);
	   FileInputStream fos = new FileInputStream(fout);
    
    BufferedReader bufReader = new BufferedReader(new InputStreamReader(fos)); 
    ArrayList<String> listOfLines = new ArrayList<>(); 
    String line = bufReader.readLine(); 
    while (line != null) { 
	listOfLines.add(line); 
	line = bufReader.readLine(); 
	} 
    bufReader.close();
    return listOfLines;
    }

}
