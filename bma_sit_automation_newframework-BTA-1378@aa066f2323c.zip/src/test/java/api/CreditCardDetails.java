package api;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

import pageObjects.BaseUIPage;



public class CreditCardDetails extends BaseUIPage {
	
	public CreditCardDetails(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//*[@id=\"addCardTab\"]")
	WebElement AddCard;
	
	@FindBy(xpath = "//*[@id=\"CcType\"]")
	WebElement Dropdown_CardUsage;	

	@FindBy(xpath = "//*[@id=\"trnCardNumber\"]")
	WebElement CardNumber;	
	
	@FindBy(xpath = "//*[@id=\"trnExpMonth\"]")
	Select ExpiryMonth;
	
	@FindBy(xpath = "//*[@id=\"trnExpYear\"]")
	Select ExpiryYear;
	
	@FindBy(xpath = "//*[@id=\"trnCardCvd\"]")
	WebElement CVD;
	
	@FindBy(xpath = "//*[@id=\"CcOwnerName\"]")
	WebElement NameOnTheCard;
	
	@FindBy(xpath = "//*[@class='btn btn-success']")
	WebElement AddThisCardButton;
	
	@FindBy(xpath="//*[@id=\"messagePane\"]/div/text()")
	WebElement SucessMessgae;
	
	public void ClickAddCard()
	{
		wait.withMessage("Card Number button not visible").until(ExpectedConditions.visibilityOf(AddCard));
		AddCard.click();	
	}
	
	public void EnterCardNumber(String CardNu)
	{
		CardNumber.sendKeys(CardNu);	
	}
	
	public void EnterExpiryMonth()
	{
		ExpiryMonth.selectByIndex(4);	
	}
	
	public void EnterExpiryYear()
	{
		ExpiryYear.selectByIndex(4);	
	}
	public void EnterCVVNumber(String CVV)
	{
		CVD.sendKeys(CVV);	
	}
	
	public void EnterCardName()
	{
		NameOnTheCard.sendKeys("Automation");	
	}
	public void AddCardDetails()
	{
		AddThisCardButton.click();	
	}
	
	public void VerifySucessMessage() throws InterruptedException, IOException 
	{
		String Messge=SucessMessgae.getText();
	      if(Messge.equalsIgnoreCase("Successfully Added Card"))
	        {
	            System.out.println("Card Successfully Added");
	            //TestBase.takeScreenshot("Card Successfully Added");
	        }
	    else{
	            System.out.println("Card Not Added");
	           // TestBase.takeScreenshot("Card Not Added");
	        }
	
	}

}
