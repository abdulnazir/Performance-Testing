package stepDefinitions;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.KeyException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchSessionException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeDriverService;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.xml.sax.SAXException;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;

import api.AOE;
import api.CPEValidation;
import api.DSAValidation;
import api.P150AccountCreate;
import api.P150AccountDisconnect;
import api.SPSDELValidation;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.After;
import io.cucumber.java.AfterStep;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObjects.AddServicesAndFeatures;
import pageObjects.AdminForm;
import pageObjects.Appointments;
import pageObjects.BaseUIPage;
import pageObjects.BillingPreferncesPage;
import pageObjects.CreditCheck;
import pageObjects.CustomerDetails;
import pageObjects.DisconnectServicesPage;
import pageObjects.EquipmentStatus;
import pageObjects.Equipmentsearch;
import pageObjects.FFMPage;
import pageObjects.FinishPage;
import pageObjects.Heirarchypage;
import pageObjects.ImmediateSwapPage;
import pageObjects.InternetServices;
import pageObjects.LDAPQueryTool;
import pageObjects.NetCrackerHomePage;
import pageObjects.NetCrackerLoginPage;
import pageObjects.NetCrackerModules;
import pageObjects.NetCrackerSuspensionHistoryPage;
import pageObjects.NetcrackerDFShippingPage;
import pageObjects.OrderManagement;
import pageObjects.OverviewPage;
import pageObjects.PhoneServices;
import pageObjects.Promotions;
import pageObjects.ProvDetails;
import pageObjects.ReinstatePage;
import pageObjects.ReviewPage;
import pageObjects.SecurityDevicesPage;
import pageObjects.ServiceCallPage;
import pageObjects.TVServices;
import pageObjects.TechConfirmPage;
import pageObjects.TestBase;
import pageObjects.WebUD_Alerts;
import pageObjects.WebUD_HardwaresummaryPage;
import pageObjects.WebUD_HomePage;
import pageObjects.WebUD_Notes;
import pageObjects.WebUD_OrderEntryPage;
import pageObjects.WebUD_OverviewPage;
import pageObjects.WebUD_SAML_Login;
import pageObjects.WebUD_ViewBill;
import pageObjects.SnowbirdSuspendResumePage;
import pageObjects.Summary;
import util.FakeHardwareGeneration;
import pageObjects.HostUrls;
//import util.HostUrls;
import util.TestUtil;
import util.XRAYValidation;
import util.DFTextFile;
import util.DatabaseCDI;
import util.FDBValidation;
import org.apache.commons.lang.RandomStringUtils;
import org.junit.Assert;


public class Steps extends BaseUIPage{


	public BaseUIPage tb;
	private StepData sd;
	NetCrackerLoginPage nclp ;
	TestUtil utils;
	FDBValidation fdb;
	CustomerDetails cd;
	AddServicesAndFeatures as;
	InternetServices is;
	TVServices ts;
	Appointments ap;
	ReviewPage rp;
	FinishPage fp;
	DatabaseCDI db;
	OverviewPage op;
	XRAYValidation xray;
	DisconnectServicesPage ds;
	PhoneServices ps;
	CPEValidation cpe;
	SnowbirdSuspendResumePage snowbird;
	OrderManagement orderMgm;
	NetCrackerSuspensionHistoryPage ncSusHistoryPage;
	BillingPreferncesPage billingpage;
	NetcrackerDFShippingPage ncdfShippingpage;
	DFTextFile dftext;
	LDAPQueryTool ldapqtool;
	FFMPage ffmPage;
	TechConfirmPage TechCnf;
	ImmediateSwapPage immswappage;
	ReinstatePage ReinPg;
	P150AccountCreate P150Acc;
	P150AccountDisconnect P150AccDisconn;
	ServiceCallPage servCallPage;
	WebUD_SAML_Login webUdLogin;
	WebUD_OrderEntryPage oePage;
	Promotions promotions;
	WebUD_OverviewPage overviewPage;
	EquipmentStatus eqpstatus;
	WebUD_Alerts webUdAlerts;
	WebUD_HomePage webudHomePage;
	NetCrackerModules ncModules;
	AdminForm adminForm;
	Summary summarypage;
	WebUD_Notes webUDNotes;
	ProvDetails prov;
	CreditCheck creditcheck;
	Equipmentsearch equipesearch;
	SecurityDevicesPage ss;
	WebUD_HardwaresummaryPage hardwaresummary;
	Heirarchypage heirarchytab;
	WebUD_ViewBill webud_ViewBill;

	String transferemail;
	String accountnumber;
	String tpiaaccountnumber;
	String accountid;
	String accountID;
	String workordernumber = "";
	String appoint;
	String serialnumberinternet = "";
	String serialNumberTv = "";
	String serialNumberHitron = "";
	String serialNumberXB6 = "";
	String serialNumberXG1V4 = "";
	String serialNumberXiD = "";
	String serialNumberDCX3200 = "";
	String serialNumberXiOne = "";
	String serialNumberDCX3510 = "";
	String serialNumberXG1V3 = "";
	String serialNumberDPT = "";
	String serialNumberDCX3400 = "";
	String serialNumberDCT700 = "";
	String serialNumberMoxiGateway = "";
	String serialNumberXi6 = "";
	String serialNumberXB7 = "";
	String serialNumberXB8 = "";
	String serialNumberXPOD = "";
	String internetdeviceserialNumber = "";
	String addStaffCustomer = "";
	String serialNumberLegacyFibreModel ="";
	String serialNumberTPIA = "";
	String billvalue;
	//Vivek NGV43435
	String serialNumberWifiRouterModel ="";
	public static String overviewpage = "";
	public static String response = "";
	public String netcrackerUser = "";
	public String tvPackage = "notset";
	String serviceId = "";
	String altId = "";
	String serialNumberDCX3400250GB = "";
	String serialNumberDCX3200P2M = "";
	String serialNumberDCX3200HDGuide = "";
	public String phonePackage = "notset";
	String serialNumberCISCODPC3848V = "";
	String serialNumberCISCODPC3825 = "";
	String serialNumberARRISSBG6782 = "";
	String internetdevice_serialnumber;
	String tvserialnumber;
	public static int example_count = 0;
	String webUdsearchCustBy="";
	private static ArrayList<String> fileWriter = new ArrayList<String>();
	private static ArrayList<String> fileWriterSourceForExampleData = new ArrayList<String>();
	private String ScratchpadNote = "Automation "+RandomStringUtils.randomAlphanumeric(10);
	private String CreateCustomerNote = "Create Automation Note"+RandomStringUtils.randomAlphanumeric(3);
	private String ModifyCustomerNote = "Modify Automation Note"+RandomStringUtils.randomAlphanumeric(3);
	private String RefundAmount = RandomStringUtils.randomNumeric(1)+".00";
	private String ChequeNumber = RandomStringUtils.randomNumeric(6);
	private String BankOrInst = RandomStringUtils.randomNumeric(3);
	private String BranchorTransit = RandomStringUtils.randomNumeric(5);
	private String PreAuthAccount = RandomStringUtils.randomNumeric(10);
	public String billcycle="";
	String tvserialNumber = "";
	Scenario scenario;
	String securityserialNumberdoor = "";
	String securityserialNumberxcam = "";
	String hardwareserialNumber = "";
	String propreitortype;
	String audittype;



	/**
	 * Retrieving and assigning the driver by Dependency Injection in Step Definition level
	 * Increases the reusability of Step Defintion
	 * @param sd Stepdata object from Dependency Injection
	 */
	public Steps(StepData sd)
	{
		this.sd=sd;

	}
	@Before
	public void driver_init(Scenario scenario) throws MalformedURLException {
		example_count++;
		System.out.println(
				"\n***********************    START OF TEST RUN    ***********************\n\n#### Scenario: Run "
						+ example_count + ": " + scenario.getName() + " ####\n");
		ArrayList<String> tagsList = new ArrayList<>(scenario.getSourceTagNames());
		tagsList.replaceAll(String::toUpperCase);

		tb= new BaseUIPage();
		tb.readPropertyFile();
		tb.driverInit();
		sd.driver=tb.launchApplication();
		sd.setScenario(scenario);
		this.scenario=sd.getScenario();
	}

	@When("^User Logins to Netcracker by entering (.*) (.*)$")

	public void cSRLoginsToNetcracker(String netcrackerUserName, String netcrackerPassword)
			throws InterruptedException, IOException {
		//		String hostss =yamlDataReader]("cdi","database_host");
		//		System.out.println(hostss);
		//	String hostss =yamlDataReaderLevel1("ffm","ffmMobileLiteUri");
		//System.out.println(hostss);
		String	netcrackerUser = netcrackerUserName;
		//		if (TestBase.prop.getProperty("environment", "non-timeshifter").equalsIgnoreCase("timeshifter")
		//				|| TestBase.prop.getProperty("matrix").equalsIgnoreCase("499")) {
		//			netcrackerUser = "sysadm";
		//			netcrackerUserName = "sysadm";
		//			netcrackerPassword = "netcracker";
		//
		//			//addInfoInReport("overriding auth details with sysadm for timeshifter");
		//		}
		nclp= new NetCrackerLoginPage(sd.driver);
		scenario.log("Screeshot test");
		//NetCrackerLoginPage(sd.driver).login(netcrackerUserName, netcrackerPassword);
		Thread.sleep(2000);
		//		netcrackerUserName="tttester2";
		//		netcrackerPassword = "wgp0HC8QRxzok320LYSr0vR#";
		nclp.login(netcrackerUserName, netcrackerPassword);

	}

	@And("^creates new customer account with (.*) (.*) (.*) (.*) (.*)$")
	public void CreateNewAccountupdateCustomerCredentials(String firstName, String lastName, String email,
			String authType, String pin) throws Exception {
		utils = new TestUtil(sd.driver);
		utils.openUrlNewTab(HostUrls.getOEUrl());
		//		webUdLogin = new WebUD_SAML_Login(sd.driver,this.scenario);
		//		Thread.sleep(2000);
		//		webUdLogin.login("shweta.paliwal@sjrb.ca");
		//		if (HostUrls.hostDomain.contains("131")){checkURL="https://tstwebud-ag.sjrb.ca/";}
		//		else if(HostUrls.hostDomain.contains("130")) {checkURL="https://matrix-1-udgfweb.matrix.sjrb.ad/";}
		//		else if(HostUrls.hostDomain.contains("182")) {checkURL="https://matrix-182-udgfweb.matrix.sjrb.ad/";}
		//		else if(HostUrls.hostPrefix.contains("181")) {checkURL="tclcooeml181";}
		//		for(int i=0;i<3;i++)
		//		{
		//			if(!sd.driver.getCurrentUrl().contains(checkURL))
		//			{	
		//				Runtime.getRuntime().exec(System.getProperty("user.dir")+"\\src\\test\\resources\\AutoIt_WindowSecurityLogin.exe");
		//				Thread.sleep(2000);
		//			}	
		//		}
		//		if(sd.driver.getCurrentUrl().contains(checkURL))
		//		{	
		//			System.out.println("Logged in");
		//		}	
		cd = new CustomerDetails(sd.driver);
		Thread.sleep(7000);
		cd.addCustomer(firstName, lastName, email, authType, pin);
		//ExtentCucumberAdapter.addTestStepLog("FirstName: " + firstName + "\nLastName: " + lastName + "\nEmail: " + email);
		//		 ExtentCucumberAdapter.addTestStepLog("FirstName: " + firstName + "\nLastName: " + lastName + "\nEmail: " + email);
	}

	@And("^click addservicesandfeatures tab$")
	public void clickAddServicesAndFeaturesTab() throws Exception {
		utils = new TestUtil(sd.driver);
		as = new AddServicesAndFeatures(sd.driver);
		as.clickAddServicesAndFeatures();

	}
	@And("^selects suspension internet service	(.*)	with TV package	(.*)$")
	public void selectsSuspensionservices(String internetService, String tvPackage) throws Exception
	{
		is = new InternetServices(sd.driver);
		is.selectInternetPackage(internetService);	
		ts = new TVServices(sd.driver);	
		ts.selectTVPackage(tvPackage);
	}
	//AddedShweta on 31/08/2023

	@And("^selects internetservice (.*) (.*) (.*)$")
	public void selectsInternetService(String internetService, String device, String technicianAppointment)
			throws Exception {
		String selfInstall = prop.getProperty("selfinstall");
		is = new InternetServices(sd.driver);
		is.selectInternetPackage(internetService);
		waitForLoading(sd.driver);
		isLoaderSpinnerVisible(sd.driver);	//AddedShweta
		if (technicianAppointment.equals("techNotRequired") && selfInstall.toUpperCase().equals("NO")) {
			if(internetService.contains("Employee Internet 300")) 
			{
				if(sd.driver.findElement(By.xpath("//td[@class=' SecondCategory']//table[@c='UIShawLinkFeature']//a[@class='wrench-button-style']/ancestor::td[1]/preceding-sibling::td[1]/descendant::label[1]")).getText().length()>1)
					is.RemoveHit();
			}
			is.DeleteandAddConvergedHardware(device);
			internetdeviceserialNumber = FakeHardwareGeneration.generateSerialNum(device);
			is.setInternetSerialNum(internetdeviceserialNumber);
			Hooks.setFileWriterExampleData(internetdeviceserialNumber + " | ");			
			is.clickOnSerialNumValidateButton();
			waitForLoading(sd.driver);
			isLoaderSpinnerVisible(sd.driver);	//AddedShweta
			is.clickOnInternetOkButton();   
			waitForLoading(sd.driver);
			is.selectInternetServiceCheckbox();
		}
		else if(technicianAppointment.equals("retailpickup") || technicianAppointment.equals("techRequired"))
		{
			//			is.deleteConvergedHardware();
			//			waitForLoading(sd.driver);
			//            is.clickOnInternetOkButton(); 
			//            waitForLoading(sd.driver);
			//            is.selectInternetServiceCheckbox();
		}
	}

	@And("^selects TV service with (.*) (.*)$")
	public void selectsTvService(String TVHardware, String technicianAppointment) throws Exception
	{
		utils =  new TestUtil(sd.driver);
		ts = new TVServices(sd.driver);	
		if (tvPackage.equals("notset")) {
			tvPackage = prop.getProperty("defaultTVPackage").trim();	
		}
		ts.selectTVPackage(tvPackage);
		ExtentCucumberAdapter.addTestStepLog("tvPackage");
		if (technicianAppointment.equals("techNotRequired")) {
			waitForLoading(sd.driver);
			ts.UnselectDefaultHardware(tvPackage);
			isLoaderSpinnerVisible(sd.driver);
			waitForLoading(sd.driver);
			String hardware[] = TVHardware.split(",");
			for (int i = 0; i < hardware.length; i++) {		
				ts.selectTVHardware(hardware[i]);
				if(hardware[i].contains("Flex Player Wireless 4K"))
					tvserialNumber = FakeHardwareGeneration.generateSerialNum("Xi6");
				else
					tvserialNumber = FakeHardwareGeneration.generateSerialNum(hardware[i]);
				ts.enterSerialNumber(tvserialNumber);
				ts.clickValidateButton();
				ExtentCucumberAdapter.addTestStepLog(hardware[i]+" serial number : " + tvserialNumber);
				ts.selectOkButton();
			}
		}
	}

	@And("^sets up appointment without technician$")
	public void setAppointmentdetails() throws Exception {
		utils =  new TestUtil(sd.driver);
		ap = new Appointments(sd.driver,this.scenario);
		ap.clickAppointmentlink();
		JavascriptExecutor js = (JavascriptExecutor) sd.driver;
		js.executeScript("window.scrollBy(0,-350)", "");
		ap.selectSelfConnectNo();			
		ap.dismissFFMIntegrationMessage();
		waitForLoading(sd.driver);
		ap.selectTechNotRequired();
		ap.setAuthorisedby();
		if (netcrackerUser.equals("sysadm")) {
			ap.setActivedirectory();
			Thread.sleep(2000);
		}
		isLoaderSpinnerVisible(sd.driver);	//AddedShweta
	}

	@And("^add agreement details (.*) (.*) (.*)$")
	public void addAgreementDetails(String methodOfConfirmation, String AcceptanceId, String proType)
			throws Exception {
		utils =  new TestUtil(sd.driver);
		ap = new Appointments(sd.driver,this.scenario);
		ap.methodOfConfirmationSelection(methodOfConfirmation);
		waitForLoading(sd.driver);
		ap.setAcceptanceId(AcceptanceId);
		if (proType.equalsIgnoreCase("ffm")) {
			as.clickAddServicesAndFeatures();
			as.clickDefaultInstallationFeeCheckbox();
		}

		if (configprop.getProperty("is_TV_Xi6", "false") == "true") {
			selectTVCheckboxTodoList();
		}

	}
	@And("^select Xi6 checkbox in todo list$")
	public void selectTVCheckboxTodoList() throws Exception {
		as.clickAddServicesAndFeatures();
		as.clickXi6Message();
	}

	@And("^navigates to review tab to select email order summary$")
	public void navigatesToReviewTab() throws Exception {
		rp = new ReviewPage(sd.driver);
		as = new AddServicesAndFeatures(sd.driver);
		rp.clickReviewTab();
		rp.setEmailOrderSummary();	
		as.checkTODOMessage();
	}

	@And("^navigates to FFM$")
	public void nvaigates_to_ffm_for_provisioning() throws Exception {
		//yamlDataReaderLevel1("ffm","ffmMobileLiteUri");
		String ffmurl = configprop.getProperty("ffmurl");
		utils =  new TestUtil(sd.driver);
		ffmPage=new FFMPage(sd.driver);
		utils.openUrlNewTab(ffmurl);
		ffmPage.updateActiveBranchId();
		ffmPage.orderSearch();
		ffmPage.enterWorkOrderNumber(workordernumber);
		ffmPage.clickSearchButton();
		ffmPage.clickActiveAccount();
	}


	@And("^submit order on finish tab and retrieves accountnumber$")
	public void submitOrder() throws Exception {
		fp = new FinishPage(sd.driver);
		fp.clickFinishTab();
		//		Thread.sleep(15000);			CommentedbyShweta 02/05
		accountnumber = fp.retrieveAccountnumber();
		Thread.sleep(2000);
		workordernumber = fp.retrieveworkOrderNumber();
		System.out.println(workordernumber);
		//addInfoInReport("Account Number: " + accountnumber + " # Work Order Number: " + workordernumber);
		ExtentCucumberAdapter.addTestStepLog("Account Number: " + accountnumber);
		ExtentCucumberAdapter.addTestStepLog("Work Order Number: " + workordernumber);
		//		TestBase.takeScreenshot("FinishPage");
	}
	//	
	
	@And ("^retrieve TPIA Account number$")
	public void retreivetpia() throws Exception{
		as= new AddServicesAndFeatures(sd.driver);
		tpiaaccountnumber = as.retrievtpiaacc();
		System.out.println(tpiaaccountnumber);
		
	}
	@And("^query cdi DB to retrieve accountid$")
	public void retriveAccIdFromCdi() throws InterruptedException {


		if (configprop.getProperty("CBSTOSTART", "no").equalsIgnoreCase("yes")) {
			Thread.sleep(10000);
		}

		if (prop.getProperty("matrix").equalsIgnoreCase("499")) {
			accountid = "1" + accountnumber;
			//addInfoInReport("Using stubbed implementation of accountid : " + accountid);
		} else {
			accountid = db.retrieveAccountId(accountnumber);
		}
		//		addInfoInReport("accountid : " + accountid);
		ExtentCucumberAdapter.addTestStepLog("AccountId : " + accountid);

	}

	@And("^query cdi DB to check pronounid$")
	public void checkPronouninCdi() throws InterruptedException {


		if (configprop.getProperty("CBSTOSTART", "no").equalsIgnoreCase("yes")) {
			Thread.sleep(10000);
		}

		if (prop.getProperty("matrix").equalsIgnoreCase("499")) {
			accountid = "1" + accountnumber;
			//addInfoInReport("Using stubbed implementation of accountid : " + accountid);
		} else {
			accountid = db.checkPronounID(accountnumber);
		}
		//		addInfoInReport("accountid : " + accountid);
		ExtentCucumberAdapter.addTestStepLog("AccountId : " + accountid);

	}

	//Added by Raj
	@And("^query cpe DB to retrieve devicerecord (.*)$")
	public void retrieveproptypeFromCpe(String serialnumber) throws InterruptedException {


		if (configprop.getProperty("CBSTOSTART", "no").equalsIgnoreCase("yes")) {
			Thread.sleep(10000);
		}


		if (prop.getProperty("matrix").equalsIgnoreCase("499")) {
			accountid = "1" + accountnumber;
			//addInfoInReport("Using stubbed implementation of accountid : " + accountid);
		} else {

			propreitortype = db.devicerecord(serialnumber);
		}
		//		addInfoInReport("accountid : " + accountid);
		ExtentCucumberAdapter.addTestStepLog("retrieveproptype : " + propreitortype);

	}

	@And("^query cpe DB to retrieve devicetable (.*)$")
	public void retrievedevicedetailFromCpe(String serialnumber) throws InterruptedException {


		if (configprop.getProperty("CBSTOSTART", "no").equalsIgnoreCase("yes")) {
			Thread.sleep(10000);
		}


		if (prop.getProperty("matrix").equalsIgnoreCase("499")) {
			accountid = "1" + accountnumber;
			//addInfoInReport("Using stubbed implementation of accountid : " + accountid);
		} else {

			audittype = db.equipedevicetable(serialnumber);
		}
		//		addInfoInReport("accountid : " + accountid);
		ExtentCucumberAdapter.addTestStepLog("retrieveproptype : " + audittype);

	}

	@Then("^Order status should be Completed in Overview Page$")
	public void validate_the_order_status_in_overview_page() throws InterruptedException, IOException {
		String overviewpage_url = HostUrls.getOverviewPageUrl();
		overviewpage = overviewpage_url + "&accountId=" + accountid;

		utils =  new TestUtil(sd.driver);

		utils.openUrlNewTab(overviewpage);

		if (prop.getProperty("waitForOrderCompletion", "true").equalsIgnoreCase("false")) {
			Thread.sleep(5000);
			//addInfoInReport("Not waiting for order completion in Overview Page. Skipping backend validations");
			return;
		}
		op = new OverviewPage(sd.driver, this.scenario);
		String orderStatus = op.retrieveOrderStatus();
		String expectedOrderStatus = "Completed";
		//		addInfoInReport("Order Status : " + orderStatus);
		ExtentCucumberAdapter.addTestStepLog("Order Status : " + orderStatus);
		Assert.assertEquals("Expected message is Completed",orderStatus, expectedOrderStatus);
	}

	@And("^Select account type as Staff and fills in the customer details with (.*) (.*) (.*) (.*) (.*)$")
	public void updateCustomerDetails(String firstName, String lastName, String email, String authType, String pin)
			throws Exception {
		utils =  new TestUtil(sd.driver);
		utils.openUrlNewTab(HostUrls.getOEUrl());
		cd = new CustomerDetails(sd.driver);
		cd.addStaffCustomer(firstName, lastName, email, authType, pin);


	}

	@And("^validate the order in DSA for (.*)$")
	public void validateDSA(String devices) throws IOException, SAXException, ParserConfigurationException {

		if (prop.getProperty("skipDSA", "false").equalsIgnoreCase("true")) {
			//addInfoInReport("skipDSA flag set true, skipping DSA Validation");
			return;
		}
		if (configprop.getProperty("environment", "non-timeshifter").equalsIgnoreCase("timeshifter")) {
			//addInfoInReport("DSA Validation not required for timeshifter");
			return;
		}
		if (prop.getProperty("waitForOrderCompletion", "true").equalsIgnoreCase("false")) {
			//addInfoInReport("Not waiting for order completion in Overview Page. Skipping backend validations");
			return;
		}
		String dsaDevices[] = devices.split(",");
		String macAddress = "";
		int dsaStatus;
		Hooks.setFileWriterExampleData(devices + " | ");
		for (int i = 0; i < dsaDevices.length; i++) {

			switch (dsaDevices[i].toUpperCase()) {
			case "HITRON":
				//				if (i == dsaDevices.length - 1)
				//					//Hooks.setFileWriterExampleData(serialNumberHitron + " | ");
				//				else
				//					//Hooks.setFileWriterExampleData(serialNumberHitron + ",");
				macAddress = FakeHardwareGeneration.generateMacAddress(serialNumberHitron, "docsys");
				if (macAddress.equals("200")) {
					ExtentCucumberAdapter.addTestStepLog("Error in fetching MacAddress");
					break;
				}

				dsaStatus = DSAValidation.validateDSA(macAddress);
				ExtentCucumberAdapter.addTestStepLog("dsa status : " + Integer.toString(dsaStatus));
				Assert.assertEquals(dsaStatus, 200);

				break;
			case "XB6":
				if (i == dsaDevices.length - 1)
					//Hooks.setFileWriterExampleData(serialNumberXB6 + " | ");
					System.out.println("XB6 DSA Validation");
				else
					//Hooks.setFileWriterExampleData(serialNumberXB6 + ",");
					macAddress = FakeHardwareGeneration.generateMacAddress(serialNumberXB6, "docsys");
				if (macAddress.equals("200")) {
					ExtentCucumberAdapter.addTestStepLog("Error in fetching MacAddress");
					break;
				}
				dsaStatus = DSAValidation.validateDSA(macAddress);
				ExtentCucumberAdapter.addTestStepLog("dsa status : " + Integer.toString(dsaStatus));
				Assert.assertEquals(dsaStatus, 200);

				break;
			case "XG1V4":
				//				if (i == dsaDevices.length - 1)
				//Hooks.setFileWriterExampleData(serialNumberXG1V4 + " | ");
				//else
				//Hooks.setFileWriterExampleData(serialNumberXG1V4 + ",");
				macAddress = FakeHardwareGeneration.generateMacAddress(serialNumberXG1V4, "docsys");
				if (macAddress.equals("200")) {
					ExtentCucumberAdapter.addTestStepLog("Error in fetching MacAddress");
					break;
				}
				dsaStatus = DSAValidation.validateDSA(macAddress);
				ExtentCucumberAdapter.addTestStepLog("dsa status : " + Integer.toString(dsaStatus));
				Assert.assertEquals(dsaStatus, 200);
				break;
			case "XID":
				//				if (i == dsaDevices.length - 1)
				//				//	Hooks.setFileWriterExampleData(serialNumberXiD + " | ");
				//				else
				//					Hooks.setFileWriterExampleData(serialNumberXiD + ",");
				macAddress = FakeHardwareGeneration.generateMacAddress(serialNumberXiD, "docsys");
				if (macAddress.equals("200")) {
					ExtentCucumberAdapter.addTestStepLog("Error in fetching MacAddress");
					break;
				}
				dsaStatus = DSAValidation.validateDSA(macAddress);
				ExtentCucumberAdapter.addTestStepLog("dsa status : " + Integer.toString(dsaStatus));
				Assert.assertEquals(dsaStatus, 200);
				break;
			case "DCX3200":
				ExtentCucumberAdapter.addTestStepLog("DSA not applicable for DCX3200");
				break;

			case "DCX3400":
				//				if (i == dsaDevices.length - 1)
				//					Hooks.setFileWriterExampleData(serialNumberDCX3400 + " | ");
				//				else
				//					Hooks.setFileWriterExampleData(serialNumberDCX3400 + ",");
				//ExtentCucumberAdapter.addTestStepLog("DSA not applicable for DCX3400");
				break;

			case "DCT700":
				//				if (i == dsaDevices.length - 1)
				//					Hooks.setFileWriterExampleData(serialNumberDCX3400 + " | ");
				//				else
				//					Hooks.setFileWriterExampleData(serialNumberDCX3400 + ",");
				//				//ExtentCucumberAdapter.addTestStepLog("DSA not applicable for DCX3400");
				break;

			case "DCX3510":
				//				if (i == dsaDevices.length - 1)
				//					Hooks.setFileWriterExampleData(serialNumberDCX3510 + " | ");
				//				else
				//					Hooks.setFileWriterExampleData(serialNumberDCX3510 + ",");
				macAddress = FakeHardwareGeneration.generateMacAddress(serialNumberDCX3510, "docsys");
				if (macAddress.equals("200")) {
					//	ExtentCucumberAdapter.addTestStepLog("Error in fetching MacAddress");
					break;
				}
				dsaStatus = DSAValidation.validateDSA(macAddress);
				//ExtentCucumberAdapter.addTestStepLog("dsa status : " + Integer.toString(dsaStatus));
				Assert.assertEquals(dsaStatus, 200);
				break;
			case "DPT":
				if (i == dsaDevices.length - 1)
					Hooks.setFileWriterExampleData(serialNumberDPT + " | ");
				else
					Hooks.setFileWriterExampleData(serialNumberDPT + ",");
				macAddress = FakeHardwareGeneration.generateMacAddress(serialNumberDPT, "docsys");
				if (macAddress.equals("200")) {
					//	ExtentCucumberAdapter.addTestStepLog("Error in fetching MacAddress");
					break;
				}
				dsaStatus = DSAValidation.validateDSA(macAddress);
				//ExtentCucumberAdapter.addTestStepLog("dsa status : " + Integer.toString(dsaStatus));
				Assert.assertEquals(dsaStatus, 200);
				break;
			case "XG1V3":
				//				if (i == dsaDevices.length - 1)
				//					Hooks.setFileWriterExampleData(serialNumberXG1V3 + " | ");
				//				else
				//					Hooks.setFileWriterExampleData(serialNumberXG1V3 + ",");
				macAddress = FakeHardwareGeneration.generateMacAddress(serialNumberXG1V3, "docsys");
				if (macAddress.equals("200")) {
					//	ExtentCucumberAdapter.addTestStepLog("Error in fetching MacAddress");
					break;
				}
				dsaStatus = DSAValidation.validateDSA(macAddress);
				//ExtentCucumberAdapter.addTestStepLog("dsa status : " + Integer.toString(dsaStatus));
				Assert.assertEquals(dsaStatus, 200);
				break;

			case "MOXIGATEWAY":
				//				if (i == dsaDevices.length - 1)
				//					Hooks.setFileWriterExampleData(serialNumberMoxiGateway + " | ");
				//				else
				//					Hooks.setFileWriterExampleData(serialNumberMoxiGateway + ",");
				macAddress = FakeHardwareGeneration.generateMacAddress(serialNumberMoxiGateway, "docsys");
				if (macAddress.equals("200")) {
					//ExtentCucumberAdapter.addTestStepLog("Error in fetching MacAddress");
					System.out.println("Error in fetching MacAddress");
					break;
				}
				dsaStatus = DSAValidation.validateDSA(macAddress);
				//ExtentCucumberAdapter.addTestStepLog("dsa status : " + Integer.toString(dsaStatus));
				Assert.assertEquals(dsaStatus, 200);
				break;
			}

		}
	}

	@And("^validate the order in CPE for (.*)$")
	public void validateCPE(String devices) throws IOException, SAXException, ParserConfigurationException {
		utils =  new TestUtil(sd.driver);

		if (prop.getProperty("skipCPE", "false").equalsIgnoreCase("true")) {
			//addInfoInReport("skipCPE flag set true, skipping CPE Validation");
			return;
		}

		if (prop.getProperty("waitForOrderCompletion", "true").equalsIgnoreCase("false")) {
			//addInfoInReport("Not waiting for order completion in Overview Page. Skipping backend validations");
			return;
		}

		String cpeDevices[] = devices.split(",");
		String cpeStatus = "";
		for (int i = 0; i < cpeDevices.length; i++) {

			switch (cpeDevices[i].toUpperCase()) {
			case "HITRON":
				cpeStatus = CPEValidation.validateCPE(serialNumberHitron);
				ExtentCucumberAdapter.addTestStepLog("cpe status : " + cpeStatus);
				Assert.assertEquals("True",cpeStatus);
				break;
			case "XB6":
				cpeStatus = CPEValidation.validateCPE(serialNumberXB6);
				ExtentCucumberAdapter.addTestStepLog("cpe status : " + cpeStatus);
				Assert.assertEquals("True",cpeStatus);
				break;
			case "XG1V4":
				cpeStatus = CPEValidation.validateCPE(serialNumberXG1V4);
				ExtentCucumberAdapter.addTestStepLog("cpe status : " + cpeStatus);
				Assert.assertEquals("True",cpeStatus);
				break;
			case "XID":
				cpeStatus = CPEValidation.validateCPE(serialNumberXiD);
				ExtentCucumberAdapter.addTestStepLog("cpe status : " + cpeStatus);
				Assert.assertEquals("True",cpeStatus);
				break;
			case "DCX3200":
				cpeStatus = CPEValidation.validateCPE(serialNumberDCX3200);
				ExtentCucumberAdapter.addTestStepLog("cpe status : " + cpeStatus);
				Assert.assertEquals("True",cpeStatus);
				break;
			case "DCX3510":
				cpeStatus = CPEValidation.validateCPE(serialNumberDCX3510);
				ExtentCucumberAdapter.addTestStepLog("cpe status : " + cpeStatus);
				Assert.assertEquals("True",cpeStatus);
				break;
			case "DPT":
				cpeStatus = CPEValidation.validateCPE(serialNumberDPT);
				ExtentCucumberAdapter.addTestStepLog("cpe status : " + cpeStatus);
				Assert.assertEquals("True",cpeStatus);
				break;
			case "XG1V3":
				cpeStatus = CPEValidation.validateCPE(serialNumberXG1V3);
				ExtentCucumberAdapter.addTestStepLog("cpe status : " + cpeStatus);
				Assert.assertEquals("True",cpeStatus);
				break;
			case "DCX3400":
				cpeStatus = CPEValidation.validateCPE(serialNumberDCX3400);
				ExtentCucumberAdapter.addTestStepLog("cpe status : " + cpeStatus);
				Assert.assertEquals("True",cpeStatus);
				break;

			}
		}
	}


	@Then("^validate in UIR for (.*)$")
	public void SPSDEL_validation(String lobs) throws InterruptedException, IOException {
		utils =  new TestUtil(sd.driver);

		if (prop.getProperty("skipUIR", "false").equalsIgnoreCase("true")) {
			//addInfoInReport("skipUIR flag set true, skipping UIR Validation");
			return;
		}
		if (System.getProperty("environment", "non-timeshifter").equalsIgnoreCase("timeshifter")) {
			//addInfoInReport("UIR Validation not required for timeshifter");
			return;
		}

		if (prop.getProperty("waitForOrderCompletion", "true").equalsIgnoreCase("false")) {
			//addInfoInReport("Not waiting for order completion in Overview Page. Skipping backend validations");
			return;
		}
		String lineOfBusinuss[] = lobs.split(",");
		for (int i = 0; i < lineOfBusinuss.length; i++) {
			Hooks.setFileWriterExampleData(lineOfBusinuss[i] + " | ");
		}
		boolean UIRValidation = SPSDELValidation.spsdelValidation(accountnumber, lobs);
		Assert.assertEquals(String.valueOf(UIRValidation), "true", "UIR Validation failed");
	}

	@Given("^Read account number (.*)$")
	public void readAccountNum(String accNumber) {
		accountnumber = accNumber;
		if (!prop.getProperty("accountnumber", "999999999").equalsIgnoreCase("999999999")) {
			accountnumber = TestBase.prop.getProperty("accountnumber");
		}
	}

	@Given("^Read work order number (.*)$")
	public void readWorkOrderNumber(String workOrderNumber) {
		workordernumber = workOrderNumber;
	}

	@And("^validate in FDB for (.*)$")
	public void checkFDBStatus(String devices)
			throws InterruptedException, IOException, SAXException, ParserConfigurationException {
		//utils =  new TestUtil(sd.driver);

		fdb = new FDBValidation(sd.driver);
		if (prop.getProperty("skipFDB", "false").equalsIgnoreCase("true")) {
			//addInfoInReport("skipFDB flag set true, skipping FDB Validation");
			return;
		}

		if (configprop.getProperty("environment", "non-timeshifter").equalsIgnoreCase("timeshifter")) {
			//addInfoInReport("FDB Validation not required for timeshifter");
			return;
		}

		if (prop.getProperty("waitForOrderCompletion", "true").equalsIgnoreCase("false")) {
			//addInfoInReport("Not waiting for order completion in Overview Page. Skipping backend validations");
			return;
		}
		boolean fdb_validation_required = true;
		String macAddress = "";
		String fdbUrl = "";
		String deviceStatusFDB = "";
		for (String ldevice : devices.toUpperCase().split(",")) {
			switch (ldevice) {
			case "HITRON":
				macAddress = FakeHardwareGeneration.generateMacAddress(serialNumberHitron, "docsys");
				break;
			case "XB6":
				macAddress = FakeHardwareGeneration.generateMacAddress(serialNumberXB6, "docsys");
				break;
			case "XG1V4":
				macAddress = FakeHardwareGeneration.generateMacAddress(serialNumberXG1V4, "docsys");
				break;
			default:
				fdb_validation_required = false;
				ExtentCucumberAdapter.addTestStepLog("FDB not applicable for " + ldevice);
				break;
			}

			if (fdb_validation_required) {
				fdbUrl = (HostUrls.getFDBUrl()) + macAddress;
				//addURLInReport(fdbUrl, "FDBPage");
				utils =  new TestUtil(sd.driver);
				utils.openUrlNewTab(fdbUrl);
				Thread.sleep(2000);
				fdb.loginToFDB();
				deviceStatusFDB = fdb.getdeviceStatus();
				ExtentCucumberAdapter.addTestStepLog("FDB Status: " + deviceStatusFDB);
				//TestBase.takeScreenshot("FDBPage");
				Assert.assertEquals(deviceStatusFDB, "ENABLED", "FDB Status");
			}
		}
	}


	@And("^validate in XRay for (.*)$")
	public void xrayValidation(String devices) throws InterruptedException, IOException {
		utils =  new TestUtil(sd.driver);
		xray = new XRAYValidation(sd.driver);

		if (prop.getProperty("skipXRAY", "false").equalsIgnoreCase("true")) {
			//addInfoInReport("skipXRAY flag set true, skipping XRAY Validation");
			return;
		}
		if (prop.getProperty("waitForOrderCompletion", "true").equalsIgnoreCase("false")) {
			//addInfoInReport("Not waiting for order completion in Overview Page. Skipping backend validations");
			return;
		}

		List<String> XRayDevices = Arrays.asList(new String[] { "XB6" });

		if (prop.getProperty("realDevice", "false").equalsIgnoreCase("true")) {
			XRayDevices.addAll(Arrays.asList(new String[] { "Xi6", "XiD", "XG1v3", "XG1v4" }));
		}

		boolean add_url_in_report = true;
		for (String xray_device : devices.split(",")) {
			if (XRayDevices.stream().anyMatch(xray_device::equalsIgnoreCase)) {
				utils.openUrlNewTab(HostUrls.getXRAYUrl());

				if (add_url_in_report) {
					//addURLInReport("XRay URL");
					add_url_in_report = false;
				}

				xray.validatingXRAY(accountnumber);
				String deviceStatus_XRay = xray.validateDeviceStatus();
				//addInfoInReport("XRay Validation for " + xray_device + " : " + deviceStatus_XRay);
				//TestBase.takeScreenshot("XRAY");
				Assert.assertEquals(deviceStatus_XRay, "Enabled",
						"XRay Validation for " + xray_device + " = " + deviceStatus_XRay);
			} else {
				//addInfoInReport("XRay Validation is not applicable for " + xray_device);
			}
		}
	}

	@And("^premise move within province$")
	public void premisemove() throws InterruptedException {
		utils =  new TestUtil(sd.driver);

		String moe_url = HostUrls.getMOEUrl();
		String premisemove_url = moe_url + "&accountId=" + accountid + "&newLocationId="
				+ prop.getProperty("premisemovelocationid");
		utils.openUrlNewTab(premisemove_url);
		Thread.sleep(12000);

	}

	@And("^modify the account to disconnect during premise move (.*)$")
	public void disconnectServicesPremiseMove(String services) throws Exception {

		utils =  new TestUtil(sd.driver);
		ps=new PhoneServices(sd.driver);
		ds = new DisconnectServicesPage(sd.driver);
		String service[] = services.split(",");
		for (int i = 0; i < service.length; i++) {
			//			Thread.sleep(4000);
			switch (service[i].toUpperCase()) {
			case "INTERNETXB6":
				ds.disconnectInternet();
				Thread.sleep(2000);
				ds.deleteXB6();
				Thread.sleep(2000);
				ds.productRemovalConfirm();
				break;
			case "INTERNET":
				ds.disconnectInternet();
				//				Thread.sleep(2000);
			case "TV":
				ds.disconnectTv();
				break;
			case "PHONE":
				if (prop.getProperty("disablePhoneSteps", "false").equalsIgnoreCase("false")) {
					ps.E911Supression();
					ds.disconnectPhone();
					ds.selectPortNumberWarningMessage();
					break;
				}
			}
		}
	}

	@And("^sets up premise move date$")
	public void setPremiseMoveDate() throws Exception {
		utils =  new TestUtil(sd.driver);

		ap = new Appointments(sd.driver,this.scenario);
		//		Thread.sleep(2000);
		ap.clickAppointmentlink();
		//		JavascriptExecutor js = (JavascriptExecutor) sd.driver;
		//		js.executeScript("window.scrollBy(0,-350)", "");
		//		Thread.sleep(5000);
		ap.selectSelfconnect();
		ap.dismissFFMIntegrationMessage();
		ap.selectExisitingHardware();
		ap.setAuthorisedby();
		if (netcrackerUser.equals("sysadm")) {
			ap.setActivedirectory();
			Thread.sleep(2000);
		}
	}

	@And("^select the disconnection reason$")
	public void disconnectionReason() throws InterruptedException {
		utils =  new TestUtil(sd.driver);

		ap = new Appointments(sd.driver,this.scenario);
		ap.setDisconnectionReason();
	}
	@And("^set the disconnection reason in webud	(.*)	(.*)$")
	public void setdisconnectionReason(String reasonCategory, String reason) throws Exception {
		ap = new Appointments(sd.driver,this.scenario);
		ap.selectDisconnectionReason(reasonCategory, reason);
	}	
	@Then("^Order status should be Completed in Overview Page at premisemovelocationid$")
	public void orderStatusPremiseMove() throws IOException, InterruptedException {
		String OverviewpageUrl = HostUrls.getPremiseMoveOverviewUrl();
		String premiseMoveLocationId = prop.getProperty("premisemovelocationid");

		String premiseMoveOverviewpageUrl = OverviewpageUrl + premiseMoveLocationId + "&accountId=" + accountid;

		utils.openUrlNewTab(premiseMoveOverviewpageUrl);
		String orderStatus = op.retrieveOrderStatus();
		String expectedOrderStatus = "Completed";
		//ExtentCucumberAdapter.addTestStepLog(orderStatus);
		Assert.assertEquals(orderStatus, expectedOrderStatus, "Expected message is Completed");
	}
	@And("^selects Employee TV service with (.*) (.*)$")
	public void selectsEmployeeTvService(String TVHardware, String technicianAppointment)
			throws Exception {

		utils =  new TestUtil(sd.driver);
		ts = new TVServices(sd.driver);
		// ts.selectLimitedTV();
		//		Thread.sleep(6000);
		//		ts.selectFlexTV();
		// ts.selectTotalTV();
		// Thread.sleep(2000);
		ts.selectEmployeeTV();
		ts.selectTvWrench();
		Thread.sleep(5000);
		String hardware[] = TVHardware.split(",");
		for (int i = 0; i < hardware.length; i++) {
			switch (hardware[i].toUpperCase()) {
			case "FLEXXI6":
				Thread.sleep(2000);
				ts.selectFlexXi6();
				if (technicianAppointment.equals("techNotRequired")) {
					serialNumberXi6 = FakeHardwareGeneration.generateSerialNum("XI6");
					ts.enterSerialNumber(serialNumberXi6);
					ts.clickValidateButton();
					//addInfoInReport("Xi6 serial number : " + serialNumberXi6);
					//ExtentCucumberAdapter.addTestStepLog("Xi6 serial number : " + serialNumberXi6);
				}
				break;
			case "XG1V4":
				Thread.sleep(2000);
				ts.selectXg1v4();
				if (technicianAppointment.equals("techNotRequired")) {
					serialNumberXG1V4 = FakeHardwareGeneration.generateSerialNum("XG1V4");
					// serialNumberXG1V4 = "M11821TRC722";
					ts.enterSerialNumber(serialNumberXG1V4);
					ts.clickValidateButton();
					//addInfoInReport("XG1V4 serial number : " + serialNumberXG1V4);
					//ExtentCucumberAdapter.addTestStepLog("XG1V4 serial number : " + serialNumberXG1V4);
				}
				break;
			case "XG1V3":
				Thread.sleep(2000);
				ts.selectXG1V3();
				Thread.sleep(2000);
				if (technicianAppointment.equals("techNotRequired")) {
					serialNumberXG1V3 = FakeHardwareGeneration.generateSerialNum("XG1V3");
					ts.enterSerialNumber(serialNumberXG1V3);
					ts.clickValidateButton();
					//addInfoInReport("XG1V3 serial number : " + serialNumberXG1V3);
					//ExtentCucumberAdapter.addTestStepLog("XG1V3 serial number : " + serialNumberXG1V3);
				}
				break;
			case "XI6":
				prop.setProperty("is_TV_Xi6", "true");
				Thread.sleep(5000);
				ts.selectXi6();
				if (technicianAppointment.equals("techNotRequired")) {
					serialNumberXi6 = FakeHardwareGeneration.generateSerialNum("XI6");
					ts.enterSerialNumber(serialNumberXi6);
					ts.clickValidateButton();
					//					addInfoInReport("Xi6 serial number : " + serialNumberXi6);
					//					ExtentCucumberAdapter.addTestStepLog("Xi6 serial number : " + serialNumberXi6);
				}
				break;

			case "SHAWMOXIGATEWAY":
				Thread.sleep(2000);
				ts.selectShawMoxiGateway();
				if (technicianAppointment.equals("techNotRequired")) {
					serialNumberMoxiGateway = FakeHardwareGeneration.generateSerialNum("SHAWMOXIGATEWAY");
					ts.enterSerialNumber(serialNumberMoxiGateway);
					ts.clickValidateButton();
					//					addInfoInReport("Moxi Gateway serial number : " + serialNumberMoxiGateway);
					//					ExtentCucumberAdapter.addTestStepLog("Moxi Gateway serial number : " + serialNumberMoxiGateway);
				}
				break;
			case "SHAWPORTAL":
				ts.selectShawMoxiPortal();
				break;
			case "XID":
				Thread.sleep(2000);
				ts.selectXid();
				Thread.sleep(2000);
				if (technicianAppointment.equals("techNotRequired")) {
					serialNumberXiD = FakeHardwareGeneration.generateSerialNum("XID");

					// serialNumberXiD = "PAY300050994";
					ts.enterSerialNumber(serialNumberXiD);
					ts.clickValidateButton();
					//					addInfoInReport("XiD serial number : " + serialNumberXiD);
					//					ExtentCucumberAdapter.addTestStepLog("XiD serial number : " + serialNumberXiD);
				}
				break;
			case "DCX3510":
				ts.selectDCX3510();
				if (technicianAppointment.equals("techNotRequired")) {
					serialNumberDCX3510 = FakeHardwareGeneration.generateSerialNum("DCX3510");
					ts.enterSerialNumber(serialNumberDCX3510);
					ts.clickValidateButton();
					//					addInfoInReport("DCX3510 serial number : " + serialNumberDCX3510);
					//					ExtentCucumberAdapter.addTestStepLog("DCX3510 serial number : " + serialNumberDCX3510);
				}
				break;
			case "DCT700":
				Thread.sleep(2000);
				ts.selectDCT700();
				if (technicianAppointment.equals("techNotRequired")) {
					serialNumberDCT700 = FakeHardwareGeneration.generateSerialNum("DCT700");
					ts.enterSerialNumber(serialNumberDCT700);
					ts.clickValidateButton();
					//					addInfoInReport("DCT700 serial number : " + serialNumberDCT700);
					//					ExtentCucumberAdapter.addTestStepLog("DCT700 serial number : " + serialNumberDCT700);
				}
				break;
			case "DCX3400":
				Thread.sleep(2000);
				ts.selectDCX3400();
				if (technicianAppointment.equals("techNotRequired")) {
					serialNumberDCX3400 = FakeHardwareGeneration.generateSerialNum("DCX3400");
					ts.enterSerialNumber(serialNumberDCX3400);
					ts.clickValidateButton();
					//					addInfoInReport("DCX3400 serial number : " + serialNumberDCX3400);
					//					ExtentCucumberAdapter.addTestStepLog("DCX3400 serial number : " + serialNumberDCX3400);
				}
				break;
			case "DCX3200":
				ts.selectDCX3200();
				Thread.sleep(2000);
				if (technicianAppointment.equals("techNotRequired")) {
					serialNumberDCX3200 = FakeHardwareGeneration.generateSerialNum("DCX3200");
					ts.enterSerialNumber(serialNumberDCX3200);
					ts.clickValidateButton();
					//					addInfoInReport("DCX3200 serial number : " + serialNumberDCX3200);
					//					ExtentCucumberAdapter.addTestStepLog("DCX3200 serial number : " + serialNumberDCX3200);
				}
				break;

			case "XIONE":
				ts.selectXiOne();
				Thread.sleep(2000);
				if (technicianAppointment.equals("techNotRequired")) {
					serialNumberXiOne = FakeHardwareGeneration.generateSerialNum("XIONE");
					ts.enterSerialNumber(serialNumberXiOne);
					ts.clickValidateButton();
					//					addInfoInReport("XIone serial number : " + serialNumberXiOne);
					Hooks.setFileWriter("XIone serial number : " + serialNumberXiOne);
				}
				break;
			}
		}
		Thread.sleep(2000);
		ts.selectOkButton();
	}

	@And("^navigates to modify OE page$")
	public void navigatestomodifyOEpage() throws IOException, InterruptedException {
		utils =  new TestUtil(sd.driver);

		String moe_url = HostUrls.getMOEUrl() + "&accountId=" + accountid;
		utils.openUrlNewTab(moe_url);
		//TestBase.takeScreenshot("Modify OE");
	}

	@And("^Add TV channels (.*)$")
	public void addChannels(String channelSet) throws Exception {
		ts = new TVServices(sd.driver);
		ts.selectDigitalChannelWrench();
		//		Thread.sleep(2000);
		ts.addChannels(channelSet);
	}

	@And("^open order in overview page$")
	public void openOrderInOverviewPage() throws IOException, InterruptedException {
		String overviewpage_url = HostUrls.getOverviewPageUrl();
		overviewpage = overviewpage_url + "&accountId=" + accountid;
		System.out.println(overviewpage);
		utils =  new TestUtil(sd.driver);
		op = new OverviewPage(sd.driver, this.scenario);
		utils.openUrlNewTab(overviewpage);
	}


	@And("^Fill device in hardware for retail pickup page (.*) (.*) (.*)$")
	public void retailPickUpActivation(String type, String Hardware, String Scenario)
			throws Exception {
		utils =  new TestUtil(sd.driver);
		//		Thread.sleep(10000);
		op = new OverviewPage(sd.driver, this.scenario);
		op.overviewHardTab();
		String hardware[] = Hardware.split(",");
		if (!Scenario.equalsIgnoreCase("Cancel")) {
			for (int i = 0; i < hardware.length; i++) {
				//				Thread.sleep(10000);
				switch (hardware[i].toUpperCase()) {
				case "XB6":
					serialNumberXB6 = FakeHardwareGeneration.generateSerialNum("XB6");
					op.xB6serNum(serialNumberXB6);
					System.out.println(serialNumberXB6);
					break;
				case "XB7":
					serialNumberXB7 = FakeHardwareGeneration.generateSerialNum("XB7");
					op.xB7serNum(serialNumberXB7);
					System.out.println(serialNumberXB7);
					break;
				case "XB8":
					serialNumberXB8 = FakeHardwareGeneration.generateSerialNum("XB8");
					op.xB8serNum(serialNumberXB8);
					System.out.println(serialNumberXB8);
					break;
				case "DCX3400":
					serialNumberDCX3400 = FakeHardwareGeneration.generateSerialNum("DCX3400");
					op.dCXserNum(serialNumberDCX3400);
					System.out.println(serialNumberDCX3400);
					break;
				case "XPOD":
					String Xpod1Num = FakeHardwareGeneration.generateSerialNum("SAGEMCOMXPOD");
					String Xpod2Num = FakeHardwareGeneration.generateSerialNum("SAGEMCOMXPOD");
					String Xpod3Num = FakeHardwareGeneration.generateSerialNum("SAGEMCOMXPOD");
					op.XPOD_serNum(Xpod1Num, Xpod2Num, Xpod3Num);
					//					addInfoInReport("XPOD1 Serial numbers: " + Xpod1Num);
					//					addInfoInReport("XPOD2 Serial numbers: " + Xpod2Num);
					//					addInfoInReport("XPOD3 Serial numbers: " + Xpod3Num);
					Thread.sleep(2000);
					break;
				case "XI6":
					serialNumberXi6 = FakeHardwareGeneration.generateSerialNum("XI6");
					op.Xi6serNum(serialNumberXi6);
					System.out.println(serialNumberXi6);
					break;
				case "DPT":
					serialNumberDPT = FakeHardwareGeneration.generateSerialNum("DPT");
					op.DPTserNum(serialNumberDPT);
					System.out.println(serialNumberDPT);
					break;
				case "HITRON":
					serialNumberHitron = FakeHardwareGeneration.generateSerialNum("HITRON");
					op.HitronserNum(serialNumberHitron);
					System.out.println(serialNumberHitron);
					break;
				}
			}
		}
		op.submitButton();
		Thread.sleep(10000);

		if (type.equals("Manual")) {
			op.ProductSummary();

			op.ConfirmActivate();
		}
		//TestBase.takeScreenshot("ActivationPage");
	}

	@And("^navigates to appointment tab$")
	public void navigatesToAppointmentTab() throws Exception {
		ap = new Appointments(sd.driver,this.scenario);
		ap.clickAppointmentlink();
	}

	@And("^sets up a selfinstall appointment type as (.*)	(.*)$")
	public void setAppointmentdetailsnew(String appointmentType, String address) throws Exception {
		ap = new Appointments(sd.driver,this.scenario);
		ap.clickAppointmentlink();
		ap.selectSelfconnect();
		switch (appointmentType.toUpperCase()) {
		case "DIRECTFULFILLMENT":
			ap.selectDirectFulfillmentMailOut();

			if (!(prop.getProperty("environment", "non-timeshifter").equalsIgnoreCase("timeshifter"))) {
				ap.enterDFAddress();
			}
			ap.selectServiceLocationCheckbox();
			ap.selectcustomerOptOutCheckbox();
			break;
		case "RETAILPICKUP":
			ap.selectRetailPickup();
			ap.selectRetailPickupAddress(address);
			break;
		case "EXISTINGHW":
			ap.selectExisitingHardware();
			break;
		case "SHAWDELIVERY":
			ap.selectShawDelivery();
			waitForLoading(sd.driver);
			ap.dismissFFMIntegrationMessage();
			ap.selectSMSNumberOptedOut();
			Thread.sleep(2000);
			ap.selectforceappointment();
			break;
		}
		ap.setAuthorisedby();
		ap.setActivedirectory();
	}


	@And("^modify the account to suspend the (.*)$")
	public void modify_account_to_suspend_services(String serviceTypes) throws Exception {
		snowbird= new SnowbirdSuspendResumePage(sd.driver);
		String service[] = serviceTypes.split(",");
		String moe = HostUrls.getMOEUrl();
		String moe_url = moe + "&accountId=" + accountid;
		utils = new TestUtil(sd.driver);
	//	utils.openUrlNewTab(moe_url);
		//		Thread.sleep(3000);
		snowbird.clickOperationsTab();
		//		Thread.sleep(2000);
		snowbird.selectSnowBird();
		//		Thread.sleep(2000);
		snowbird.selectTcisCheckbox();
		//		Thread.sleep(2000); 
		snowbird.selectSuspendStartDateCalendar();
		//		Thread.sleep(2000);
		snowbird.selectSuspendStartDate();
		//		Thread.sleep(2000);
		snowbird.selectSuspendEndDateCalendar();
				Thread.sleep(2000);
		snowbird.selectNextMonth();
		//		Thread.sleep(2000);
		snowbird.selectSuspendEndDate();
		//		Thread.sleep(2000);
		snowbird.clickSuspendOkButton();
		//		Thread.sleep(2000);
		for (int i = 0; i < service.length; i++) {
			//		Thread.sleep(4000);
			switch (service[i].toUpperCase()) {
			case "INTERNET":
				snowbird.selectSuspendInternet();
				//		Thread.sleep(2000);
				break;
			case "TV":
				snowbird.selectSuspendTv();
				//		Thread.sleep(2000);
				break;
			case "PHONE":
				snowbird.selectsuspendphone();
				//		Thread.sleep(2000);
				break;
			}
		}
		rp = new ReviewPage(sd.driver);
		as = new AddServicesAndFeatures(sd.driver);
		as.addinstallationfee();
		//		Thread.sleep(2000);
		rp.clickReviewTab();
		//		Thread.sleep(2000);
		//TestBase.takeScreenshot("reviewpage");
		rp.setEmailOrderSummary();
		//		Thread.sleep(2000);		

	}

	@And("^modify the account to (.*) the	(.*)	(.*)	in webUD$")
	public void modify_account_to_suspend_servicesinWebUD(String operation_suspendresume, String serviceTypes, String dayOfMonth) throws Exception {
		snowbird= new SnowbirdSuspendResumePage(sd.driver);
		String service[] = serviceTypes.split(",");
		snowbird.clickOperationsTab();
		snowbird.selectSnowBird();
		snowbird.selectTcisCheckbox();
		if(operation_suspendresume.contains("suspend")) {
			snowbird.selectSuspendStartDateCalendar();
			snowbird.selectSuspendStartDate();
			snowbird.selectFutureSuspendDate(dayOfMonth);}
		else if(operation_suspendresume.contains("resume")){
			snowbird.selectSuspendEndDateCalendar();
			snowbird.selectResumeDate();}
		snowbird.clickSuspendOkButton();
		waitForLoading(sd.driver);	
		isLoaderSpinnerVisible(sd.driver);	//AddedShweta
				for (int i = 0; i < service.length; i++) {
				switch (service[i].toUpperCase()) {
				case "INTERNET":
				snowbird.selectSuspendInternet();
				break;
				case "TV":
				snowbird.selectSuspendTv();
				break;
				case "PHONE":
				snowbird.selectsuspendphone();
				break;
				}
				}		
		as = new AddServicesAndFeatures(sd.driver);
		as.addinstallationfee();
	}



	@And("^update phone number in customer details$")
	public void updatePhoneinCustomerDetails() throws Exception {

		cd = new CustomerDetails(sd.driver);
		isLoaderSpinnerVisible(sd.driver);
		waitForLoading(sd.driver);		
		cd.clickCustomerAndIdTab();
		cd.selectPrimaryContactType("Other");
		cd.setPhoneNumber();
		//		cd.setEmailAddress("shweta.paliwal@sjrb.ca");
		//		cd.customerOptOutMobileNumber();
	}
	@And("^select billing preferences$")
	public void selectBillingPrefernces() throws Exception
	{
		billingpage= new BillingPreferncesPage(sd.driver, this.scenario);
		waitForLoading(sd.driver);
		billingpage.clickBillingPreferenceTab();
		waitForLoading(sd.driver);
		billingpage.selectMailingAddress();
		waitForLoading(sd.driver);
		billingpage.selectpaperbill();
	}
	@And("^selects Customer and ID tab$")
	public void selectsCustomerandIDtab() throws Exception {	
		cd = new CustomerDetails(sd.driver);
		isLoaderSpinnerVisible(sd.driver);
		waitForLoading(sd.driver);		
		cd.clickCustomerAndIdTab();
	}	
	@And("^set auth by$")
	public void setAuthBy() throws Exception {

		ap = new Appointments(sd.driver,this.scenario);
		//		Thread.sleep(4000);
		ap.clickAppointmentlink();
		//		Thread.sleep(4000);
		ap.setAuthorisedby();
		//		Thread.sleep(2000);
	}


	@And("^open accountnumber in Netcracker and retrieve account id$")
	public void openAccountnumberInNetcrackerAndRetrieveAccountId() throws Exception {
		String matrix = configprop.getProperty("environment");
		utils = new TestUtil(sd.driver);
		orderMgm = new OrderManagement(sd.driver);
		if (matrix.toLowerCase().equals("timeshifter")) {
			String ordermanagement_url = HostUrls.getOMUrl("stub");
			utils.openUrlNewTab(ordermanagement_url);
			Thread.sleep(2000);
			orderMgm.AccountIconFilterBtn();
			Thread.sleep(2000);
			orderMgm.EnterAccountNum(accountnumber);
			Thread.sleep(2000);
			orderMgm.AccountNumLink();
			Thread.sleep(2000);
			accountid = orderMgm.RetrieveTimeshiftAccId();

		} else if (matrix.toLowerCase().equals("non-timeshifter")) {
			String ordermanagement_url = HostUrls.getOMUrl("integrated");
			utils.openUrlNewTab(ordermanagement_url);
			orderMgm.enterAccountNumber(accountnumber);
			Thread.sleep(20000);
			orderMgm.accountSearch();
			accountid = orderMgm.RetrieveAccId();
		} else {
			String ordermanagement_url = HostUrls.getOMUrl("preprod");
			utils.openUrlNewTab(ordermanagement_url);
			orderMgm.enterAccountNumber(accountnumber);
			Thread.sleep(40000);
			orderMgm.accountSearch();
			accountid = orderMgm.RetrieveAccId();
		}
		//addInfoInReport("AccountId : " + accountid);
		ExtentCucumberAdapter.addTestStepLog("AccountId : " + accountid);
	}

	@And("^navigates to suspension history to validate the suspend status$")
	public void navigates_to_suspension_history() throws Exception {
		ncSusHistoryPage= new NetCrackerSuspensionHistoryPage(sd.driver);
		ncSusHistoryPage.suspensionHistory();
		ncSusHistoryPage.validateSuspensionStatus();
		//TestBase.takeScreenshot("suspensionHistory");

	}

	@And("^retrieves workordernumber$")
	public void retrievesworkordernumber() throws Exception {
		//ageobjmanager = new pageObjectManager(driver);
		fp = new FinishPage(sd.driver);
		workordernumber = fp.retrieveworkOrderNumber();
	}
	@And("^remove xpod$")
	public void removeXpods() throws Exception {
		is.deleteXpod();
	}

	@And("^remove TV channels (.*)$")
	public void removeChannels(String channelSet) throws Exception {
		ts = new TVServices(sd.driver);
		ts.selectDigitalChannelWrench();
		//		Thread.sleep(2000);
		ts.addChannels(channelSet);
	}

	@And("^navigates to billing tab to select mailing address$")
	public void selectMailingAddress() throws Exception {
		billingpage= new BillingPreferncesPage(sd.driver, this.scenario);
		billingpage.clickBillingPreferenceTab();
		Thread.sleep(4000);
		billingpage.selectMailingAddress();
		//		pageObjManager.billingpreferncespage().selectMailingAddress();
	}

	@And("^selects xpods and enter serial numbers$")
	public void selectsXpods() throws Exception {
		is = new InternetServices(sd.driver);
		String Xpod1Num = FakeHardwareGeneration.generateSerialNum("SAGEMCOMXPOD");
		String Xpod2Num = FakeHardwareGeneration.generateSerialNum("SAGEMCOMXPOD");
		String Xpod3Num = FakeHardwareGeneration.generateSerialNum("SAGEMCOMXPOD");
		is.AddXpod(Xpod1Num, Xpod2Num, Xpod3Num);
		//addInfoInReport("XPOD1 Serial numbers: " + Xpod1Num);
		//addInfoInReport("XPOD2 Serial numbers: " + Xpod2Num);
		//addInfoInReport("XPOD3 Serial numbers: " + Xpod3Num);
	}

	@And("^validate the active directory id$")
	public void validateactivedirectory() throws Exception {
		ap = new Appointments(sd.driver,this.scenario);
		ap.clickAppointmentlink();
		ap.setAuthorisedby();
		ap.setActivedirectory();

	}

	@And("^activate device in overviewpage$")
	public void activateDeviceInOverviewPage() throws Exception {
		op = new OverviewPage(sd.driver, this.scenario);
		//		Thread.sleep(10000);
		op.ConfirmActivate();
		//		Thread.sleep(3000);
		//TestBase.takeScreenshot("ActivatingDevice");
	}

	@And("^write spsdel response xml$")
	public void writeSpsdelResponse() throws IOException {
		SPSDELValidation.spsdelResponseXML(accountnumber);
	}

	@And("^selects internetService for directFulfilment(.*)$")
	public void selectsInternetServiceForDF(String internetService) throws IOException, InterruptedException {
		is =new InternetServices(sd.driver);
		is.selectInternetPackage(internetService);
	}

	@And("^selects TV service for DirectFulfilment (.*)$")
	public void selectsTVserviceForDF(String TVHardware) throws Exception {
		ts =new TVServices(sd.driver);
		Thread.sleep(2000);
		//		ts.selectSmallTVPrebuilt();
		ts.selectIgniteTotalTV();
		//ts.selectTotalTV();
		ts.selectTvWrench();
		String hardware[] = TVHardware.split(",");

		for (int i = 0; i < hardware.length; i++) {
			switch (hardware[i].toUpperCase()) {

			case "DCX3510":
				ts.selectDCX3510();
				Thread.sleep(3000);
				break;
			case "DCX3400":
				ts.selectDCX3400();
				Thread.sleep(2000);
				break;
			case "XI6":
				ts.selectXi6();
				Thread.sleep(2000);
				break;
			case "XG1V3":
				ts.selectXG1V3();
				break;
			case "XG1V4":
				ts.selectXg1v4();
				break;
			case "SHAWMOXIGATEWAY":
				Thread.sleep(2000);
				ts.selectShawMoxiGateway();
				break;
			case "DCX3200":
				ts.selectDCX3200();
				break;
			case "XID":
				ts.selectXid();
				Thread.sleep(2000);
			case "DCT700":
				ts.selectDCT700();
				Thread.sleep(2000);
			}
		}
		Thread.sleep(2000);
		ts.selectOkButton();
	}


	@And("^navigates to netcracker to complete directfulfillment shipping task (.*)$")
	public void CompleteDirectFulfillmentShippingTask(String hardwaremodelname)
			throws Exception {
		utils = new TestUtil(sd.driver);

		ncdfShippingpage= new NetcrackerDFShippingPage(sd.driver, this.scenario);
		String df_url = HostUrls.getNetcrackerDocumentDfUrl();
		Thread.sleep(10000);
		utils.openUrlNewTab(df_url);
		Thread.sleep(10000);
		ncdfShippingpage.clickDFAccountFilter();
		Thread.sleep(2000);
		ncdfShippingpage.enterAccountNumber(accountnumber);
		Thread.sleep(2000);
		ncdfShippingpage.selectDFFilterAccount();
		Thread.sleep(2000);
		ncdfShippingpage.DFActiveAccount();
		Thread.sleep(2000);
		ncdfShippingpage.StartShipping();
		Thread.sleep(2000);
		ncdfShippingpage.selectDFImportShippingInfo();
		Thread.sleep(2000);
		String modelname[] = hardwaremodelname.split(",");
		String serialNumber[] = new String[modelname.length];
		for (int i = 0; i < modelname.length; i++) {

			serialNumber[i] = FakeHardwareGeneration.generateSerialNum(modelname[i].toUpperCase());
			switch (modelname[i].toUpperCase()) {
			case "HITRON":
				serialNumberHitron = serialNumber[i];
				break;

			case "XB6":
				serialNumberXB6 = serialNumber[i];
				break;

			case "XG1V4":
				serialNumberXG1V4 = serialNumber[i];
				break;

			case "XID":
				serialNumberXiD = serialNumber[i];
				break;

			case "DCX3200":
				serialNumberDCX3200 = serialNumber[i];
				break;

			case "DCX3400":
				serialNumberDCX3400 = serialNumber[i];
				break;
			case "SHAWMOXIGATEWAY":
				serialNumberMoxiGateway = serialNumber[i];
				break;
			case "XI6":
				serialNumberXi6 = serialNumber[i];
				break;
			case "DCT700":
				serialNumberDCT700 = serialNumber[i];
				break;
			}

		}
		Thread.sleep(9000);
		dftext.dftextfile(accountnumber, modelname, serialNumber, "1234567891209812");
		ncdfShippingpage.selectTextFile(System.getProperty("user.home") + "\\dftextfile.txt");
		ncdfShippingpage.clickImportButton();
		ncdfShippingpage.clickDFAccountFilter();
		Thread.sleep(2000);
		ncdfShippingpage.enterAccountNumber(accountnumber);
		Thread.sleep(2000);
		ncdfShippingpage.selectDFFilterAccount();
		Thread.sleep(2000);
		ncdfShippingpage.DFActiveAccount();
		ncdfShippingpage.completeShipping();
		//TestBase.takeScreenshot("DFCompletion");
	}

	@And("^selects internet service (.*) (.*) (.*)$")
	public void internetServiceSelection(String internetService, String device, String technicianAppointment)
			throws Exception {
		String selfInstall = prop.getProperty("selfinstall");
		is = new InternetServices(sd.driver);
		is.selectInternetPackage(internetService);
		waitForLoading(sd.driver);	
		isLoaderSpinnerVisible(sd.driver);	//AddedShweta	
		if (technicianAppointment.equals("techNotRequired") && selfInstall.toUpperCase().equals("NO")) {
			sd.driver.findElement(By.xpath("//td[contains(@class,'SecondCategory')]//*[contains(@id,'wrench-button')]"))
			.click();
			waitForLoading(sd.driver);
			if (sd.driver.findElements(By.xpath("//span[text()='Delete']")).size() > 0) {
				sd.driver.findElement(By.xpath("//span[text()='Delete']")).click();
				waitForLoading(sd.driver);
			}

			String lserial = "";
			String deviceSearchString = "";
			switch (device.toUpperCase()) {
			case "CISCODPC3848V":
			case "CISCODPC3825":
			case "ARRISSBG6782":
			case "GRANDFATHERED_HITRON":
			case "GRANDFATHERED_CISCODPC3825":
			case "GRANDFATHERED_ARRISSBG6782":
			case "GRANDFATHERED_CISCODPC3848V":
			case "HITRON":
				lserial = FakeHardwareGeneration.generateSerialNum(device.toUpperCase());
				if (device.equalsIgnoreCase("HITRON") || device.equalsIgnoreCase("GRANDFATHERED_HITRON")) {
					serialNumberHitron = lserial;
					deviceSearchString = "326/327";
				} else if (device.equalsIgnoreCase("CISCODPC3848V")
						|| device.equalsIgnoreCase("GRANDFATHERED_CISCODPC3848V")) {
					serialNumberCISCODPC3848V = lserial;
					deviceSearchString = "326/327";
				} else if (device.equalsIgnoreCase("CISCODPC3825")
						|| device.equalsIgnoreCase("GRANDFATHERED_CISCODPC3825")) {
					serialNumberCISCODPC3825 = lserial;
					deviceSearchString = "342/347";
				} else if (device.equalsIgnoreCase("ARRISSBG6782")
						|| device.equalsIgnoreCase("GRANDFATHERED_ARRISSBG6782")) {
					serialNumberARRISSBG6782 = lserial;
					deviceSearchString = "366";
				}
				sd.driver.findElement(By.xpath("//div[@id='hardware-popup']//*[contains(text(),'" + deviceSearchString
						+ "')]/ancestor::tr[1]//span[text()='+Rent']")).click();
				//takeScreenshot("renting device");

				break;
			case "XB6":
			case "XB7":
				waitForLoading(sd.driver);
				sd.driver.findElement(By.xpath("//span[contains(text(),'OK')]")).click();
				waitForLoading(sd.driver);
				if (sd.driver.findElements(By.xpath(
						"//a[@id='ConvergedHardwareCategory_addOfferButton' and not(contains(@class,'disabled'))]"))
						.size() > 0) {
					//takeScreenshot("deleting device");
					sd.driver.findElement(By.xpath(
							"//a[@id='ConvergedHardwareCategory_addOfferButton' and not(contains(@class,'disabled'))]"))
					.click();
					//takeScreenshot("deleting device");
					waitForLoading(sd.driver);
				}
				is.clickXb6Wrench();
				//takeScreenshot("deleting device");
				waitForLoading(sd.driver);
				for (char c : "12".toCharArray()) {
					if (sd.driver.findElements(By.xpath("//a[contains(@id, 'removeHardware')]/span")).size() > 0) {
						sd.driver.findElement(By.xpath("//a[contains(@id, 'removeHardware')]/span")).click();
						//takeScreenshot("deleting device");
						Thread.sleep(1000);
					}
					waitForLoading(sd.driver);
				}
				sd.driver.findElement(By.xpath("//div[@id='hardware-popup']//*[contains(text(),'" + device+ "')]/ancestor::tr[1]//span[text()='+Rent']")).click();
				//takeScreenshot("deleting device");
				waitForLoading(sd.driver);

				lserial = FakeHardwareGeneration.generateSerialNum(device.toUpperCase());
				if (device.equalsIgnoreCase("XB6")) {
					serialNumberXB6 = lserial;
				} else if (device.equalsIgnoreCase("XB7")) {
					serialNumberXB7 = lserial;
				}
				break;
			}

			//addInfoInReport(device + " serial number : " + lserial);
			//			ExtentCucumberAdapter.addTestStepLog(device + " serial number : " + lserial);
			//			Hooks.setFileWriterExampleData(lserial + " | ");

			is.setInternetSerialNum(lserial);
			is.clickOnSerialNumValidateButton();
			//takeScreenshot("serial number validate ");
			Thread.sleep(2000);
			is.clickOnInternetOkButton();
			Thread.sleep(2000);
			//TestBase.takeScreenshot("SelectInternetDevice");
			if (device.equalsIgnoreCase("XB6") || device.equalsIgnoreCase("XB7")) {
				WebElement lthis = sd.driver.findElement(By.xpath(
						"//td[@class=' FourthCategory']//div[text()='Internet Service']/../..//input[@type='checkbox']"));
				if (lthis.getAttribute("checked") != null) {
					//addInfoInReport("internet service already selected");
				} else {
					//addInfoInReport("selecting internet service");
					is.selectInternetServiceCheckbox();
				}
				Thread.sleep(4000);
				//TestBase.takeScreenshot("SelectInternetDevice");
			}
		}else if (technicianAppointment.equals("techRequired")) {
			if ((internetService.equalsIgnoreCase("Fibre+ 500")
					|| internetService.equalsIgnoreCase("Fibre+ 300") ) && (device.equals("XB6"))) {
				waitForLoading();
				is.clickXb6Wrench();
				is.deleteinternet();
				is.selectXB6RentButton();
				is.clickOnInternetOkButton();
				waitForLoading();
				is.selectInternetServiceCheckbox();
			} else if ((internetService.equalsIgnoreCase("Fibre+ 150") || internetService.equalsIgnoreCase("Fibre+ 250")) && (device.equals("Hitron"))) {
				removeXB7();
				waitForLoading();
				is.selectInternetWrench();
				is.rentHitron();

			}
			//			else if (internetService.equalsIgnoreCase("Fibre+ 500") && (device.equals("XB6"))) {
			//				waitForLoading();
			//				is.clickXb6Wrench();
			//				is.deleteinternet();
			//				is.selectXB6RentButton();
			//				is.clickOnInternetOkButton();
			//				waitForLoading();
			//				is.selectInternetServiceCheckbox();
			//
			//			}
			else if (internetService.equalsIgnoreCase("Fibre+ 500") && (device.equals("XB7"))) {

			}
		}
	}


	@And("^selects TV with tvpackage (.*) and tvhardware (.*) (.*)$")
	public void selectsTVPackageAndServices(String TVPackage, String TVHardware, String technicianAppointment)
			throws Exception {
		ts = new TVServices(sd.driver);
		tvPackage = TVPackage;
		this.selectsTvService(TVHardware, technicianAppointment);
	}

	@Given("User queries for using (.*) (.*) (.*) (.*) (.*)$")
	public void user_queries_for_altId(String type, String suffix, String env, String server, String port)
			throws InterruptedException {
		ldapqtool= new LDAPQueryTool(sd.driver);
		altId = ldapqtool.getAltId(accountnumber, type, suffix, env, server, port);
	}


	@And("^downgrade the service from flex trial$")
	public void downgradeToFlex() throws Exception {
		ts.selectEmployeeTV();
		ts.selectTvWrench();
		ts.levelupTV();
		Thread.sleep(2000);
		ts.selectOkButton();
	}

	@And("^downgrading the service from flex trial$")
	public void downgradingToFlex() throws Exception {
		ts.selectEmployeeTV();
		ts.selectTvWrench();
		//		Thread.sleep(2000);
		ts.deletetv();
		waitForLoading(sd.driver);
		ts.selectXiOne();
		waitForLoading(sd.driver);
		serialNumberXiOne = FakeHardwareGeneration.generateSerialNum("XIONE");
		ts.enterSerialNumber(serialNumberXiOne);
		ts.clickValidateButton();
		//			addInfoInReport("XIone serial number : " + serialNumberXiOne);
		Hooks.setFileWriter("XIone serial number : " + serialNumberXiOne);
		ts.selectOkButton();
	}

	@And("^downgrading the service to TVService	(.*)$")
	public void downgradingToTVService(String tVService) throws Exception {
		ts.selectEmployeeTV();
		ts.selectTvWrench();
		//		Thread.sleep(2000);
		ts.deletetv();
		waitForLoading(sd.driver);
		//		ts.selectXiOne();
		ts.selectTVHardware(tVService);
		waitForLoading(sd.driver);
		tvserialNumber = FakeHardwareGeneration.generateSerialNum(tVService);
		ts.enterSerialNumber(tvserialNumber);
		ts.clickValidateButton();
		//			addInfoInReport("XIone serial number : " + serialNumberXiOne);
		Hooks.setFileWriter(tVService+" serial number : " + tvserialNumber);
		ts.selectOkButton();
	}

	@And("^sets up appointment with technician for current date$")
	public void selecttechnician() throws Exception {
		//		Thread.sleep(40000);

		ap = new Appointments(sd.driver,this.scenario);
		ap.clickAppointmentlink();
		ap.selectSelfConnectNo();
		ap.dismissFFMIntegrationMessage();
		ap.Techreq();
		ap.selectSMSNumberOptedOut();
		ap.selectforceappointment();
		ap.setAuthorisedby();
		ap.setActivedirectory();
	}


	@And("^click on ffmhardware$")
	public void clickOnFFMHardware() throws InterruptedException {
		ffmPage=new FFMPage(sd.driver);

		ffmPage.clickFfmHardware();
		Thread.sleep(2000);
	}

	@And("^provision techretry Hitron and XG1V4 in FFM$")
	public void provisionTechRetry()
			throws InterruptedException, IOException, SAXException, ParserConfigurationException {

		ffmPage=new FFMPage(sd.driver);
		// String serialNumDPC = pageobjmanager.ReadHardware().ReadHardware_Excel("DPC",
		// 1, 0);
		String serialNumberXB6 = FakeHardwareGeneration.generateSerialNum("XB6");
		ffmPage.provision_Hitron(serialNumberXB6);
		Thread.sleep(20000);

		serialNumberDCX3510 = FakeHardwareGeneration.generateSerialNum("DCX3510");

		ffmPage.provision_Xg1V4(serialNumberDCX3510);
		Thread.sleep(20000);
		sd.driver.navigate().refresh();
		Thread.sleep(20000);
		ffmPage.clickFfmHardware();
		Thread.sleep(2000);

	}

	@And("^provision techretry (.*) and (.*) in FFM$")
	public void provisionTechRetryXB7(String internetdevice, String tvhardware)
			throws InterruptedException, IOException,Exception {
		ffmPage=new FFMPage(sd.driver);
		// String serialNumDPC = pageobjmanager.ReadHardware().ReadHardware_Excel("DPC",
		// 1, 0);
		String serialNumberXB7 = FakeHardwareGeneration.generateSerialNum(internetdevice);
		ffmPage.provisionXB7();
		Thread.sleep(20000);

		serialNumberXi6 = FakeHardwareGeneration.generateSerialNum(tvhardware.toUpperCase());

		ffmPage.provisionExisitngXi6();
		Thread.sleep(20000);
		sd.driver.navigate().refresh();
		Thread.sleep(20000);
		ffmPage.clickFfmHardware();
		Thread.sleep(2000);

	}
	@And("^add phone services converged$")
	public void addPhoneServiceConverged() throws Exception {
		ps= new PhoneServices(sd.driver);
		if (configprop.getProperty("disablePhoneSteps", "false").equalsIgnoreCase("true")) {
			System.out.println("disablePhoneSteps flag set true, skipping phone related steps");
			return;
		}
		if (phonePackage.equals("notset")) {
			phonePackage = prop.getProperty("defaultPhonePackage", "Personal Phone").trim();
		}
		//waitForLoading(sd.driver);
		Thread.sleep(4000);
		ps.Add_Phone(phonePackage);
		ps.selectPhoneNumber();
		ps.selectXB6PhoneService();
	}

	@And("^modify the account to disconnect the (.*)$")
	public void modifyAccountToDisconnectServices(String services) throws Exception {
		ds = new DisconnectServicesPage(sd.driver);
		utils =  new TestUtil(sd.driver);
		ps=new PhoneServices(sd.driver);
		cd = new CustomerDetails(sd.driver);
		as = new AddServicesAndFeatures(sd.driver);
		is = new InternetServices(sd.driver);

		if(System.getProperty("environment").equalsIgnoreCase("webud"))
		{
			cd.clickCustomerAndIdTab();
			as.clickAddServicesAndFeatures();
		}
		else
		{
			String moe = HostUrls.getMOEUrl();
			String moe_url = moe + "&accountId=" + accountid;
			utils.openUrlNewTab(moe_url);
		}

		String service[] = services.split(",");

		for (int i = 0; i < service.length; i++) {
			switch (service[i].toUpperCase()) {
			case "INTERNETXB6":
				ds.disconnectInternet();
				//				Thread.sleep(2000);
				ds.deleteXB6();
				//				Thread.sleep(2000);
				ds.productRemovalConfirm();
				break;
			case "INTERNET":
				ds.disconnectInternet();
				waitForLoading(sd.driver);
				//				Thread.sleep(2000);
				ds.deleteXB6();
				//				Thread.sleep(2000);
				ds.productRemovalConfirm();
				break;
			case "TV":
				ds.disconnectTv();
				waitForLoading(sd.driver);
				break;
			case "PHONE":
				ps.E911Supression();
				ds.disconnectPhone();
				//				Thread.sleep(2000);
				ds.selectPortNumberWarningMessage();
				if((sd.driver.findElements(By.xpath("//td[@class=' FourthCategory']//table[@c='UIShawLinkFeature']//a[@class='wrench-button-style']")).size())!=0)
				{
					is.DisconnectConvergedHardware();
					//					is.clickOnInternetOkButton();
				}
				break;
			}
		}
	}

	@And("^sets up appointment for future date (.*) (.*)$")
	public void setsupAppointmentForFutureDate(String technicianAppointment, String dayOfMonth)
			throws Exception {
		ap = new Appointments(sd.driver,this.scenario);
		ap.clickAppointmentlink();
		ap.selectSelfConnectNo();
		LocalDate currentdate = LocalDate.now();
		Month currentMonth = currentdate.getMonth();
		int currentYear = currentdate.getYear();
		if (technicianAppointment.equals("techNotRequired")) {
			ap.TechReqNo();
			ap.selectFutureDateWithoutTech(dayOfMonth);
		} else {
			ap.Techreq();
			ap.selectSMSNumberOptedOut();
			ap.selectforceappointment();
			ap.selectFutureDateWithTech(dayOfMonth);
		}
		ap.setAuthorisedby();
		//		ExtentCucumberAdapter.addTestStepLog("Future Activation Date : " + dayOfMonth + "-" + currentMonth + "-" + currentYear);
		ap.setActivedirectory();
	}

	@And("^finish and click return hardware popup")
	public void returnHardwarePopip() throws Exception {
		fp = new FinishPage(sd.driver);
		fp.clickFinishTab();
		fp.clickHardwareReturnPopup();
		Thread.sleep(8000);
		fp.clickDisconnectRefundPopup();
		Thread.sleep(8000);
		accountnumber = fp.retrieveAccountnumber();
		Thread.sleep(2000);
		workordernumber = fp.retrieveworkOrderNumber();
	}

	@Then("^Order status should be Processing in Overview Page$")
	public void orderstatusProcessing() throws InterruptedException, IOException {
		utils = new TestUtil(sd.driver);
		op = new OverviewPage(sd.driver, this.scenario);
		String overviewpage_url = HostUrls.getOverviewPageUrl();
		overviewpage = overviewpage_url + "&accountId=" + accountid;
		utils.openUrlNewTab(overviewpage);
		Thread.sleep(4000);
		String orderStatus = op.retrieveProcessingOrderStatus();
		String expectedOrderStatus = "Processing";
		Assert.assertEquals("Expected message is Processing",orderStatus, expectedOrderStatus);
	}

	@And("^select the disconnection date as futuredate (.*)$")
	public void futureDisconnectionDate(String dayOfMonth) throws Exception {
		ap = new Appointments(sd.driver,this.scenario);
		ap.clickAppointmentlink();
		ap.selectFutureDisconnectedDate(dayOfMonth);
		ap.setAuthorisedby();
		ap.setActivedirectory();
	}

	@And("^run the DSA link to simulate device plugin and Complete the Order (.*)$")
	public void simulateDevicePlugin(String hardwaremodelname)
			throws IOException, SAXException, ParserConfigurationException, InterruptedException {
		utils = new TestUtil(sd.driver);
		String dsaDevices[] = hardwaremodelname.split(",");
		String macAddress = "";

		for (int i = 0; i < dsaDevices.length; i++) {

			switch (dsaDevices[i].toUpperCase()) {
			case "HITRON":
				macAddress = FakeHardwareGeneration.generateMacAddress(serialNumberHitron, "docsys");
				break;

			case "XB6":
				macAddress = FakeHardwareGeneration.generateMacAddress(serialNumberXB6, "docsys");
				break;

			case "XG1V4":
				macAddress = FakeHardwareGeneration.generateMacAddress(serialNumberXG1V4, "docsys");
				break;

			case "XID":
				macAddress = FakeHardwareGeneration.generateMacAddress(serialNumberXiD, "docsys");
				break;

			case "DCX3200":
				macAddress = FakeHardwareGeneration.generateMacAddress(serialNumberDCX3200, "docsys");
				break;

			case "DCX3400":
				macAddress = FakeHardwareGeneration.generateMacAddress(serialNumberDCX3400, "docsys");
				break;
			case "SHAWMOXIGATEWAY":
				macAddress = FakeHardwareGeneration.generateMacAddress(serialNumberMoxiGateway, "docsys");
				break;

			}
			String dsaPluginUrl = "http://pd2rre1.so.cg.pre.oss.int.inet/rre/binary/" + macAddress
					+ "?source=10.191.128.1&notify=true";
			utils.openUrlNewTab(dsaPluginUrl);
			//TestBase.takeScreenshot("dsaPluginUrl");
		}
	}

	@And("^navigates to order history page to cancel the order$")
	public void cancelOrderInHistoryPage() throws InterruptedException, IOException,Exception {
		op = new OverviewPage(sd.driver, this.scenario);
		op.cancelOrder();
		Thread.sleep(45000);
		//TestBase.takeScreenshot("OverviewPage");
	}

	@And("^click on new customerorder$")
	public void clickNewCustomerOrder() throws InterruptedException {
		TechCnf = new TechConfirmPage(sd.driver);
		Thread.sleep(10000);
		TechCnf.clickNewCustomerOrder();
		Thread.sleep(120000);
	}

	@And("^complete the tech confirmation task$")
	public void completeTechConfirmationTask() throws InterruptedException {
		TechCnf = new TechConfirmPage(sd.driver);
		TechCnf.click_Nc_Task();
		Thread.sleep(2000);
		TechCnf.clickNcStatusFiler();
		Thread.sleep(5000);
		TechCnf.enterNcStatusInput();
		Thread.sleep(5000);
		TechCnf.clickNcWaitingTask();
		Thread.sleep(5000);
		TechCnf.clickNcTechConfirmTask();
		Thread.sleep(2000);
		TechCnf.click_MarkFinish();
		Thread.sleep(2000);
	}

	@And("navigates to immediate changes page")
	public void launchImmediateChangePage() throws IOException, InterruptedException {
		utils = new TestUtil(sd.driver);
		String immediateChangesUrl = HostUrls.getImmediateChangesUrl() + "&accountId=" + accountid;
		// String immediateChangesUrl= HostUrls.getImmediateChangesUrl();
		utils.openUrlNewTab(immediateChangesUrl);
		//TestBase.takeScreenshot("immediateSwapPage");
	}

	@And("^swap the hardware in immediate change page (.*)$")
	public void swapHardware(String TVHardware) throws Exception {
		immswappage = new ImmediateSwapPage(sd.driver);
		utils = new TestUtil(sd.driver);
		serialNumberXB6 = FakeHardwareGeneration.generateSerialNum("XB6");
		immswappage.SwapXB6(serialNumberXB6);

		String overviewpage_url = HostUrls.getOverviewPageUrl();
		String overviewpage = overviewpage_url + "&accountId=" + accountid;

		utils.openUrlNewTab(overviewpage);
		Thread.sleep(60000);
		immswappage.clickOrderSummary();
		Thread.sleep(8000);
		immswappage.checkImmediateSwapStatus();
		//TestBase.takeScreenshot("SwapDeviceStatus");
		String immediateChangesUrl = HostUrls.getImmediateChangesUrl() + "&accountId=" + accountid;
		utils.openUrlNewTab(immediateChangesUrl);
		Thread.sleep(4000);
		switch (TVHardware.toUpperCase()) {
		case "SHAWMOXIGATEWAY":
			serialNumberMoxiGateway = FakeHardwareGeneration.generateSerialNum("SHAWMOXIGATEWAY");
			immswappage.swapShawMoxiGateway(serialNumberMoxiGateway);		
			break;
		case "XI6":
			serialNumberXi6 = FakeHardwareGeneration.generateSerialNum("XI6");
			immswappage.swapShawMoxiGateway(serialNumberXi6);
			break;
		}


		overviewpage_url = HostUrls.getOverviewPageUrl();
		overviewpage = overviewpage_url + "&accountId=" + accountid;

		utils.openUrlNewTab(overviewpage);
		Thread.sleep(60000);
		immswappage.clickOrderSummary();
		Thread.sleep(2000);
		immswappage.checkImmediateSwapStatus();
	}

	@And("^aup suspend the service (.*)$")
	public void aupSupendOfServices(String services) throws Exception {
		ncSusHistoryPage= new NetCrackerSuspensionHistoryPage(sd.driver);
		ncSusHistoryPage.suspensionHistory();
		String serviceType[] = services.split(",");
		for (int i = 0; i < serviceType.length; i++)
			ncSusHistoryPage.aupSuspendService(serviceType[i]);
		ncSusHistoryPage.validateSuspensionStatus();
	}

	@And("^aup resume the service (.*)$")
	public void aupResumeOfServices(String services) throws Exception {
		ncSusHistoryPage= new NetCrackerSuspensionHistoryPage(sd.driver);
		ncSusHistoryPage.suspensionHistory();
		String serviceType[] = services.split(",");
		for (int i = 0; i < serviceType.length; i++)
			ncSusHistoryPage.aupResume(serviceType[i]);
		ncSusHistoryPage.validateResumeStatus();
		//TestBase.takeScreenshot("resumeHistory");
	}

	@And("^provisionioning provisionDevice in FFM	(.*)	(.*)$")
	public void provisionInFFM(String device, String swapDevice)
			throws Exception {
		ffmPage=new FFMPage(sd.driver);
		//		List<List<String>> list = dt.asLists(String.class);
		//		String provisionDevices = list.get(0).get(0);
		String cDevice[] = device.split(",");
		String provisionDevice[] = swapDevice.split(",");
		for (int i = 0; i < provisionDevice.length; i++) {
			String sdevice, serialNumber;
			sdevice= provisionDevice[i].toUpperCase();
			serialNumber = FakeHardwareGeneration.generateSerialNum(sdevice);
			ffmPage.provision_Device(cDevice[i], serialNumber);
		}
		// TestBase.takeScreenshot("ffmpage");
	}

	@And("^select the disconnection date$")
	public void selectDisconnectionReason() throws Exception {
		ap = new Appointments(sd.driver,this.scenario);
		ap.clickAppointmentlink();
		//		Thread.sleep(8000);
		ap.selectDisconnectCalendar();
		//		Thread.sleep(3000);
		ap.selectDisconnectionDate();
		//		Thread.sleep(1000);
		ap.setAuthorisedby();
		//		Thread.sleep(2000);
		//TestBase.takeScreenshot("Disconnection Order");
		ap.setActivedirectory();
	}

	@And("^select the premisemove date (.*)$")
	public void selectPremiseMoveDate(String dayOfMonth) throws Exception {
		ap = new Appointments(sd.driver,this.scenario);
		ap.clickAppointmentlink();
		waitForLoading(sd.driver);
		waitForLoading(sd.driver);
		waitForLoading(sd.driver);
		waitForLoading(sd.driver);
		Thread.sleep(2000);
		ap.selectPremiseMove();
		Thread.sleep(2000);
		ap.enterActivationDate(dayOfMonth);
		ap.enterPremiseMoveDisconnectionDate();
		Thread.sleep(2000);
		ap.setAuthorisedby();
		Thread.sleep(2000);
		ap.setActivedirectory();
	}

	@And("^upgrade internet device and service$")
	public void upgradeInternetDeviceAndService()
			throws Exception {
		is = new InternetServices(sd.driver);
		//is.selectFibre500();
		is.selectIgniteInternetProduct();
		//		is.addXB6InternetProduct();
		//		is.clickXb6Wrench();
		//is.selectXB6RentButton();
		is.addXB7Product();
		serialNumberXB7 = FakeHardwareGeneration.generateSerialNum("XB7");
		is.setInternetSerialNum(serialNumberXB7);
		Hooks.setFileWriter("XB7 serial number : " + serialNumberXB7);
		Hooks.setFileWriterExampleData(serialNumberXB7 + " | ");
		is.clickOnSerialNumValidateButton();
		Thread.sleep(2000);
		is.clickOnInternetOkButton();
		is.selectInternetServiceCheckbox();
		ExtentCucumberAdapter.addTestStepLog("XB7 serial number : " +serialNumberXB6);
	}

	@And("^selects existing hardware future date (.*)$")
	public void selectsExistingHardwareFutureDate(String dayOfMonth) throws InterruptedException {
		ap = new Appointments(sd.driver,this.scenario);
		ap.enterActivationDate(dayOfMonth);
	}

	@And("^modify account to suspend the services (.*) (.*)$")
	public void modifyAccountToFutureSuspendServices(String serviceTypes, String dayOfMonth)
			throws Exception {
		snowbird= new SnowbirdSuspendResumePage(sd.driver);
		utils = new TestUtil(sd.driver);
		as = new AddServicesAndFeatures(sd.driver);
		rp = new ReviewPage(sd.driver);
		String service[] = serviceTypes.split(",");
		String moe = HostUrls.getMOEUrl();
		String moe_url = moe + "&accountId=" + accountid;
		utils.openUrlNewTab(moe_url);
		Thread.sleep(3000);
		snowbird.clickOperationsTab();
		Thread.sleep(2000);
		snowbird.selectSnowBird();
		Thread.sleep(2000);
		snowbird.selectTcisCheckbox();
		Thread.sleep(2000);
		snowbird.selectSuspendStartDateCalendar();
		Thread.sleep(2000);
		snowbird.selectFutureSuspendDate(dayOfMonth);
		Thread.sleep(2000);
		snowbird.selectSuspendEndDateCalendar();
		Thread.sleep(2000);
		snowbird.selectNextMonth();
		Thread.sleep(2000);
		snowbird.selectSuspendEndDate();
		Thread.sleep(2000);
		snowbird.clickSuspendOkButton();
		Thread.sleep(2000);
		for (int i = 0; i < service.length; i++) {
			Thread.sleep(4000);
			switch (service[i].toUpperCase()) {
			case "INTERNET":
				snowbird.selectSuspendInternet();
				Thread.sleep(2000);
				break;
			case "TV":
				snowbird.selectSuspendTv();
				Thread.sleep(2000);
				break;
			case "PHONE":
				snowbird.selectsuspendphone();
				Thread.sleep(2000);
				break;
			}
		}
		as.addinstallationfee();
		Thread.sleep(2000);
		rp.clickReviewTab();
		Thread.sleep(2000);
		rp.setEmailOrderSummary();
		Thread.sleep(2000);
	}

	//	Swati : Added for NGV-43462
	@And("^creates new customer staff account with(.*) (.*) (.*) (.*) (.*)$")
	public void CreateNewStaffAccountupdateCustomerCredentials(String firstName, String lastName, String email,
			String authType, String pin) throws Exception {
		utils =  new TestUtil(sd.driver);
		cd = new CustomerDetails(sd.driver);
		utils.openUrlNewTab(HostUrls.getOEUrl());
		//Swati NGV-43462: Created Method AddStaffCustomer 
		cd.addStaffCustomer(firstName, lastName, email, authType, pin);
		Hooks.setFileWriter("FirstName: " + firstName + "\nLastName: " + lastName + "\nEmail: " + email);
	}

	//Swati : Added for EWAN TCs NGV-43426
	@And("^Staff selects internetservice(.*) (.*) (.*)$")
	public void selectsInternetServiceForStaff(String internetService, String device, String technicianAppointment)
			throws Exception {
		String selfInstall = prop.getProperty("selfinstall");
		is= new InternetServices(sd.driver);
		is.selectInternetPackage(internetService);
		if (technicianAppointment.equals("techNotRequired") && selfInstall.toUpperCase().equals("NO")) {
			switch (device.toUpperCase()) {
			case "HITRON":
				is.selectInternetWrench();
				serialNumberHitron = FakeHardwareGeneration.generateSerialNum("HITRON");
				is.setInternetSerialNum(serialNumberHitron);
				Hooks.setFileWriter("Hitron Serial Number : " + serialNumberHitron);
				Hooks.setFileWriterExampleData(serialNumberHitron + " | ");
				break;
			case "XB6":
				if (internetService.equalsIgnoreCase("Employee Internet 300")) {
					is.selectInternetWrench();
					waitForLoading(sd.driver);
					//is.RemoveHit();
					// Thread.sleep(1000);
					sd.driver.findElement(By.xpath("//div[@id='hardware-popup']//span[text()='Delete']")).click();
					waitForLoading(sd.driver);
					sd.driver.findElement(By.xpath("//a[@id='hardware-popup-ok-button']//span[contains(text(),'OK')]"))
					.click();
					waitForLoading(sd.driver);
				}
				else {
					is.RemoveHit();
				}
				is.addConvergedHardwareAddProduct();
				waitForLoading(sd.driver);
				is.clickXb6Wrench();
				if (internetService.equalsIgnoreCase("Employee Internet 300")) {
					is.selectXB6RentButton();
				}else if(internetService.equalsIgnoreCase("Fibre+ 300")){
					is.selectXB6RentButtonFibre300();

				}
				serialNumberXB6 = FakeHardwareGeneration.generateSerialNum("XB6");
				is.setInternetSerialNum(serialNumberXB6);	          
				Hooks.setFileWriter("XB6 serial number : " + serialNumberXB6);
				Hooks.setFileWriterExampleData(serialNumberXB6 + " | ");
				break;
			case "XB7":
				if (internetService.equalsIgnoreCase("Employee Internet 300")) {
					is.selectInternetWrench();
					waitForLoading(sd.driver);
					sd.driver.findElement(By.xpath("//div[@id='hardware-popup']//span[text()='Delete']")).click();
					waitForLoading(sd.driver);
					//driver.findElement(By.xpath("//a[@id='hardware-popup-ok-button']//span[contains(text(),'OK')]"))
					//    .click();
					waitForLoading(sd.driver);
					sd.driver.findElement(By.xpath("//td[contains(@class,'FourthCategory')]//span[text()='Add Product']"))
					.click();
					waitForLoading(sd.driver);
				}
				waitForLoading(sd.driver);
				//	                  is.clickXb6Wrench();
				//	                  is.AddXB6ProductWithSerialNumber();
				is.clickXb6Wrench();

				if (internetService.trim().equalsIgnoreCase("Employee Fibre+ Gig")) {
					is.DeleteandAddConvergedHardware("XB7");
					//	                  waitForLoading(sd.driver);
					//	                	  Thread.sleep(2000);
					//	                        sd.driver.findElement(By.xpath("//div[@id='hardware-popup']//span[text()='Delete']")).click();
					//waitForLoading(sd.driver);
					//	                       Thread.sleep(2000);
					//	                        is.rentXB7();
				}

				serialNumberXB7 = FakeHardwareGeneration.generateSerialNum("XB7");
				// serialNumberXB6 = "74T2C489C986734";
				is.setInternetSerialNum(serialNumberXB7);
				// addInfoInReport("XB7 serial number : " + serialNumberXB7);
				Hooks.setFileWriter("XB7 serial number : " + serialNumberXB7);
				Hooks.setFileWriterExampleData(serialNumberXB7 + " | ");
				break;
			}

			is.clickOnSerialNumValidateButton();
			waitForLoading(sd.driver);
			is.clickOnInternetOkButton();
			// TestBase.takeScreenshot("SelectInternetDevice");
			waitForLoading(sd.driver);
			is.clickWifiRouterCheckBox();
			//	            if (internetService.equalsIgnoreCase("Employee Fibre+ Gig")) {
			//	                  is.selectInternetServiceCheckbox();
			//	            }else 
			if(internetService.equalsIgnoreCase("Fibre+ 300")) {
				is.selectInternetServiceCheckbox();
			}

		}
	}

	//Swati - NGV-43452 
	@And("^addInternetModem$")
	public void addInternetModem() throws Exception {

		is= new InternetServices(sd.driver);
		is.selectInternetWrenchWithModemSerialNumer();
		waitForLoading(sd.driver);
		serialNumberLegacyFibreModel = FakeHardwareGeneration.generateSerialNum("LEGACYFIBREMODEM");
		is.setInternetSerialNum(serialNumberLegacyFibreModel);
		Hooks.setFileWriter("Legacy Fibre Model serial number : " + serialNumberLegacyFibreModel);
		Hooks.setFileWriterExampleData(serialNumberLegacyFibreModel + " | ");
		is.clickOnSerialNumValidateButton();
		waitForLoading(sd.driver);
		is.clickOnInternetOkButton();
		waitForLoading(sd.driver);
		is.clickWifiRouterCheckBox();

	}

	//Swati - Added for NGV-43426
	@And("^selects staff TV service with (.*) (.*)$")
	public void staffTVServices(String TVHardware, String technicianAppointment)
			throws Exception {

		ts = new TVServices(sd.driver);

		ts.selectEmployeeTV();
		ts.selectTvWrench();
		//	ts.selectXi6();

		String hardware[] = TVHardware.split(",");
		for (int i = 0; i < hardware.length; i++) {
			switch (hardware[i].toUpperCase()) {
			case "XG1V4":
				waitForLoading(sd.driver);
				ts.selectXg1v4();
				if (technicianAppointment.equals("techNotRequired")) {
					serialNumberXG1V4 = FakeHardwareGeneration.generateSerialNum("XG1V4");
					ts.enterSerialNumber(serialNumberXG1V4);
					ts.clickValidateButton();
					//addInfoInReport("XG1V4 serial number : " + serialNumberXG1V4);
					Hooks.setFileWriter("XG1V4 serial number : " + serialNumberXG1V4);
				}
				break;
			case "XG1V3":
				waitForLoading(sd.driver);
				ts.selectXG1V3();
				waitForLoading(sd.driver);
				if (technicianAppointment.equals("techNotRequired")) {
					serialNumberXG1V3 = FakeHardwareGeneration.generateSerialNum("XG1V3");
					ts.enterSerialNumber(serialNumberXG1V3);
					ts.clickValidateButton();
					//addInfoInReport("XG1V3 serial number : " + serialNumberXG1V3);
					Hooks.setFileWriter("XG1V3 serial number : " + serialNumberXG1V3);
				}
				break;
			case "XI6":
				prop.setProperty("is_TV_Xi6", "true");
				waitForLoading(sd.driver);
				ts.selectXi6();
				if (technicianAppointment.equals("techNotRequired")) {
					serialNumberXi6 = FakeHardwareGeneration.generateSerialNum("XI6");
					ts.enterSerialNumber(serialNumberXi6);
					ts.clickValidateButton();
					//addInfoInReport("Xi6 serial number : " + serialNumberXi6);
					Hooks.setFileWriter("Xi6 serial number : " + serialNumberXi6);
				}
				break;

			case "SHAWMOXIGATEWAY":
				waitForLoading(sd.driver);
				ts.selectShawMoxiGateway();
				if (technicianAppointment.equals("techNotRequired")) {
					serialNumberMoxiGateway = FakeHardwareGeneration.generateSerialNum("SHAWMOXIGATEWAY");
					ts.enterSerialNumber(serialNumberMoxiGateway);
					ts.clickValidateButton();
					//addInfoInReport("Moxi Gateway serial number : " + serialNumberMoxiGateway);
					Hooks.setFileWriter("Moxi Gateway serial number : " + serialNumberMoxiGateway);
				}
				break;
			case "SHAWPORTAL":
				ts.selectShawMoxiPortal();
				break;
			case "XID":
				waitForLoading(sd.driver);
				ts.selectXid();
				waitForLoading(sd.driver);
				if (technicianAppointment.equals("techNotRequired")) {
					serialNumberXiD = FakeHardwareGeneration.generateSerialNum("XID");
					ts.enterSerialNumber(serialNumberXiD);
					ts.clickValidateButton();
					//addInfoInReport("XiD serial number : " + serialNumberXiD);
					Hooks.setFileWriter("XiD serial number : " + serialNumberXiD);
				}
				break;
			case "DCX3510":
				ts.selectDCX3510();
				if (technicianAppointment.equals("techNotRequired")) {
					serialNumberDCX3510 = FakeHardwareGeneration.generateSerialNum("DCX3510");
					ts.enterSerialNumber(serialNumberDCX3510);
					ts.clickValidateButton();
					//addInfoInReport("DCX3510 serial number : " + serialNumberDCX3510);
					Hooks.setFileWriter("DCX3510 serial number : " + serialNumberDCX3510);
				}
				break;
			case "DCT700":
				waitForLoading(sd.driver);
				ts.selectDCT700();
				if (technicianAppointment.equals("techNotRequired")) {
					serialNumberDCT700 = FakeHardwareGeneration.generateSerialNum("DCT700");
					ts.enterSerialNumber(serialNumberDCT700);
					ts.clickValidateButton();
					//addInfoInReport("DCT700 serial number : " + serialNumberDCT700);
					Hooks.setFileWriter("DCT700 serial number : " + serialNumberDCT700);
				}
				break;
			case "DCX3400":
				waitForLoading(sd.driver);
				ts.selectDCX3400();
				if (technicianAppointment.equals("techNotRequired")) {
					serialNumberDCX3400 = FakeHardwareGeneration.generateSerialNum("DCX3400");
					ts.enterSerialNumber(serialNumberDCX3400);
					ts.clickValidateButton();
					//addInfoInReport("DCX3400 serial number : " + serialNumberDCX3400);
					Hooks.setFileWriter("DCX3400 serial number : " + serialNumberDCX3400);
				}
				break;
			case "DCX3200":
				ts.selectDCX3200();
				waitForLoading(sd.driver);
				if (technicianAppointment.equals("techNotRequired")) {
					serialNumberDCX3200 = FakeHardwareGeneration.generateSerialNum("DCX3200");
					ts.enterSerialNumber(serialNumberDCX3200);
					ts.clickValidateButton();
					//addInfoInReport("DCX3200 serial number : " + serialNumberDCX3200);
					Hooks.setFileWriter("DCX3200 serial number : " + serialNumberDCX3200);
				}
				break;
			case "DCX3400250GB":
				ts.selectDCX3400250GB();
				if (technicianAppointment.equals("techNotRequired")) {
					serialNumberDCX3400250GB = FakeHardwareGeneration.generateSerialNum("DCX3400250GB");
					ts.enterSerialNumber(serialNumberDCX3400250GB);
					ts.clickValidateButton();
					//addInfoInReport("DCX3400 serial number : " + serialNumberDCX3400250GB);
					Hooks.setFileWriter("DCX3400 serial number : " + serialNumberDCX3400250GB);
				}
				break;
			case "DCX3200P2M":
				ts.selectDCX3200P2M();
				if (technicianAppointment.equals("techNotRequired")) {
					serialNumberDCX3200P2M = FakeHardwareGeneration.generateSerialNum("DCX3200P2M");
					ts.enterSerialNumber(serialNumberDCX3200P2M);
					ts.clickValidateButton();
					//addInfoInReport("DCX3200 serial number : " + serialNumberDCX3200P2M);
					Hooks.setFileWriter("DCX3200 serial number : " + serialNumberDCX3200P2M);
				}
				break;
			case "DCX3200HDGUIDE":
				ts.selectDCX3200HDGuide();
				if (technicianAppointment.equals("techNotRequired")) {
					serialNumberDCX3200HDGuide = FakeHardwareGeneration.generateSerialNum("DCX3200HDGuide");
					ts.enterSerialNumber(serialNumberDCX3200HDGuide);
					ts.clickValidateButton();
					//addInfoInReport("DCX3200 serial number : " + serialNumberDCX3200HDGuide);
					Hooks.setFileWriter("DCX3200 serial number : " + serialNumberDCX3200HDGuide);
				}
				break;
			case "FLEXXI6":
				waitForLoading(sd.driver);
				ts.selectFlexXi6();
				if (technicianAppointment.equals("techNotRequired")) {
					serialNumberXi6 = FakeHardwareGeneration.generateSerialNum("XI6");
					ts.enterSerialNumber(serialNumberXi6);
					ts.clickValidateButton();
					//addInfoInReport("Xi6 serial number : " + serialNumberXi6);
					Hooks.setFileWriter("Xi6 serial number : " + serialNumberXi6);
				}
				break;
			}
		}
		waitForLoading(sd.driver);

		ts.selectOkButton();
		//TestBase.takeScreenshot("TV Devices");
	}

	//@NGV-43435 start
	@And("^selects wifi router internetservice (.*) (.*) (.*)$")
	public void selectsWifiInternetService(String internetService, String device, String technicianAppointment)
			throws Exception {
		is = new InternetServices(sd.driver);
		String selfInstall = prop.getProperty("selfinstall");
		waitForLoading(sd.driver);
		is.selectInternetPackage(internetService);
		if (technicianAppointment.equals("techNotRequired") && selfInstall.toUpperCase().equals("NO")) {
			switch (device.toUpperCase()) {
			case "HITRON":
				is.selectInternetWrench();
				serialNumberHitron = FakeHardwareGeneration.generateSerialNum("HITRON");
				is.setInternetSerialNum(serialNumberHitron);
				Hooks.setFileWriter("Hitron Serial Number : " + serialNumberHitron);
				Hooks.setFileWriterExampleData(serialNumberHitron + " | ");
				break;
			case "XB6":
				if (internetService.equalsIgnoreCase("Employee Internet 300")) {
					is.selectInternetWrench();
					waitForLoading(sd.driver);
					waitForLoading(sd.driver);
					sd.driver.findElement(By.xpath("//div[@id='hardware-popup']//span[text()='Delete']")).click();
					waitForLoading(sd.driver);
					sd.driver.findElement(By.xpath("//a[@id='hardware-popup-ok-button']//span[contains(text(),'OK')]"))
					.click();
					waitForLoading(sd.driver);
					sd.driver.findElement(By.xpath("//td[contains(@class,'FourthCategory')]//span[text()='Add Product']"))
					.click();
					waitForLoading(sd.driver);
				}
				is.clickXb6Wrench();
				if (internetService.equalsIgnoreCase("Employee Internet 300")) {
					is.selectXB6RentButton();
				}

				serialNumberXB6 = FakeHardwareGeneration.generateSerialNum("XB6");
				is.setInternetSerialNum(serialNumberXB6);
				Hooks.setFileWriter("XB6 serial number : " + serialNumberXB6);
				Hooks.setFileWriterExampleData(serialNumberXB6 + " | ");
				break;
			case "XB7":
				// Code to Add Modem 
				is.selectInternetWrenchWithModemSerialNumer();
				waitForLoading(sd.driver);
				serialNumberLegacyFibreModel = FakeHardwareGeneration.generateSerialNum("LEGACYFIBREMODEM");
				is.setInternetSerialNum(serialNumberLegacyFibreModel);
				Hooks.setFileWriter("Legacy Fibre Model serial number : " + serialNumberLegacyFibreModel);
				Hooks.setFileWriterExampleData(serialNumberLegacyFibreModel + " | ");
				is.clickOnSerialNumValidateButton();
				waitForLoading(sd.driver);

				// Add Wifi Router 
				sd.driver.findElement(By.xpath("//*[contains(text(),'Wifi Router (316)')]/ancestor::td[contains(@class,'hardware-model')]/following-sibling::td/following-sibling::td//span[contains(text(),'+Rent')]/ancestor::a[@c='UIShawButton']"))
				.click();

				serialNumberWifiRouterModel = FakeHardwareGeneration.generateSerialNum("WIFIROUTER");
				is.setInternetSerialNum(serialNumberWifiRouterModel);
				Hooks.setFileWriter("Wifi Router serial number : " + serialNumberWifiRouterModel);
				Hooks.setFileWriterExampleData(serialNumberWifiRouterModel + " | ");
				is.clickOnSerialNumValidateButton();
				waitForLoading(sd.driver);
				is.clickOnInternetOkButton();
				waitForLoading(sd.driver);
			}		
		}
	}

	//			@And("^modify the account to change wifi router$")
	//			public void modifyAccountChangeWifi() throws Exception {
	//				String moe = HostUrls.getMOEUrl();
	//				String moe_url = moe + "&accountId=" + accountid;
	//				is = new InternetServices(sd.driver);
	//				utils=new TestUtil(sd.driver);
	//				utils.openUrlNewTab(moe_url);
	//				waitForLoading(sd.driver);
	//				
	//				sd.driver.findElement(By.xpath("//td[@class=' SecondCategory']//table[@c='UIShawLinkFeature']//a[@class=\"wrench-button-style\"]"))
	//				.click();
	//				waitForLoading(sd.driver);
	//				
	//				//Delete Wifi Router 
	//				sd.driver.findElement(By.xpath("(//*[text()='Delete'])[2]"))
	//				.click();
	//				waitForLoading(sd.driver);
	//				
	//				is.clickOnInternetOkButton();
	//				waitForLoading(sd.driver);
	//				
	//				sd.driver.findElement(By.xpath("//td[contains(@class,'FourthCategory')]//span[text()='Add Product']"))
	//				.click();
	//				waitForLoading(sd.driver);
	//				
	//				sd.driver.findElement(By.xpath("//td[@class=' FourthCategory']//table[@c='UIShawLinkFeature']//a[@class=\"wrench-button-style\"]"))
	//				.click();
	//				waitForLoading(sd.driver);
	//				
	//				//Add XB7 Fiber Router
	//				sd.driver.findElement(By.xpath("//*[contains(text(),'Shaw Fibre+ Gateway 2.0 XB7 Modem')]/ancestor::td[contains(@class,'hardware-model')]/following-sibling::td/following-sibling::td//span[contains(text(),'+Rent')]/ancestor::a[@c='UIShawButton']"))
	//				.click();
	//				waitForLoading(sd.driver);
	//				
	//				serialNumberXB7 = FakeHardwareGeneration.generateSerialNum("XB7");
	//				is.setInternetSerialNum(serialNumberXB7);
	//				Hooks.setFileWriter("XB7 serial number : " + serialNumberXB7);
	//				Hooks.setFileWriterExampleData(serialNumberXB7 + " | ");
	//				is.clickOnSerialNumValidateButton();
	//				waitForLoading(sd.driver);
	//				is.clickOnInternetOkButton();
	//				waitForLoading(sd.driver);
	//				
	//				sd.driver.findElement(By.xpath("//*[@class=\"UITable9Box-body\"]//table[@class=\"UIVerticalLayout offer-placeholder\"]//input[@class=\"UICheckBox UICheckFeature_left_cb\"]"))
	//				.click();
	//				waitForLoading(sd.driver);
	//							
	//			}

	@And("^selects TPIA internetservice (.*) (.*) (.*) (.*)$")
	public void selectsTPIAInternetService(String internetService, String device, String technicianAppointment, String SeriaNumber)
			throws Exception {
		String selfInstall = prop.getProperty("selfinstall");
		is = new InternetServices(sd.driver);
		is.selectInternetPackage(internetService);
		waitForLoading(sd.driver);
		isLoaderSpinnerVisible(sd.driver);	//AddedShweta
		cd = new CustomerDetails(sd.driver);				
		//pageobjmanager = new pageObjectManager(driver);
		//				utils.openUrlNewTab(moe_url);
		waitForLoading(sd.driver);
		Thread.sleep(5000);
		//	    as.selectPlan();
		waitForLoading(sd.driver);
		Thread.sleep(15000);

		//	is.selectInternetWrench();	
	//	cd.OrderEntryTab();
		is.addtpiamodem();
	//	serialNumberTPIA = FakeHardwareGeneration.generateSerialNum("TPIAMODEM");
		serialNumberTPIA = SeriaNumber;
		is.setInternetSerialNum(serialNumberTPIA);
		//addInfoInReport("XB7 serial number : " + serialNumberXB7);
		Hooks.setFileWriter("TPIA serial number : " + serialNumberTPIA);
		Hooks.setFileWriterExampleData(serialNumberTPIA + " | ");
		is.clickOnSerialNumValidateButton();
		waitForLoading(sd.driver);
		is.clickOnInternetOkButton();
		waitForLoading(sd.driver);				
//		sd.driver.findElement(By.xpath("//*[@class=\"UITable9Box-body\"]//table[@class=\"UIVerticalLayout offer-placeholder\"]//input[@class=\"UICheckBox UICheckFeature_left_cb\"]")).click();
		waitForLoading(sd.driver);

	}

	@And("^modify the account to change wifi router$")
	public void modifyAccountChangeWifi() throws Exception {
		//				String moe = HostUrls.getMOEUrl();
		//				String moe_url = moe + "&accountId=" + accountid;
		is = new InternetServices(sd.driver);
		cd = new CustomerDetails(sd.driver);				
		//pageobjmanager = new pageObjectManager(driver);
		//				utils.openUrlNewTab(moe_url);
		waitForLoading(sd.driver);
		Thread.sleep(5000);
		//	    as.selectPlan();
		waitForLoading(sd.driver);
		Thread.sleep(15000);

		//	is.selectInternetWrench();	
		cd.OrderEntryTab();
		is.changewifi();
		serialNumberXB7 = FakeHardwareGeneration.generateSerialNum("XB7");
		is.setInternetSerialNum(serialNumberXB7);
		//addInfoInReport("XB7 serial number : " + serialNumberXB7);
		Hooks.setFileWriter("XB7 serial number : " + serialNumberXB7);
		Hooks.setFileWriterExampleData(serialNumberXB7 + " | ");
		is.clickOnSerialNumValidateButton();
		waitForLoading(sd.driver);
		is.clickOnInternetOkButton();
		waitForLoading(sd.driver);				
		sd.driver.findElement(By.xpath("//*[@class=\"UITable9Box-body\"]//table[@class=\"UIVerticalLayout offer-placeholder\"]//input[@class=\"UICheckBox UICheckFeature_left_cb\"]"))
		.click();
		waitForLoading(sd.driver);

	}

	@And("^remove XB7$")
	public void removeXB7() throws InterruptedException {
		is = new InternetServices(sd.driver);
		is.deleteXB7();
		waitForLoading(sd.driver);
	}

	@And("^select the disconnection reason for the created account$")
	public void disconnectReason() throws Exception {
		ap.clickAppointmentlink();
		waitForLoading(sd.driver);
		waitForLoading(sd.driver);
		Thread.sleep(15000);
		ap.selectDisconnectCalendar();
		waitForLoading(sd.driver);
		Thread.sleep(50000);
		ap.selectDisconnectionDate();
		waitForLoading(sd.driver);
		ap.setAuthorisedby();
		ap.setDisconnectionReason();
	}

	@And("^modify the account to reinstate the services with past resources for Internet service$")
	public void reinstateWithPastResourcesInternetService() throws Exception {
		ReinPg= new ReinstatePage(sd.driver);
		String moe = HostUrls.getMOEUrl();
		String premisemove_url = moe + "&accountId=" + accountid + "&newLocationId="
				+ prop.getProperty("premisemovelocationid");
		//utils.openUrlNewTab(premisemove_url);
		ReinPg.selectReinstateWithPastResources();

		waitForLoading(sd.driver);
		billingpage.clickBillingPreferenceTab();
		waitForLoading(sd.driver);
		billingpage.selectMailingAddress();
		waitForLoading(sd.driver);
		billingpage.selectpaperbill();
	}

	@And("^modify the account to reinstate the services with past resources for Internet service in webud$")
	public void reinstateAccountInWebud() throws Exception {
		ReinPg= new ReinstatePage(sd.driver);
		billingpage = new BillingPreferncesPage(sd.driver, this.scenario);
		ReinPg.selectReinstateWithPastResources();				
		waitForLoading(sd.driver);
		billingpage.clickBillingPreferenceTab();
		waitForLoading(sd.driver);
		billingpage.selectMailingAddress();
		waitForLoading(sd.driver);
		billingpage.selectpaperbill();
	}			
	@And("^AOE account is created$")
	public void createAOEAccount()
			throws UnrecoverableKeyException, KeyException, NoSuchAlgorithmException, KeyStoreException, IOException {
		accountnumber = AOE.createAOEAccount();
	}

	@And("^p150 account is created$")
	public void createP150Account() throws UnrecoverableKeyException, KeyException, NoSuchAlgorithmException,
	KeyStoreException, IOException, SAXException, ParserConfigurationException {
		P150Acc=new P150AccountCreate(sd.driver);
		serialNumberXB6 = FakeHardwareGeneration.generateSerialNum("XB6");
		accountnumber = P150Acc.createP150Account(serialNumberXB6);
		Hooks.setFileWriter("account number : " + accountnumber);
	}

	@Then("^disconnect p150 account$") 
	public void discP150Account()
			throws UnrecoverableKeyException, KeyException, NoSuchAlgorithmException, KeyStoreException, IOException {
		P150AccDisconn=new P150AccountDisconnect(sd.driver);
		int status = P150AccDisconn.accountDisconnect(accountnumber, serialNumberXB6);
		Assert.assertEquals("invalid response",status, 200);
	}

	@And("^changeInternetModem$")
	public void changeInternetModem() throws Exception {

		//				is.selectInternetWrench();
		//				is.deleteinternet();
		//				waitForLoading(sd.driver);
		//				is.SelectInternetOkButton();
		is = new InternetServices(sd.driver);
		is.selectInternetWrenchWithModemSerialNumer();
		is.deleteinternet();
		waitForLoading(sd.driver);
		is.SelectInternetOkButton();
	}

	//Swati - Updated for NGV- 43446
	@And("^provisionioning Existing provisionDevice in FFM$")
	public void provisionInFFMExistingDevice(DataTable dt)
			throws InterruptedException, IOException, SAXException, ParserConfigurationException,Exception {
		List<List<String>> list = dt.asLists(String.class);
		String provisionDevices = list.get(0).get(0);
		String provisionDevice[] = provisionDevices.split(",");
		for (int i = 0; i < provisionDevice.length; i++) {
			switch (provisionDevice[i].toUpperCase()) {
			case "XB7":
				ffmPage.provisionXB7();
				break;
				
			case "XI6":
				ffmPage.provisionExisitngXi6();
				waitForLoading(sd.driver);
				break;
				
			case "PHONE":
				ffmPage.provisionPhone();
				waitForLoading(sd.driver);
				break;	
				
			case "FIBREMODEM":
				ffmPage.provisionFibremodem();
			}
		}
	}


	@And("^selects phone service (.*)$")
	public void selectsPhoneService(String technicianAppointment)
			throws Exception {
		ps=new PhoneServices(sd.driver);			
		if (phonePackage.equals("notset")) {
			phonePackage = prop.getProperty("defaultPhonePackage", "Personal Phone").trim();
		}
		Thread.sleep(2000);
		ps.Add_Phone(phonePackage);
		ps.selectPhoneNumber();
		ps.Add_Hardware();
		if (technicianAppointment.trim().equals("techNotRequired")) {
			ps.clickWrench();
			serialNumberDPT = FakeHardwareGeneration.generateSerialNum("DPT");
			ps.enterPhoneSerialNumber(serialNumberDPT);
			ps.clickValidateButton();
			ps.clickPhoneOkButton();
		}
	}

	@And("^click on modify customer order$")
	public void clickModifyCustomerOrder() throws InterruptedException {
		TechCnf = new TechConfirmPage(sd.driver);
		Thread.sleep(5000);
		TechCnf.clickModifyCustomerOrder();
		Thread.sleep(180000);
	}

	@And("^selects Flex Employee TV service with (.*) (.*)$")
	public void selectsFlexEmployeeTvService(String TVHardware, String technicianAppointment)
			throws Exception {

		utils =  new TestUtil(sd.driver);
		ts = new TVServices(sd.driver);
		// ts.selectLimitedTV();				
		ts.selectFlexTV();
		// ts.selectTotalTV();
		//				 ts.selectEmployeeTV();
		ts.selectTvWrench();
		String hardware[] = TVHardware.split(",");
		for (int i = 0; i < hardware.length; i++) {
			switch (hardware[i].toUpperCase()) {
			case "FLEXXI6":
				Thread.sleep(2000);
				ts.selectFlexXi6();
				if (technicianAppointment.equals("techNotRequired")) {
					serialNumberXi6 = FakeHardwareGeneration.generateSerialNum("XI6");
					ts.enterSerialNumber(serialNumberXi6);
					ts.clickValidateButton();
					//addInfoInReport("Xi6 serial number : " + serialNumberXi6);
					//ExtentCucumberAdapter.addTestStepLog("Xi6 serial number : " + serialNumberXi6);
				}
				break;
			case "XG1V4":
				Thread.sleep(2000);
				ts.selectXg1v4();
				if (technicianAppointment.equals("techNotRequired")) {
					serialNumberXG1V4 = FakeHardwareGeneration.generateSerialNum("XG1V4");
					// serialNumberXG1V4 = "M11821TRC722";
					ts.enterSerialNumber(serialNumberXG1V4);
					ts.clickValidateButton();
					//addInfoInReport("XG1V4 serial number : " + serialNumberXG1V4);
					//ExtentCucumberAdapter.addTestStepLog("XG1V4 serial number : " + serialNumberXG1V4);
				}
				break;
			case "XG1V3":
				Thread.sleep(2000);
				ts.selectXG1V3();
				Thread.sleep(2000);
				if (technicianAppointment.equals("techNotRequired")) {
					serialNumberXG1V3 = FakeHardwareGeneration.generateSerialNum("XG1V3");
					ts.enterSerialNumber(serialNumberXG1V3);
					ts.clickValidateButton();
					//addInfoInReport("XG1V3 serial number : " + serialNumberXG1V3);
					//ExtentCucumberAdapter.addTestStepLog("XG1V3 serial number : " + serialNumberXG1V3);
				}
				break;
			case "XI6":
				prop.setProperty("is_TV_Xi6", "true");
				Thread.sleep(5000);
				ts.selectXi6();
				if (technicianAppointment.equals("techNotRequired")) {
					serialNumberXi6 = FakeHardwareGeneration.generateSerialNum("XI6");
					ts.enterSerialNumber(serialNumberXi6);
					ts.clickValidateButton();
					//							addInfoInReport("Xi6 serial number : " + serialNumberXi6);
					//							ExtentCucumberAdapter.addTestStepLog("Xi6 serial number : " + serialNumberXi6);
				}
				break;

			case "SHAWMOXIGATEWAY":
				Thread.sleep(2000);
				ts.selectShawMoxiGateway();
				if (technicianAppointment.equals("techNotRequired")) {
					serialNumberMoxiGateway = FakeHardwareGeneration.generateSerialNum("SHAWMOXIGATEWAY");
					ts.enterSerialNumber(serialNumberMoxiGateway);
					ts.clickValidateButton();
					//							addInfoInReport("Moxi Gateway serial number : " + serialNumberMoxiGateway);
					//							ExtentCucumberAdapter.addTestStepLog("Moxi Gateway serial number : " + serialNumberMoxiGateway);
				}
				break;
			case "SHAWPORTAL":
				ts.selectShawMoxiPortal();
				break;
			case "XID":
				Thread.sleep(2000);
				ts.selectXid();
				Thread.sleep(2000);
				if (technicianAppointment.equals("techNotRequired")) {
					serialNumberXiD = FakeHardwareGeneration.generateSerialNum("XID");

					// serialNumberXiD = "PAY300050994";
					ts.enterSerialNumber(serialNumberXiD);
					ts.clickValidateButton();
					//							addInfoInReport("XiD serial number : " + serialNumberXiD);
					//							ExtentCucumberAdapter.addTestStepLog("XiD serial number : " + serialNumberXiD);
				}
				break;
			case "DCX3510":
				ts.selectDCX3510();
				if (technicianAppointment.equals("techNotRequired")) {
					serialNumberDCX3510 = FakeHardwareGeneration.generateSerialNum("DCX3510");
					ts.enterSerialNumber(serialNumberDCX3510);
					ts.clickValidateButton();
					//							addInfoInReport("DCX3510 serial number : " + serialNumberDCX3510);
					//							ExtentCucumberAdapter.addTestStepLog("DCX3510 serial number : " + serialNumberDCX3510);
				}
				break;
			case "DCT700":
				Thread.sleep(2000);
				ts.selectDCT700();
				if (technicianAppointment.equals("techNotRequired")) {
					serialNumberDCT700 = FakeHardwareGeneration.generateSerialNum("DCT700");
					ts.enterSerialNumber(serialNumberDCT700);
					ts.clickValidateButton();
					//							addInfoInReport("DCT700 serial number : " + serialNumberDCT700);
					//							ExtentCucumberAdapter.addTestStepLog("DCT700 serial number : " + serialNumberDCT700);
				}
				break;
			case "DCX3400":
				Thread.sleep(2000);
				ts.selectDCX3400();
				if (technicianAppointment.equals("techNotRequired")) {
					serialNumberDCX3400 = FakeHardwareGeneration.generateSerialNum("DCX3400");
					ts.enterSerialNumber(serialNumberDCX3400);
					ts.clickValidateButton();
					//							addInfoInReport("DCX3400 serial number : " + serialNumberDCX3400);
					//							ExtentCucumberAdapter.addTestStepLog("DCX3400 serial number : " + serialNumberDCX3400);
				}
				break;
			case "DCX3200":
				ts.selectDCX3200();
				Thread.sleep(2000);
				if (technicianAppointment.equals("techNotRequired")) {
					serialNumberDCX3200 = FakeHardwareGeneration.generateSerialNum("DCX3200");
					ts.enterSerialNumber(serialNumberDCX3200);
					ts.clickValidateButton();
					//							addInfoInReport("DCX3200 serial number : " + serialNumberDCX3200);
					//							ExtentCucumberAdapter.addTestStepLog("DCX3200 serial number : " + serialNumberDCX3200);
				}
				break;
			}
		}
		ts.selectOkButton();
	}

	@And("^upgrade the service to flex trial$")
	public void upgradeToFlex() throws Exception {
		ts.selectFlexTV();
		ts.selectTvWrench();
		ts.levelupTV();
		Thread.sleep(2000);
		ts.selectOkButton();
	}

	@And("^upgrading the service to flex trial$")
	public void upgradingToFlex() throws Exception {
		ts.selectFlexTV();
		ts.selectTvWrench();
		Thread.sleep(2000);
		ts.deletetv();
		waitForLoading(sd.driver);
		ts.selectXiOne();
		waitForLoading(sd.driver);
		serialNumberXiOne = FakeHardwareGeneration.generateSerialNum("XIONE");
		ts.enterSerialNumber(serialNumberXiOne);
		ts.clickValidateButton();
		Hooks.setFileWriter("XIone serial number : " + serialNumberXiOne);
		ts.selectOkButton();
	}


	@And("^validate the mailout order summary page$")
	public void mailOutSummary() throws IOException, InterruptedException
	{
		op.overviewHardTab();
		//TestBase.takeScreenshot("OverviewPage");	
	}

	@And("^change the shipping mailout address$")
	public void changeMailOut() throws Exception
	{
		ap = new Appointments(sd.driver,this.scenario);
		Thread.sleep(2000);
		ap.clickAppointmentlink();
		Thread.sleep(2000);
		ap.changeDFAddress();
		//TestBase.takeScreenshot("Modified DF Address");
	}

	//Swati : Added for EWAN TCs for NGV-43452
	@And("^staff moves from cable to fibre selects internetservice(.*) (.*) (.*)$")
	public void selectsInternetServiceForStaffCabelToFibre(String internetService, String device, String technicianAppointment)
			throws Exception {
		String selfInstall = prop.getProperty("selfinstall");
		is = new InternetServices(sd.driver);
		waitForLoading(sd.driver);
		is.selectInternetPackage(internetService);
		//TestBase.takeScreenshot("SelectInternetService");
		//addInfoInReport("Tech Appointment = " + technicianAppointment + "  #  Self Install = selfInstall");
		if (technicianAppointment.equals("techNotRequired") && selfInstall.toUpperCase().equals("NO")) {
			switch (device.toUpperCase()) {
			case "XB6":
				if (internetService.equalsIgnoreCase("Employee Internet 300")) {
					is.selectInternetWrench();
					waitForLoading(sd.driver);
					sd.driver.findElement(By.xpath("//div[@id='hardware-popup']//span[text()='Delete']")).click();
					waitForLoading(sd.driver);
					sd.driver.findElement(By.xpath("//a[@id='hardware-popup-ok-button']//span[contains(text(),'OK')]"))
					.click();
					waitForLoading(sd.driver);
					sd.driver.findElement(By.xpath("//td[contains(@class,'FourthCategory')]//span[text()='Add Product']"))
					.click();
					waitForLoading(sd.driver);
				}
				is.clickXb6Wrench();
				if (internetService.equalsIgnoreCase("Employee Internet 300")) {
					is.selectXB6RentButton();
				}

				serialNumberXB6 = FakeHardwareGeneration.generateSerialNum("XB6");
				is.setInternetSerialNum(serialNumberXB6);
				//addInfoInReport("XB6 serial number : " + serialNumberXB6);
				Hooks.setFileWriter("XB6 serial number : " + serialNumberXB6);
				Hooks.setFileWriterExampleData(serialNumberXB6 + " | ");
				break;
			case "XB7":
				if (internetService.equalsIgnoreCase("Employee Internet 300")) {
					is.selectInternetWrench();
					waitForLoading(sd.driver);
					sd.driver.findElement(By.xpath("//div[@id='hardware-popup']//span[text()='Delete']")).click();
					waitForLoading(sd.driver);
					sd.driver.findElement(By.xpath("//a[@id='hardware-popup-ok-button']//span[contains(text(),'OK')]"))
					.click();
					waitForLoading(sd.driver);
					sd.driver.findElement(By.xpath("//td[contains(@class,'FourthCategory')]//span[text()='Add Product']"))
					.click();
					waitForLoading(sd.driver);
				}
				waitForLoading(sd.driver);
				is.addXB7Product();

				if (internetService.equalsIgnoreCase("Employee Internet 300")) {
					is.selectXB6RentButton();
				}

				serialNumberXB7 = FakeHardwareGeneration.generateSerialNum("XB7");
				is.setInternetSerialNum(serialNumberXB7);
				Hooks.setFileWriter("XB7 serial number : " + serialNumberXB7);
				Hooks.setFileWriterExampleData(serialNumberXB7 + " | ");
				break;
			}
			//Swati - calling clickOnSerialNumValidateButton
			is.clickOnSerialNumValidateButton();
			waitForLoading(sd.driver);
			is.clickOnInternetOkButton();
			//TestBase.takeScreenshot("SelectInternetDevice");
			waitForLoading(sd.driver);
			is.clickWifiRouterCheckBox();
			if (internetService.equalsIgnoreCase("Employee Internet 300")) {
				is.selectInternetServiceCheckbox();
			}


		}
	}

	@And("^navigates to suspension history to validate the resume status$")
	public void navigatesToSuspensionHistoryToValidateResumeStatus() throws Exception 
	{
		ncSusHistoryPage= new NetCrackerSuspensionHistoryPage(sd.driver);
		ncSusHistoryPage.suspensionHistory();
		Thread.sleep(40000); // Resume takes some time for status update (Change 4/3/2024)
		sd.driver.navigate().refresh();
		//TestBase.takeScreenshot("suspensionHistory");
		ncSusHistoryPage.validateFirstLobResumeStatus();
		Thread.sleep(2000);
		ncSusHistoryPage.validateSecondLobResumeStatus();
		Thread.sleep(2000);
		ncSusHistoryPage.validateThirdLobResumeStatus();

	}

	@And("^supress E911 service$")
	public void supressE911Service() throws Exception {
		ps= new PhoneServices(sd.driver);
		ps.E911Supression();
	}

	@And("^change the shipping mailout address to Shaw Delivery$")
	public void changeMailOutShawDelivery() throws Exception
	{
		ap = new Appointments(sd.driver,this.scenario);
		ap.clickAppointmentlink();
		waitForLoading(sd.driver);
		//addInfoInReport("Inflight Modification to Shaw Delivery");

		ap.selectShawDelivery();
		waitForLoading(sd.driver);
		ap.dismissFFMIntegrationMessage();
		ap.selectSMSNumberOptedOut();
		waitForLoading(sd.driver);
		ap.selectforceappointment();
		//TestBase.takeScreenshot("Modified DF Address");
		ap.setAuthorisedby();
		ap.setActivedirectory();
		//TestBase.takeScreenshot("Shaw Delivery appointment");
	}

	@And("^navigates to service call page$")
	public void navigatestoServicecallPage() throws InterruptedException {
		utils = new TestUtil(sd.driver);
		// String accountid = "10000000003144261";
		String serviceCallUrl = HostUrls.getServiceCallUrl() + accountid;
		utils.openUrlNewTab(serviceCallUrl);
	}
	@And("^navigates to service call page in webud	(.*)	(.*)$")
	public void navigatestoServicecallPageinwebud(String UserName, String Password) throws Exception {
		servCallPage= new ServiceCallPage(sd.driver);
		if (HostUrls.matrix.contains("130")){checkURL="130-ffmweb.matrix.sjrb.ad";}
		else if(HostUrls.matrix.contains("113")) {checkURL="113-ffmweb.matrix.sjrb.ad";}
		else if(HostUrls.matrix.contains("182")) {checkURL="182-ffmweb.matrix.sjrb.ad";}
		else if(HostUrls.matrix.contains("181")) {checkURL="181-ffmweb.matrix.sjrb.ad";}
		else if(HostUrls.matrix.contains("135")) {checkURL="135-ffmweb.matrix.sjrb.ad";}
		servCallPage.selectServiceCalltab(checkURL, UserName, Password);
	}

	@And("^Book an service appointment	(.*)	(.*)$")
	public void bookServiceAppointment(String strserviceType, String notes) throws Exception {
		servCallPage= new ServiceCallPage(sd.driver);
		servCallPage.clickNewServiceCall();
		servCallPage.selectServiceType(strserviceType);
		servCallPage.notes(notes);
		servCallPage.clickForceAppointmnet();
		servCallPage.clickForceAppointmnetButton();
		servCallPage.clickSmsOptOut();
		servCallPage.bookServiceCall();
		serviceId = servCallPage.getServiceId();
		ExtentCucumberAdapter.addTestStepLog("Service Id : " + serviceId);

	}

	@And("^click on existing ffmhardware and swapping	(.*)$")
	public void clickOnExsistingFFMHardware(String swapDevice) throws Exception {
		String deviceToSwap[] = swapDevice.split(",");
		ffmPage.clickExistingHardware();
		ffmPage=new FFMPage(sd.driver);
		for (int i = 0; i < deviceToSwap.length; i++) {
			switch (deviceToSwap[i].toUpperCase().trim()) {
			case "DCX3400":
				ffmPage.clickDCXSwapButton();
				break;
			case "HITRON":
				ffmPage.clickHitronSwapButton();
				break;
			case "DCT":
				ffmPage.clickDCTSwapButton();
				break;
			default:
				ffmPage.clickFFMSwapButton(deviceToSwap[i].trim());
				break;	
			}
		}
		//TestBase.takeScreenshot("ffmswappage");
	}

	@And("^check in order summary for swap$")
	public void checkOrderSummary() throws Exception {
		utils = new TestUtil(sd.driver);
		immswappage = new ImmediateSwapPage(sd.driver);
		String overviewpage_url = HostUrls.getOverviewPageUrl();
		String overviewpage = overviewpage_url + "&accountId=" + accountid;
		utils.openUrlNewTab(overviewpage);
		Thread.sleep(60000);
		immswappage.clickOrderSummary();
		Thread.sleep(2000);
		//TestBase.takeScreenshot("orderSummary");
		String expectedOrderStatus = "Completed";
		String orderStatus = immswappage.checkImmediateSwapStatus();
		//TestBase.takeScreenshot("orderstatus");
		Assert.assertEquals(orderStatus, expectedOrderStatus, "Expected message is Completed");
	}

	@And("^check in order summary for swap in webud$")
	public void checkOrderSummaryinwebud() throws Exception {
		immswappage = new ImmediateSwapPage(sd.driver);
		immswappage.clickOrderSummaryinwebud();
		String expectedOrderStatus = "Completed";
		String orderStatus = immswappage.checkImmediateSwapStatus();
		Assert.assertEquals(orderStatus, expectedOrderStatus);
		//	Assert.assertEquals(orderStatus, expectedOrderStatus, "Expected message is Completed");
	}

	String ordernumber="";
	@Then("^user checks the Order Status in Account Summary in Overview tab for	(.*)	(.*)$")
	public void checkAccountSummaryOrderStatus(String customerOrderType, String expectedcustomerfOrderStatus ) throws Exception {
		op = new OverviewPage(sd.driver, this.scenario);
		webUdLogin = new WebUD_SAML_Login(sd.driver,this.scenario);	
		String strcustomerOrderType = (customerOrderType.replace("\"", "")).trim();
		String strexpectedcustomerfOrderStatus = (expectedcustomerfOrderStatus.replace("\"", "")).trim();
		op.checkAccountSummaryOrderStatus("", strcustomerOrderType, strexpectedcustomerfOrderStatus);
	}

	@And("^navigates to service call FFM$")
	public void navigatesToFfmDerviceCall() throws Exception

	{
		utils = new TestUtil(sd.driver);
		ffmPage=new FFMPage(sd.driver);
		String ffmurl = configprop.getProperty("ffmurl");
		utils.openUrlNewTab(ffmurl);
		ffmPage.updateActiveBranchId();
		ffmPage.orderSearch();
		ffmPage.clickServiceCall();
		ffmPage.enterWorkOrderNumber(serviceId);
		ffmPage.clickSearchButton();
		ffmPage.clickActiveAccount();
	}

	@And("^update customer details$")
	public void updateCustomerDetails() throws Exception {
		cd = new CustomerDetails(sd.driver);
		Thread.sleep(50000);
		cd.clickCustomerAndIdTab();
		Thread.sleep(4000);
		cd.updateEmailAddress();
		Thread.sleep(5000);
		cd.setEmailAddress("swati.hota@sjrb.ca");
	}

	@And("^add phone features$")
	public void addPhoneFeature() throws Exception {

		ps= new PhoneServices(sd.driver);
		ps.VoicemailAndUnlimitedFeatureAndILDCalling();

	}

	@And("^modify the account to downgrade the (.*)$")
	public void downgradeServices(String services) throws InterruptedException {
		utils =  new TestUtil(sd.driver);
		String moe_url = HostUrls.getMOEUrl() + "&accountId=" + accountid;
		utils.openUrlNewTab(moe_url);
		//	Thread.sleep(40000);
		//	String service[] = services.split(",");
		//
		//	for (int i = 0; i < service.length; i++) {
		//		Thread.sleep(4000);
		//		switch (service[i].toUpperCase()) {
		//		case "INTERNET":
		//			is.selectInternet75();
		//			Thread.sleep(5000);
		//			break;
		//		case "TV":
		//			ts.selectLimitedTV();
		//			Thread.sleep(2000);
		//			break;
		//		}

		//}

	}

	@And("^sets up appointment and add authorizer$")
	public void sets_up_appointment_and_add_authorizer() throws Exception {

		ap = new Appointments(sd.driver,this.scenario);
		ap.clickAppointmentlink();
		waitForLoading(sd.driver);
		ap.setAuthorisedby();
		//	Thread.sleep(5000);
		ap.setActivedirectory();

	}

	@And("^validate alone the order in DSA for (.*) (.*)$")
	public void validateDSAAlone(String devices, String serialNumbers)
			throws IOException, SAXException, ParserConfigurationException {

		if (prop.getProperty("skipDSA", "false").equalsIgnoreCase("true")) {
			ExtentCucumberAdapter.addTestStepLog("skipDSA flag set true, skipping DSA Validation");
			return;
		}

		String dsaDevices[] = devices.split(",");
		String serialNumber[] = serialNumbers.split(",");

		//	Assert softAssert = new Assert();

		for (int i = 0; i < dsaDevices.length; i++) {
			Hooks.setFileWriterExampleData(dsaDevices[i] + " | " + serialNumber[i] + " | ");
			switch (dsaDevices[i].toUpperCase().trim()) {
			case "DCX3400":
			case "DCX3200":
			case "XI6":
			case "XID":
			case "DCT":
			case "DCT700":
				ExtentCucumberAdapter.addTestStepLog("DSA Validation is not required for " + dsaDevices[i]);
				break;
			default:
				String macAdd = FakeHardwareGeneration.generateMacAddress(serialNumber[i], "docsys");
				int dsaStatus = DSAValidation.validateDSA(macAdd);
				Assert.assertEquals("DSA VAlidation failed for " + dsaDevices[i],dsaStatus, 200);
				break;
			}
		}
		//	softAssert.assertAll();
	}

	@And("^validate alone the order in CPE for (.*) (.*)$")
	public void validateCPEAlone(String devices, String serialNumbers)
			throws IOException, SAXException, ParserConfigurationException {
		String cpeDevices[] = devices.split(",");
		String serialNumber[] = serialNumbers.split(",");

		if (prop.getProperty("skipCPE", "false").equalsIgnoreCase("true")) {
			ExtentCucumberAdapter.addTestStepLog("skipCPE flag set true, skipping CPE Validation");
			return;
		}

		for (int i = 0; i < cpeDevices.length; i++) {
			String serialnum = serialNumber[i];
			Hooks.setFileWriterExampleData(cpeDevices[i] + " | " + serialnum + " | ");
			String cpeStatus = CPEValidation.validateCPE(serialnum);
			Assert.assertEquals(cpeStatus, "True");
			ExtentCucumberAdapter.addTestStepLog(cpeStatus);
		}
	}

	@And("^validate alone the order in FDB (.*) (.*)$")
	public void checkAloneFDBStatus(String devices, String serialNumbers)
			throws IOException, SAXException, ParserConfigurationException, InterruptedException {

		utils = new TestUtil(sd.driver);
		fdb = new FDBValidation(sd.driver);
		if (prop.getProperty("skipFDB", "false").equalsIgnoreCase("true")) {
			ExtentCucumberAdapter.addTestStepLog("skipFDB flag set true, skipping FDB Validation");
			return;
		}
		if (TestBase.prop.getProperty("environment", "non-timeshifter").equalsIgnoreCase("timeshifter")) {
			ExtentCucumberAdapter.addTestStepLog("FDB Validation not required for timeshifter");
			return;
		}
		String fdbDevices[] = devices.split(",");
		String macAddress = "";
		String fdbUrl = "";
		String deviceStatusFDB = "";
		String serialNumber[] = serialNumbers.split(",");

		for (int i = 0; i < fdbDevices.length; i++) {
			switch (fdbDevices[i].toUpperCase().trim()) {
			case "HITRON":
			case "XB6":
			case "XG1V4":
				macAddress = FakeHardwareGeneration.generateMacAddress(serialNumber[i], "docsys");
				fdbUrl = (HostUrls.getFDBUrl()) + macAddress;
				addURLInReport(fdbUrl, "FDBPage");
				utils.openUrlNewTab(fdbUrl);
				Thread.sleep(2000);
				fdb.loginToFDB();
				Hooks.setFileWriterExampleData(fdbDevices[i] + " | " + serialNumber[i] + " | ");
				deviceStatusFDB = fdb.getdeviceStatus();
				Assert.assertEquals(deviceStatusFDB, "ENABLED", "FDB Status");
				ExtentCucumberAdapter.addTestStepLog("FDB Status: " + deviceStatusFDB);

				ExtentCucumberAdapter.addTestStepLog("FDB status for : " + fdbDevices[i] + deviceStatusFDB);
				break;
			default:
				ExtentCucumberAdapter.addTestStepLog("FDB not applicable for " + fdbDevices[i]);
				break;
			}
		}
	}

	@And("^modify the order to retrieve order information$")
	public void retrieveOrderInformation() throws IOException, InterruptedException,Exception {
		ReinPg = new ReinstatePage(sd.driver);
		Thread.sleep(45000);
		utils = new TestUtil(sd.driver);
		String moe = HostUrls.getMOEUrl();
		String moe_url = moe + "&accountId=" + accountid;
	//	utils.openUrlNewTab(moe_url);
		Thread.sleep(2000);
		ReinPg.selectRetrieveAccountInformation();
		//TestBase.takeScreenshot("Reinstate Page");

	}

	@And("^sets up appointment without technician as RetailPickup$")
	public void setAppointment() throws Exception {
		ap = new Appointments(sd.driver,this.scenario);
		ap.clickAppointmentlink();
		ap.selectSelfconnect();
		ap.selectRetailPickup();
		ap.setAuthorisedby();
		// ap.setActivedirectory();
		// Thread.sleep(2000);
		// ap.clickValidatebutton();
		// Thread.sleep(2000);
		//	ap.MethodOfConfirmation();
		//	ap.setAcceptanceId("0199");
	}

	@And("^add phone services via Vanity Search$")
	public void addPhoneServiceVanitySearch() throws Exception {
		ps = new PhoneServices(sd.driver);
		if (prop.getProperty("disablePhoneSteps", "false").equalsIgnoreCase("true")) {
			//		addInfoInReport("disablePhoneSteps flag set true, skipping phone related steps");
			return;
		}
		if (phonePackage.equals("notset")) {
			phonePackage = prop.getProperty("defaultPhonePackage", "Personal Phone").trim();
		}
		waitForLoading(sd.driver);
		ps.Add_Phone(phonePackage);
		ps.selectPhoneNumberByVanitySearch();
		ps.selectXB6PhoneService();
	}


	@And("^selects xpods$")
	public void addXpods() throws Exception {
		is =new InternetServices(sd.driver);
		is.selectXpod();
	}

	@And("^modify the account to swap hitron with xb6 and legacy tv with xi6$")
	public void swapdevices() throws Exception {
		is =new InternetServices(sd.driver);
		ts=new TVServices(sd.driver);
		ds =new DisconnectServicesPage(sd.driver);
		ps =new PhoneServices(sd.driver);
		utils=new TestUtil(sd.driver);
		String moe = HostUrls.getMOEUrl();
		String moe_url = moe + "&accountId=" + accountid;
		utils.openUrlNewTab(moe_url);
		is.selectInternetWrench();
		Thread.sleep(3000);
		is.deleteinternet();
		Thread.sleep(3000);
		is.SelectInternetOkButton();
		Thread.sleep(3000);
		ts.selectTvWrench();
		Thread.sleep(20000);
		ts.deletetv();
		Thread.sleep(2000);
		ts.selectXi6();
		Thread.sleep(2000);
		ts.selectOkButton();
		Thread.sleep(2000);
		ds.disconnectPhone();
		Thread.sleep(2000);
		ps.addPersonalPhone();
		Thread.sleep(2000);
		is.AddXB6Product();
		Thread.sleep(2000);
		is.selectPhoneServiceXB6();
		Thread.sleep(6000);
		// as.clickXi6Message();
		// Thread.sleep(2000);

	}

	@And("^sets up retailpickup appointment (.*)$")
	public void setRetailPickupAppointment(String address) throws Exception {

		ap= new Appointments(sd.driver,this.scenario);
		ap.clickAppointmentlink();
		Thread.sleep(2000);
		ap.selectRetailPickup();
		ap.selectRetailPickupAddress(address);

	}

	@And("^navigates to review tab to select email order summary as yes$")
	public void emailOrderSummaryYes() throws Exception {
		as= new AddServicesAndFeatures(sd.driver);
		rp= new ReviewPage(sd.driver);
		rp.clickReviewTab();
		Thread.sleep(2000);
		rp.setEmailOrderSummary();
		//	TestBase.takeScreenshot("OrderSummaryReview");

		as.checkTODOMessage();
		Thread.sleep(2000);
	}
	
	@And("^user verifies the installation fee$")
	public void emailOrderSummaryinstal() throws Exception {
		as= new AddServicesAndFeatures(sd.driver);
		rp= new ReviewPage(sd.driver);
		rp.clickReviewTab();
		Thread.sleep(2000);
	//	rp.setEmailOrderSummary();
		//	TestBase.takeScreenshot("OrderSummaryReview");
		String installationfee = rp.getinstallationfee();
		ExtentCucumberAdapter.addTestStepLog(installationfee);
		Thread.sleep(2000);
	}
	

	@And("^selects total bundle product category$")
	public void selectsTotalBundle() throws InterruptedException, IOException {
		as= new AddServicesAndFeatures(sd.driver);
		as.selectTotalBundle();
		//	TestBase.takeScreenshot("totalbundleselection");
	}

	@And("^provide the serialnumber for bundle products$")
	public void provideBundleProductSerialNumber()
			throws InterruptedException, IOException, SAXException, ParserConfigurationException {
		Thread.sleep(6000);
		is =new InternetServices(sd.driver);
		is.addXB6InternetProduct();
		//	TestBase.takeScreenshot("Interet");
		//	pageobjmanager.InternetServices().clickXb6Wrench();
		//	TestBase.takeScreenshot("Interet");
		//pageObjManager.InternetServices().selectXB6RentButton();
		//TestBase.takeScreenshot("Interet");
		//serialNumberXB6 = FakeHardwareGeneration.generateSerialNum("XB6");
		//pageobjmanager.InternetServices().setInternetSerialNum(serialNumberXB6);
		//pageObjManager.InternetServices().clickOnSerialNumValidateButton();
		//	pageObjManager.InternetServices().clickOnInternetOkButton();
		//	addInfoInReport("XB6 serial number : " + serialNumberXB6);
		//	Hooks.setFileWriter("XB6 serial number : " + serialNumberXB6);
		Thread.sleep(5000);
		//	pageobjmanager.TVServices().selectTvWrench();
		//	serialNumberXi6 = FakeHardwareGeneration.generateSerialNum("XI6");
		//	pageobjmanager.TVServices().enterSerialNumber(serialNumberXi6);
		//	pageobjmanager.TVServices().clickValidateButton();
		//	pageObjManager.TVServices().selectOkButton();
		//	addInfoInReport("Xi6 serial number : " + serialNumberXi6);
		//	Hooks.setFileWriter("Xi6 serial number : " + serialNumberXi6);
	}

	@And("^selects promotion$")
	public void selectPromotions() throws Exception {
		promotions=new Promotions(sd.driver);
		promotions.bundlePriceGuranteePromotion();
		//	TestBase.takeScreenshot("promotionselection");
	}

	@And("^downgrade the total bundle product$")
	public void removeTotalBundle() throws Exception {

		as= new AddServicesAndFeatures(sd.driver);
		is =new InternetServices(sd.driver);
		ts=new TVServices(sd.driver);
		waitForLoading(sd.driver);
		as.bundleOfferNotSelected();
		waitForLoading(sd.driver);
		is.selectFibreInternet75();
		ts.selectLimitedTV();
	}

	@And("^modify the account to resume the lobs$")
	public void modifyAccountToResumeServices() throws Exception {
		String moe = HostUrls.getMOEUrl();
		Thread.sleep(4000);
		String moe_url = moe + "&accountId=" + accountid;
		rp = new ReviewPage(sd.driver);
		snowbird= new SnowbirdSuspendResumePage(sd.driver);
		utils = new TestUtil(sd.driver);
//		utils.openUrlNewTab(moe_url);
		Thread.sleep(35000);
		snowbird.clickOperationsTab();
		Thread.sleep(2000);
		snowbird.selectSnowBird();
		Thread.sleep(2000);
		snowbird.selectSuspendEndDateCalendar();
		Thread.sleep(2000);
		snowbird.selectPreviousMonth();
		Thread.sleep(2000);
		snowbird.selectResumeDate();
		Thread.sleep(2000);
		snowbird.clickSuspendOkButton();
		Thread.sleep(2000);
		rp.clickReviewTab();
		Thread.sleep(2000);
		rp.setEmailOrderSummary();
		Thread.sleep(2000);
	}

	@And("^modify the account to resume the lobs in WebUD$")
	public void modifyAccountToResumeServicesinWebUD() throws Exception {
		rp = new ReviewPage(sd.driver);
		snowbird= new SnowbirdSuspendResumePage(sd.driver);
		snowbird.clickOperationsTab();
		snowbird.selectSnowBird();
		snowbird.selectSuspendEndDateCalendar();
		snowbird.selectPreviousMonth();
		snowbird.selectResumeDate();
		snowbird.clickSuspendOkButton();
		rp.clickReviewTab();
		rp.setEmailOrderSummary();
	}



	@Given("^User Logins to SAML by entering (.*)	(.*)$")

	public void userLoginsToSAML(String webUDUserName, String webUDUserPswd)
			throws Exception, IOException {
		webUdLogin = new WebUD_SAML_Login(sd.driver,this.scenario);
		Thread.sleep(2000);
		webUdLogin.login(webUDUserName, webUDUserPswd);
	}


	@And("^search the Customer By (.*)$")
	public void SearchCustomerBy(String searchCustBy)throws Exception {
		webUdLogin = new WebUD_SAML_Login(sd.driver,this.scenario);
		//Variable webUdsearchCustBy used as a global variable and reused in "input customer search value" method
		webUdsearchCustBy=searchCustBy;
		webUdLogin.searchCustomer(searchCustBy);
	}

	@And("^search the Customer By	(.*)	further$")
	public void SearchCustomerByfurther(String searchCustBy)throws Exception {
		webUdLogin = new WebUD_SAML_Login(sd.driver,this.scenario);
		//Variable webUdsearchCustBy used as a global variable and reused in "input customer search value" method
		webUdsearchCustBy=searchCustBy;
		webUdLogin.searchCustomerfurther(searchCustBy);
	}

	@And ("^click on the displayed address link")
	public void AddressLink() throws InterruptedException, IOException
	{
		webUdLogin = new WebUD_SAML_Login(sd.driver,this.scenario);
		webUdLogin.clickAddressLink();
	}

	@And("^input customer search value	(.*)$")
	public void SearchCustomerValue(String searchCusValue)throws Exception {
		webUdLogin = new WebUD_SAML_Login(sd.driver,this.scenario);
		if(webUdsearchCustBy.equalsIgnoreCase("Account Number"))
		{
			accountnumber="03000014088";

			if(accountnumber!= null)
			{
				webUdLogin.searchCustomerValue(accountnumber);
			}
			else
			{
				webUdLogin.searchCustomerValue(searchCusValue);
			}
		}
		else
		{
			webUdLogin.searchCustomerValue(searchCusValue);      
		}
		isLoaderSpinnerVisible(sd.driver);	//AddedShweta
		//	 TestBase.takeScreenshot("Search Value Displayed");

	}
	@And("^input cbacustomer search value	(.*)$")
	public void SearchTpiaCustomerValue(String cbasearchCusValue)throws Exception {
		webUdLogin = new WebUD_SAML_Login(sd.driver,this.scenario);
		if(webUdsearchCustBy.equalsIgnoreCase("Account Number"))
		{
			//	accountnumber="03700021311";
			
			if(accountnumber!= null)
			{
				webUdLogin.searchCbaCustomerValue(accountnumber);
			}
			else
			{
				webUdLogin.searchCbaCustomerValue(cbasearchCusValue);
			}
		}
		else
		{
			webUdLogin.searchCustomerValue(cbasearchCusValue);      
		}
		isLoaderSpinnerVisible(sd.driver);	//AddedShweta
		//	 TestBase.takeScreenshot("Search Value Displayed");

	}

	@And("create new customer for the given address")
	public void createCustomer() throws Exception
	{
		webUdLogin = new WebUD_SAML_Login(sd.driver,this.scenario);
		webUdLogin.createNewCustomer();
	}
	
	@And("create new customer for the given address wohandle")
	public void createCustomerwohandle() throws Exception
	{
		webUdLogin = new WebUD_SAML_Login(sd.driver,this.scenario);
		webUdLogin.createNewCustomerwohandle();
	}
	
	
	@And("^validate prov details (.*) (.*)$")
	public void validateprovdetails(String device, String TVHardware) throws Exception
	{
		prov = new ProvDetails(sd.driver);
		switch (device.toUpperCase()) {
		case "XB6":
			internetdevice_serialnumber=serialNumberXB6;
			break;
		case "XB7":
			internetdevice_serialnumber=serialNumberXB7;
			break;		
		case "HITRON":
			internetdevice_serialnumber=serialNumberHitron;
			break;
		}	
		String hardware[] = TVHardware.split(",");
		for (int i = 0; i < hardware.length; i++) {
			switch (hardware[i].toUpperCase()) {
			case "XG1V4":
				tvserialnumber=serialNumberXG1V4+";";
				break;
			case "XG1V3":
				tvserialnumber=serialNumberXG1V3+";";
				break;
			case "XI6":
				tvserialnumber=serialNumberXi6+";";
				break;
			case "XID":
				tvserialnumber=serialNumberXiD+";";
				break;
			case "DCX3510":
				tvserialnumber=serialNumberDCX3510+";";
				break;
			case "DCT700":
				tvserialnumber=serialNumberDCT700+";";
				break;
			case "DCX3400":
				tvserialnumber=serialNumberDCX3400+";";
				break;
			case "DCX3200":
				tvserialnumber=serialNumberDCX3200+";";
				break;
			case "DCX3400250GB":
				tvserialnumber=serialNumberDCX3400250GB+";";
				break;
			case "DCX3200P2M":
				tvserialnumber=serialNumberDCX3200P2M+";";
				break;
			case "DCX3200HDGUIDE":
				tvserialnumber=serialNumberDCX3200HDGuide+";";
				break;
			}
		}	
		prov.validateprovdetails(internetdevice_serialnumber, tvserialnumber);	
	}

	@And("^create new customer with (.*) (.*) (.*) (.*) (.*)$")
	public void CreateNewAccountCustomerAndIdTab(String firstName, String lastName, String email,
			String authType, String pin) throws Exception {
		cd = new CustomerDetails(sd.driver);
		cd.custAndIdTab(firstName, lastName, email, authType, pin);
		Hooks.setFileWriter("FirstName: " + firstName + "\nLastName: " + lastName + "\nEmail: " + email);
	}


	@And("^create a new customer with email transfer (.*) (.*) (.*) (.*) (.*)$")
	public void CreateNewAccwithemailCustomerAndIdTab(String firstName, String lastName, String email,
			String authType, String pin) throws Exception {
		cd = new CustomerDetails(sd.driver);
		cd.custAndIdTabemail(firstName, lastName, email, authType, pin);
		Hooks.setFileWriter("FirstName: " + firstName + "\nLastName: " + lastName + "\nEmail: " + email);
	}

	@And("^create new vip customer with (.*) (.*) (.*) (.*) (.*)$")
	public void CreateNewvipAccountCustomerAndIdTab(String firstName, String lastName, String email,
			String authType, String pin) throws Exception {
		cd = new CustomerDetails(sd.driver);
		cd.createNewAccountWithVipCustomerAndIdTab(firstName, lastName, email, authType, pin);

		Hooks.setFileWriter("FirstName: " + firstName + "\nLastName: " + lastName + "\nEmail: " + email);
	}

	@And("^create primary account holder with	(.*) (.*) (.*) (.*) (.*)	(.*)	(.*)	(.*)$")
	public void createNewAccountWithPronounCustomerAndIdTab(String firstName, String lastName, String email,
			String authType, String pin, String pronoun, String accountType, String accountSubType) throws Exception {
		cd = new CustomerDetails(sd.driver);
		cd.createNewAccountWithPronounCustomerAndIdTab(firstName, lastName, email, authType, pin, pronoun, accountType, accountSubType);
		Hooks.setFileWriter("FirstName: " + firstName + "\nLastName: " + lastName + "\nEmail: " + email);
	}
	@And("^modify pronoun for Primary Account Holder	(.*)$")
	public void modifypronounforPrimaryAccountHolder(String updatePrimaryPronoun) throws Exception {
		cd = new CustomerDetails(sd.driver);
		cd.modifypronounforPrimaryAccountHolder(updatePrimaryPronoun);
	}
	@And("close the displayed account")
	public void closeAccountDisplayed() throws Exception
	{
		webUdLogin = new WebUD_SAML_Login(sd.driver,this.scenario);
		webUdLogin.closeAccount();
	}

	@And("click on search icon")
	public void clickSearchIcon() throws Exception
	{
		webUdLogin = new WebUD_SAML_Login(sd.driver,this.scenario);
		webUdLogin.searchIcon();
	}

	@And("click on search icon refresh")
	public void clickSearchIconrefresh() throws Exception
	{
		webUdLogin = new WebUD_SAML_Login(sd.driver,this.scenario);
		webUdLogin.searchIconreferesh();
	}

	@Then("^Order status should be Completed in webud Overview Page$")
	public void validate_the_order_status_in_overview_page_webud() throws Exception {

		op = new OverviewPage(sd.driver, this.scenario);
		webUdLogin = new WebUD_SAML_Login(sd.driver,this.scenario);
		if (prop.getProperty("waitForOrderCompletion", "true").equalsIgnoreCase("false")) {
			Thread.sleep(5000);
			//		addInfoInReport("Not waiting for order completion in Overview Page. Skipping backend validations");
			return;
		}

		String orderStatus = op.webUDretrieveOrderStatus();
		String expectedOrderStatus = "Completed";
		//	addInfoInReport("Order Status : " + orderStatus);
		Hooks.setFileWriter("Order Status : " + orderStatus);
		Assert.assertEquals("Expected message is Completed",orderStatus, expectedOrderStatus);
	}

	@And("^launch application$")	

	public void relaunchApplication() throws MalformedURLException {

		tb.readPropertyFile();
		tb.driverInit();		
		sd.driver=tb.launchApplication();
	}	

	@And("^close browser$")	
	public void closebrowser() {
		sd.driver.quit();
	}


	@And("^modify the order to change the account to residential account (.*)$")
	public void resModifyAccount(String internetservice) throws Exception {
		as = new AddServicesAndFeatures(sd.driver);
		utils = new TestUtil(sd.driver);
		cd = new CustomerDetails(sd.driver);
		is = new InternetServices(sd.driver);
		ts = new TVServices(sd.driver);
		if (System.getProperty("environment").equalsIgnoreCase("webud"))
		{
			System.out.println("Changing the account from Staff to residential");
		}
		else
		{
			String moe_url = HostUrls.getMOEUrl() + "&accountId=" + accountid;
			utils.openUrlNewTab(moe_url);
		}
		//TestBase.takeScreenshot("Modify OE");
		//	Thread.sleep(5000);
		cd.clickCustomerAndIdTab();
		//	Thread.sleep(2000);
		cd.resAccountType();
		//	Thread.sleep(6000);
		as.clickAddServicesAndFeatures();
		//	Thread.sleep(10000);
		if (System.getProperty("environment").equalsIgnoreCase("webud"))
		{
			System.out.println("Changing the account from Staff to residential");
		}
		else
		{
			as.bundleOfferNotSelected();
		}
		//	Thread.sleep(5000);
		Thread.sleep(5000);
		as.selectPlan(internetservice);
		Thread.sleep(5000);
			as.internetNotSelected();
		//	Thread.sleep(5000);
		as.tvNotSelected();
		//	Thread.sleep(5000);
		is.selectIgniteInternetProduct();
		//	Thread.sleep(2000);
		is.selectInternetServiceCheckbox();
		//TestBase.takeScreenshot("SelectInternetDevice");
		//	Thread.sleep(4000);
		ts.selectLimitedTV();
		//	Thread.sleep(5000);

	}
	
	@And("^modify the order to change the account to staff account$")
	public void stafModifyAccount() throws Exception {
			as = new AddServicesAndFeatures(sd.driver);
			utils = new TestUtil(sd.driver);
			cd = new CustomerDetails(sd.driver);
			is = new InternetServices(sd.driver);
			ts = new TVServices(sd.driver);
		if(System.getProperty("environment").equalsIgnoreCase("webud"))
		{
			System.out.println("Changing the account from residential to staff");
		}
		else
		{
			String moe_url = HostUrls.getMOEUrl() + "&accountId=" + accountid;
			utils.openUrlNewTab(moe_url);
		}
		//TestBase.takeScreenshot("Modify OE");
		Thread.sleep(5000);
		cd.clickCustomerAndIdTab();
		Thread.sleep(8000);
		cd.stafAccountType();
		isLoaderSpinnerVisible(sd.driver);
		Thread.sleep(6000);
		as.clickAddServicesAndFeatures();
		Thread.sleep(10000);
		if(System.getProperty("environment").equalsIgnoreCase("webud"))
		{
			System.out.println("Changing the account from residential to staff");
		}
		else
		{
			as.bundleOfferNotSelected();
		}
		Thread.sleep(5000);
//		as.selectPlans(); //Added Raj
		Thread.sleep(5000);	
		as.internetNotSelected();
		Thread.sleep(5000);
		as.tvNotSelected();
		Thread.sleep(5000);
		is.selectEmployeeInternet();
		Thread.sleep(2000);
		is.selectInternetServiceCheckbox();
		//TestBase.takeScreenshot("SelectInternetDevice");
		Thread.sleep(4000);
		ts.selectEmployeeTV();
		Thread.sleep(5000);
		
	}

	@And("^create new staff customer with (.*) (.*) (.*) (.*) (.*)$")
	public void CreateNewAccountStaffCustomerAndIdTab(String firstName, String lastName, String email,
			String authType, String pin) throws Exception {
		cd = new CustomerDetails(sd.driver);
		cd.staffcustAndIdTab(firstName, lastName, email, authType, pin);
		Hooks.setFileWriter("FirstName: " + firstName + "\nLastName: " + lastName + "\nEmail: " + email);
	}

	
	@And("^create new tpia customer with (.*) (.*) (.*) (.*) (.*)$")
	public void CreateNewAccountTpiaCustomerAndIdTab(String firstName, String lastName, String email,
			String authType, String pin) throws Exception {
		cd = new CustomerDetails(sd.driver);
		cd.tpiacustAndIdTab(firstName, lastName, email, authType, pin);
		Hooks.setFileWriter("FirstName: " + firstName + "\nLastName: " + lastName + "\nEmail: " + email);
	}
	@Then("^Webud Order status should be Processing in Overview Page$")
	public void webUdOrderstatusProcessing() throws Exception {
		utils = new TestUtil(sd.driver);
		op = new OverviewPage(sd.driver, this.scenario);
		Thread.sleep(4000);
		String orderStatus = op.webUdRetrieveProcessingOrderStatus();
		String expectedOrderStatus = "Processing";
		//	ExtentCucumberAdapter.addTestStepLog(orderStatus);
		Assert.assertEquals("Expected message is Processing",orderStatus, expectedOrderStatus);
		Thread.sleep(2000);
		//TestBase.takeScreenshot("OverViewPage");

	}
	@And("^User Logins to webUdNetcracker by entering (.*) (.*)$")
	public void userLoginstoNetcracker(String ncUserName, String password) throws Exception {
		webUdLogin = new WebUD_SAML_Login(sd.driver,this.scenario);
		//		Thread.sleep(2000);
		webUdLogin.ncLogin(ncUserName, password);		//Commented for R24.8
		//		TestBase.takeScreenshot("WebUD Login");

	}

	@And("^User check Disney subscription status$")
	public void userCheckDisneySubscription() throws InterruptedException, IOException {
		overviewPage = new WebUD_OverviewPage(sd.driver);
		overviewPage.clickThreeDots();
		overviewPage.gwpStatusLink();
		overviewPage.disneyStatusMsg();	
	}
	@And("^change status of the TV equipment$")
	public void lostTVEquipment() throws Exception
	{

		eqpstatus = new EquipmentStatus(sd.driver,this.scenario);
		eqpstatus.tvEquipmentDetails();	
		eqpstatus.lostTvEquipment();
		eqpstatus.stolenTvEquipment();
		eqpstatus.foundTvEquipment();	
	}
	@And("^change status of the internet equipment$")
	public void lostInternetEquipment() throws Exception
	{

		eqpstatus = new EquipmentStatus(sd.driver,this.scenario);
		eqpstatus.internetEquipmentDetails();
		eqpstatus.lostInternetEquipment();
		eqpstatus.stolenInternetEquipment();
		eqpstatus.foundinternetEquipment();
	}

	@And("^change status of the converged equipment$")
	public void lostConvergedEquipment() throws Exception
	{

		eqpstatus = new EquipmentStatus(sd.driver,this.scenario);
		eqpstatus.convergedEquipmentDetails();
		eqpstatus.lostConvergedEquipment();
		eqpstatus.stolenConvergedEquipment();
		eqpstatus.foundConvergedEquipment();
	}
	@And("^return of the TV equipment$")
	public void returnTVEquipment() throws Exception
	{

		eqpstatus = new EquipmentStatus(sd.driver,this.scenario);
		eqpstatus.tvEquipmentDetails();
		eqpstatus.returnTvEquipment();	
	}

	@And("^return of the converged equipment$")
	public void returnConvergedEquipment() throws Exception
	{
		eqpstatus = new EquipmentStatus(sd.driver,this.scenario);
		eqpstatus.returnConvergedEquipment();
		//	eqpstatus.returnTvEquipment();	
	}

	@And("^close Scratch Pad$")

	public void closescratchPad()throws Exception {	
		webudHomePage = new WebUD_HomePage(sd.driver,this.scenario);
		webudHomePage.closescratchPad(); 
	} 

	@And("^write notes in scratchpad$")

	public void writenotesinScratchpad()throws Exception {	
		webudHomePage = new WebUD_HomePage(sd.driver,this.scenario);
		webudHomePage.writenotes(ScratchpadNote); 
	}

	@Then("^notes should be visible in scratchpad$")
	public void validatenotesinscratchpad() throws InterruptedException, IOException {
		webudHomePage = new WebUD_HomePage(sd.driver,this.scenario);
		String VisibleNotes = webudHomePage.retrieveNotes();
		ExtentCucumberAdapter.addTestStepLog("Notes : " + VisibleNotes);
		Assert.assertTrue("Notes are visible in scratchpad",VisibleNotes.contains(ScratchpadNote));
	}

	@And("^Create Notes$")

	public void CreateNotes()throws Exception {
		webUDNotes = new WebUD_Notes(sd.driver);
		webUDNotes.CreateCustomerNotes(CreateCustomerNote); 
	}

	@And("^Modify Notes$")

	public void ModifyNotes()throws Exception {
		webUDNotes = new WebUD_Notes(sd.driver);
		webUDNotes.ModifyCustomerNotes(ModifyCustomerNote); 
	}

	@And("^Delete Notes$")

	public void DeleteNotes()throws Exception {
		webUDNotes = new WebUD_Notes(sd.driver);
		webUDNotes.DeleteCustomerNotes(ModifyCustomerNote); 
	}

	@And("^access Activity History to validate the actions in Notes Tab$") 

	public void ValidateActivityHistoryinNotesTab()throws Exception { 
		webUDNotes = new WebUD_Notes(sd.driver);
		webUDNotes.ValidateActivityHistory();
	}

	@And("^validate user is able to create account alerts (.*)$")

	public void CreateAccountAlerts(String alerttypes)throws Exception {
		webUdAlerts = new WebUD_Alerts(sd.driver, this.scenario);
		webUdAlerts.CreateAlerts(alerttypes); 
	}

	@And("^validate agent is able to launch Case Management$") 

	public void launchCaseManagement()throws Exception { 
		webUDNotes = new WebUD_Notes(sd.driver);
		webUDNotes.launchCaseManagement();
	}

	@And("^select an option from Access Applications and Websites (.*)$") 

	public void selectApplicationsandWebsites(String accessoption)throws Exception { 
		webudHomePage = new WebUD_HomePage(sd.driver,this.scenario);
		webudHomePage.selectApplicationsandWebsites(accessoption);
	}

	@And("^validate UDGF Admin form screen (.*)	(.*)	(.*)	(.*)$")

	public void validateAdminForm(String accountnumber, String agency, String collectionagencystatus, String holdenddate)throws Exception {
		adminForm = new AdminForm(sd.driver);
		adminForm.validateAdminForm(accountnumber, agency, collectionagencystatus, holdenddate); 
	}

	@And("click Billing tab")
	public void selectBillingtab() throws Exception
	{
		billingpage = new BillingPreferncesPage(sd.driver, this.scenario);
		billingpage.selectBillingtab();
	}

	@And("^navigate to validate details in Assign to Agency tab	(.*)	(.*)	(.*)$")

	public void validateAssigntoAgencytabdetails(String agency, String collectionagencystatus, String holdenddate)throws Exception {
		billingpage = new BillingPreferncesPage(sd.driver, this.scenario);
		billingpage.validateAssigntoAgencytabdetails(agency, collectionagencystatus, holdenddate); 
	}
	public String partnerAccountNumber="";
	@And("^update Partner Account Number (.*) (.*) (.*) (.*)$")
	public void updatePartnerAccountNumber(String partner, String accountnumber, String notedId, String discountstatus)throws Exception {
		partnerAccountNumber = accountnumber+RandomStringUtils.randomAlphanumeric(3);
		summarypage = new Summary(sd.driver);
		summarypage.updatePartnerAccountNumber(partner, partnerAccountNumber, notedId, discountstatus, billcycle); 
	}

	@And("^retrieve the Bill Cycle from Bill Cycle History option under Billing tab$")
	public void retrieveBillCycle()throws Exception {
		billingpage = new BillingPreferncesPage(sd.driver, this.scenario);
		billcycle=billingpage.retrieveBillCycle(); 
	}

	@Then("^Partner Account Number should be (.*) Audit History  (.*)$")
	public void checkPartnerAccountAuditHistory(String action, String partner)throws Exception {
		summarypage = new Summary(sd.driver);
		summarypage.checkPartnerAccountAuditHistory(action, partner, partnerAccountNumber);
	}

	@And("^de-associate Partner Account Number (.*)$")
	public void deassociatePartnerAccountNumber(String partner)throws Exception {
		summarypage = new Summary(sd.driver);
		summarypage.deassociatePartnerAccountNumber(partner, partnerAccountNumber);
	}

	@And("navigates to immediate changes page in webud")
	public void NavigateImmediateChangePage()
			throws Exception {
		utils = new TestUtil(sd.driver);
		immswappage = new ImmediateSwapPage(sd.driver);
		immswappage.navigateToImmScenarioTab();
		immswappage.SwapXB7inWebUD(serialNumberXB7);

	}

	@And("^change set of phone features$")
	public void changePhoneFeature() throws InterruptedException {

		ps= new PhoneServices(sd.driver);
		ps.changephonefeature();

	}
	@Then("^swap hardware in immediate change page in WebUD (.*)$")
	public void SwapDeviceInImmediateChangePage(String device)
			throws Exception {
		immswappage = new ImmediateSwapPage(sd.driver);
		immswappage.SwapdeviceinImmScenarioninWebUD(device);	
	}


	@And("verify the order status in Overview page")
	public void VerifyOrderCompletion() throws Exception {
		String orderStatus = op.webUDcheckOrderCompleted(15000);
		System.out.println("Order Status is:" + orderStatus);
		String expectedOrderStatus = "Completed";
		//addInfoInReport("Order Status : " + orderStatus);
		// Hooks.setFileWriter("Order Status : " + orderStatus);
		Assert.assertEquals("Order Status :", expectedOrderStatus, orderStatus);
	}

	@And("^User navigates to Webud Order Entry page$")
	public void navigateToOrderEntryWebud() throws Exception {
		oePage= new WebUD_OrderEntryPage(sd.driver);
		oePage.navigateToOE();
	}

	@And("^Remove internet service and device$")
	public void removePlanDevice() throws Exception{
		oePage= new WebUD_OrderEntryPage(sd.driver);
		is = new InternetServices(sd.driver);
		oePage.deselectionOfPlansDevice();
	}

	@And("^upgrade the internet device to XB6$")
	public void upgradeInternetDevice()
			throws Exception {
		is = new InternetServices(sd.driver);
		is.selectFibre500();

		is.addXB6();

		is.selectXB6RentButton();
		serialNumberXB6 = FakeHardwareGeneration.generateSerialNum("XB6");
		is.setInternetSerialNum(serialNumberXB6);
		Thread.sleep(2000);
		is.clickOnSerialNumValidateButton();
		Thread.sleep(4000);
		is.clickOnInternetOkButton();
		waitForLoading(sd.driver);
		is.selectInternetServiceCheckbox();
		Thread.sleep(2000);
		// TestBase.takeScreenshot("SelectInternetDevice");
		Thread.sleep(4000);
		ExtentCucumberAdapter.addTestStepLog("XB6 serial number : " + serialNumberXB6);
		// addInfoInReport("XB6 serial number : " + serialNumberXB6);
		Hooks.setFileWriter("XB6 serial number : " + serialNumberXB6);
	}

	@And("click AccountHistory Icon$")
	public void accountHistoryTab() throws Exception
	{
		webUdLogin = new WebUD_SAML_Login(sd.driver,this.scenario);
		webUdLogin.clickAccountHistoryIcon();
	}
	String accountSelected;
	@And("click Account Displayed$")
	public void clickonAccountDisplayed() throws InterruptedException, IOException
	{
		webUdLogin = new WebUD_SAML_Login(sd.driver,this.scenario);
		accountSelected=webUdLogin.validateAccountDisplayed();
	}

	@And("validate Account details in the search Page$")
	public void validateAccountDetails() throws InterruptedException, IOException
	{
		String accountDisplayed=webUdLogin.validateAccountonSearchPage();
		Assert.assertEquals(accountSelected,accountDisplayed);
	}
	@And("validateAccountDetails")
	public void validate_account_details() {

		webUdLogin = new WebUD_SAML_Login(sd.driver,this.scenario);
		webUdLogin.validateAccountDetails();

	}
	@And("^click on ellipsis icon to open more tabs$")
	public void openmoretabs()throws Exception {	
		creditcheck = new CreditCheck(sd.driver);
		creditcheck.openmoretabs(); 
	} 

	@And("^click on Credit Check$")
	public void clickCreditCheck()throws Exception {	
		creditcheck = new CreditCheck(sd.driver);
		creditcheck.clickCreditCheck(); 
	} 

	@And("^customer should accept the terms$")
	public void customeracceptterms()throws Exception {	
		creditcheck = new CreditCheck(sd.driver);
		creditcheck.customeracceptterms(); 
	}

	@And("^customer selects consent method (.*)$")
	public void selectConsentMethodInCreditCheck(String consentmethod)throws Exception {
		creditcheck = new CreditCheck(sd.driver);
		creditcheck.selectConsentMethodinCreditCheck(consentmethod);
	}

	@And("^fills credit check information	(.*)	(.*)	(.*)	(.*)	(.*)	(.*)	(.*)$")
	public void enterInformationInCreditCheck(String FirstName, String LastName, String DOB, String Address, String City, String Province, String PostalCode)throws Exception {
		creditcheck = new CreditCheck(sd.driver);
		creditcheck.enterInformationInCreditCheck(FirstName, LastName, DOB, Address, City, Province, PostalCode); 
	}

	@And("^generates consent for verifying identity of different forms (.*)$")
	public void selectIdentityTypesForCreditCheck(String identitytypes)throws Exception {
		creditcheck = new CreditCheck(sd.driver);
		creditcheck.selectIdentityTypesForCreditCheck(identitytypes);
	}

	@And("^submits consent to run credit check$")
	public void runCreditCheck()throws Exception {	
		creditcheck = new CreditCheck(sd.driver);
		creditcheck.runCreditCheck(); 
	} 

	@And("^check if the Profile is approved$")
	public void validateProfileApproval()throws Exception {	
		creditcheck = new CreditCheck(sd.driver);
		creditcheck.validateProfileApproval(); 
	} 

	public String checkURL="";
	@And("^User Logins to application (.*) (.*)$")	
	public void LogintoApplication(String UserName, String Password) throws Exception
	{
		if (HostUrls.matrix.contains("130")){checkURL="https://tstwebud-ag.sjrb.ca/";}
		else if(HostUrls.matrix.contains("460")) {checkURL="https://matrix-460-udgfweb.matrix.sjrb.ad/";}
		else if(HostUrls.matrix.contains("182")) {checkURL="https://matrix-182-udgfweb.matrix.sjrb.ad/";}
		else if(HostUrls.matrix.contains("181")) {checkURL="https://matrix-181-udgfweb.matrix.sjrb.ad/";}
		else if(HostUrls.matrix.contains("137")) {checkURL="https://matrix-137-udgfweb.matrix.sjrb.ad/";}
		applicationlogin(sd.driver, UserName, Password, checkURL);
	}

	@And("click Refunds tab")
	public void selectRefundstab() throws Exception
	{
		billingpage = new BillingPreferncesPage(sd.driver, this.scenario);
		billingpage.selectRefundstab();
	}

	@And("^make a refund	(.*)	(.*)	(.*)	(.*)	(.*)	(.*)	(.*)$")
	public void makeRefund(String RefundAmount, String ReasonforRefund, String RefundType, String RefundLocationProvince, String RefundLocationCity, String RefundLocation, String RefundLocationChannel)throws Exception {
		billingpage = new BillingPreferncesPage(sd.driver, this.scenario);
		billingpage.makeRefund(PaymentTransactionID, RefundAmount, ReasonforRefund, RefundType, RefundLocationProvince, RefundLocationCity, RefundLocation, RefundLocationChannel); 
	}

	@And("^submit the refund and validate if	(.*)	is processed$")
	public void submitRefundandvalidate(String RefundAmount) throws Exception
	{
		billingpage = new BillingPreferncesPage(sd.driver, this.scenario);
		billingpage.submitRefundandvalidate(RefundAmount);
	}

	@And("click Transactions tab")
	public void selectTransactionstab() throws Exception
	{
		billingpage = new BillingPreferncesPage(sd.driver, this.scenario);
		billingpage.selectTransactionstab();
	}

	@And("^validate the	(.*)	refund transaction	(.*)	(.*)	(.*)$")
	public void validateRefundTransaction(String PaymentMethod, String RefundAmount, String ReasonforRefund, String RefundLocation)throws Exception {
		billingpage = new BillingPreferncesPage(sd.driver, this.scenario);
		billingpage.validateRefundTransaction(PaymentMethod, RefundAmount,ReasonforRefund,RefundLocation);
	}

	@And("^selects BaseManagement (.*)$")
	public void planSelectionBaseManagement(String internetservice) throws Exception {
		as = new AddServicesAndFeatures(sd.driver);
		waitForLoading(sd.driver);
		as.selectPlan(internetservice);
		waitForLoading(sd.driver);
	}

	@And("^selects UserRole with Products	(.*)	(.*)$")
	public void productSelectionUserRole(String internetservice, String tvproduct) throws Exception {
		as = new AddServicesAndFeatures(sd.driver);
		waitForLoading(sd.driver);
		as.selectProducts(internetservice, tvproduct);
		waitForLoading(sd.driver);
	}

	public String defaultUserRole;
	@And("^fetch default selected UserRole$")
	public void fetch_default_UserRole() throws Exception {
		as = new AddServicesAndFeatures(sd.driver);
		waitForLoading(sd.driver);
		defaultUserRole=as.fetch_default_UserRole();
		waitForLoading(sd.driver);
	}

	@Then("^verify default selected UserRole (.*)$")
	public void verify_default_UserRole(String functionalGroup) throws Exception {
		as = new AddServicesAndFeatures(sd.driver);
		waitForLoading(sd.driver);
		as.verify_default_UserRole(functionalGroup);
		waitForLoading(sd.driver);
	}

	public ArrayList<String> userRole_Offerings;
	@And("^check offerings with default selected UserRole$")
	public void check_default_offerings_with_UserRole() throws Exception {
		as = new AddServicesAndFeatures(sd.driver);
		waitForLoading(sd.driver);
		userRole_Offerings=as.check_default_offerings_with_UserRole();
		waitForLoading(sd.driver);
	}

	@And("^select new Functional Group in UserRole (.*)$")
	public void check_default_UserRole(String functionalGroup) throws Exception {
		as = new AddServicesAndFeatures(sd.driver);
		waitForLoading(sd.driver);
		as.select_UserRole(functionalGroup);
		// waitForLoading(sd.driver);
	}

	@And("verify if the offerings for both Functional Groups are different")
	public void verifyOfferingsinFunctionalGroups() throws Exception {
		as = new AddServicesAndFeatures(sd.driver);
		as.verifyOfferingsinFunctionalGroups(userRole_Offerings); 
	}

	@And("^selects promotion and coupon selection$")
	public void select_Promotion_and_Coupon_selection() throws Exception {
		promotions=new Promotions(sd.driver);
		promotions.select_Promotion_and_Coupon_selection();
	}

	@Then("^selects internet promotion and coupon (.*)$")
	public void select_internetPromotions(String internetPromo) throws Exception {
		promotions=new Promotions(sd.driver);
		promotions.select_internetPromotions(internetPromo);
	}

	@And("^close internet promotion and coupon selection pop up$")
	public void close_Promotion_and_Coupon_selection() throws Exception {
		promotions=new Promotions(sd.driver);
		promotions.select_ConfirmPromotions();
	}

	@Then("^check Functional Group in Promotion and coupon selection pop up (.*)$")
	public void check_FunctionalGroup_in_Promotionandcouponselection_popup(String functionalGroup) throws Exception {
		promotions=new Promotions(sd.driver);
		//	 if(functionalGroup.isEmpty())functionalGroup=defaultUserRole;
		promotions.check_FunctionalGroup_in_Promotionandcouponselection_popup(functionalGroup);
	}

	@And("select Delinquent tab")
	public void selectDelinquentTab() throws Exception
	{
		billingpage = new BillingPreferncesPage(sd.driver, this.scenario);
		billingpage.selectDelinquentTab();
	}

	@And("selects PaymentsandPreferences tab")
	public void PaymentsandPreferences() throws Exception
	{
		billingpage = new BillingPreferncesPage(sd.driver, this.scenario);
		billingpage.PaymentsandPreferences();
	}
	@And("^selects CreditCardProfile option (.*)$")
	public void selectCreditCardProfile(String option) throws Exception
	{
		billingpage = new BillingPreferncesPage(sd.driver, this.scenario);
		billingpage.selectCreditCardProfile(option);
	}
	@And("^make a payment	(.*)	(.*)	(.*)	(.*)	(.*)	(.*)	(.*)$")
	public void makePayment(String PaymentMethod, String ChequeNo, String ChequeAmount, String CCProvince, String CCLocationCity, String CCLocation, String CCChannel)throws Exception {
		billingpage = new BillingPreferncesPage(sd.driver, this.scenario);
		ChequeNo=ChequeNumber;
		billingpage.makePayment(PaymentMethod, ChequeNo, ChequeAmount, CCProvince, CCLocationCity, CCLocation, CCChannel); 
	}
	@And("^submit the payment$")
	public void submitPayment() throws Exception
	{
		billingpage = new BillingPreferncesPage(sd.driver, this.scenario);
		billingpage.submitPayment();
	}
	String BillPaymentAmount;
	@And("^enter the Credit Card details (.*) (.*) (.*) (.*) (.*) (.*)$")
	public void enterCreditCardDetailstoMakePayment(String CCNumber, String CCNameOnCard,String CCExpiry,  String CCCVD, String SaveCard, String PayAmount)throws Exception {
		billingpage = new BillingPreferncesPage(sd.driver, this.scenario);
		if(PayAmount.isEmpty()) PayAmount=BillPaymentAmount;
		billingpage.enterCreditCardDetailstoMakePayment(PayAmount, CCNameOnCard, CCNumber, CCExpiry, CCCVD, SaveCard); 
	}

	@Then("^validate Payment	(.*)	is processed$")
	public void validatePaymentProcessing(String PayAmount) throws Exception
	{
		billingpage = new BillingPreferncesPage(sd.driver, this.scenario);
		billingpage.validatePaymentProcessing(PayAmount);
	}
	public String PaymentTransactionID;
	@Then("^validate the	(.*)	payment transaction	(.*)	(.*)	(.*)")
	public void validateTransaction(String PaymentMethod, String PayAmount, String CCLocation, String webUDusername) throws Exception
	{
		billingpage = new BillingPreferncesPage(sd.driver, this.scenario);
		PaymentTransactionID = billingpage.validatePaymentTransaction(PaymentMethod, PayAmount, CCLocation, webUDusername);
	}

	@And("^select Reverse Payment	(.*)	(.*)$")
	public void selectReversePayment(String PayAmount, String PaymentMethod) throws Exception
	{
		billingpage = new BillingPreferncesPage(sd.driver, this.scenario);
		billingpage.selectReversePayment(PayAmount, PaymentMethod);
	}
	@And("^reverse the payment with	(.*)$")
	public void reverse_the_payment_with_reversalreason(String ReversalReason) throws Exception
	{
		billingpage = new BillingPreferncesPage(sd.driver, this.scenario);
		billingpage.reversePayment(ReversalReason);
	}

	@Then("^validate if the payment is reversed	(.*)	(.*)$")
	public void validatePaymentReversal(String ReversalReason, String PayAmount) throws Exception
	{
		billingpage = new BillingPreferncesPage(sd.driver, this.scenario);
		billingpage.validateReversedPayment(PaymentTransactionID, ReversalReason, PayAmount);
	}

	@And("^reverse the Adjustment with	(.*)$")
	public void reverse_the_adjustment_with_reversalreason(String ReversalReason) throws Exception
	{
		billingpage = new BillingPreferncesPage(sd.driver, this.scenario);
		billingpage.reverseAdjustment(ReversalReason);
	}

	@Then("^validate if the Adjustment is reversed	(.*)	(.*)$")
	public void validateAdjustmentReversal(String ReversalReason, String ReasonCode) throws Exception
	{
		billingpage = new BillingPreferncesPage(sd.driver, this.scenario);
		billingpage.validateAdjustmentReversal(ReversalReason, ReasonCode);
	}

	String get_PCIURL;
	@And("^Add Card using	(.*)$")
	public void addCardtoCreditCardProfile(String EmailOrMobile) throws Exception
	{
		billingpage = new BillingPreferncesPage(sd.driver, this.scenario);
		get_PCIURL=billingpage.addCardtoCreditCardProfile(EmailOrMobile);
	}
	@And("^SetUp Credit Card Profile	(.*)	(.*)	(.*)	(.*)$")
	public void setupCreditCardProfileForAccount(String CCNameOnCard, String CCNumber,String CCExpiry,  String CCCVD)throws Exception {
		billingpage = new BillingPreferncesPage(sd.driver, this.scenario);
		billingpage.setupCreditCardProfile(get_PCIURL, CCNameOnCard, CCNumber, CCExpiry, CCCVD); 
	}
	@Then("^validate if Credit Card Profile created	(.*)$")
	public void validateCreatedCreditCardProfile(String ProfileCreationStatus) throws Exception
	{
		billingpage = new BillingPreferncesPage(sd.driver, this.scenario);
		billingpage.validateCreatedCreditCardProfile(ProfileCreationStatus);
	}
	@And("^enter the email id or mobile number	(.*)	to make payment$")
	public void enterEmailIdorMobiletomakePayment(String EmailorSMS) throws Exception
	{
		billingpage = new BillingPreferncesPage(sd.driver, this.scenario);
		billingpage.enterEmailIdorMobiletomakePayment(EmailorSMS);
	}
	@And("^validate	(.*)	submission and get the link to make Credit Card payment$")
	public void validateEmailorSMSSubmissionandfetchURL(String EmailorSMS) throws Exception
	{
		billingpage = new BillingPreferncesPage(sd.driver, this.scenario);
		get_PCIURL=billingpage.validateEmailorSMSSubmissionandfetchURL(EmailorSMS);
	}
	@And("^launch the link to enter the credit card details$")
	public void launchPCIwebToolURL() throws Exception
	{
		billingpage = new BillingPreferncesPage(sd.driver, this.scenario);
		System.out.println(get_PCIURL);
		billingpage.launchPCIwebToolURL(get_PCIURL);
	}
	@And("^enter Credit Card details to make one time payment	(.*)	(.*)	(.*)	(.*)	(.*)$")
	public void enterCreditCardDetailstoMakeOneTimePayment(String PayAmount, String CCNameOnCard, String CCNumber,String CCExpiry,  String CCCVD)throws Exception {
		billingpage = new BillingPreferncesPage(sd.driver, this.scenario);
		billingpage.enterCreditCardDetailstoMakeOneTimePayment(PayAmount, CCNameOnCard, CCNumber, CCExpiry, CCCVD); 
	}
	@And("^select and activate Preauthorized Payments with	(.*)$")
	public void selectPreauthorizedPaymentandActivate(String PaymentType) throws Exception
	{
		billingpage = new BillingPreferncesPage(sd.driver, this.scenario);
		billingpage.selectPreauthorizedPaymentandActivate(PaymentType);
	}
	@And("^submit a Preauthorized Payment Plan	(.*)$")
	public void submitPreauthorizedPaymentPlan(String ReceiveInvoice)throws Exception {
		billingpage = new BillingPreferncesPage(sd.driver, this.scenario);
		billingpage.submitPreauthorizedPaymentPlan(BankOrInst, BranchorTransit, PreAuthAccount, ReceiveInvoice); 
	}
	@Then("^validate if Preauthorized Payment is enabled	(.*)$")
	public void validateenabledPreauthorizedPayment(String PreauthoziedPayStatus) throws Exception
	{
		billingpage = new BillingPreferncesPage(sd.driver, this.scenario);
		billingpage.validateenabledPreauthorizedPayment(PreauthoziedPayStatus);
	}
	@And("^agent should be able to (.*) the PreAuth payment	(.*)$")
	public void editorremovePreauthorizedPayment(String strOption, String editReceiveInvoice)throws Exception {
		billingpage = new BillingPreferncesPage(sd.driver, this.scenario);
		billingpage.edit_remove_PreauthorizedPayment(strOption, editReceiveInvoice); 
	}

	@And("^verify if Credit Card is saved for future payment	(.*)$")
	public void verifySavedCreditCard(String CCNumber) throws Exception
	{
		billingpage = new BillingPreferncesPage(sd.driver, this.scenario);
		billingpage.verifySavedCreditCard(CCNumber);
	}
	@And("^verify if Delete Card option is enabled and delete the Credit Card	(.*)$")
	public void verifyDeleteCreditCard(String CCNumber) throws Exception
	{
		billingpage = new BillingPreferncesPage(sd.driver, this.scenario);
		billingpage.verifyDeleteCreditCard(CCNumber);
	}

	@And("select Payment Arrangements tab")
	public void selectPaymentArrangementsTab() throws Exception
	{
		billingpage = new BillingPreferncesPage(sd.driver, this.scenario);
		billingpage.selectPaymentArrangementsTab();
	}
	@And("^Create Payment Arrangement	(.*)	(.*)	(.*)	(.*)$")
	public void createPaymentArrangement(String Method, String Location,String ExpiryDate,  String CreateNote)throws Exception {
		billingpage = new BillingPreferncesPage(sd.driver, this.scenario);
		billingpage.createPaymentArrangement(Method, Location, ExpiryDate, CreateNote); 
	}
	@Then("^Edit Payment Arrangement and validate it	(.*)	(.*)	(.*)	(.*)$")
	public void editandvalidatePaymentArrangement(String Method, String Location,String ExpiryDate, String EditNote)throws Exception {
		billingpage = new BillingPreferncesPage(sd.driver, this.scenario);
		billingpage.editandvalidatePaymentArrangement(Method, Location, ExpiryDate, EditNote); 
	}
	@And("^make Miscellaneous Account Adjustment	(.*)	(.*)	(.*)	(.*)	(.*)$")
	public void makeMiscellaneousAccountAdjustment(String webUDusername, String AdjustmentType, String AdjustmentSubType, String AdjustmentAmount,String AdjustmentNotes)throws Exception {
		billingpage = new BillingPreferncesPage(sd.driver,this.scenario);
		billingpage.makeMiscellaneousAccountAdjustment(webUDusername, AdjustmentType, AdjustmentSubType, AdjustmentAmount, AdjustmentNotes); 
	}
	@Then("^validate Adjustment in Transactions tab	(.*)	(.*)	(.*)	(.*)	(.*)	(.*)$")
	public void validateAdjustment(String webUDusername, String AdjustmentType, String AdjustmentSubType, String AdjustmentAmount,String AdjustmentNotes, String reasonCode)throws Exception {
		billingpage = new BillingPreferncesPage(sd.driver,this.scenario);
		billingpage.validateAdjustment(webUDusername, AdjustmentType, AdjustmentSubType, AdjustmentAmount, AdjustmentNotes, reasonCode, adjustmentamountwithouttax); 
	}
	@And("get Bill Amount from Transactions tab")
	public void getBillAmountfromTransactionstab() throws Exception
	{
		billingpage = new BillingPreferncesPage(sd.driver, this.scenario);
		BillPaymentAmount = billingpage.getBillAmountfromTransactionstab();
	}
	@And("^perform and validate reverse adjustment	(.*)	(.*)	(.*)	(.*)$")
	public void performandvalidateAdjustmentReversal(String AdjustmentType, String AdjustmentSubType, String AdjustmentAmount,String AdjustmentNotes)throws Exception {
		billingpage = new BillingPreferncesPage(sd.driver,this.scenario);
		billingpage.performandvalidateAdjustmentReversal(AdjustmentType, AdjustmentSubType, AdjustmentAmount, AdjustmentNotes); 
	}

	//@And("^And agent should be able to Edit the Pre-auth payment	(.*)	(.*)	(.*)	(.*)$")
	//public void editPreAuthPayment(String AdjustmentType, String AdjustmentSubType, String AdjustmentAmount,String AdjustmentNotes)throws Exception {
	//	billingpage = new BillingPreferncesPage(sd.driver,this.scenario);
	//	billingpage.editPreAuthPayment(AdjustmentType, AdjustmentSubType, AdjustmentAmount, AdjustmentNotes); 
	//}
	//@And("selects VerifyCreditCardDetails option")
	//public void selectVerifyCreditCardDetails() throws Exception
	//{
	//	billingpage = new BillingPreferncesPage(sd.driver, this.scenario);
	//	billingpage.selectVerifyCreditCardDetails();
	//}
	@And("^verify the Existing Card Details	(.*)	(.*)	(.*)$")
	public void verifyExistingCardDetails(String CCNameOnCard, String CCNumber, String CCExpiry)throws Exception {
		billingpage = new BillingPreferncesPage(sd.driver,this.scenario);
		billingpage.verifyExistingCardDetails(CCNameOnCard, CCNumber, CCExpiry); 
	}
	@And("^Remove Existing Card	(.*)$")
	public void removeExistingCard(String strRemove)throws Exception {
		billingpage = new BillingPreferncesPage(sd.driver,this.scenario);
		billingpage.removeExistingCard(strRemove); 
	}
	@And("^selects Equipment Search$")
	public void selectEquipmentSearch()throws Exception {
		webudHomePage = new WebUD_HomePage(sd.driver,this.scenario);
		webudHomePage.selectEquipmentSearch(); 
	}
	public String strEquipmentValue="";
	@And("^search Equipment by (.*) (.*) (.*)$")
	public void searchEquipmentby(String strretrieveEquipmentby, String strretrieveEquipmentNum, String strretrieveEquipmentType)throws Exception {
		webudHomePage = new WebUD_HomePage(sd.driver,this.scenario);

		switch(strretrieveEquipmentType) {
		case "TV":
			if(strretrieveEquipmentNum.isEmpty()) strEquipmentValue=tvserialNumber;
			else strEquipmentValue=strretrieveEquipmentNum;
			break;
		case "MAC": strEquipmentValue=MACAddress; break;
		case "MTA": strEquipmentValue=MTAAddress; break;
		case "Internet": strEquipmentValue=strretrieveEquipmentNum; break;
		case "Converged Details": strEquipmentValue=strretrieveEquipmentNum; break;
		}
		webudHomePage.searchEquipmentby(strretrieveEquipmentby, strEquipmentValue); 
	}
	public String MACAddress="";
	public String MTAAddress="";
	@And("^fetch the MAC Address and MTA MAC Address$")
	public void fetchMACandMTAAddress()throws Exception {
		webudHomePage = new WebUD_HomePage(sd.driver,this.scenario);
		String Address=webudHomePage.fetchMACandMTAAddress(strEquipmentValue); 
		String addr[] = Address.split(",");
		MACAddress=addr[0];
		MTAAddress=addr[1];

	}
	@And("^user should be able to open the account in START	(.*)$")
	public void openAccountinSTART(String accountnum)throws Exception {
		webudHomePage = new WebUD_HomePage(sd.driver,this.scenario);
		accountnumber=accountnum;
		//	String straccountNumber="08200007852";
		webudHomePage.openAccountinSTART(accountnumber); 
	}

	@Given("^user selects View Equipment Details in (.*)$")
	public void viewEquipmentDetails(String strViewEquipmentDetailsin)throws Exception {
		webudHomePage = new WebUD_HomePage(sd.driver,this.scenario);
		webudHomePage.viewEquipmentDetails(strViewEquipmentDetailsin); 
	}
	public String adjustmentamountwithouttax;
	@And("^user clicks on transaction bill for event level adjustment (.*)	(.*)$")
	public void eventLevelAdjustmentOnBill(String reasonCode, String notes) throws IOException,Exception , InterruptedException{
		billingpage= new BillingPreferncesPage(sd.driver, this.scenario);
		adjustmentamountwithouttax=billingpage.clickBillTransaction(reasonCode, notes);
	}

	@And("^user modifies the appointment date")
	public void modifyAppointmentDate() throws IOException,Exception, InterruptedException {
		utils = new TestUtil(sd.driver);
		ap = new Appointments(sd.driver,this.scenario);
		ap.navigateToAppointmentpage();
		waitForLoading(sd.driver);
		ap.selectSelfConnectNo();
		waitForLoading(sd.driver);
		ap.dismissFFMIntegrationMessage();
		waitForLoading(sd.driver);
		ap.selectTechNotRequired();	
	}
	@And("User adds disconnection date")
	public void disconnectionInflight() throws IOException,Exception, InterruptedException{
		utils = new TestUtil(sd.driver);
		ap = new Appointments(sd.driver,this.scenario);
		ap.clickAppointmentlink();
		waitForLoading(sd.driver);
		ap.selectDisconnectCalendar();
		ap.selectDisconnectionDateToday();
		waitForLoading(sd.driver);
		ap.setAuthorisedby();
		waitForLoading(sd.driver);
		ap.setDisconnectionReason();	
	}
	@And("User adds on a date disconnection date")
	public void disconnectionOnDate() throws IOException,Exception, InterruptedException{
		utils = new TestUtil(sd.driver);
		ap = new Appointments(sd.driver,this.scenario);
		ap.clickAppointmentlink();
		waitForLoading(sd.driver);
		ap.selectDisconnectCalendar();
		ap.selectDisconnectionDateToday();
		waitForLoading(sd.driver);
	}
	@And("^user update refund preference$")
	public void refundPreference() throws Exception {
		billingpage = new BillingPreferncesPage(sd.driver, this.scenario);
		billingpage.selectBillingtab();
		billingpage.clickRefundTab();
	}
	@And("^navigates to Immediate Scenario tab and select change (.*)$")
	public void selectChangeInImmediateScenario(String Change)
			throws Exception {
		utils = new TestUtil(sd.driver);
		immswappage = new ImmediateSwapPage(sd.driver);
		immswappage.navigateToImmScenarioTab();
		immswappage.selectChangeInImmediateScenario(Change);

	}
	@And("user create or transfer email address")
	public void createortransferEmailAddress()
			throws Exception {
		utils = new TestUtil(sd.driver);
		immswappage = new ImmediateSwapPage(sd.driver);
		immswappage.createortransferEmailAddress();
	}
	@And("^validates Reset Password Checkbox is not displayed when (.*) is selected in Immediate Scenario tab$")
	public void validateResetPswdNotPresentinImmScenariotab(String transferemailoption)
			throws Exception {
		utils = new TestUtil(sd.driver);
		immswappage = new ImmediateSwapPage(sd.driver);
		immswappage.validateResetPswdNotPresentinImmScenariotab(transferemailoption);
	}
	@And("^validates Reset Password Checkbox is not displayed when (.*) is selected in Order Entry tab$")
	public void validateResetPswdNotPresentinOrderEntrytab(String transferemailoption)
			throws Exception {
		utils = new TestUtil(sd.driver);
		immswappage = new ImmediateSwapPage(sd.driver);
		immswappage.validateResetPswdNotPresentinOrderEntrytab(transferemailoption);
	}
	@And("click on Provision button and provisoning should be successfull$")
	public void provisionTV() throws Exception
	{
		eqpstatus = new EquipmentStatus(sd.driver,this.scenario);
		eqpstatus.clickProvisionButton();
	}
	@And("validate the customerDetails displayed based on the search criteria$")
	public void validateSearchCriteria() throws InterruptedException, IOException
	{
		webUdLogin = new WebUD_SAML_Login(sd.driver,this.scenario);
		webUdLogin.validateCustomerDetailsPage();
	}

	@And("verify displayed results coloumn values$")
	public void validateDiplayedTable() throws InterruptedException, IOException
	{
		webUdLogin = new WebUD_SAML_Login(sd.driver,this.scenario);
		webUdLogin.validateTableDisplayed();
	}

	@And("^webUD premise move within province(.*)$")
	public void AddressMenu(String premiseMoveAddress) throws Exception {
		webUdAlerts = new WebUD_Alerts(sd.driver,this.scenario);
		waitForLoading(sd.driver);
		webUdAlerts.premiseMove(premiseMoveAddress);
		waitForLoading(sd.driver);
	}

	@Then("^Launch Netcracker application$")
	public void launchNetcrackerApplication() throws InterruptedException
	{
		String netcrackerURL;
		String hostPrefix="";
		String matrix="";
		String hostDomain="";
		switch(System.getProperty("webUdMatrix"))
		{
		case "181":
			hostDomain=".matrix.sjrb.ad:9001";
			hostPrefix="https://tclcooeml";
			matrix=System.getProperty("webUdMatrix")+"-01";
			break;
		case "182":			
			//			hostPrefix="https://tclcooeml";
			//			matrix=System.getProperty("webUdMatrix")+"-01";
			hostPrefix="https://oeservicetst-";
			matrix=System.getProperty("webUdMatrix");
			hostDomain=".matrix.sjrb.ad";
			break;
		case "130":
			hostDomain=".matrix.sjrb.ad:9001";
			hostPrefix="https://tstcoreoeml";
			matrix=System.getProperty("webUdMatrix");
			//			hostPrefix="https://oeservicetst-";
			//			matrix=System.getProperty("webUdMatrix");
			//			hostDomain=".matrix.sjrb.ad";
			break;
		}
		netcrackerURL=hostPrefix+matrix+hostDomain;
		//	String netcrackerURL = "https://tstcoreoeml"+System.getProperty("webUdMatrix")+".matrix.sjrb.ad:9001";
		//	String netcrackerURL ="https://tclcooeml182-01.matrix.sjrb.ad:9001";
		//	String netcrackerURL ="https://tclcooeml181-01.matrix.sjrb.ad:9001";
		utils =  new TestUtil(sd.driver);
		ExtentCucumberAdapter.addTestStepLog("NetCracker URL used : " + netcrackerURL);
		utils.openUrlNewTab(netcrackerURL);	
	}

	@Then("^switch to webUd application$")
	public void switchTooldTab() throws Exception
	{
		ArrayList tabs = new ArrayList (sd.driver.getWindowHandles());
		//	WebUDRoutingChange
		if(HostUrls.webUDroutingChanges.contains("Yes")) {
			System.out.println(tabs.size());
			//	switchtoWindow("Order History", sd.driver);
			sd.driver.switchTo().window((String) tabs.get(1));}
		else
			sd.driver.switchTo().window((String) tabs.get(0));	
	}
	
	@Then("^switch to webUd$")
	public void switchTab() throws Exception
	{
		ArrayList tabs = new ArrayList (sd.driver.getWindowHandles());
		//	WebUDRoutingChange
		if(HostUrls.webUDroutingChanges.contains("Yes")) {
			System.out.println(tabs.size());
			//	switchtoWindow("Order History", sd.driver);
			sd.driver.switchTo().window((String) tabs.get(0));}
		else
			sd.driver.switchTo().window((String) tabs.get(1));	
	}
	
	@Then("^switch Champ to webUd application$")
	public void switchchampTab() throws Exception
	{
		ArrayList tabs = new ArrayList (sd.driver.getWindowHandles());
		//	WebUDRoutingChange
		if(HostUrls.webUDroutingChanges.contains("Yes")) {
			System.out.println(tabs.size());
			//	switchtoWindow("Order History", sd.driver);
			sd.driver.switchTo().window((String) tabs.get(2));}
		else
			sd.driver.switchTo().window((String) tabs.get(0));	
	}

	@And("^navigate to	(.*)$")
	public void navigateToOption(String strOption) throws Exception {
		NetCrackerHomePage nchp= new NetCrackerHomePage(sd.driver,this.scenario);
		waitForLoading(sd.driver);
		nchp.navigateToModule(strOption);
		waitForLoading(sd.driver);
	}

	//Added by Ashish [Start]
	@And("^submit order on finish tab and retrieves accountnumber in bundle case$")
	public void submitBundleOrder() throws Exception {
		fp = new FinishPage(sd.driver);
		fp.clickFinishTab();
		Thread.sleep(15000);
		as.checkTODOMessage();
		Thread.sleep(2000);
		fp.clickFinishTab();
		Thread.sleep(15000);
		accountnumber = fp.retrieveAccountnumber();
		Thread.sleep(2000);
		workordernumber = fp.retrieveworkOrderNumber();
		ExtentCucumberAdapter.addTestStepLog("Account Number: " + accountnumber);
		ExtentCucumberAdapter.addTestStepLog("Work Order Number: " + workordernumber);
	}

	// Added by Ashish [Finish]

	@And("^navigates to webUD netcracker to complete directfulfillment shipping task (.*)$")
	public void CompletewebUDDirectFulfillmentShippingTask(String hardwaremodelname)
			throws Exception {
		utils = new TestUtil(sd.driver);
		String df_WebUdUrl;
		String hostPrefix="";
		String matrix="";
		String hostDomain="";	
		ncdfShippingpage= new NetcrackerDFShippingPage(sd.driver,this.scenario);
		if (System.getProperty("environment").equalsIgnoreCase("webud"))
		{
			switch(System.getProperty("webUdMatrix"))
			{
			case "181":
				hostPrefix="https://tclcooeml";
				matrix=System.getProperty("webUdMatrix")+"-01";
				hostDomain=".matrix.sjrb.ad:9001/common/uobject.jsp?tab=_Active+Shipping+Tasks&object=9137754422113767327";	
				break;
			case "182":
				//			hostPrefix="https://tclcooeml";
				//			matrix=System.getProperty("webUdMatrix")+"-01";
				hostPrefix="https://oeservicetst-";
				matrix=System.getProperty("webUdMatrix");
				hostDomain=".matrix.sjrb.ad/common/uobject.jsp?tab=_Active+Shipping+Tasks&object=9137754422113767327";	
				break;
			case "130":
			//	hostPrefix="https://oeservicetst-";
				hostPrefix="https://tstcoreoeml";
				matrix=System.getProperty("webUdMatrix");
				hostDomain=".matrix.sjrb.ad:9001/common/uobject.jsp?tab=_Active+Shipping+Tasks&object=9137754422113767327";							
				break;
			}
			df_WebUdUrl=hostPrefix+matrix+hostDomain;
			//		String df_WebUdUrl = "https://tstcoreoeml"+System.getProperty("webUdMatrix")+".matrix.sjrb.ad:9001"+"/common/uobject.jsp?tab=_Active+Shipping+Tasks&object=9137754422113767327";
			//		String df_WebUdUrl = "https://tclcooeml182-01.matrix.sjrb.ad:9001"+"/common/uobject.jsp?tab=_Active+Shipping+Tasks&object=9137754422113767327";
			//		String df_WebUdUrl = "https://tclcooeml181-01.matrix.sjrb.ad:9001"+"/common/uobject.jsp?tab=_Active+Shipping+Tasks&object=9137754422113767327";
			//		Thread.sleep(10000);
			utils.openUrlNewTab(df_WebUdUrl);
			// 		Thread.sleep(10000);
		}
		else
		{
			String df_url = HostUrls.getNetcrackerDocumentDfUrl();
			//		Thread.sleep(10000);
			utils.openUrlNewTab(df_url);
			// 		Thread.sleep(10000);
		}
		isLoaderSpinnerVisible(sd.driver);
		waitForLoading(sd.driver);
		ncdfShippingpage.searchCustomerAccount(accountnumber);
		String modelname[] = hardwaremodelname.split(",");
		String serialNumber[] = new String[modelname.length];
		for (int i = 0; i < modelname.length; i++) {

			serialNumber[i] = FakeHardwareGeneration.generateSerialNum(modelname[i].toUpperCase());
			switch (modelname[i].toUpperCase()) {
			case "HITRON":
				serialNumberHitron = serialNumber[i];
				break;

			case "XB6":
				serialNumberXB6 = serialNumber[i];
				break;

			case "XB7":
				serialNumberXB7 = serialNumber[i];
				break;

			case "XB8":
				serialNumberXB7 = serialNumber[i];
				break;

			case "SAGEMCOMXPOD":
				serialNumberXPOD = serialNumber[i];
				break;			

			case "XG1V4":
				serialNumberXG1V4 = serialNumber[i];
				break;

			case "XID":
				serialNumberXiD = serialNumber[i];
				break;

			case "DCX3200":
				serialNumberDCX3200 = serialNumber[i];
				break;

			case "DCX3400":
				serialNumberDCX3400 = serialNumber[i];
				break;

			case "SHAWMOXIGATEWAY":
				serialNumberMoxiGateway = serialNumber[i];
				break;

			case "XI6":
				serialNumberXi6 = serialNumber[i];
				break;

			case "DCT700":
				serialNumberDCT700 = serialNumber[i];
				break;				

			case "XG1V3":
				serialNumberXG1V3 = serialNumber[i];
				break;
			}

		}

		ncdfShippingpage.enterSerialNoHardwareAndTrackingNumber(serialNumberHitron,serialNumberXB6,serialNumberXG1V4,serialNumberXiD,serialNumberXi6,serialNumberXG1V3,serialNumberXB7,serialNumberXPOD);
			ncdfShippingpage.DFActiveAccount();
		//	Thread.sleep(2000);
		ncdfShippingpage.clickSave();
		//	Thread.sleep(2000);
	//	ncdfShippingpage.DFActiveAccount();
		addScreenshot(sd.driver, this.scenario, "Start Shipping");
		ncdfShippingpage.StartShipping();		
		//	Thread.sleep(2000);
		try {
			WebDriverWait wait = new WebDriverWait(sd.driver,10);
			wait.until(ExpectedConditions.alertIsPresent());
			Alert confirmationAlert = sd.driver.switchTo().alert();
			confirmationAlert.accept();
			System.out.println("Unexpected alert accepted");
		} catch (Exception e) {
			System.out.println("unexpected alert not present");
		}

	//	ncdfShippingpage.searchCustomerAccount(accountnumber);
		Thread.sleep(5000);
		ncdfShippingpage.DFActiveAccount();
		Thread.sleep(5000);
		ncdfShippingpage.clickSave();
		Thread.sleep(5000);
		ncdfShippingpage.clickSave();
		Thread.sleep(5000);
		ncdfShippingpage.completeShipping();
		waitForLoading(sd.driver);
		//TestBase.takeScreenshot("DFCompletion");
	}

	//Added by Ashish [Start]

	@And("^navigates to webUD netcracker to complete DF shipping task for XPODs (.*)$")
	public void CompletewebUDDirectFulfillmentShippingTaskXpods(String hardwaremodelname)
			throws Exception {
		utils = new TestUtil(sd.driver);
		String df_WebUdUrl;
		String hostPrefix="";
		String matrix="";
		String hostDomain="";	
		ncdfShippingpage= new NetcrackerDFShippingPage(sd.driver,this.scenario);
		if (System.getProperty("environment").equalsIgnoreCase("webud"))
		{
			switch(System.getProperty("webUdMatrix"))
			{
			case "181":
				hostPrefix="https://tclcooeml";
				matrix=System.getProperty("webUdMatrix")+"-01";
				hostDomain=".matrix.sjrb.ad:9001/common/uobject.jsp?tab=_Active+Shipping+Tasks&object=9137754422113767327";
				break;
			case "182":
				hostPrefix="https://tclcooeml";
				//			matrix=System.getProperty("webUdMatrix")+"-01";
				matrix=System.getProperty("webUdMatrix")+"-11";
				hostDomain=".matrix.sjrb.ad/common/uobject.jsp?tab=_Active+Shipping+Tasks&object=9137754422113767327";
				break;
			case "130":
				hostPrefix="https://tstcoreoeml";
				matrix=System.getProperty("webUdMatrix");
				hostDomain=".matrix.sjrb.ad:9001/common/uobject.jsp?tab=_Active+Shipping+Tasks&object=9137754422113767327";
				break;
			case "183":
				hostPrefix="https://tclcooeml";
				matrix=System.getProperty("webUdMatrix")+"-01";
				hostDomain=".matrix.sjrb.ad:9001/common/uobject.jsp?tab=_Active+Shipping+Tasks&object=9137754422113767327";
				break;
			case "460":
				hostPrefix="https://dtscoreoeml";
				matrix=System.getProperty("webUdMatrix");
				hostDomain=".matrix.sjrb.ad:9001/common/uobject.jsp?tab=_Active+Shipping+Tasks&object=9137754422113767327";
				break;
			case "470":
				hostPrefix="https://dtscoreoeml";
				matrix=System.getProperty("webUdMatrix");
				hostDomain=".matrix.sjrb.ad:9001/common/uobject.jsp?tab=_Active+Shipping+Tasks&object=9137754422113767327";
				break;
			}
			df_WebUdUrl=hostPrefix+matrix+hostDomain;
			utils.openUrlNewTab(df_WebUdUrl);
		}
		else
		{
			String df_url = HostUrls.getNetcrackerDocumentDfUrl();
			utils.openUrlNewTab(df_url);
		}
		isLoaderSpinnerVisible(sd.driver);
		waitForLoading(sd.driver);
	//	accountnumber = "08200008626";
		ncdfShippingpage.searchCustomerAccount(accountnumber);
		String modelname[] = hardwaremodelname.split(",");
		String serialNumber[] = new String[modelname.length];
		for (int i = 0; i < modelname.length; i++) {

			serialNumber[i] = FakeHardwareGeneration.generateSerialNum(modelname[i].toUpperCase());
			switch (modelname[i].toUpperCase()) {
			case "SAGEMCOMXPOD":
				serialNumberXPOD = serialNumber[i];
				break;
			}
			ncdfShippingpage.enterSerialNoHardwareAndTrackingNumberXPOD(serialNumberXPOD);
		}

		//ncdfShippingpage.enterSerialNoHardwareAndTrackingNumber(serialNumberHitron,serialNumberXB6,serialNumberXG1V4,serialNumberXiD,serialNumberXi6,serialNumberXG1V3,serialNumberXB7,serialNumberXPOD);
		ncdfShippingpage.clickSave();
		ncdfShippingpage.DFActiveAccount();
		addScreenshot(sd.driver, this.scenario, "Start Shipping");
		ncdfShippingpage.StartShipping();		
		try {
			WebDriverWait wait = new WebDriverWait(sd.driver,10);
			wait.until(ExpectedConditions.alertIsPresent());
			Alert confirmationAlert = sd.driver.switchTo().alert();
			confirmationAlert.accept();
			System.out.println("Unexpected alert accepted");
		} catch (Exception e) {
			System.out.println("unexpected alert not present");
		}

		ncdfShippingpage.searchCustomerAccount(accountnumber);
		ncdfShippingpage.DFActiveAccount();
		ncdfShippingpage.completeShipping();
		waitForLoading(sd.driver);
	}


	//Added by Ashish [End]

	@And("^sets up a selfinstall appointment type and change shipping address(.*)	(.*)$")
	public void setAppointmentdetailsnewShippingAddress(String appointmentType, String address) throws Exception {
		ap = new Appointments(sd.driver,this.scenario);
		ap.clickAppointmentlink();
		ap.selectSelfconnect();
		switch (appointmentType.toUpperCase()) {
		case "DIRECTFULFILLMENT":
			ap.selectDirectFulfillmentMailOut();

			if (!(prop.getProperty("environment", "non-timeshifter").equalsIgnoreCase("timeshifter"))) {
				ap.changeToDifferentDFAddress(address);
			}
			ap.selectServiceLocationCheckbox();
			ap.selectcustomerOptOutCheckbox();
			break;
		case "RETAILPICKUP":
			ap.selectRetailPickup();
			ap.selectRetailPickupAddress(address);
			break;
		case "EXISTINGHW":
			ap.selectExisitingHardware();
			break;
		case "SHAWDELIVERY":
			ap.selectShawDelivery();
			waitForLoading(sd.driver);
			ap.dismissFFMIntegrationMessage();
			ap.selectSMSNumberOptedOut();
			Thread.sleep(2000);
			ap.selectforceappointment();
			break;
		}
		ap.setAuthorisedby();
		ap.setActivedirectory();
		//TestBase.takeScreenshot("self install appointment");
	}

	@And("^validate serviceNowPopUp$")
	public void validateServiceDetails() throws Exception
	{
		webudHomePage = new WebUD_HomePage(sd.driver,this.scenario);
		webudHomePage.validateReleaseNote();
		webudHomePage.closeReleaseNote();
	}

	@Then("^transfer email to a customer account from OE (.*)$")
	public void transfer_email_to_a_customer_account_from_oe(String transferemail) throws InterruptedException, IOException,Exception {
		immswappage = new ImmediateSwapPage(sd.driver);
		immswappage.navigateToImmScenarioTab();
		System.out.println(transferemail);
		// transferemail = immswappage.immEmailadd();
		immswappage.transferEmailInOE(accountnumber,transferemail);
	}

	@And("^validate TV birth certificate$")
	public void birthCertTVEquipment() throws Exception
	{
		//	pageobjmanager = new pageObjectManager(driver);
		eqpstatus = new EquipmentStatus(sd.driver,this.scenario);
		eqpstatus.tvEquipmentDetails();
		eqpstatus.validatebirthCertificate();

	}	


	@And("^validate TV provisioning time stamp$")
	public void provisionTVEquipment() throws Exception
	{
		//	pageobjmanager = new pageObjectManager(driver);
		eqpstatus = new EquipmentStatus(sd.driver,this.scenario);
		//	eqpstatus.tvEquipmentDetails();
		eqpstatus.provisionTVDetails();

	}

	@And("^validate converged birth certificate$")
	public void birthCertConvrgedEquipment() throws Exception
	{
		//	pageobjmanager = new pageObjectManager(driver);
		eqpstatus = new EquipmentStatus(sd.driver,this.scenario);
		eqpstatus.validateConvergedbirthCertificate();
	}
	@And("^validate converged provisioning time stamp (.*)$")
	public void provisionConvergedEquipment(String hardware) throws Exception
	{
		//	pageobjmanager = new pageObjectManager(driver);
		eqpstatus = new EquipmentStatus(sd.driver,this.scenario);
		//	eqpstatus.tvEquipmentDetails();
		switch (hardware.toUpperCase()) {
		case "XB6":
			eqpstatus.enterConvergedSerialNumber(serialNumberXB6);
			break;
		case "XB7":
			eqpstatus.enterConvergedSerialNumber(serialNumberXB7);
			break;
		case "XB8":
			eqpstatus.enterConvergedSerialNumber(serialNumberXB8);
			break;
		case "DCX3400":
			eqpstatus.enterConvergedSerialNumber(serialNumberDCX3400);
			break;
		case "XI6":
			eqpstatus.enterConvergedSerialNumber(serialNumberXi6);
			break;
		case "DPT":
			eqpstatus.enterConvergedSerialNumber(serialNumberDPT);
			break;
		case "HITRON":
			eqpstatus.enterConvergedSerialNumber(serialNumberHitron);
			break;
		}



		eqpstatus.provisionConvergedDetails();

	}



	@And("^close the displayed equipment details$")
	public void closeEquipment() throws InterruptedException, IOException,Exception
	{
		eqpstatus = new EquipmentStatus(sd.driver,this.scenario);
		eqpstatus.closeEquipment();
	}

	@Then("User validates Account History table after webud refresh")
	public void user_click_on_account_history_table_values()	throws Exception{
		webudHomePage = new WebUD_HomePage(sd.driver,this.scenario);
		webudHomePage.accounthistorytablevalue();
		Thread.sleep(10000);
		sd.driver.navigate().refresh();
	}

	@Then("User validates Account History table after webpage refresh")
	public void user_click_on_account_history_table_values_after_webpage_refresh() throws Exception{
		webudHomePage = new WebUD_HomePage(sd.driver,this.scenario);
		webudHomePage.accounthistoryafterwebpagerefresh();
	}

	@Then("User validates Account History table")
	public void user_click_on_account_history_table() throws Exception {
		webudHomePage = new WebUD_HomePage(sd.driver,this.scenario);
		webudHomePage.accounthistorytable();
		Thread.sleep(5000);

	}
	@Then("^filter with and select Project Name	(.*)	(.*)$")
	public void filterandselect_projectnameinNC(String modulename, String projectname) throws Exception {
		ncModules = new NetCrackerModules(sd.driver,this.scenario);
		ncModules.filterandselect_projectnameinNC(modulename,projectname);  
	}
	@And("^filter with and select Customer Account Number	in	Customer Accounts$")
	public void filterandselect_customeraccountnumberinNC() throws Exception {
		ncModules = new NetCrackerModules(sd.driver,this.scenario);
		//	accountnumber="08200011325";
		ncModules.filterandselect_customeraccountnumberinNC(accountnumber);  
	}
	@And("^view the Integration Report for Pronouns$")
	public void view_IntegrationReport () throws Exception {
		ncModules = new NetCrackerModules(sd.driver,this.scenario);
		ncModules.view_IntegrationReport(accountnumber, strCheckPronounsinIntReport);  
	}
	public ArrayList<String> strPronounOptions;
	//strPronounOptions=["Not Specified", 'any', 'he/him', 'he/they', 'she/her', 'she/they', 'they/them', 'xe/xem', 'ze/zie', 'ze/zir'];
	@And("fetch the Pronouns present under Customer Pronouns")
	public void fetchCustomerPronounsinNC() throws Exception {
		ncModules = new NetCrackerModules(sd.driver,this.scenario);
		strPronounOptions=ncModules.fetchCustomerPronounsinNC(); 
		System.out.println(strPronounOptions);
	}
	@And("verify pronouns present in WebUD with NC pronoun list")
	public void verifyCustomerPronounsinWebUDwithNClist() throws Exception {
		cd = new CustomerDetails(sd.driver);
		cd.verifyCustomerPronounsinWebUDwithNClist(strPronounOptions); 
	}
	public ArrayList<String> strCheckPronounsinIntReport;
	@And("^add additional authorized person	(.*)$")
	public void add_additional_authorized_person(String addpersondetails) throws Exception {
		cd = new CustomerDetails(sd.driver);
		strCheckPronounsinIntReport=cd.add_additional_authorized_person(addpersondetails); 
	}
	@And("^open accountnumber in WebUDNetcracker and retrieve account id$")
	public void openAccountnumberInwebudNetcrackerAndRetrieveAccountId() throws InterruptedException,Exception {
		String matrix = configprop.getProperty("environment");
		utils = new TestUtil(sd.driver);
		String df_WebUdUrl;
		String hostPrefix="";

		String hostDomain=".matrix.sjrb.ad:9001/common/uobject.jsp?tab=_Customer+Accounts&object=7022760707013150025";	

		if (System.getProperty("environment").equalsIgnoreCase("webud"))
		{
			switch(System.getProperty("webUdMatrix"))
			{
			case "181":
				hostPrefix="https://tclcooeml";
				matrix=System.getProperty("webUdMatrix")+"-01";
				break;
			case "182":
				hostPrefix="https://tclcooeml";
				matrix=System.getProperty("webUdMatrix")+"-11";
				break;
			case "130":
				hostPrefix="https://tstcoreoeml";
				matrix=System.getProperty("webUdMatrix");
				break;
			case "183":
				hostPrefix="https://tclcooeml";
				matrix=System.getProperty("webUdMatrix")+"-11";
				break;	

			}
			df_WebUdUrl=hostPrefix+matrix+hostDomain;
			System.out.println(df_WebUdUrl);
			utils.openUrlNewTab(df_WebUdUrl);
			Thread.sleep(10000);


		}
		else
		{
			String df_url = HostUrls.getNetcrackerDocumentDfUrl();
			//		Thread.sleep(10000);
			//	utils.openUrlNewTab(df_url);
			// 		Thread.sleep(10000);
		}
		orderMgm = new OrderManagement(sd.driver);
		{
			Thread.sleep(5000);
			orderMgm.AccountIconFilterBtn();
			Thread.sleep(10000);
			//	accountnumber= "03000013358";
			orderMgm.enterAccountNumber(accountnumber);
			Thread.sleep(5000);
			orderMgm.accountidapply();
			Thread.sleep(5000);
			accountid = orderMgm.RetrieveAccId();

			//addInfoInReport("AccountId : " + accountid);
			ExtentCucumberAdapter.addTestStepLog("AccountId : " + accountid);
		}	
	}


	@And("^selects OTT Subscription (.*)$")
	public void selectsOTTSubscription(String strOTTSubscription)
			throws Exception {
		//		String strOTTSubscription[] = strOTTSubscriptions.split(",");
		//		for (int i = 0; i < strOTTSubscription.length; i++) {	
		//			if(strOTTSubscription[i].contains(strOTTSubscriptions))
		if(!strOTTSubscription.isEmpty())
			ts.selectOTTSubscription(strOTTSubscription);
		//		}

	}

	@Then("^Add email to a customer account from immediate page$")
	public void add_email_to_a_customer_account_from_immediate_page()throws InterruptedException, IOException,Exception {
	    
		 immswappage = new ImmediateSwapPage(sd.driver);
		 immswappage.navigateToImmScenarioTab();
		 Thread.sleep(5000);
		 immswappage.addEmail();
		 Thread.sleep(5000);
		 transferemail = immswappage.createortransferEmailAddress();
//		 transferemail = immswappage.immEmailadd();
		 System.out.println(transferemail);
		 
	}

	@Then("^transfer email to a customer account from OE$")
	public void transfer_email_to_a_customer_account_from_oe() throws InterruptedException, IOException,Exception {
		 immswappage = new ImmediateSwapPage(sd.driver);
		 immswappage.navigateToImmScenarioTab();
		 System.out.println(transferemail);
		// transferemail = immswappage.immEmailadd();
	//	 String transferemail = "JcVIJJ";
		 immswappage.transferEmailInOE(accountnumber,transferemail);
	}

	@And("^User clicks on Equipement search (.*) (.*)$")
	public void user_clicks_on_equipesearch(String retrievEquipBy , String equipSearchvalue) throws Exception {
		equipesearch = new Equipmentsearch(sd.driver, this.scenario);
	//	equipSearchvalue = hardwareserialNumber;
		equipesearch.equipmentSearch( retrievEquipBy , equipSearchvalue );

	}


	@Then("^User validates the Vip account number in Equipement search page$")
	public void user_validates_accno_equipesearch() throws Exception {
		equipesearch = new Equipmentsearch(sd.driver, this.scenario);
		equipesearch.equipmentaccno();

	}
	@When("^User clicks on change status of lost ONT devices$")
	public void user_clicks_on_changestatus_lost_ONT() throws Exception {
		equipesearch = new Equipmentsearch(sd.driver, this.scenario);
		equipesearch.lostOnt();


	}

	@And("^User validates the status of the ONT devices$")
	public void user_validated_lost_ONT_status() throws Exception {
		equipesearch = new Equipmentsearch(sd.driver, this.scenario);
		equipesearch.ontStatus();
	}

	@And("^User clicks on change status of stolen ONT device$")
	public void user_clicks_on_changestatus_stolen_ONT() throws Exception {
		equipesearch = new Equipmentsearch(sd.driver, this.scenario);
		equipesearch.stolenOnt();

	}

	@And("^User clicks on change status of found ONT device$")
	public void user_clicks_on_changestatus_found_ONT() throws Exception {
		equipesearch = new Equipmentsearch(sd.driver, this.scenario);
		equipesearch.foundOnt();

	}


	@And("^User clicks on TPIA Equipement search icon$")
	public void user_clicks_on_TPIA_equipesearchicon() throws Exception {
		equipesearch = new Equipmentsearch(sd.driver, this.scenario);
		equipesearch.tpiaequipmentSearchicon();

	}

	@And("^User clicks on TPIA Equipement search$")
	public void user_clicks_on_TPIA_equipesearch() throws Exception {
		equipesearch = new Equipmentsearch(sd.driver, this.scenario);
		equipesearch.tpiaequipmentSearch();

	}

	@And("^User clicks on TPIA Manage Equipement$")
	public void user_clicks_on_TPIA_managae_equipe() throws Exception {
		equipesearch = new Equipmentsearch(sd.driver, this.scenario);
		equipesearch.tpiamanageequipment();

	}


	@When("^User Add/update TPIA Equipement (.*) (.*) (.*) (.*)$")
	public void user_clicks_on_TPIA_equipesearch(String SeriaNumber , String manufacturer , String macaddress, String modelCode) throws Exception {
		equipesearch = new Equipmentsearch(sd.driver, this.scenario);
		equipesearch.addtpiaequipment( SeriaNumber, manufacturer, macaddress, modelCode);

	}


	@Then("^User validates TPIA Equipment$")
	public void user_validates_TPIA_equipe() throws Exception {
		equipesearch = new Equipmentsearch(sd.driver, this.scenario);
		equipesearch.tpiaduplicatedevice();

	}




	@When("^User selects Edit TPIA Equipment and adds Non-TPIA Device (.*)$")
	public void user_selects_Edit_TPIA_equipe(String SeriaNumber) throws Exception {
		equipesearch = new Equipmentsearch(sd.driver, this.scenario);
		equipesearch.edittpiaequip(SeriaNumber);

	}


	@Then("^User validates NON-TPIA Equipment$")
	public void user_validates_NonTPIA_equipe() throws Exception {
		equipesearch = new Equipmentsearch(sd.driver, this.scenario);
		equipesearch.nontpiadevice();

	}

	@When("^User selects Edit TPIA Equipment and adds TPIA Device (.*)$")
	public void user_selects_Edit_addTPIA_equipe(String SeriaNumber) throws Exception {
		equipesearch = new Equipmentsearch(sd.driver, this.scenario);
		equipesearch.edittpiaequip(SeriaNumber);

	}
	
	@When("^User selects Edit TPIA Equipment and edit TPIA Device Macaddress (.*)$")
	public void user_selects_Edit_tpia_mac_equipe(String macaddress) throws Exception {
		equipesearch = new Equipmentsearch(sd.driver, this.scenario);
		equipesearch.edittpiamac(macaddress);

	}

	@Then("^User valdiates the displayed message$")
	public void user_validates_message() throws Exception{		
		equipesearch = new Equipmentsearch(sd.driver, this.scenario);
		equipesearch.tpiadevicemsg();
	}

	@And("^selects Security device with (.*) (.*) (.*)$")
	public void selectsSecurityService(String Securitydevice, String SecurityHardware, String Discount) throws Exception
	{
		utils =  new TestUtil(sd.driver);
		System.out.println(Securitydevice);
		ss = new SecurityDevicesPage(sd.driver);
		System.out.println(SecurityHardware);
		ss.selectSecurityDevice(Securitydevice);
		ExtentCucumberAdapter.addTestStepLog("Securitydevice");
		ss.selectSecurityWrench();
		waitForLoading(sd.driver);	
		isLoaderSpinnerVisible(sd.driver);
		waitForLoading(sd.driver);
		ss.selectSecurityHardwarepurchase(SecurityHardware, Discount);				
		securityserialNumberxcam = FakeHardwareGeneration.generateSerialNum("XCAM");
		ss.enterSerialNumber(securityserialNumberxcam);
		ss.clickValidateButton();
		ss.selectOkButton();
	}




	@And("^select Security device with financed (.*) (.*) (.*) (.*)$")
	public void selectsSecurityService(String Securitydevice , String SecurityHardware1 , String SecurityHardware2 , String Discount) throws Exception
	{
		utils =  new TestUtil(sd.driver);
		System.out.println(Securitydevice);
		ss = new SecurityDevicesPage(sd.driver);
		ss.selectSecurityDevice(Securitydevice);
		ExtentCucumberAdapter.addTestStepLog(Securitydevice);
		ss.selectSecurityWrench();
		waitForLoading(sd.driver);	
		isLoaderSpinnerVisible(sd.driver);
		waitForLoading(sd.driver);	
		ss.selectSecurityHardwarefinance(SecurityHardware1, SecurityHardware2, Discount);	
		securityserialNumberdoor = FakeHardwareGeneration.generateSerialNum("DOORBELL");
		securityserialNumberxcam = FakeHardwareGeneration.generateSerialNum("XCAM");
		ss.enterSerialNumber(securityserialNumberdoor);
		ss.clickValidateButton();
		ss.enterSerialNumber(securityserialNumberxcam);
		ss.clickValidateButton();	
		ss.selectOkButton();
	}

	@Then("^User validates finance hardware summary table$")
	public void hardwaresummarytable( ) throws Exception {
		hardwaresummary = new WebUD_HardwaresummaryPage(sd.driver);
		hardwaresummary.hardwaresummary();
		//hardwaresummary.hardwaresummarytable();
		String hardwaresum =hardwaresummary.fiancedhardwaresummarytable();
		//	Assert.assertNull(hardwaresum);
		//Assert.assertNull(hardwaresum,"");
		if(hardwaresum==null) {
			ExtentCucumberAdapter.addTestStepLog("There is no Entry on the Finance summary table for the purchased device");
		}
		else {
			ExtentCucumberAdapter.addTestStepLog("There is an Entry on the Finance summary table for the purchased device");
		}
	}
	@And("^User navigates to hardware summary tab$")
	public void hardwaresummarytab( ) throws Exception {
		hardwaresummary = new WebUD_HardwaresummaryPage(sd.driver);
		hardwaresummary.hardwaresummary();
	}

	@And("^User retrieves hardware serial number$")
	public void hardwareserialnum( ) throws Exception {
		hardwaresummary = new WebUD_HardwaresummaryPage(sd.driver);
		hardwaresummary.hardwaresummary();
		hardwareserialNumber = hardwaresummary.hardwareserialnum();

	}


	@And("^user make the prepayment for doorbell in finance hardware summary table$")
	public void hardware_prepayment_finance() throws Exception {
		hardwaresummary = new WebUD_HardwaresummaryPage(sd.driver);
		hardwaresummary.doorprepay();

	}

	@Then("^User validates the Finance device tab$")
	public void finance_device_tab() throws Exception {
		billingpage = new BillingPreferncesPage(sd.driver, this.scenario);
		billingpage.selectFinancedevicetab();
	}

	@Then("^User validates device update in equipement search$")
	public void validate_equipement() throws Exception {
		equipesearch = new Equipmentsearch(sd.driver, this.scenario);
		equipesearch.equipmentvalidation();

	}
	
	@When("^user clicks on Heirarchy tab and link tpia account$")
	public void userlinktpiaacc() throws Exception {
		heirarchytab = new Heirarchypage(sd.driver, this.scenario);
		heirarchytab.heirarchyTab(tpiaaccountnumber);
			
		
	}
	
	;
	@And("^add installation fee and verify the waive message$")
	public void addinstallfee() throws Exception {
		as = new AddServicesAndFeatures(sd.driver);
		String defaultinstfee = as.defaultinstallationfee();
		ExtentCucumberAdapter.addTestStepLog("The default Installation fee is :"+ defaultinstfee);
		as.addinstallationfee();		
		as.checkTODOMessage();


	}
	
	@Given("^User Logins in to Rogers champ site (.*) (.*)$")
		public void userLoginsTochamp(String champUsername, String champPassword)
				throws Exception, IOException {
			webUdLogin = new WebUD_SAML_Login(sd.driver,this.scenario);
			sd.driver.get("https://qa01-unilogin.rogers.com/");
			Thread.sleep(2000);
			webUdLogin.champLogin(champUsername, champPassword);
		}
	
	
	@And("^User clicks on billing tab$")
	public void user_clicks_on_billing_tab() throws Exception {
		billingpage = new BillingPreferncesPage(sd.driver, this.scenario);
		billvalue = billingpage.billingtab();
	}
	
	@Then("^User clicks on View bill$")
	public void user_clicks_on_view_bill() throws Exception {
		webud_ViewBill = new WebUD_ViewBill(sd.driver,this.scenario);
		webud_ViewBill.viewbill();
   
	}
	@Then("User saves pdf file and validates the pdf content")
	public void user_validates_pdf_content() throws Exception {

		webud_ViewBill = new WebUD_ViewBill(sd.driver,this.scenario);
		webud_ViewBill.saveAndValidatepdf(billvalue);
	   
	}

	@AfterStep
	public void attachStepSC(Scenario scenario) throws Exception
	{ 
		try
		{
			final byte[] screenshot = ((TakesScreenshot) sd.driver).getScreenshotAs(OutputType.BYTES);
			scenario.attach(screenshot, "image/png", scenario.getName());
		}catch(NoSuchSessionException exc) {
			exc.printStackTrace();
			//throw new Exception(exc + "Exception on scrolling the webelement");	
		}
	}
	@After
	public void teardown(Scenario scenario)
	{
		if(scenario.isFailed())
		{
			final byte[] screenshot = ((TakesScreenshot) sd.driver).getScreenshotAs(OutputType.BYTES);
			scenario.attach(screenshot, "image/png", scenario.getName());
			scenario.log("Attached sc");
		}
		sd.driver.quit();
	}
	//    public void afterScenario(Scenario scenario) throws IOException, InterruptedException{
	//	
	//		System.out.println(
	//				"\n\n\n#### Scenario: Run " + example_count + ": " + scenario.getStatus() + " : " + scenario.getName()
	//						+ " ####\n\n\n***********************     END OF TEST RUN     ***********************\n\n");
	////         if(scenario.isFailed()){
	//            File src = ((TakesScreenshot) sd.driver).getScreenshotAs(OutputType.FILE);
	//                byte[] fileContent = FileUtils.readFileToByteArray(src);
	//                scenario.attach(fileContent, "image/png", "screenshot name"); 
	////        	 TakesScreenshot ts = (TakesScreenshot) sd.driver;
	////        	 System.out.println("TakeScreenshot");
	////        	 String base64_image = ts.getScreenshotAs(OutputType.BASE64);
	////        	 System.out.println(base64_image);
	////        	 ExtentCucumberAdapter.addTestStepScreenCaptureFromPath(base64_image);
	//        	 takeScreenshot(sd.driver,"afterScenario");
	//
	//
	////            }
	//         ExtentCucumberAdapter.addTestStepLog("Closed successful");
	//
	//            sd.driver.quit();
	//            
	////    		if (sd.driver != null) {
	////    			takeScreenshot(sd.driver,"afterScenario");
	////    			addURLInReport(sd.driver.getCurrentUrl(), "Last Opened Page");
	////     			addURLInReport("Last Opened Page");
	////    			fileWriter.add("TestStatus:" + example_count + ":" + scenario.getStatus());
	////    			fileWriter.add("##################################################");
	////    			AccountInfo.addTextToFile(fileWriter, scenario.getName(), "nLine");
	////    			AccountInfo.addTextToFile(fileWriterSourceForExampleData, scenario.getName() + "exampleData", "sLine");
	////    			AccountInfo.storePageSourceOfLastPage(sd.driver.getPageSource());
	////    			sd.driver.quit();
	////    			sd.driver = null;
	////    		}
	//          }

}
