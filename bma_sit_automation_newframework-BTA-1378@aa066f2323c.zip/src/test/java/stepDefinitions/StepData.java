package stepDefinitions;

import org.openqa.selenium.WebDriver;

import io.cucumber.java.Scenario;

/**
 * Base file for Cucumber Dependency Injection
 * Dependency injection supported to share the state of driver and data between steps in Scenarios
 * Any driver details and step level data can be maintained in this file
 * Cucumber PicoContainer Supports this functionality
 *
 */
public class StepData {

	//Intialize step definition level driver
	//Increase the reusability of step definition across features
public WebDriver driver;
public String orderID;
Scenario scenario;

public Scenario getScenario()
{return scenario;}
public void setScenario(Scenario scenario)
{this.scenario=scenario;}

}
