package stepDefinitions;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.naming.Context;
import javax.swing.text.AbstractDocument.Content;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
//import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;
//import com.cucumber.listener.Reporter;

//import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;
//import com.cucumber.listener.Reporter;

import org.openqa.selenium.TakesScreenshot;

import pageObjects.TestBase;
//import util.AccountInfo;
import pageObjects.HostUrls;

public class Hooks extends TestBase {
	public static String scenarioName;
	public static int example_count = 0;
	public static Boolean chromeBrowser = false;
	public static Boolean retailpickupCase = false;
	public static FileOutputStream fos;
	private static ArrayList<String> fileWriter = new ArrayList<String>();
	private static ArrayList<String> fileWriterSourceForExampleData = new ArrayList<String>();

//	@Before("@Counter")
//	public void countScenarioOutlineRows() {
//		example_count++;
//	}

//	@Before
//	public void beforeScenario(Scenario scenario) throws FileNotFoundException {
//		example_count++;
//		System.out.println(
//				"\n***********************    START OF TEST RUN    ***********************\n\n#### Scenario: Run "
//						+ example_count + ": " + scenario.getName() + " ####\n");
//
//		ArrayList<String> tagsList = new ArrayList<>(scenario.getSourceTagNames());
//		tagsList.replaceAll(String::toUpperCase);
//
//		if (tagsList.contains("@DF") || tagsList.contains("@FFM") || tagsList.contains("@CHROME")) {
//			chromeBrowser = true;
//		}
//		if (tagsList.contains("@RETAIL_PICKUP")) {
//			retailpickupCase = true;
//		}
//	}

//	@After
//	public static void afterScenario(Scenario scenario) throws IOException, InterruptedException {
//		System.out.println(
//				"\n\n\n#### Scenario: Run " + example_count + ": " + scenario.getStatus() + " : " + scenario.getName()
//						+ " ####\n\n\n***********************     END OF TEST RUN     ***********************\n\n");
//		if (driver != null) {
//			TestBase.takeScreenshot("afterScenario");
//			addURLInReport("Last Opened Page");
//			fileWriter.add("TestStatus:" + example_count + ":" + scenario.getStatus());
//			fileWriter.add("##################################################");
////			AccountInfo.addTextToFile(fileWriter, scenario.getName(), "nLine");
////			AccountInfo.addTextToFile(fileWriterSourceForExampleData, scenario.getName() + "exampleData", "sLine");
////			AccountInfo.storePageSourceOfLastPage(driver.getPageSource());
//			driver.quit();
//			driver = null;
//		}

//	}

	public static void setFileWriter(String text) {
		fileWriter.add(text);
	}

	public static void setFileWriterExampleData(String text) {
		fileWriterSourceForExampleData.add(text);
	}
}
