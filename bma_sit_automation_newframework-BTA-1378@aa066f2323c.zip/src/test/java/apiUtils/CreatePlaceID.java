package apiUtils;

import org.junit.Assert;

/**
 * Rest API Create Place ID service reusable components class
 *
 */
public class CreatePlaceID extends BaseAPI{

	/**
	 * Validating the POST response 
	 */
	public void createPlaceIDReponseValidation()
	{
		Assert.assertTrue(response.jsonPath().getString("status").equals("OK"));
		
		String placeID=response.jsonPath().getString("place_id");
		
		Assert.assertTrue(!placeID.isEmpty());
		
	}
}
