package apiUtils;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.json.simple.JSONObject;
import org.junit.Assert;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

/**
 * Base class for Rest Assured Reusable Components
 *
 */
public class BaseAPI {
	
	//Object for Properties file
	public static Properties prop;
	//Object for Properties File Input Stream
	FileInputStream file;
	//Retrieving the Maven Environment variable
	public static String environment=System.getProperty("environment");
	//Rest Assured Request Specification object
	public static RequestSpecification requestSpecification;
	//Rest Assured Response object
	public static Response response;
	public static Properties configprop;
	
	/**
	 * Read the property files
	 * @param filename Property file name
	 */
	public void readPropertyFile(String filename)
	{
		try {
		prop=new Properties();
		file=new FileInputStream(filename);
		prop.load(file);
		} 
		catch (IOException e) {
			System.out.println("File not found");
		}
		
	}
	
	/**
	 * Retrieved the baseURI from ApiUrls.properties file
	 * Establish connection to the application server
	 */
	public void baseAPIConnectionEstablisher()
	{
		readPropertyFile(System.getProperty("user.dir")+"/src/main/resources/ApiUrls.properties");
		requestSpecification=RestAssured.given();
		
		
	}
	
	/**
	 * Setting up the baseURI retrieved in the server
	 */
	public void baseURISetup()
	{
		requestSpecification.baseUri(prop.getProperty(environment+"_Url"));
	}
	
	/**
	 * Getting the input of request details and declaring them to RequestSpecification
	 * @param headerValue Header value of rest request
	 * @param queryParamKey Query param key name
	 * @param queryParamValue Query param Value
	 * @param requestBody REST request JSON Body
	 */
	public void requestInput(String headerValue,String queryParamKey,String queryParamValue,JSONObject requestBody)
	{
		requestSpecification.header("Content-Type",headerValue);
		
		requestSpecification.queryParam(queryParamKey,queryParamValue);
		
		requestSpecification.body(requestBody.toJSONString());
	}
	
	/**
	 * Perform Rest API POST Operation
	 * @param resourceURL
	 */
	public void postRequest(String resourceURL)
	{
		response=requestSpecification.post(resourceURL);
		
		System.out.println(response.asString());
	}
	
	/**
	 * Perform Rest API GET Operation
	 * @param resourceURL
	 */
	public void getRequest(String resourceURL)
	{
		response=requestSpecification.get(resourceURL);
		
		System.out.println(response.asString());
	}
	
	/**
	 * Perform Rest API PUT Operation
	 * @param resourceURL
	 */
	public void putRequest(String resourceURL)
	{
		response=requestSpecification.put(resourceURL);
		
		System.out.println(response.asString());
	}
	
	/**
	 * Perform Rest API DELETE Operation
	 * @param resourceURL
	 */
	public void deleteRequest(String resourceURL)
	{
		response=requestSpecification.delete(resourceURL);
		
		System.out.println(response.asString());
	}
	
	/**
	 * Validate the status code with the response status code
	 * @param statuscode
	 */
	public void statusCodeValidation(int statuscode)
	{
		Assert.assertTrue(response.getStatusCode()==statuscode);
		
	}
	
	

}
