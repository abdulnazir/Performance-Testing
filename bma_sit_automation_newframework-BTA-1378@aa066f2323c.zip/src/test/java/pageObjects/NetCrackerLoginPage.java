package pageObjects;

import java.io.IOException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import pageObjects.TestBase;

public class NetCrackerLoginPage extends BaseUIPage{
	private WebDriver driver;
	public NetCrackerLoginPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//*[@id=\"user\"]")
	WebElement ncUserName;

	@FindBy(xpath = "//*[@id=\"pass\"]")
	WebElement NCPassword;

	@FindBy(xpath = "//*[@id=\"loginButton\"]/div")
	WebElement NCloginButton;		
	
	public void enterNetcrackerUsername(String NetcrackerUsername) {
		WebDriverWait w = new WebDriverWait(driver, 60);
		w.until(ExpectedConditions.visibilityOf(ncUserName));
		ncUserName.sendKeys(NetcrackerUsername);
	}

	public void enterNetcrackerPassword(String NetcrackerPassword) {
		NCPassword.sendKeys(NetcrackerPassword);
	}

	public void clickOnLoginButton() {
		wait.withMessage("NC login button not found").until(ExpectedConditions.visibilityOf(NCloginButton));
		NCloginButton.click();
	}

	public void login(String NetcrackerUsername, String NetcrackerPassword) throws IOException, InterruptedException {

//		if (TestBase.prop.getProperty("environment", "non-timeshifter").equalsIgnoreCase("preprod")) {
//			(By.xpath("//a[text()='Log on as NT user']")).shouldBe(visible).click();
//			
//			return;
//		}
		enterNetcrackerUsername(NetcrackerUsername);
		enterNetcrackerPassword(NetcrackerPassword);
		clickOnLoginButton();
		//$(By.xpath("//a[text()='Inventory']")).waitUntil(visible, 20000);
//		Thread.sleep(2000);
		//takeScreenshot(null);
	}
}
