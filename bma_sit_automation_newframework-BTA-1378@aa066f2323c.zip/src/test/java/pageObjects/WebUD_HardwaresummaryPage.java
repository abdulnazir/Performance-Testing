package pageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;

import junit.framework.Assert;

public class WebUD_HardwaresummaryPage extends BaseUIPage {
	
	private WebDriver driver;
	public WebUD_HardwaresummaryPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//a[@id='hardware-summary-tab_main']")
	public WebElement hardwaresummarytab;
	
	
	@FindBy(xpath = "//table[@id='hardware-summary-table_main']//table[@class='UIXTable']")
	public WebElement hardwaresummarytable;
	
	
	@FindBy(xpath = "//table[@id='financed-hardware-summary-table-target-layout_main']//table[@class='UIXTable']")
	public WebElement financedhardwaresummarytable;
	
	
	@FindBy(xpath = "//tbody//td/table[@id='hardware-summaries']//tbody//tr[2]/td[4]")
	public WebElement hardwareserialnum;
	
	
	@FindBy(xpath = "//*[contains(text(),'Ignite Doorbell Camera (Wired) 36 Month Term')]/following::td[7]//input")
	public WebElement doorbellprepay;
	
	@FindBy(xpath = "//*[contains(text(),'Ignite Doorbell Camera (Wired) 36 Month Term')]/following::td[8]/a/span")
	public WebElement calculate;
	
	
	@FindBy(xpath = "//span[contains(text(),'Submit')]")
	public WebElement submit;
	
	@FindBy(xpath="//a[@id=\"ordersViewSelector_main\"][contains(text(),'Account Summary')] | //div[@id='summaryViewSelector']")
	WebElement accountSummary;

	
	public void hardwaresummary() throws  Exception
	{
		
		WebDriverWait w = new WebDriverWait(driver, 120);
		Thread.sleep(5000);
		goToFrame(driver, "ncframeOrderHistory");
		w.until(ExpectedConditions.visibilityOf(hardwaresummarytab));
		scrollToElementAndClick(hardwaresummarytab,driver);
		waitForLoading(driver);
		scrollToElementAndClick(accountSummary, driver);
		w.until(ExpectedConditions.visibilityOf(hardwaresummarytab));
		scrollToElementAndClick(hardwaresummarytab,driver);
	}
	

	public String fiancedhardwaresummarytable() throws  Exception
	{
		WebDriverWait w = new WebDriverWait(driver, 120);
		String celltext=null;
	//	WebElement tbl = driver.findElement(By.xpath("//table[@id='financed-hardware-summary-table-target-layout_main']//table[@class='UIXTable']"));
		w.until(ExpectedConditions.visibilityOf(financedhardwaresummarytable));
		List<WebElement> rows = financedhardwaresummarytable.findElements(By.tagName("tr"));
		for(int i=1; i<rows.size(); i++) {
		    List<WebElement> cols = rows.get(i).findElements(By.tagName("td"));
		    for(int j=0; j<cols.size(); j++) {
		      //  System.out.println(cols.get(j).getText());
		    	WebElement cell = cols.get(j);
		    	 celltext = cell.getText();	
		    	 System.out.println(celltext);
		    }   
	
	  }
		
	return celltext;
	
	}
	
	
	public void hardwaresummarytable() throws  Exception
	{

	//	WebElement tbl = driver.findElement(By.xpath("//table[@id='financed-hardware-summary-table-target-layout_main']//table[@class='UIXTable']"));
		List<WebElement> rows = hardwaresummarytable.findElements(By.tagName("tr"));
		for(int i=0; i<rows.size(); i++) {
		    List<WebElement> cols = rows.get(i).findElements(By.tagName("td"));
		    for(int j=0; j<cols.size(); j++) {
		        System.out.println(cols.get(j).getText());
		    }

		}
	}
	
	
	public String hardwareserialnum() throws  Exception
	{

		WebDriverWait w = new WebDriverWait(driver, 120);
		w.until(ExpectedConditions.visibilityOf(hardwareserialnum));
		scrollToElement(hardwareserialnum,driver);
		String hardwareserialno = hardwareserialnum.getText();
		waitForLoading(driver);
		return hardwareserialno;
		
	}
	
	public void doorprepay() throws Exception {
	
		WebDriverWait w = new WebDriverWait(driver, 120);
		w.until(ExpectedConditions.visibilityOf(doorbellprepay));
		scrollToElementAndClick(doorbellprepay,driver);
		doorbellprepay.clear();
		doorbellprepay.sendKeys("175");	
		w.until(ExpectedConditions.visibilityOf(calculate));
		scrollToElementAndClick(calculate,driver);
		driver.switchTo().activeElement();
		w.until(ExpectedConditions.visibilityOf(submit));
		scrollToElementAndClick(submit,driver);
		
	}
	
}
