package pageObjects;

import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


import util.TestUtil;

public class FDBValidationPage extends BaseUIPage {

	private WebDriver driver;
	TestUtil utils;
	public FDBValidationPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//table[@id='grdView']/tbody/tr[2]/td[6]")
	WebElement fdbdeviceStatus;

	@FindBy(xpath = "//input[@id='txtUserName']")
	WebElement userName;

	@FindBy(xpath = "//input[@id='txtPassword']")
	WebElement password;

	@FindBy(xpath = "//input[@id='btnLogin']")
	WebElement loginbutton;

	public void loginToFDB() throws InterruptedException {
		Thread.sleep(10000);
		if (driver.findElements(By.xpath("//*[@id=\"txtUserName\"]")).size() > 0) {
			userName.sendKeys("trainer");
			Thread.sleep(2000);
			password.sendKeys("trainer");
			Thread.sleep(2000);
			loginbutton.click();
		}
	}

	public String getdeviceStatus() throws InterruptedException {
		String fdbTableContent = "//td[contains(text(),'ENABLED')]";
		for (char c : "123456".toCharArray()) {
			Thread.sleep(9999);
			if ($(By.xpath(fdbTableContent)).exists())
				break;
			driver.navigate().refresh();
		}
		return fdbdeviceStatus.getText();
	}
}
