package pageObjects;

//import java.sql.Driver;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import util.TestUtil;

public class InternetServices extends BaseUIPage {
	private WebDriver driver;
	TestUtil utils;
	public InternetServices(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}


	@FindBy(xpath = "//*[text()='Grandfathered Internet 600']")
	WebElement GrandfatheredInternet600;

	@FindBy(xpath = "//*[text()='Internet 300']")
	WebElement Internet300;

	@FindBy(xpath = "//*[text()='Grandfathered Internet 75']")
	WebElement Grandfatheredinternet75;

	@FindBy(xpath = "//*[text()='Grandfathered Internet 50']")
	WebElement internet50;

	@FindBy(xpath = "//*[text()='Fibre+ 150']")
	WebElement internetFibre150;

	@FindBy(xpath = "//*[text()='Ignite Internet 75']")
	WebElement internetFibre75;

	// Added by Ashish [Start]
	@FindBy(xpath = "//*[text()='Ignite Internet 250']")
	WebElement igniteinternet250;
	
	@FindBy(xpath = "//*[text()='Ignite Flex 10']")
	WebElement igniteflex10;

	// Added by Ashish [Finish]

	@FindBy(xpath = "//*[text()='Fibre+ Gig']")
	WebElement internetFibreGigPlus;

	@FindBy(xpath = "//*[text()='Grandfathered Internet 300']")
	WebElement GrandfatheredInternet300;

	@FindBy(xpath = "//*[text()='Grandfathered Internet 300 Unlimited']")
	WebElement Grandfatheredinternet300unlimited;
	
	@FindBy(xpath = "//*[contains(text(),'Ignite Internet 500')]")
	WebElement fibre500;

	@FindBy(xpath = "/html[1]/body[1]/div[5]/table[1]/tbody[1]/tr[2]/td[1]/div[1]/div[1]/table[1]/tbody[1]/tr[2]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[2]/div[1]/table[1]/tbody[1]/tr[2]/td[2]/div[1]/div[1]/table[1]/tbody[1]/tr[5]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/input[1]")
	WebElement EMPInternet300;

	@FindBy(xpath = "//*[text()='Freedom Internet 150']")
	WebElement freedomInternet150;

	@FindBy(xpath = "//*[@id=\"ConvergedHardwareCategory_addOfferButton\"]/span/span | //*[@id=\"ConvergedHardwareCategory_addOfferButton\"]")
	WebElement addXB6Product;

	@FindBy(xpath = "//*[@id=\"addHardware9147984470013220657\"]/span/span | //*[@class=\"selector-layout\"]//span[@class=\"UIShawButton\"]")
	WebElement Rent;

	@FindBy(xpath = "//*[@id=\"9147984470013220652091479844700132206510914798447001322065191479844700132206540914798447001322065191479844700132206560914798447001322065191479844700132206580914798447001322065191479844700132206620_ft_main\"] | //*[@class=\"UITable9Box-body\"]//table[@class=\"UIVerticalLayout offer-placeholder\"]//input[@class=\"UICheckBox UICheckFeature_left_cb\"]")
	WebElement Xb6IntCheck;

	@FindBy(xpath = "//*[@id=\"hardware-popup-ok-button\"]/span/span")
	WebElement XB6serialnumokbutton;

	
	@FindBy(xpath = "//td[@class=' SecondCategory']//table[@c='UIShawLinkFeature']//a[@class='wrench-button-style']")
	WebElement IntHardwareWrench;
	
		
	@FindBy(xpath = "//*[@id=\"addHardware9153540577913917993\"]/span/span")
	WebElement Xpod3pkRent;

	@FindBy(xpath = "//span[contains(text(),'Delete')]")
	WebElement DelHit;

	@FindBy(xpath = "//span[contains(text(),'OK')]")
	WebElement AddIntokBtn;

	@FindBy(xpath = "//a[@id='UIHyperlink_selectorButton_9155240722713244955091552407227132449470915524072271324494791338346713136561070_main']")
	WebElement HitEmail;

	@FindBy(xpath = "//span[contains(text(),'Add E-mail Address')]")
	WebElement AddEmailBtn;

	@FindBy(xpath = "//" + "[@id='emailUsername_main']")
	WebElement EmailTextbox;

	@FindBy(xpath = "//span[contains(text(),'Validate')]")
	WebElement ValidateEmail;

	@FindBy(xpath = "//input[@id='emailFirstName_main']")
	WebElement emailFirstName;

	@FindBy(xpath = "//input[@id='emailLastName_main']")
	WebElement emailLastName;

	@FindBy(xpath = "//span[contains(text(),'OK')]")
	WebElement AddEmailOkBtn;

	@FindBy(xpath = "//span[contains(text(),'Transfer from another account')]")
	WebElement Transferlist;

	@FindBy(xpath = "//input[@id='accountNumber']")
	WebElement TransferAccountnum;

	@FindBy(xpath = "//*[text()='Employee Internet 300']")
	WebElement EmployeeInternet300;

	/*@FindBy(xpath = "//td[@class=' FourthCategory']//table[@c='UIShawLinkFeature']//a[@class=\"wrench-button-style\"] | //*[@class=\"FeatureLayout offer-components-block line-feature-layout\"]//div[contains(@id,'wrench-button-')]")
	WebElement XB6Wrench;*/
	
	@FindBy(xpath = "//td[@class=' FourthCategory']//table[@c='UIShawLinkFeature']//a[@class='wrench-button-style']")
	WebElement XB6Wrench;

	@FindBy(xpath = "//div/label[text()='Converged Hardware']/following::td[4]//a[contains(@class,'wrench-button-style')][1]")
	WebElement convergerdHardwareWrenchtech;
	
	
	@FindBy(xpath = "//div/label[text()='Converged Hardware']/following::td[@class='offerSelector']//select[1]")
	WebElement selectConvergerdHardwaretech;
	
	@FindBy(xpath = "//div[text()='Converged Hardware']/following::a[contains(@class,'wrench')][1]")
	WebElement convergerdHardwareWrench;
	
	@FindBy(xpath = "//div[text()='Converged Hardware']/following::select[1]")
	WebElement selectConvergerdHardware;

	@FindBy(xpath = "//td[@class='serial-number-input']/div/input")
	WebElement internetserialnumtextbox;

	@FindBy(xpath = "//td[@class=' validate-hardware']/a/span/span")
	WebElement Internetserialnumvalidatebutton;

	@FindBy(xpath = "//td[@class=' SecondCategory']//table[@c='UIShawLinkFeature']//a[@class='wrench-button-style']")
	WebElement InternetWrench;
	
	@FindBy(xpath = "//*[text()='Delete']") 
	WebElement deletedevice;

	@FindBy(xpath = "//*[@id=\"hardware-popup-ok-button\"]/span/span")
	WebElement internetokbutton;

	@FindBy(xpath = "//*[@id=\"9147984470013220652091479844700132206510914798447001322065191479844700132206540914798447001322065191479844700132206560914798447001322065191479844700132206580914798447001322065191479844700132206680_ft_main\"]")
	WebElement phoneservicecheck;

	@FindBy(xpath = "/html/body/div[17]/table/tbody/tr[2]/td[2]/div/table/tbody/tr[2]/td[2]/div/div/table/tbody/tr[3]/td/div/table/tbody/tr[2]/td[1]/div[2]/table/tbody/tr/td[1]/div/input")
	WebElement xpodEnterserial1;

	@FindBy(xpath = "/html/body/div[17]/table/tbody/tr[2]/td[2]/div/table/tbody/tr[2]/td[2]/div/div/table/tbody/tr[3]/td/div/table/tbody/tr[2]/td[1]/div[3]/table/tbody/tr/td[1]/div/input")
	WebElement xpodEnterserial2;

	@FindBy(xpath = "/html/body/div[17]/table/tbody/tr[2]/td[2]/div/table/tbody/tr[2]/td[2]/div/div/table/tbody/tr[3]/td/div/table/tbody/tr[2]/td[1]/div[4]/table/tbody/tr/td[1]/div/input")
	WebElement xpodEnterserial3;

	@FindBy(xpath = "/html/body/div[17]/table/tbody/tr[2]/td[2]/div/table/tbody/tr[2]/td[2]/div/div/table/tbody/tr[3]/td/div/table/tbody/tr[2]/td[1]/div[2]/table/tbody/tr/td[4]/a/span/span")
	WebElement xpodvalidate1;

	@FindBy(xpath = "/html/body/div[17]/table/tbody/tr[2]/td[2]/div/table/tbody/tr[2]/td[2]/div/div/table/tbody/tr[3]/td/div/table/tbody/tr[2]/td[1]/div[3]/table/tbody/tr/td[4]/a/span/span")
	WebElement xpodvalidate2;

	@FindBy(xpath = "/html/body/div[17]/table/tbody/tr[2]/td[2]/div/table/tbody/tr[2]/td[2]/div/div/table/tbody/tr[3]/td/div/table/tbody/tr[2]/td[1]/div[4]/table/tbody/tr/td[4]/a/span/span")
	WebElement xpodvalidate3;

	@FindBy(xpath = "/html/body/div[17]/table/tbody/tr[2]/td[2]/div/table/tbody/tr[2]/td[2]/div/div/table/tbody/tr[3]/td/div/table/tbody/tr[2]/td[1]/div[2]/table/tbody/tr/td[3]/a/span/span")
	WebElement deletexpod1;

	@FindBy(xpath = "/html/body/div[17]/table/tbody/tr[2]/td[2]/div/table/tbody/tr[2]/td[2]/div/div/table/tbody/tr[3]/td/div/table/tbody/tr[2]/td[1]/div[3]/table/tbody/tr/td[3]/a/span/span")
	WebElement deletexpod2;

	@FindBy(xpath = "/html/body/div[17]/table/tbody/tr[2]/td[2]/div/table/tbody/tr[2]/td[2]/div/div/table/tbody/tr[3]/td/div/table/tbody/tr[2]/td[1]/div[4]/table/tbody/tr/td[3]/a/span/span")
	WebElement deletexpod3;

	@FindBy(xpath = "//td[@class=' FourthCategory']//select/option[contains(text(),'Not selected')]")
	WebElement xb6NotSelected;
	
	@FindBy(xpath = "//td[@class=' FourthCategory']//select/option[contains(text(),'Not selected')]")
	WebElement xb7NotSelected;

	@FindBy(xpath = "//*[@id=\"addHardware9157289954413941909\"]/span/span")
	WebElement hitron;

	@FindBy(xpath = "//*[@id=\"addHardware9147984470013220657\"]/span/span")
	WebElement XB6RentButton;

	@FindBy(xpath = "//*[@id=\"addHardware9157571199113078574\"]/span/span | //div[@class='_span_ UIValue']/label[contains(text(),'Shaw Fibre+ Gateway 2.0 XB7 Modem')]/ancestor::tr[1]/td[3]//a")
	WebElement XB7RentButton;

	@FindBy(xpath = "//*[text()='Employee Fibre+ Gig']")
	WebElement employeeInternetFibre_gig;

	@FindBy(xpath = "//div[text()=\"Email\"]/ancestor::table[@c=\"UIQtyFeature\"]//a[contains(@id,\"UIHyperlink_selectorButton\")]")
	WebElement internetEmail;

	@FindBy(xpath = "//div[text()=\"BlueCurve Network Security\"]/ancestor::table[contains(@class,'fourth')]//div[1]")
	WebElement blueCurveNetworkSecurity;

	@FindBy(xpath = "//span[text()=\"Swap\"]")
	WebElement swapButton;

	@FindBy(xpath = "//label[text()=\"Technician\"]")
	WebElement technician;

	@FindBy(xpath = "//*[contains(@id,'technicianIdInput')]/input")
	WebElement techIdInputBox;

	@FindBy(xpath = "//*[contains(@id,'validateTechnicianId')]\r\n" + "")
	WebElement validateTechIdButton;

	@FindBy(xpath = "//table[@class=\"hardware-grid\"]//input[@hint=' - Serial Number - ']")
	WebElement inputSerialNumber;

	@FindBy(xpath = "//*[text()='Validate']")
	WebElement validateButton;

	@FindBy(xpath = "//*[@id=\"email-popup-ok-button\"]/span/span")
	WebElement okButton;
	
	@FindBy(xpath = "//*[@class='hardware-grid']/tbody/tr[1]/td[3]//td[2]//span/span")
	WebElement ModemRentButton;
	
	@FindBy(xpath="//a[@id='ConvergedHardwareCategory_addOfferButton']//span[contains(text(),'Add Product')]")
    WebElement AddProductXB6;
	
	@FindBy(xpath="//label[contains(text(),'BlueCurve Gateway')]//following::span[contains(text(),'+Rent')]")
	    WebElement XB6RentFibre300;
	
	@FindBy(xpath="//div[text()='Converged Hardware']/following::span[text()='Add Product'][1]")
    WebElement addProduct_ConvergedHardware;
	//added by Raj
		@FindBy(xpath="//tr[11]//table[@class='hardware-instance existing-instance']//td[5]/a")
	    WebElement delwifirouter;
		//added by Raj
		@FindBy(xpath="//td[@class=' FourthCategory']//table[@c='UIShawLinkFeature']//a[@class='wrench-button-style']")
	    WebElement Addinternetwrench;
		
		@FindBy(xpath="//a[@id='ConvergedHardwareCategory_addOfferButton']//span[contains(text(),'Add Product')]")
	    WebElement AddProductoffer;
		
		
		@FindBy(xpath="//tr[3]/td/div/table/tbody/tr/td[2]/div/table/tbody/tr/td[2]/a/span/span")
	    WebElement addtpiamodem;
		
		
	
	
	public void selectXB6RentButtonFibre300() throws InterruptedException {
	                    //waitForLoading();
						Thread.sleep(3000);
	                    XB6RentFibre300.click();
	    }
	public void addConvergedHardwareAddProduct() throws InterruptedException{
	                   // waitForLoading();
						Thread.sleep(2000);
	                    AddProductXB6.click();
	    }

	
	public void deleteXpod() throws Exception {

//		Thread.sleep(2000);
		scrollToElementAndClick(IntHardwareWrench, driver);
//		IntHardwareWrench.click();
		waitForLoading(driver);
//		isLoaderSpinnerVisible(driver);
//		Thread.sleep(5000);
		WebElement hardwareDialog = driver.findElement(By.xpath("//div[@id='hardware-popup']"));
		for (char c : "123".toCharArray()) {
			hardwareDialog.findElement(By.xpath("//span[text()='Delete']")).click();
			isLoaderSpinnerVisible(driver);
			waitForLoading(driver);
//			Thread.sleep(3000);
		}
		scrollToElementAndClick(AddIntokBtn, driver);
//		AddIntokBtn.click();
//		Thread.sleep(2000);
	}

	

	public void deleteXB6() throws InterruptedException {
		Thread.sleep(2000);
		xb6NotSelected.click();
	}
	public void deleteXB7() throws InterruptedException {
		List XB7NotDisplayed =driver.findElements(By.xpath("//td[@class=' FourthCategory']//select/option[contains(text(),'Not selected')]"));
		if (XB7NotDisplayed.size()<1)	
		{			
			//XB6Product.click();
			waitForLoading(driver);
		}
		else{
			xb7NotSelected.click();
			waitForLoading(driver);
		}
	}

	public void selectInternetWrench() throws Exception {
		waitForLoading(driver);
//		JavascriptExecutor js = (JavascriptExecutor) driver;
//		WebElement InternettWrench=driver.findElement(By.xpath("//td[@class=' SecondCategory']//table[@c='UIShawLinkFeature']//a[@class='wrench-button-style']"));
//		WebDriverWait w = new WebDriverWait(driver, 60);
//		w.until(ExpectedConditions.visibilityOf(InternettWrench));		
//		if(System.getProperty("environment").equalsIgnoreCase("webud"))
//		{		
//			driver.switchTo().parentFrame();
//			List <WebElement> iframes = driver.findElements(By.tagName("iframe"));	
//			for(WebElement iframe: iframes)
//			{
//				if (iframe.getAttribute("id").equals("ncOrderEntry"))
//				{
//					driver.switchTo().frame("ncOrderEntry");
//					scrollToElement(InternettWrench, driver);
//					break;
//				}
//			}
//		}
//		js.executeScript("arguments[0].click();", InternettWrench);
//		if(driver.findElements(By.xpath("//div[text()='Converged Hardware']/following::span[text()='Add Product'][1]")).size()!=0)
//		if(!(driver.findElement(By.xpath("//div[text()='Converged Hardware']/following::span[text()='Add Product'][1]/ancestor::a")).getAttribute("class").contains("disabled")))
//			scrollToElementAndClick(addProduct_ConvergedHardware, driver);	
		scrollToElementAndClick(InternetWrench, driver);	
//		selectElementFromDropdown(selectConvergerdHardware, driver, "VisibleText", "Hardware");
	}

	public void deleteinternet() throws InterruptedException {
		Thread.sleep(2000);
		if(driver.findElements(By.xpath("//*[text()='Delete']")).size()!=0) deletedevice.click();
	}

	public void SelectInternetOkButton() throws Exception {
		scrollToElementAndClick(internetokbutton, driver);
//		internetokbutton.click();
	}
	
	//Swati : Added for EWAN TCs NGV-43426
	public void selectInternetWrenchWithModemSerialNumer() throws Exception {
		wait.withMessage("InternetWrenchButton not visible").until(ExpectedConditions.visibilityOf(InternetWrench));
//		InternetWrench.click();
		scrollToElementAndClick(InternetWrench, driver);
//		Thread.sleep(2000);
		isLoaderSpinnerVisible(driver);
		scrollToElementAndClick(ModemRentButton, driver);
//		ModemRentButton.click();
	}

	public void selectInternetPackage(String internetPackage) throws InterruptedException {
		String lXpath;
		isLoaderSpinnerVisible(driver);	//AddedShweta
		if (internetPackage.contains(":")) {
			String lpackage = internetPackage.split(":")[0].trim();
			String price = internetPackage.split(":")[1].trim();
			//addInfoInReport("package = " + lpackage);
			//addInfoInReport("price = " + price);
			lXpath = "//td[contains(@class,'SecondCategory')]//label[text()='" + lpackage
					+ "']/ancestor::tr[1]//div[contains(text(), '" + price + "')]/ancestor::tr[1]//input";
		} else {
			lXpath = "//div[@id='internetCategory']//label[text() = '" + internetPackage.trim()
					+ "']/preceding-sibling::input";
		}
		JavascriptExecutor js = (JavascriptExecutor) driver;
		wait.withMessage(internetPackage + " not visible")
				.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(lXpath.trim()))));

		if(System.getProperty("environment").equalsIgnoreCase("webud"))
		{
			driver.switchTo().parentFrame();
			List <WebElement> iframes = driver.findElements(By.tagName("iframe"));
			for(WebElement iframe: iframes)
			{
				if (iframe.getAttribute("id").equals("ncOrderEntry"))
				{
					driver.switchTo().frame("ncOrderEntry");
					js.executeScript("arguments[0].scrollIntoView();", driver.findElement(By.xpath(lXpath.trim())));
					break;
				}
			}
		}
		js.executeScript("arguments[0].click();", driver.findElement(By.xpath(lXpath.trim())));
	}

	public void selectInternetProductEMPInternet300() throws InterruptedException {
		Thread.sleep(5000);
		EMPInternet300.click();
	}

	public void selectGrandfatheredInternet300() throws InterruptedException {
		Thread.sleep(5000);
		GrandfatheredInternet300.click();
	}

	public void selectFibreInternet150() throws InterruptedException {
		Thread.sleep(5000);
		internetFibre150.click();
	}

	public void selectFibreInternet75() throws Exception {
		Thread.sleep(5000);
		scrollToElementAndClick(internetFibre75, driver);
//		internetFibre75.click();
	}
	// Added by Ashish [Start]
	public void selectIgniteInternet250() throws Exception {
		Thread.sleep(5000);
		scrollToElementAndClick(igniteinternet250, driver);
	}
	
	public void selectIgniteTV() throws Exception {
		Thread.sleep(5000);
		igniteflex10.click();
		scrollToElementAndClick(igniteflex10, driver);
	}
	// Added by Ashish [Finish]
	public void selectHitronProduct() throws InterruptedException {
		Thread.sleep(5000);
		Internet300.click();
	}

	public void InternetProductEmail(String ID, String ID2) throws InterruptedException {
		//waitForLoading();
		Thread.sleep(2000);
		HitEmail.click();
		Thread.sleep(5000);
		AddEmailBtn.click();
		Thread.sleep(5000);
		EmailTextbox.sendKeys(ID);
		ValidateEmail.click();
		Thread.sleep(5000);
		emailFirstName.sendKeys(ID);
		emailLastName.sendKeys(ID2);
		Thread.sleep(5000);
		AddEmailOkBtn.click();
		Thread.sleep(5000);
		AddEmailBtn.click();
		Thread.sleep(5000);
		EmailTextbox.sendKeys(ID2);
		Thread.sleep(5000);
		ValidateEmail.click();
		Thread.sleep(5000);
		emailFirstName.sendKeys(ID2);
		Thread.sleep(5000);
		emailLastName.sendKeys(ID2);
		Thread.sleep(5000);
		AddEmailOkBtn.click();
		Thread.sleep(5000);
		AddEmailOkBtn.click();
		Thread.sleep(5000);
	}

	public void InternetTransferEmail(String ID, String acc) throws InterruptedException {
		Thread.sleep(5000);
		HitEmail.click();
		Thread.sleep(5000);
		AddEmailBtn.click();
		Thread.sleep(5000);
		Transferlist.click();
		Thread.sleep(5000);
		TransferAccountnum.sendKeys(acc);
		Thread.sleep(5000);
		EmailTextbox.sendKeys(ID);
		Thread.sleep(5000);
		ValidateEmail.click();
		Thread.sleep(5000);
		AddEmailOkBtn.click();
		Thread.sleep(5000);
	}

	public void AddXB6Product() throws InterruptedException {
		Thread.sleep(5000);
		addXB6Product.click();
		Thread.sleep(5000);
		XB6Wrench.click();
		Thread.sleep(5000);
		Rent.click();
		Thread.sleep(5000);
		XB6serialnumokbutton.click();
		Thread.sleep(5000);
		Xb6IntCheck.click();

	}
	String strlen;
	public void DeleteandAddConvergedHardware(String internetdevicehardware) throws Exception
	{
		deleteConvergedHardware();
	//	deleteConvergedHardwaretech();
//		isLoaderSpinnerVisible(driver);	//AddedShweta
//		goToFrame(driver, "ncOrderEntry");
		waitForLoading(driver);			//Added23/5
		WebElement rentinternethardware=driver.findElement(By.xpath("//div[text()='Hardware' and contains(@class,'Popup')]/following::label[contains(text(),'"+internetdevicehardware+"')]/following::span[contains(text(),'Rent')][1]"));
//		wait.until(ExpectedConditions.elementToBeClickable(rentinternethardware));
		Thread.sleep(2000);
		scrollToElementAndClick(rentinternethardware, driver);		
	}

	public void deleteConvergedHardware() throws Exception
	{	
		WebDriverWait w = new WebDriverWait(driver, 90);
		isLoaderSpinnerVisible(driver);	//AddedShweta
		waitForLoading(driver);	
		isLoaderSpinnerVisible(driver);	//AddedShweta
//		w.until(ExpectedConditions.invisibilityOfAllElements(driver.findElements(By.xpath("//*[contains(text(),'Loading')]"))));
		if(driver.findElements(By.xpath("//div[text()='Converged Hardware']/following::span[text()='Add Product'][1]")).size()!=0)
		if(!(driver.findElement(By.xpath("//div[text()='Converged Hardware']/following::span[text()='Add Product'][1]/ancestor::a")).getAttribute("class").contains("disabled")))
			scrollToElementAndClick(addProduct_ConvergedHardware, driver);	
		isLoaderSpinnerVisible(driver);
		selectElementFromDropdown(selectConvergerdHardware, driver, "VisibleText", "Hardware");
		waitForLoading(driver);	
		isLoaderSpinnerVisible(driver);	//AddedShweta
		if(driver.findElements(By.xpath("//div[text()='Converged Hardware']/following::a[contains(@class,'wrench')][1]")).size()!=0)
		strlen=driver.findElement(By.xpath("(//div[text()='Converged Hardware']/following::a[contains(@class,'wrench')][1])/ancestor::td[1]/preceding-sibling::td[1]/descendant::label[1]")).getText();
		scrollToElementAndClick(convergerdHardwareWrench, driver);
		w.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[text()='Hardware' and contains(@class,'Popup')]")));
//		w.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//div[text()='Hardware' and contains(@class,'Popup')]")))); Commented23/5
		if(strlen.length()>1)
		{
			isLoaderSpinnerVisible(driver);	//AddedShweta
//			waitForLoading(driver);	Commented23/5
			scrollToElement(deletedevice, driver);	
			scrollToElementAndClick(deletedevice, driver);	
		}	
	}
	
	public void deleteConvergedHardwaretech() throws Exception
	{	
		WebDriverWait w = new WebDriverWait(driver, 90);
		isLoaderSpinnerVisible(driver);	//AddedShweta
		waitForLoading(driver);	
		isLoaderSpinnerVisible(driver);	//AddedShweta
//		w.until(ExpectedConditions.invisibilityOfAllElements(driver.findElements(By.xpath("//*[contains(text(),'Loading')]"))));
		if(driver.findElements(By.xpath("//div[text()='Converged Hardware']/following::span[text()='Add Product'][1]")).size()!=0)
		if(!(driver.findElement(By.xpath("//div[text()='Converged Hardware']/following::span[text()='Add Product'][1]/ancestor::a")).getAttribute("class").contains("disabled")))
			scrollToElementAndClick(addProduct_ConvergedHardware, driver);	
		selectElementFromDropdown(selectConvergerdHardwaretech, driver, "VisibleText", "Hardware");
		waitForLoading(driver);	
		isLoaderSpinnerVisible(driver);	//AddedShweta
		if(driver.findElements(By.xpath("//div/label[text()='Converged Hardware']/following::td[4]//a[contains(@class,'wrench-button-style')][1]")).size()!=0)
		strlen=driver.findElement(By.xpath("(//div/label[text()='Converged Hardware']/following::td[4]//a[contains(@class,'wrench-button-style')][1])/ancestor::td[1]/preceding-sibling::td[1]/descendant::label[1]")).getText();
		scrollToElementAndClick(convergerdHardwareWrenchtech, driver);
		w.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[text()='Hardware' and contains(@class,'Popup')]")));
//		w.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//div[text()='Hardware' and contains(@class,'Popup')]")))); Commented23/5
		if(strlen.length()>1)
		{
			isLoaderSpinnerVisible(driver);	//AddedShweta
//			waitForLoading(driver);	Commented23/5
			scrollToElement(deletedevice, driver);	
			scrollToElementAndClick(deletedevice, driver);	
		}	
	}
	public void DisconnectConvergedHardware() throws Exception
	{
		selectElementFromDropdown(selectConvergerdHardware, driver, "VisibleText", "Not selected");
//		scrollToElementAndClick(XB6Wrench, driver);
//		isLoaderSpinnerVisible(driver);	//AddedShweta
//		waitForLoading(driver);	
//		scrollToElement(deletedevice, driver);	
//		scrollToElementAndClick(deletedevice, driver);
	}
	public void AddXB6ProductWithSerialNumber() throws InterruptedException {
		Thread.sleep(12000);
		waitForLoading(driver);
		waitForLoading(driver);
		waitForLoading(driver);
		waitForLoading(driver);
		waitForLoading(driver);
		waitForLoading(driver);
		addXB6Product.click();
		Thread.sleep(5000);
		XB6Wrench.click();
		Thread.sleep(5000);
		Rent.click();
		Thread.sleep(5000);
	}

	public void AddXpod(String serialOne, String serialTwo, String serialThree)
			throws Exception {
		Thread.sleep(6000);
		scrollToElementAndClick(IntHardwareWrench, driver);
//		IntHardwareWrench.click();
		Thread.sleep(2000);
		Xpod3pkRent.click();
		Thread.sleep(2000);
		String lserial = "";
		for (char c : "123".toCharArray()) {
			switch (Character.toString(c)) {
			case "1":
				lserial = serialOne;
				break;
			case "2":
				lserial = serialTwo;
				break;
			case "3":
				lserial = serialThree;
				break;
			}
			//addInfoInReport("Adding XPOD with serial number = " + lserial);
			driver.findElements(By.xpath("//input[contains(@id, 'serial')]")).get(0).sendKeys(lserial);
			driver.findElements(By.xpath("//td[contains(@class,'validate-hardware')]//span[text() = 'Validate']"))
					.get(0).click();
			Thread.sleep(5000);
			//TestBase.takeScreenshot("AddXpod");
		}
		AddIntokBtn.click();
		Thread.sleep(2000);
	}

	public void selectXpod() throws Exception {
		scrollToElementAndClick(IntHardwareWrench, driver);
		scrollToElementAndClick(Xpod3pkRent, driver);
		scrollToElementAndClick(AddIntokBtn, driver);
	}

	public void RemoveHit() throws Exception {
		//Thread.sleep(12000);
		waitForLoading(driver);
		scrollToElementAndClick(IntHardwareWrench, driver);
		Thread.sleep(2000);
		if (driver.findElements(By.xpath("//span[contains(text(),'Delete')]")).size()>0)
			{
		DelHit.click();
			}
		AddIntokBtn.click();
		Thread.sleep(3000);		
	}

	public void selectGrandfatheredInternetProduct300() {
		wait.withMessage("GrandfatheredInternet300 not visible")
				.until(ExpectedConditions.visibilityOf(GrandfatheredInternet300));
		GrandfatheredInternet300.click();
	}

	public void selectGrandfatheredInternet600() {

		GrandfatheredInternet600.click();
	}

	public void selectEmployeeInternet() {
		wait.withMessage("Employee Internet 300 not visible")
				.until(ExpectedConditions.visibilityOf(EmployeeInternet300));
		EmployeeInternet300.click();
	}

	public void selectInternetProduct300() {
		wait.withMessage("Internet300 not visible").until(ExpectedConditions.visibilityOf(Internet300));
		Internet300.click();
	}

	public void clickXb6Wrench() throws Exception {
		JavascriptExecutor js = (JavascriptExecutor) driver;
	 if(System.getProperty("environment").equalsIgnoreCase("webud"))
	 {
	 driver.switchTo().parentFrame();
	 List <WebElement> iframes = driver.findElements(By.tagName("iframe"));
	 for(WebElement iframe: iframes)
	 {
		 if (iframe.getAttribute("id").equals("ncOrderEntry"))
		 {
			 driver.switchTo().frame("ncOrderEntry");
			 js.executeScript("window.scrollBy(0,-800)", "");
			 break;
			 }
		 }
	 }
	 if (driver.findElement(By.xpath("//*[@id='ConvergedHardwareCategory_addOfferButton']")).getAttribute("class").equalsIgnoreCase("AddOfferButton UIShawButton"))
	 {
		 scrollToElementAndClick(addXB6Product, driver);
		 waitForLoading(driver);
	 }
	 scrollToElementAndClick(XB6Wrench, driver);
	 }

	public void setInternetSerialNum(String serialnumXB6) throws Exception {
		wait.withMessage("InternetSerialNumberTextBox  button not visible")
				.until(ExpectedConditions.visibilityOf(internetserialnumtextbox));
		enterValueInField(internetserialnumtextbox, serialnumXB6, driver);
//		internetserialnumtextbox.sendKeys(serialnumXB6);
	}

	public void clickOnSerialNumValidateButton() throws Exception {
		scrollToElementAndClick(Internetserialnumvalidatebutton, driver);
//		Internetserialnumvalidatebutton.click();
	}

	public void selectHitron() throws InterruptedException {
		Thread.sleep(2000);
		internetFibre150.click();
		Thread.sleep(2000);
		IntHardwareWrench.click();
		Thread.sleep(2000);
		hitron.click();
		Thread.sleep(2000);
		internetokbutton.click();
	}

	public void clickOnInternetOkButton() throws Exception {
		scrollToElementAndClick(internetokbutton, driver);
	}
	
	public void clickWifiRouterCheckBox() throws Exception {
//		Thread.sleep(7000);
		scrollToElementAndClick(Xb6IntCheck, driver);
//		Xb6IntCheck.click();
//		Thread.sleep(2000);
	}

	public void selectInternet75() {
		wait.withMessage("Grandfathered internet 75 button not found")
				.until(ExpectedConditions.visibilityOf(Grandfatheredinternet75));
		Grandfatheredinternet75.click();
	}

	public void selectInternet300() {
		Grandfatheredinternet300unlimited.click();
	}

	public void selectFreedomInternet150() {
		wait.withMessage("Freedom Internet 150 button not found")
				.until(ExpectedConditions.visibilityOf(freedomInternet150));
		freedomInternet150.click();
	}

	public void selectPhoneServiceXB6() throws InterruptedException {
		wait.withMessage("phone service check button not found")
				.until(ExpectedConditions.visibilityOf(phoneservicecheck));
		Thread.sleep(2000);
		phoneservicecheck.click();
	}

	public void selectInternet50() {
		internet50.click();
	}

	public void addXB6InternetProduct() throws InterruptedException {
		Thread.sleep(6000);
		addXB6Product.click();
	}

	public void selectXB6RentButton() throws InterruptedException {
		XB6RentButton.click();
	}

	public void selectInternetServiceCheckbox() throws Exception {		
		waitForLoading(driver);
		if (driver.findElements(By.xpath("//td[@class=' FourthCategory']//div[text()='Internet Service']/../..//input[@type=\"checkbox\"]")).size() > 0) {
			WebElement IntenetServices= driver.findElement(By.xpath("//td[@class=' FourthCategory']//div[text()='Internet Service']/../..//input[@type=\"checkbox\"]"));
			Thread.sleep(8000);
			scrollToElement(IntenetServices, driver);	
			isLoaderSpinnerVisible(driver);	//AddedShweta during 24.7
			if (IntenetServices.isSelected()==false)
			{
				scrollToElementAndClick(IntenetServices, driver);
				waitForLoading(driver);
			}
		}
	}
	
	
	public void rentXB7() throws InterruptedException {
		Thread.sleep(2000);
		XB7RentButton.click();
	}

	public void employeeInternetfibreGig() throws InterruptedException {
		Thread.sleep(2000);
		employeeInternetFibre_gig.click();
	}

	public void addInternetEmail() throws InterruptedException {
		internetEmail.click();
		Thread.sleep(2000);

	}

	public void addBlueCurveSecurity() throws InterruptedException {
		blueCurveNetworkSecurity.click();
		Thread.sleep(2000);
	}

	public void selectBulkInternetPackage(String bulkInternet) throws InterruptedException {
		String lXpath;

		lXpath = "//div[@id='internetCategory']//label[text() = '" + bulkInternet + "']/preceding-sibling::input";

		wait.withMessage(bulkInternet + " not visible")
				.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(lXpath))));
		Thread.sleep(2000);
		driver.findElement(By.xpath(lXpath)).click();
	}

	public void SwapInternet(String serialNumber) throws InterruptedException {
		swapButton.click();
		Thread.sleep(2000);
		technician.click();
		Thread.sleep(2000);
		techIdInputBox.sendKeys("5353");
		Thread.sleep(2000);
		validateTechIdButton.click();
		Thread.sleep(2000);
		inputSerialNumber.sendKeys(serialNumber);
		Thread.sleep(2000);
		validateButton.click();
		okButton.click();
	}
	public void selectFibre500() throws Exception {
		scrollToElementAndClick(fibre500, driver);
	}
	public void selectIgniteInternetProduct() throws Exception {
		scrollToElementAndClick(driver.findElement(By.xpath("//*[text()='Ignite Internet 250']")), driver);
	}	
	//Swati : Added for NGV-43452
	public void addXB7Product() throws Exception {
		scrollToElementAndClick(XB6Wrench, driver);
		scrollToElementAndClick(deletedevice, driver);
		Thread.sleep(2000);
		Rent.click();
		Thread.sleep(2000);
	}
	
	public void rentHitron() throws Exception{
		waitForLoading(driver);
		scrollToElementAndClick(hitron, driver);
		waitForLoading(driver);
	}
	
	public void addXB6() throws InterruptedException
	{
		Thread.sleep(3000);
		addXB6Product.click();
		Thread.sleep(4000);
		XB6Wrench.click();
	}
	
	public void changewifi() throws Exception {
		JavascriptExecutor js = ((JavascriptExecutor) driver);
		js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
		Thread.sleep(5000);
		js.executeScript("window.scrollBy(0,-250)", "");
		Thread.sleep(5000);
	//	upArrowClick(driver);
		Thread.sleep(5000);
		scrollToElement(IntHardwareWrench,driver);
		IntHardwareWrench.click();
	//	sd.driver.findElement(By.xpath("//td[@class=' SecondCategory']//table[@c='UIShawLinkFeature']//a[@class=\"wrench-button-style\"]")).click();
		waitForLoading(driver);				
		//Delete Wifi Router 
		Thread.sleep(5000);
		scrollToElement(delwifirouter,driver);
		delwifirouter.click();
//		sd.driver.findElement(By.xpath("//tr[11]//table[@class='hardware-instance existing-instance']//td[5]/a")).click();
		waitForLoading(driver);				
		clickOnInternetOkButton();
		waitForLoading(driver);
		scrollToElement(AddProductoffer,driver);
		AddProductoffer.click();
	//	sd.driver.findElement(By.xpath("//td[contains(@class,'FourthCategory')]//span[text()='Add Product']"))
		scrollToElement(Addinternetwrench,driver);
		Addinternetwrench.click();
		waitForLoading(driver);				
	//	sd.driver.findElement(By.xpath("//td[@class=' FourthCategory']//table[@c='UIShawLinkFeature']//a[@class=\"wrench-button-style\"]")).click();
		waitForLoading(driver);				
		//Add XB7 Fiber Router
//		sd.driver.findElement(By.xpath("//*[contains(text(),'Shaw Fibre+ Gateway 2.0 XB7 Modem')]/ancestor::td[contains(@class,'hardware-model')]/following-sibling::td/following-sibling::td//span[contains(text(),'+Rent')]/ancestor::a[@c='UIShawButton']"))
//		.click();
		scrollToElement(XB7RentButton,driver);
		XB7RentButton.click();
	//	sd.driver.findElement(By.xpath("//*[contains(text(),'Ignite WiFi Gateway (Gen 2) modem (XB7)')]/ancestor::td[contains(@class,'hardware-model')]/following-sibling::td/following-sibling::td//span[contains(text(),'+Rent')]/ancestor::a[@c='UIShawButton']")).click();				
		waitForLoading(driver);				
		
	}
	
	
	
	public void addtpiamodem() throws Exception {
		JavascriptExecutor js = ((JavascriptExecutor) driver);
		js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
		Thread.sleep(5000);
		js.executeScript("window.scrollBy(0,-250)", "");
		Thread.sleep(5000);
	//	upArrowClick(driver);
		Thread.sleep(5000);
		scrollToElement(IntHardwareWrench,driver);
		IntHardwareWrench.click();
		scrollToElementAndClick(addtpiamodem,driver);
		
		
		
	}
	
}