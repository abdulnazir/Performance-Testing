package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import util.TestUtil;

public class ComPage extends BaseUIPage {

	private WebDriver driver;
	TestUtil utils;
	public ComPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	@FindBy(xpath="//*[@id=\"id_tab_11\"]/a")
	WebElement Comorders;
	
	
	public void ClickComOrders()
	{
		Comorders.click();
	}
}
