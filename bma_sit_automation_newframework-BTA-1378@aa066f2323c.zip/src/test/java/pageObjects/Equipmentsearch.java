package pageObjects;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.*;
import org.testng.Assert;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;

import io.cucumber.java.Scenario;
import stepDefinitions.StepData;
import util.TestUtil;

public class Equipmentsearch extends BaseUIPage {

	private WebDriver driver;
	public BaseUIPage tb=new BaseUIPage();

public Equipmentsearch(WebDriver driver,Scenario scenario) {
	this.driver=driver;
	PageFactory.initElements(driver, this);
	 this.sd=new StepData();			
	sd.setScenario(scenario);		
	this.scenario=sd.getScenario();
	}
	
@FindBy(xpath = "//a[@id='dropdownMenuTv'] | //*[@id='televisonstatus']/div/a/div[contains(@class,'d-flex')]/i")
WebElement equipmentStatus;

@FindBy(xpath = "//*[@id='televisonstatus']/div[1]/div/table/tr[11]/td[2]/span")
WebElement changeStatusLink;

@FindBy(xpath = "//*[@id='internetstatus']/div[1]/div/table/tr[10]/td[2]/span")
WebElement internetchangeStatusLink;

@FindBy(xpath = "//div[@class='card']//parent::div/parent::div/div[2]//div//p[contains(text(),'Lost')]/parent::div/input")
WebElement EquipeLostRadioButton;

@FindBy(xpath = "//div[@class='card']//parent::div/parent::div/div[2]//div//p[contains(text(),'Stolen')]/parent::div/input")
WebElement EquipestolenRadioButton;

@FindBy(xpath = "//div[@class='card']//parent::div/parent::div/div[2]//div//p[contains(text(),'Found')]/parent::div/input")
WebElement EquipeFoundRadioButton;

@FindBy(xpath = "//div/b[contains(text(),'Serial Number')]/following-sibling::a")
WebElement serialnumbertext;


@FindBy(xpath = "//*[@id='changInternetStatusModalLabel']/parent::div/parent::div/div[2]//div//p[contains(text(),'Lost')]/parent::div/input")
WebElement internetLostRadioButton;

@FindBy(xpath = "//*[@id='changInternetStatusModalLabel']/parent::div/parent::div/div[2]//div//p[contains(text(),'Stolen')]/parent::div/input")
WebElement internetstolenRadioButton;

@FindBy(xpath = "//*[@id='changInternetStatusModalLabel']/parent::div/parent::div/div[2]//div//p[contains(text(),'Found')]/parent::div/input")
WebElement internetFoundRadioButton;

@FindBy(xpath = "//div[@class='modal-content']//div[@class='mt-1 mb-2']/textarea")
WebElement TextArea;

@FindBy(xpath = "//div[@class='modal-content']//*[contains(text(),'Change Equipment Status')]/following::button[contains(text(),'Submit')]")
WebElement SubmitButton;

@FindBy(xpath = "//*[@id='changInternetStatusModalLabel']/parent::div/parent::div//div[2]//div[@class='mt-1 mb-2']/textarea")
WebElement internetTextArea;

@FindBy(xpath = "//*[@id='changInternetStatusModalLabel']/parent::div/parent::div//div[2]/div[2]/div/button[contains(text(),'Submit')]")
WebElement internetSubmitButton;

@FindBy(xpath ="//*[@id='televisonstatus']/div[1]/div/table/tr[10]/td[2]")
WebElement Status;

@FindBy(xpath ="//*[@id='internetstatus']/div[1]/div/table/tr[9]/td[2]")
WebElement internetStatus;

@FindBy(xpath = "//a[@id='dropdownMenuInternet'] | //*[@class='dropdown']/a")
WebElement equipmentInternetdropdown;

@FindBy(xpath = "//*[@id='televisonstatus']/div[1]/div//p/a/span[contains(text(),'Return Equipment')]")
WebElement returnTvEquipmentLink;

@FindBy(xpath = "//*[@id='retailLocations']")
WebElement retailLocationDropdown;

@FindBy(xpath = "//*[@class='modal fade modalchangees show']//div[@class='modal-content']//div[@class='bttn']/button[contains(text(),'Return Equipment')]")
WebElement returnEquipmentButton;

@FindBy(xpath = "//*[@class='modal fade show']//div[@class='modal-content mdlcontent1']//div[@class='bttn dvbtngroup']/button[contains(text(),'Return Equipment')]")
WebElement returnConvergedEquipmentButton;	

@FindBy(xpath = "//a[@id='dropdownMenuConverged'] | //*[@id='suspstatus']/div/a/div[@class='d-flex flex-nowrap ms-auto']/i")
WebElement convergedDropdown;

@FindBy(xpath = "//ul[@class='dropdown-menu drpinternet show']/li[2]/div/div/div[2]/p/a/span | //*[@id='suspstatus']/div/ul/li[2]//*[@id='internetstatus']/div[@class='card dvcardinternet']//span[contains(text(),'Return Equipment')]")
WebElement returnConvergedEquipmentLink;

@FindBy(xpath = "//*[@id='returnConvergedModal']/div/div/div[2]/div[1]/b | //b[contains(text(),'Return Equipment Successsful')]")
WebElement convergedreturnEqipmentStatus;	

@FindBy(xpath = "//*[@id='returnConvergedModal']//button[contains(text(),'Close')] | //*[@class='dvhwrstatus']//button[contains(text(),'Close')]")
WebElement convergedCloseButton;

@FindBy(xpath = "//*[@id='televisonstatus']//div/div/div[2]/div[1]/b")
WebElement TVreturnEqipmentStatus;	

@FindBy(xpath = "//*[@id='televisonstatus']//button[contains(text(),'Close')]")
WebElement TVCloseButton;	

//@FindBy(xpath="//div[@class='full-row user-info bg-white']/img[4]")
@FindBy(xpath="//div[@class='full-row user-info bg-white']/descendant::*[contains(@class,'Refresh')]")
WebElement webudRefreshIcon;

@FindBy(xpath="//*[@id='televisonstatus']/div[@class='card']//div[contains(text(),'Birth Certificate')]")
WebElement birthCertificate;

@FindBy(xpath="//*[@id='televisonstatus']/div[@class='card']//div[contains(text(),'Birth Certificate')]/span[contains(@class,'Provision_White')]")
WebElement birthCertificateProvision;	

@FindBy(xpath="//*[@id='televisonstatus']/div[@class='card']/div//a[contains(text(),'View Equipment Details')]")
WebElement viewEquipmentDetailsLink;

@FindBy(xpath="//*[contains(text(),'Retrieve equipment by:')]/following::select[1]")
WebElement serialNumberDropdown;

@FindBy(xpath="//*[@class='mar mar1 ml-35 ng-valid ng-touched ng-dirty']")
WebElement searchValue;	

@FindBy(xpath="//*[contains(text(),'Retrieve equipment by:')]/parent::div/parent::div/parent::div//button[contains(text(),'Search')]")
WebElement searchButton;	

@FindBy(xpath="//b[contains(text(),'Provisioned')]/parent::div/p")
WebElement provisionDate;

@FindBy(xpath="//*[@id='suspstatus']/div/ul/li[2]/div/div/p[contains(text(),'Birth Certificate')]/img[2]")
WebElement birthCertificateConvergedProvision;	

@FindBy(xpath="//*[@id='suspstatus']/div/ul/li[2]/div/div/pc | //*[@id='suspstatus']/div/ul/li[2]/div/app-converged-equipmentdetails/div[1]//div[contains(text(),'Birth Certificate')]")
WebElement birthCertificateConverged;


@FindBy(xpath="//*[@id='suspstatus']/div/ul/li[2]/div/app-converged-equipmentdetails/div[1]//a[contains(text(),'View Equipment Details')]")
WebElement viewEquipmentDetailsConvergedLink;

@FindBy(xpath="//div[@class='Notify card card-body col-5']/b/button[contains(@class,'close')]")
WebElement closeEquipmentTab;

@FindBy(xpath="//button[contains(text(),'Provision')]/parent::div[@class='col-4']/button")
WebElement ProvisionButton;

@FindBy(xpath="//*[@id='suspstatus']/div/ul/li[2]/div/app-converged-equipmentdetails/div/div[@class='card-body dvcardbodyintr']/table//td[contains(text(),'Status:')]/parent::tr/td[2]")
WebElement convergedStatus;

@FindBy(xpath = "//*[@id='internetstatus']/div[1]/div/table/tr[11]/td[2]/span")
WebElement convergedChangeStatusLink;

@FindBy(xpath = "//a[@class='disp bg-icon_app_equipment']")
WebElement equipementsearch;

@FindBy(xpath = "//a[contains(text(),'Equipment Search')]")
WebElement equipementsearchtext;

@FindBy(xpath = "//select[@name='searchType']")
WebElement retrievequipementby;

@FindBy(xpath = "//div/div[2]/div/div[3]/div/input[@name='fname']")
WebElement searchentry;

@FindBy(xpath = "//div[4]/div[3]/div[3]/div[1]/div[1]/span[contains(text(),'Change Status')]")
WebElement equipechangestatuslink;

@FindBy(xpath = "//div[4]/div[3]/div[3]/div[3]")
WebElement locationType;

@FindBy(xpath = "//div[@class='Notify card card-body col-5']//button[2]/span")
WebElement Equiperefresh;

@FindBy(xpath = "//span[contains(text(),'View Notes')]")
WebElement viewnotes;

@FindBy(xpath = "//div/div/div/div[2]/table/tr/div[2]")
WebElement equipenotes;

@FindBy(xpath = "//b[contains(text(),'Equipment Notes')]/following-sibling::button")
WebElement equipenotesclose;

@FindBy(xpath = "//div/div[4]/div[3]/div[3]/div[2]/span")
WebElement equipenotestatus;

//Added by Raj - 06/20
@FindBy(xpath = "//a[@class='nav-link disp bg-icon_app_equipment']")
WebElement tpiaequipementsearchicon;

@FindBy(xpath = "//a[contains(text(),'Equipment Search')]")
WebElement tpiaequipementsearch;

@FindBy(xpath = "//a[contains(text(),'Manage TPIA Equipment')]")
WebElement tpiaManageEquipe;

@FindBy(xpath = "//div/input[@formcontrolname='serialNumber']")
WebElement tpiaaddserialnum;

@FindBy(xpath = "//select[@formcontrolname='manufacturer']")
WebElement tpiamanufacdropdown;

@FindBy(xpath = "//input[@formcontrolname='macAddress']")
WebElement tpiamacaddress;


@FindBy(xpath = "//select[@formcontrolname='modelCode']")
WebElement tpiamodeldropdown;

@FindBy(xpath = "//button[contains(text(),'Save')]")
WebElement tpiaequipesave;

@FindBy(xpath = "//input[@name='fname']")
WebElement tpiaeditserailnumtext;

@FindBy(xpath = "//input[@name='serialNumber']")
WebElement tpianoneditserailnumtext;


@FindBy(xpath = "//app-equipment-form/div[1]/div/div[2]/div/select")
WebElement tpiaaddeditdropdown;

@FindBy(xpath = "//button[contains(text(),'Search')]")
WebElement tpiaeditsearch;

@FindBy(xpath = "//button[contains(text(),'Confirm')]")
WebElement tpiaequipeconfirm;
//button[contains(text(),'Confirm')]


@FindBy(xpath = "//div[contains(text(),'Duplicate device found')]")
WebElement tpiaduplicatedevicemsg;

@FindBy(xpath = "//p[@class='Error textCentre']")
WebElement nontpiadevicemsg;

@FindBy(xpath = "//span[@class='accNo']")
WebElement accno;


@FindBy(xpath = "//div[@class='section3']//div[4]//a")
WebElement macaddress;

@FindBy(xpath = "//p[@class='Error textCentre']")
WebElement tpiadeviceactivemsg;



	
	public void equipmentSearch(String retrievEquipBy, String equipSearchvalue) throws Exception {
		
		waitForLoading(driver);
		WebDriverWait w = new WebDriverWait(driver, 10);
		w.until(ExpectedConditions.elementToBeClickable(equipementsearchtext));	
		if(equipementsearchtext.isDisplayed()) {
			scrollToElementAndClick(equipementsearchtext , driver);
			ExtentCucumberAdapter.addTestStepLog("The tool tip for the Equipment icon is displayed on the screen");
			ExtentCucumberAdapter.addTestStepLog("Equipment search icon is displayed and Manage TPIA is not displayed");
		}
		
		
		w.until(ExpectedConditions.elementToBeClickable(retrievequipementby));	
		selectElementFromDropdown(retrievequipementby , driver , "VisibleText" , retrievEquipBy);
	//	w.until(ExpectedConditions.elementToBeClickable(searchentry));	
	//	searchentry.clear();
		Thread.sleep(15000);
		System.out.println(equipSearchvalue);
		searchentry.sendKeys("181062A065E6yuty");
		w.until(ExpectedConditions.visibilityOf(searchButton));	
		scrollToElementAndClick(searchButton,driver);
		Thread.sleep(5000);
	
	}
	
	public void equipmentaccno() throws Exception {
		WebDriverWait w = new WebDriverWait(driver, 10);
	//	w.until(ExpectedConditions.invisibilityOf(accno));	
		Thread.sleep(5000);
		String accnum = accno.getText();
		System.out.println(accnum + "accountnumber");
		if(accnum.contains("")) {
			
			ExtentCucumberAdapter.addTestStepLog("Accoun number is not displayed in Equipement search for VIP Account");
		}
		
		else
		{
			ExtentCucumberAdapter.addTestStepLog("Accoun number is displayed in Equipement search for VIP Account");
		}
	}
	
	public void equipmentvalidation() throws Exception {
		WebDriverWait w = new WebDriverWait(driver, 10);
	//	w.until(ExpectedConditions.invisibilityOf(accno));	
		Thread.sleep(5000);
		String macadress = macaddress.getText();
		System.out.println(macadress + "Macadress");
		if(!macadress.contains("")) {
			
			ExtentCucumberAdapter.addTestStepLog("Macadress is not updated for an Account");
		}
		
		else
		{
			ExtentCucumberAdapter.addTestStepLog("Macadress is updated for an Account");
		}
	}
	
	public void lostOnt() throws Exception {
		
		WebDriverWait w = new WebDriverWait(driver, 10);
		waitForLoading(driver);
		String loctype = locationType.getText();
	if (loctype.equals("Location\n"	+ "OnLocation")) {
		scrollToElementAndClick(equipechangestatuslink, driver);
			Thread.sleep(2000);
			waitForLoading(driver);
			String serialnumber = serialnumbertext.getText();
			scrollToElementAndClick(EquipeLostRadioButton, driver);
			EquipeLostRadioButton.click();
			TextArea.clear();
			TextArea.sendKeys("Lost Equipment");
			tb.addScreenshot(driver, this.scenario, "Status updated to Lost");
			scrollToElementAndClick(SubmitButton, driver);
			//scrollToElementAndClick(Equiperefresh,driver);
			Thread.sleep(5000);
			WebElement Equiperefresh = driver.findElement(By.xpath("//button[contains(text(),'" + serialnumber + "')]/following-sibling::*/span"));
			scrollToElementAndClick(Equiperefresh,driver);
			Thread.sleep(5000);
			scrollToElementAndClick(viewnotes,driver);
			driver.switchTo().defaultContent();
			String equipenote =  equipenotes.getText();
			ExtentCucumberAdapter.addTestStepLog(equipenote);
			scrollToElementAndClick(equipenotesclose,driver);
			
			
		}
	
	else {		
		ExtentCucumberAdapter.addTestStepLog("Equipement change status is not available when the device is not on location");
	}
		
	}
	
	public void ontStatus() throws Exception {
		
		String loctype = locationType.getText();
		String equipestatus = equipenotestatus.getText();
		ExtentCucumberAdapter.addTestStepLog(equipestatus);
		ExtentCucumberAdapter.addTestStepLog(loctype);
		
	}
	
	
	public void stolenOnt() throws Exception {
		
		WebDriverWait w = new WebDriverWait(driver, 10);
		waitForLoading(driver);
		String loctype = locationType.getText();
	if (loctype.equals("Location\n"	+ "OnLocation")) {
		scrollToElementAndClick(equipechangestatuslink, driver);
			Thread.sleep(2000);
			waitForLoading(driver);
			scrollToElementAndClick(EquipestolenRadioButton, driver);
			EquipestolenRadioButton.click();
			TextArea.clear();
			TextArea.sendKeys("Stolen Equipment");
			tb.addScreenshot(driver, this.scenario, "Status updated to Stolen");
			scrollToElementAndClick(SubmitButton, driver);
//			String equipref = "//button[@contains(text(),'"+ serialnumber +"')]";
			scrollToElementAndClick(Equiperefresh,driver);
			scrollToElementAndClick(viewnotes,driver);
			driver.switchTo().defaultContent();
			String equipenote =  equipenotes.getText();
			System.out.println(equipenote);
			scrollToElementAndClick(equipenotesclose,driver);
			String equipestatus = equipenotestatus.getText();
			System.out.println(equipestatus);
		}
	
	else {		
		ExtentCucumberAdapter.addTestStepLog("Equipement change status is not available ");
	}
	}	
	
public void foundOnt() throws Exception {
		
		WebDriverWait w = new WebDriverWait(driver, 10);
		waitForLoading(driver);
		String loctype = locationType.getText();
	if (loctype.equals("Location\n"	+ "OnLocation")) {
			scrollToElementAndClick(Equiperefresh,driver);
			scrollToElementAndClick(equipechangestatuslink, driver);
			Thread.sleep(2000);
			waitForLoading(driver);
			scrollToElementAndClick(EquipeFoundRadioButton, driver);
			EquipeFoundRadioButton.click();
			TextArea.clear();
			TextArea.sendKeys("Found Equipment");
			tb.addScreenshot(driver, this.scenario, "Status updated to Found");
			scrollToElementAndClick(SubmitButton, driver);
			scrollToElementAndClick(Equiperefresh,driver);
			scrollToElementAndClick(viewnotes,driver);
			driver.switchTo().defaultContent();
			String equipenote =  equipenotes.getText();
			System.out.println(equipenote);
			scrollToElementAndClick(equipenotesclose,driver);
			String equipestatus = equipenotestatus.getText();
			System.out.println(equipestatus);
		}
	
	else {		
		ExtentCucumberAdapter.addTestStepLog("Equipement change status is not available ");
	}
		
//		tb.addScreenshot(driver, this.scenario, "Status updated to Lost");
//		scrollToElementAndClick(SubmitButton, driver);
	
	}
	

public void tpiaequipmentSearch() throws Exception {
	
	waitForLoading(driver);
	WebDriverWait w = new WebDriverWait(driver, 10);
	w.until(ExpectedConditions.elementToBeClickable(tpiaequipementsearch));	
	scrollToElementAndClick(tpiaequipementsearch , driver);	
	Thread.sleep(5000);
	ExtentCucumberAdapter.addTestStepLog("Equipment search page is displayed");
	
}

public void tpiamanageequipment() throws Exception {
	
	waitForLoading(driver);
	WebDriverWait w = new WebDriverWait(driver, 10);
	w.until(ExpectedConditions.elementToBeClickable(tpiaManageEquipe));	
	scrollToElementAndClick(tpiaManageEquipe , driver);	
	ExtentCucumberAdapter.addTestStepLog("Manage Equipement page is displayed");
	
}

public void addtpiaequipment(String SeriaNumber, String manufacturer, String macaddress, String modelCode) throws Exception {
	
	waitForLoading(driver);
	WebDriverWait w = new WebDriverWait(driver, 10);
	w.until(ExpectedConditions.elementToBeClickable(tpiaaddserialnum));	
	tpiaaddserialnum.sendKeys(SeriaNumber);	
	w.until(ExpectedConditions.elementToBeClickable(tpiamanufacdropdown));	
	selectElementFromDropdown(tpiamanufacdropdown , driver , "VisibleText" , manufacturer);	
	w.until(ExpectedConditions.elementToBeClickable(tpiamacaddress));
	tpiamacaddress.clear();
	tpiamacaddress.sendKeys(macaddress);	
	w.until(ExpectedConditions.elementToBeClickable(tpiamodeldropdown));	
	selectElementFromDropdown(tpiamodeldropdown , driver , "VisibleText" , modelCode);	
	w.until(ExpectedConditions.visibilityOf(tpiaequipesave));	
	scrollToElementAndClick(tpiaequipesave,driver);
	w.until(ExpectedConditions.visibilityOf(tpiaequipeconfirm));
	scrollToElementAndClick(tpiaequipeconfirm,driver);
	
	

}

public void tpiaequipmentSearchicon() throws Exception {
	
	waitForLoading(driver);
	WebDriverWait w = new WebDriverWait(driver, 10);
	w.until(ExpectedConditions.elementToBeClickable(tpiaequipementsearchicon));	
	scrollToElementAndClick(tpiaequipementsearchicon,driver);
	if(tpiaequipementsearch.isDisplayed()) {		
		ExtentCucumberAdapter.addTestStepLog("The tool tip for the Equipment icon is displayed on the screen");
		ExtentCucumberAdapter.addTestStepLog("Equipment search and Manage TPIA Equipment icon is displayed");
	}		
		
}

public void tpiaduplicatedevice() throws Exception {
	
	waitForLoading(driver);
	WebDriverWait w = new WebDriverWait(driver, 10);
	w.until(ExpectedConditions.elementToBeClickable(tpiaduplicatedevicemsg));
	if(tpiaduplicatedevicemsg.isDisplayed()) {
	String Errormessage = tpiaduplicatedevicemsg.getText();
	ExtentCucumberAdapter.addTestStepLog("Error Message : " + Errormessage );
	
	}
}

public void edittpiaequip(String SeriaNumber) throws Exception {
	
	waitForLoading(driver);
	WebDriverWait w = new WebDriverWait(driver, 10);
	w.until(ExpectedConditions.elementToBeClickable(tpiaaddeditdropdown));
	selectElementFromDropdown(tpiaaddeditdropdown , driver , "VisibleText" , "Edit TPIA Equipment");
	w.until(ExpectedConditions.visibilityOf(tpiaeditserailnumtext));
	tpiaeditserailnumtext.sendKeys(SeriaNumber);
	String expectedtext = SeriaNumber;
	String actualtext = tpiaeditserailnumtext.getAttribute("value");
	if(actualtext.equals(expectedtext)){
		System.out.println("spl char not entered");
		scrollToElementAndClick(tpiaeditsearch,driver);
		if(!tpiadeviceactivemsg.isDisplayed()) {
		w.until(ExpectedConditions.visibilityOf(tpiaequipesave));	
		scrollToElementAndClick(tpiaequipesave,driver);
		w.until(ExpectedConditions.visibilityOf(tpiaequipeconfirm));
		scrollToElementAndClick(tpiaequipeconfirm,driver);
		}
		else {
			System.out.println("Save button is not available");
		}
	}
	else {
	
		ExtentCucumberAdapter.addTestStepLog("Not allowed to enter special characters in serial number");
	}


}

public void edittpiamac(String macaddress) throws Exception {
	
	waitForLoading(driver);
	WebDriverWait w = new WebDriverWait(driver, 10);
	w.until(ExpectedConditions.elementToBeClickable(tpiamanufacdropdown));	
//	selectElementFromDropdown(tpiamanufacdropdown , driver , "VisibleText" , manufacturer);	
	w.until(ExpectedConditions.elementToBeClickable(tpiamacaddress));
	tpiamacaddress.clear();
	tpiamacaddress.sendKeys(macaddress);
	String expectedmac = macaddress;
	String Actualmac = tpiamacaddress.getAttribute("value");
	if(Actualmac.equals(expectedmac)) {
//		w.until(ExpectedConditions.elementToBeClickable(tpiamodeldropdown));	
//		selectElementFromDropdown(tpiamodeldropdown , driver , "VisibleText" , modelCode);	
		w.until(ExpectedConditions.visibilityOf(tpiaequipesave));	
		scrollToElementAndClick(tpiaequipesave,driver);
		w.until(ExpectedConditions.visibilityOf(tpiaequipeconfirm));
		scrollToElementAndClick(tpiaequipeconfirm,driver);
		w.until(ExpectedConditions.visibilityOf(tpianoneditserailnumtext));
		if(tpianoneditserailnumtext.isEnabled()== false) {
			ExtentCucumberAdapter.addTestStepLog("Serial number field is editable");
		}else {
				ExtentCucumberAdapter.addTestStepLog("Serial number field is non editable");
			}
			}
	else {
		ExtentCucumberAdapter.addTestStepLog("Not allowed to enter special characters in mac adress");
	}
}


public void nontpiadevice() throws Exception {
	waitForLoading(driver);
	WebDriverWait w = new WebDriverWait(driver, 10);
	w.until(ExpectedConditions.elementToBeClickable(nontpiadevicemsg));
	if(nontpiadevicemsg.isDisplayed()) {
		String NonTpiadevmsg = nontpiadevicemsg.getText();
	ExtentCucumberAdapter.addTestStepLog("Error Message : " + NonTpiadevmsg );
	Assert.assertEquals(NonTpiadevmsg,"This device is not supported by TPIA.");
	}
}

public void tpiadevicemsg() throws Exception {
	waitForLoading(driver);
	WebDriverWait w = new WebDriverWait(driver, 10);
	w.until(ExpectedConditions.visibilityOf(tpiadeviceactivemsg));
	if(tpiadeviceactivemsg.isDisplayed()) {
	String tpiadevicemsg = tpiadeviceactivemsg.getText();
	ExtentCucumberAdapter.addTestStepLog("Error Message : " + tpiadevicemsg );
	Assert.assertEquals(tpiadevicemsg,"Update cannot be performed as the device is currently active and to prevent any disruption to the account’s service");
	}
	
}

}
