package pageObjects;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.Scenario;
import stepDefinitions.StepData;
import util.TestUtil;

//import groovyjarjarantlr.collections.List;


public class NetcrackerDFShippingPage extends BaseUIPage {

	private WebDriver driver;
	TestUtil utils;
	public BaseUIPage tb=new BaseUIPage();
	public NetcrackerDFShippingPage(WebDriver driver, Scenario scenario) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
		 this.sd=new StepData();			
		sd.setScenario(scenario);		
		this.scenario=sd.getScenario();
	}

	@FindBy(xpath = "//*[@id=\"ui-id-1\"]/img")
	WebElement DFAccountFilter;
	
	@FindBy(xpath="//*[@id=\"t9137754111213767154_0____9137753893213763903\"]/div[2]/a/img")
	WebElement dfAcc;

	@FindBy(xpath = "//*[@id=\"attrIDDiv\"]/div[3]/input")
	WebElement DFAccountInput;

	@FindBy(xpath = "//*[@id=\"fvalues\"]/li/a")
	WebElement DFFilterAccount;

	@FindBy(xpath = "//*[@id=\"t9137754111213767154_0_t\"]/tbody/tr/td[1]/input")
	WebElement DFActiveAccount;

	@FindBy(xpath = "//*[@id=\"t9137754111213767154_0_t\"]/tbody/tr[2]/td[1]/input")
	WebElement DFActiveAccount2;

	@FindBy(xpath = "//*[@id=\"9138730814813201128\"]")
	WebElement DFStartShipping;

	@FindBy(xpath = "//*[@id=\"9137754560513767463\"]")
	WebElement DFCompleteShipping;

	@FindBy(xpath = "//*[@id=\"9137755040513767746\"]")
	WebElement DFImportShippingInfo;

	@FindBy(xpath = "//*[@id=\"propertyFile\"]")
	WebElement chooseFile;

	@FindBy(xpath = "//div[@class=\"ui-dialog-buttonset\"]/button//span[contains(text(),\"Import\")]")
	WebElement DFImportButton;
	
	@FindBy(xpath = "//table[@class='mainControl']")
	WebElement shippingTable;
	
	@FindBy(xpath = "//tbody/tr/td/table[1]/tbody/tr/td[1]/a")
	WebElement saveButton;
	
  
	
	public void DFActiveAccount() throws InterruptedException {
		waitForLoading(driver);	
		isLoaderSpinnerVisible(driver);
		List<WebElement> DF_Active_Hardware = driver.findElements(By.xpath("//input[@class=\"checkbox\"]"));
		for (int num = 0; num < (DF_Active_Hardware).size(); num++) {
			DF_Active_Hardware.get(num).click();
		}
	}

	public void clickDFAccountFilter() throws Exception {
		wait.withMessage("dfAcc is not visible").until(ExpectedConditions.visibilityOf(dfAcc));
		dfAcc.click();
		//Thread.sleep(2000);
		//DFAccountFilter.click();
		
	}

	public void enterAccountNumber(String accountnumber) throws InterruptedException {
		WebDriverWait w = new WebDriverWait(driver, 300);
		w.withMessage("Dfbutton is not visible").until(ExpectedConditions.visibilityOf(DFAccountInput));
		waitForLoading(driver);
		DFAccountInput.sendKeys(accountnumber);
	}

	public void selectDFFilterAccount() {
		wait.withMessage("FilterButton is not visible").until(ExpectedConditions.visibilityOf(DFFilterAccount));
		DFFilterAccount.click();
	}

	public void selectActiveAccount() {
		DFActiveAccount.click();
	}

	public void selectSecondActiveAccount() {
		DFActiveAccount2.click();
	}

	public void StartShipping() throws Exception {
		waitForLoading(driver);	
		scrollToElementAndClick(DFStartShipping, driver);
		isLoaderSpinnerVisible(driver);	//AddedShweta
		waitForLoading(driver);			
//		DFStartShipping.click();
		addScreenshot(driver, this.scenario, "Start Shipping");
	}

	public void selectDFImportShippingInfo() {
		DFImportShippingInfo.click();
	}

	public void selectTextFile(String dftextfilepath) throws InterruptedException {
		Thread.sleep(2000);
		driver.switchTo().frame("content");
		chooseFile.sendKeys(dftextfilepath);
	}

	public void clickImportButton() throws InterruptedException {
		driver.switchTo().defaultContent();
		DFImportButton.click();
		Thread.sleep(5000);
		driver.switchTo().alert().accept();
	}

	public void completeShipping() {
		DFCompleteShipping.click();
	}
	
	public void searchCustomerAccount(String enterAccountNumber) throws Exception {
		clickDFAccountFilter();
		waitForLoading(driver);
		enterAccountNumber(enterAccountNumber);
		waitForLoading(driver);
		selectDFFilterAccount();
		waitForLoading(driver);
	}
	
	public void enterSerialNoHardwareAndTrackingNumber(String serialNumberHitron, String serialNumberXB6,String serialNumberXG1V4,String serialNumberXiD,String serialNumberXi6,String serialNoXG1V3,String serialNumberXB7, String serialNumberXPOD) throws Exception
	{
		Actions action=new Actions(driver); 
				List<WebElement> rows=driver.findElements(By.xpath("//table[@class='mainControl']/tbody/tr"));                                       
	    		int rowCount=rows.size();                                                                                                               
        		System.out.println("rows"+rowCount);                                                                                                    
        		List<WebElement> column=driver.findElements(By.xpath("//table[@class='mainControl']/thead/tr[1]/th"));                               
        		int colCount=column.size();                                                                                                             
        		System.out.println("column"+colCount);                                                                                                  
                                                                                               
        		//Determine the column no                                                                                                               
        		for (int i=3;i<=colCount;i++)                                                                                                           
        		{                                                                                                                                       
        			String colValue=driver.findElement(By.xpath("//table[@class='mainControl']/thead/tr/th["+i+"]/table//td[1]/a")).getText();          
//        			System.out.println("colValue"+colValue);                                                                                               
        			if(colValue.equalsIgnoreCase("Offering"))                                                                                              
        			{                                                                                                                                      
//        				System.out.println("Found Offering");                                                                                                 
        				for(int j=1;j<=rowCount;j++)                                                                                                          
        				{                                                                                                                                     
        					String rowValue=driver.findElement(By.xpath("//table[@class='mainControl']/tbody/tr["+j+"]/td["+i+"]/a/span")).getText();         
        					System.out.println("rowValue"+rowValue);
        					switch(rowValue)                                                                                                                     
        					{                                                                                                                                    
        					case "Rental BlueCurve Gateway WiFi Modem (XB6) - 348":                                                                              
        						System.out.println("Enter xb6 serial number");                                                                            
        						enterSerialNumber(j,serialNumberXB6);                                                                        
        						WebElement hardwareXB6=driver.findElement(By.xpath("//div[@id='nc_refsel_list_table']/div[2]/div[2]"));                          
        						selectHardware(hardwareXB6);                                                                            
        						enterTrackingNumber(j);                                                                       
        						break;  
        						
        					case "Ignite Entertainment Box (Xi6/XiOne) Rental": 
        						System.out.println("Enter xi6 serial number");  
        						enterSerialNumber(j,serialNumberXi6);                                                                                                        
        						WebElement hardware_Xi6=driver.findElement(By.xpath("//div[@id='nc_refsel_list_table']/div[1]/div[2]"));                          
        						selectHardware(hardware_Xi6);                                                                                                                
        						enterTrackingNumber(j);                                                                                                         
        						break;
        						
        					case "BlueCurve TV Player Wireless 4K Rental":                                                                                       
        						System.out.println("Enter xi6 serial number");  
        						enterSerialNumber(j,serialNumberXi6);                                                                                                        
        						WebElement hardwareXi6=driver.findElement(By.xpath("//div[@id='nc_refsel_list_table']/div[1]/div[2]"));                          
        						selectHardware(hardwareXi6);                                                                                                                
        						enterTrackingNumber(j);                                                                                                         
        						break;
        						
        					case "TV Player (XG1v3) Rental":
        						
        					case "XG1v3 BlueCurve TV Player Rental":
        						System.out.println("Enter XG1V3 serial number");  
        						enterSerialNumber(j,serialNoXG1V3); 
        						WebElement hardwareXG1V3=driver.findElement(By.xpath("//div[@id='nc_refsel_list_table']/div[1]/div[2]"));                          
        						selectHardware(hardwareXG1V3);   
        						enterTrackingNumber(j);  
        						break;
        						
        					case "Rental AC DOCSIS 3N Advanced WiFi Modem":
        						System.out.println("Enter Hitron serial number");  
        						enterSerialNumber(j,serialNumberHitron); 
        						WebElement hardwareHitron=driver.findElement(By.xpath("//div[@id='nc_refsel_list_table']/div[2]/div[2]"));                          
        						selectHardware(hardwareHitron);  
        						enterTrackingNumber(j);  
        						break;
        					
        					case "Rental Ignite WiFi Gateway modem (XB6)":                                                                              
        						System.out.println("Enter xb6 serial number");                                                                            
        						enterSerialNumber(j,serialNumberXB6);                                                                        
        						WebElement IgnitehardwareXB6=driver.findElement(By.xpath("//div[@id='nc_refsel_list_table']/div[2]/div[2]"));                          
        						selectHardware(IgnitehardwareXB6);                                                                            
        						enterTrackingNumber(j);                                                                       
        						break;	
        						
        					case "Rental Ignite WiFi Gateway (Gen 2) modem (XB7)":                                                                              
        						System.out.println("Enter xb7 serial number");                                                                            
        						enterSerialNumber(j,serialNumberXB7);                                                                        
        						WebElement hardwareXB7=driver.findElement(By.xpath("//div[@id='nc_refsel_list_table']/div[2]/div[2]"));                          
        						selectHardware(hardwareXB7);                                                                            
        						enterTrackingNumber(j);                                                                       
        						break;
        						
        					case "Rental Ignite WiFi Gateway (Gen 3) modem (XB8)":                                                                              
        						System.out.println("Enter xb8 serial number");                                                                            
        						enterSerialNumber(j,serialNumberXB7);                                                                        
//        						WebElement hardwareXB8=driver.findElement(By.xpath("//div[@id='nc_refsel_list_table']/div[2]/div[2]"));                          
//        						selectHardware(hardwareXB8);                                                                            
        						enterTrackingNumber(j);                                                                       
        						break;	

//        						Added by Ashish [Start]
						case "Rental Ignite WiFi Pods (3Pk) Component":                                                                              
        						System.out.println("Enter XPODs serial number");                                                                            
        						enterSerialNumber(j,serialNumberXPOD);
        						System.out.println("J and serialNumberXPOD: "+ j +" " + serialNumberXPOD);
        						WebElement hardwareXPOD=driver.findElement(By.xpath("//div[@id='nc_refsel_list_table']/div[2]/div[2]"));
        						selectHardware(hardwareXPOD);
        						System.out.println("hardwareXPOD : "+ hardwareXPOD);
        						enterTrackingNumber(j);
        						break;
//        						Added by Ashish [Finish]
        					}                                                                                                                                    
        				}                                                                                                                                     
        				break;                                                                                                                                
        			}         			
        		} 
        		tb.addScreenshot(driver, this.scenario, "Serial Number Entered");
        		
	}
	
	public void enterSerialNoHardwareAndTrackingNumberXPOD(String serialNumberXPOD) throws Exception
	{
		Actions action=new Actions(driver);
				List<WebElement> rows=driver.findElements(By.xpath("//table[@class='mainControl']/tbody/tr"));                                       
	    		int rowCount=rows.size();                                                                                                               
        		System.out.println("rows"+rowCount);                                                                                                    
        		List<WebElement> column=driver.findElements(By.xpath("//table[@class='mainControl']/thead/tr[1]/th"));                               
        		int colCount=column.size();                                                                                                             
        		System.out.println("column"+colCount);                                                                                                  
                                                                                                                                                                                                 
        		for (int i=3;i<=colCount;i++)  
//        		if (i==i+1)
        		{                                                                                                                                       
        			String colValue=driver.findElement(By.xpath("//table[@class='mainControl']/thead/tr/th["+i+"]/table//td[1]/a")).getText();          
//        			System.out.println("colValue"+colValue);                                                                                               
        			if(colValue.equalsIgnoreCase("Offering"))                                                                                              
        			{                                                                                                                                                                                                                                                                           
        					String rowValue=driver.findElement(By.xpath("//table[@class='mainControl']/tbody/tr["+1+"]/td["+i+"]/a/span")).getText();         
        					System.out.println("rowValue"+rowValue);
        					switch(rowValue)                                                                                                                     
        					{  						
        					case "Rental Ignite WiFi Pods (3Pk) Component":                                                                              
        						System.out.println("Enter XPODs serial number");                                                                            
        						enterSerialNumber(i,serialNumberXPOD);
        						System.out.println("I and serialNumberXPOD: "+ i +" " + serialNumberXPOD);
        						WebElement hardwareXPOD=driver.findElement(By.xpath("//div[@id='nc_refsel_list_table']/div[2]/div[2]"));
        						selectHardware(hardwareXPOD);
        						System.out.println("hardwareXPOD : "+ hardwareXPOD);
        						enterTrackingNumber(i);
        						break;
        					}                                                                                                                                    
        				}                                                                                                                                     
//        				break;		
        		} 
        		tb.addScreenshot(driver, this.scenario, "Serial Number Entered");
        		
	}
	
	public void enterSerialNumber(int rowValue,String SerialNo) throws InterruptedException
	{
		Actions action=new Actions(driver); 
		action.moveToElement(driver.findElement(By.xpath("//table[@class='mainControl']/tbody/tr["+rowValue+"]/td[4]"))).perform();             
        driver.findElement(By.xpath("//table[@class='mainControl']/tbody/tr["+rowValue+"]/td[4]/div/div[2]")).click();
//        driver.findElement(By.xpath("//table[@class='mainControl']/tbody/tr["+rowValue+"]/td[4]/div/div[2]")).sendKeys(Keys.CLEAR);
//		driver.findElement(By.xpath("//table[@class='mainControl']/tbody/tr["+rowValue+"]/td[4]/div//form/textarea")).sendKeys(SerialNo);
		driver.findElement(By.xpath("//table[@class='mainControl']/tbody/tr["+rowValue+"]/td[4]/div//form/textarea")).sendKeys(Keys.HOME,Keys.chord(Keys.SHIFT,Keys.END),SerialNo);
//		driver.findElement(By.xpath("//table[@class='mainControl']/tbody/tr["+rowValue+"]/td[4]/div//form/textarea")).sendKeys(SerialNo);
		action.moveToElement(driver.findElement(By.xpath("//table[@class='mainControl']/tbody/tr["+rowValue+"]/td[5]"))).perform();         
		driver.findElement(By.xpath("//table[@class='mainControl']/tbody/tr["+rowValue+"]/td[5]/div/div[2]")).click();                          
		waitForLoading(driver); 
	}
	
	public void enterTrackingNumber(int rowValue) throws InterruptedException
	{
		Actions action=new Actions(driver); 
		action.moveToElement(driver.findElement(By.xpath("//table[@class='mainControl']/tbody/tr["+rowValue+"]/td[12]"))).perform();            
		driver.findElement(By.xpath("//table[@class='mainControl']/tbody/tr["+rowValue+"]/td[12]/div/div[2]")).click();						                   
		driver.findElement(By.xpath("//table[@class='mainControl']/tbody/tr["+rowValue+"]/td[12]/div//form/textarea")).sendKeys("2088866982548734");  
		action.moveToElement(driver.findElement(By.xpath("//table[@class='mainControl']/tbody/tr["+rowValue+"]/td[13]"))).perform();            
		driver.findElement(By.xpath("//table[@class='mainControl']/tbody/tr["+rowValue+"]/td[13]/div/div[2]")).click();                         
		waitForLoading(driver);
	}
	
	public void selectHardware(WebElement hardwareType) throws Exception
	{
		Actions action=new Actions(driver); 
		action.moveToElement(hardwareType).perform();   
		scrollToElementAndClick(hardwareType, driver);
//		hardwareType.click();  
	}
	
	public void clickSave() throws Exception
	{
		scrollToElementAndClick(saveButton, driver);
		waitForLoading(driver);
//		saveButton.click();
	}
	
}