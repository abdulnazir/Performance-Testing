package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import static com.codeborne.selenide.Selenide.*;

import util.TestUtil;

public class SecurityDevicesPage extends BaseUIPage {
	private WebDriver driver;
	TestUtil utils;
	public SecurityDevicesPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	

	@FindBy(xpath = "//label[contains(text(),'Ignite Self Protect')]")
	WebElement IgniteSelfprotectradio;
	
	@FindBy(xpath = "//div[@id='SecurityCategory']//table[@c='UIShawLinkFeature']//a[@class='wrench-button-style']")
	WebElement securitywrench;

	@FindBy(xpath = "//td[@class='serial-number-input']/div/input")
	WebElement enterSerialNumber;
	
	@FindBy(xpath = "//td[@class=' validate-hardware']/a/span/span")
	WebElement clickValidateButton;
	
	@FindBy(xpath = "//*[@id='hardware-popup-ok-button']")
	WebElement OkButton;
	
	@FindBy(xpath = "//tbody/tr[3]/td/div/table/tbody/tr[2]/td[4]/div/table/tbody/tr/td[1]/div")
	WebElement discountDropdown;
	
	@FindBy(xpath = "//tbody/tr[3]/td/div/table/tbody/tr[2]/td[4]/div/table/tbody/tr/td[1]/div/select")
	WebElement doordiscountDropdown;
	
	@FindBy(xpath = "//tbody/tr[3]/td/div/table/tbody/tr[5]/td[4]/div/table/tbody/tr/td[1]/div/select")
	WebElement xcamdiscountDropdown;
	
	@FindBy(xpath = "//table[@class='UIXTable']//tr[2]//td[8][@class='FinancedHardwareSummaryContentRow']//input")
	WebElement xcamprepay;
	
		
	
	
	public void selectSecurityDevice(String securitydevice) throws Exception {
//		waitForLoading(driver);
		isLoaderSpinnerVisible(driver);	
		Thread.sleep(5000);
		scrollToElementAndClick(driver.findElement(By.xpath("//div[@id='SecurityCategory']//label[text() = 'Ignite Self Protect']/preceding-sibling::input")), driver);
	}

	
	public void selectSecurityWrench() throws Exception {
		isLoaderSpinnerVisible(driver);	
	//	waitForLoading(driver);
		Thread.sleep(5000);
		scrollToElementAndClick(securitywrench, driver);
	}
	
	public void selectSecurityHardwarefinance(String securityhardware, String securityhardware2, String discount) throws Exception {
		WebDriverWait w = new WebDriverWait(driver, 90);
		Thread.sleep(5000);
		selectElementFromDropdown(doordiscountDropdown, driver, "VisibleText", "36 Installments $5.00 with 0% Subsidy");
		WebElement rentsecurityhardware=driver.findElement(By.xpath("//div[text()='Hardware' and contains(@class,'Popup')]/following::label[contains(text(),'Ignite Doorbell Camera (Wired)')]/following::span[contains(text(),'+Finance')][1]"));
		waitForLoading(driver);
		w.until(ExpectedConditions.visibilityOf(rentsecurityhardware));
		scrollToElementAndClick(rentsecurityhardware, driver);
		Thread.sleep(5000);
		WebElement rentsecurityhardware2=driver.findElement(By.xpath("//div[text()='Hardware' and contains(@class,'Popup')]/following::label[contains(text(),'Ignite Indoor/Outdoor Camera (Wired)')]/following::span[contains(text(),'+Finance')][1]"));
		waitForLoading(driver);
		Thread.sleep(5000);
		selectElementFromDropdown(xcamdiscountDropdown, driver, "VisibleText", "36 Installments $5.00 with 0% Subsidy");
		w.until(ExpectedConditions.visibilityOf(rentsecurityhardware2));
		scrollToElementAndClick(rentsecurityhardware2, driver);
	}
	
	public void selectSecurityHardwarepurchase(String SecurityHardware, String discount) throws Exception {
		Thread.sleep(5000);
//		WebDriverWait w = new WebDriverWait(driver, 10);
//		w.until(ExpectedConditions.elementToBeClickable(discountDropdown));
	//	selectElementFromDropdown(discountDropdown, driver, "VisibleText", discount);
		WebElement rentsecurityhardware1=driver.findElement(By.xpath("//div[text()='Hardware' and contains(@class,'Popup')]/following::label[contains(text(),'Ignite Indoor/Outdoor Camera (Wired)')]/following::span[contains(text(),'+Buy')][1]"));
		waitForLoading(driver);
		Thread.sleep(5000);
		scrollToElementAndClick(rentsecurityhardware1, driver);
		waitForLoading(driver);
	}
	
	public void enterSerialNumber(String serialnumber) {
		wait.withMessage("Enter Serial Number button is not visible")
				.until(ExpectedConditions.visibilityOf(enterSerialNumber));
		enterSerialNumber.sendKeys(serialnumber);
	}
	
	public void clickValidateButton() throws Exception {
//		wait.withMessage("Validatebutton").until(ExpectedConditions.visibilityOf(clickValidateButton));
		scrollToElementAndClick(clickValidateButton, driver);

	}
	
	public void selectOkButton() throws Exception {
		waitForLoading(driver);
		scrollToElementAndClick(OkButton, driver);
	}
	
	
	
	
}
