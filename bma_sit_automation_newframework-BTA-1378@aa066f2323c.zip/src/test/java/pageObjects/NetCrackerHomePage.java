package pageObjects;

import java.io.IOException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.Scenario;
import pageObjects.TestBase;
import stepDefinitions.StepData;

public class NetCrackerHomePage extends BaseUIPage{
	private WebDriver driver;
	public NetCrackerHomePage(WebDriver driver,Scenario scenario) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
		 this.sd=new StepData();			
		sd.setScenario(scenario);		
		this.scenario=sd.getScenario();
	}

	@FindBy(xpath = "//*[@id=\"user\"]")
	WebElement ncUserName;

	@FindBy(xpath = "//*[@id=\"pass\"]")
	WebElement NCPassword;

	@FindBy(xpath = "//*[@id=\"loginButton\"]/div")
	WebElement NCloginButton;	
	
	@FindBy(xpath = "//li[@role='menuitem']/following::*[contains(text(),'Navigation') and contains(@href,'modules')]")
	WebElement ncNavigation;	

	public void enterNetcrackerUsername(String NetcrackerUsername) {
		WebDriverWait w = new WebDriverWait(driver, 60);
		w.until(ExpectedConditions.visibilityOf(ncUserName));
		ncUserName.sendKeys(NetcrackerUsername);
	}

	public void enterNetcrackerPassword(String NetcrackerPassword) {
		NCPassword.sendKeys(NetcrackerPassword);
	}

	public void clickOnLoginButton() {
		wait.withMessage("NC login button not found").until(ExpectedConditions.visibilityOf(NCloginButton));
		NCloginButton.click();
	}

	public void navigateToModule(String strOption) throws Exception {
		isLoaderSpinnerVisible(driver);	//AddedShweta
		Actions action=new Actions(driver);
		if(!driver.findElement(By.xpath("//li[@role='menuitem']/descendant::*[text()='Data Mapping']")).isDisplayed())
			action.moveToElement(ncNavigation).perform();
		WebElement ncModule= driver.findElement(By.xpath("//li[@role='menuitem']/descendant::*[text()='"+strOption+"']"));
		action.moveToElement(ncNavigation).moveToElement(ncModule).build().perform();
//		ncModule.click();
		scrollToElementAndClick(ncModule, driver);
//		wait.withMessage("Time Out. Still on NC HomePage. Didn't navigate to expected module in time.").until(ExpectedConditions.invisibilityOf(driver.findElement(By.xpath("//a[text()='System Modules']"))));
	}
	
	//td/a[text()='Name']/ancestor::tr[1]/descendant::td[2]/descendant::a
}
