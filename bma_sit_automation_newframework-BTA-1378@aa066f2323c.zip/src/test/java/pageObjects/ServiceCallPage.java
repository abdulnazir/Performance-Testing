package pageObjects;

import java.io.IOException;
import java.util.ArrayList;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import util.TestUtil;

public class ServiceCallPage extends BaseUIPage {
	private WebDriver driver;
	TestUtil utils;
	
	public ServiceCallPage(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
    
    @FindBy(xpath = "//*[@id=\"newServiceCallButtonId\"]")
    WebElement newServiceCall;
    
    @FindBy(xpath = "//*[@id=\"SMSOpt\"]")
    WebElement smsOptOut;
    
    @FindBy(xpath = "//select[@id='ServiceType']")
    WebElement serviceType;
    
    @FindBy(xpath = "//textarea[@id='Notes']")
    WebElement notesTextBox;
    
    @FindBy(xpath = "//*[@id=\"forceAppointmentLink\"]")
    WebElement forceAppointmentLink;
    
    @FindBy(xpath = "//*[@id=\"forceAppointmentButton\"]")
    WebElement forceAppointmentButton;
    
    @FindBy(xpath = "//*[text()='Order Id']/../td[2]")
    WebElement serviceId;
    
    @FindBy(xpath = "//*[@id=\"bookItBtn\"]")
    WebElement bookitButton;
    
    @FindBy(xpath = "//*[contains(@id,'service-tab')]")
    WebElement serviceCall;

    @FindBy(xpath = "//*[@id='ServiceCallFilter']")
    WebElement serviceCallFilter;
    
    public void clickNewServiceCall() {
	wait.withMessage("new service call button not visible").until(ExpectedConditions.visibilityOf(newServiceCall));
         newServiceCall.click();
    }
    
    public void clickSmsOptOut() throws Exception {
	wait.withMessage("sms opt out checkbix  not visible").until(ExpectedConditions.visibilityOf(smsOptOut));
	scrollToElementAndClick(smsOptOut, driver);
//	smsOptOut.click();
   }

    public void selectServiceType(String strserviceType) {
    	wait.withMessage("serviceType selection is  not visible").until(ExpectedConditions.visibilityOf(serviceType));
       	Select srvcTypDropDown = new Select(serviceType);
       	srvcTypDropDown.selectByVisibleText(strserviceType);
      }
    
    public void notes(String notes) {
	notesTextBox.sendKeys(notes);
   }
    
    public void clickForceAppointmnet() throws Exception {
    	scrollToElementAndClick(forceAppointmentLink, driver);
      }
    
    public void clickForceAppointmnetButton() throws Exception {
	    scrollToElementAndClick(forceAppointmentButton, driver);
	    Assert.assertTrue("ServiceCall Page is launched in a new tab", driver.getTitle().contains("Review Appointment"));   
      }
    public String getServiceId() throws InterruptedException, IOException {
		wait.withMessage("serviceId is  not visible").until(ExpectedConditions.visibilityOf(serviceId));
		String serviceIdvalue =serviceId.getText();
		//TestBase.takeScreenshot("ServiceId");
		return serviceIdvalue;
      }
    
    public void bookServiceCall() throws InterruptedException {
	   	wait.withMessage("bookitButton is  not visible").until(ExpectedConditions.visibilityOf(bookitButton));
	   	bookitButton.click();
    }

	public void selectServiceCalltab(String checkURL, String UserName, String Password) throws Exception {
		waitForLoading(driver);
		driver.switchTo().defaultContent();
		scrollToElementAndClick(serviceCall, driver);
		waitForLoading(driver);
		isLoaderSpinnerVisible(driver);	//AddedShweta
		applicationlogin(driver, UserName, Password, checkURL);
		waitForLoading(driver);
		switchtoWindow(checkURL, driver);	
		waitForLoading(driver);
		waitForVisibilityOfElement(serviceCallFilter,driver); 
		WebDriverWait w = new WebDriverWait(driver, 120);
//		w.until(ExpectedConditions.visibilityOf((serviceCallFilter)));
	}
}
