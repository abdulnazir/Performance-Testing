package pageObjects;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import stepDefinitions.Hooks;
import stepDefinitions.StepData;

import org.openqa.selenium.support.ui.Select;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.*;

//import stepdefinitions.Hooks;
//import util.TestBase;
import util.TestUtil;

public class PhoneServices extends BaseUIPage {
	private WebDriver driver;
	TestUtil utils;
	public BaseUIPage tb=new BaseUIPage();//Added by Ashish
	
	public PhoneServices(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
		this.sd=new StepData();			
		sd.setScenario(scenario);		
		this.scenario=sd.getScenario();

	}

	@FindBy(xpath = "//*[@id='telephonyCategory']//tr[2]//a/span/span")
	WebElement Phone_add_hardware;

	@FindBy(xpath = "//*[@id='telephonyCategory']//tr[2]//a/span/span")
	WebElement phoneselectiondropdown;

	@FindBy(xpath = "//*[@class='offerSelector']//select/option[contains(text(),'Personal Phone')]")
	WebElement PersPhone;

	@FindBy(xpath = "//a[contains(text(),'Select number')]")
	WebElement Select_num;

	@FindBy(xpath = "//td[@class='FirstCategory']//a[@class=\"UIHyperlink line-selector\"]")
	WebElement phoneNumber;

	@FindBy(xpath = "//label[contains(text(),'Choose a number')]")
	WebElement Choose_num_radio;

	@FindBy(xpath = "//*[@id='phoneNumberSelectList']//option[4]")
	WebElement Choose_num;

	@FindBy(xpath = "//*[@id=\"assign-tn-btn\"]//span[contains(text(),'Assign')]")
	WebElement Assign_btn;

	@FindBy(xpath = "//*[@id='save-phone-changes-button']//span[contains(text(),'OK')]")
	WebElement OK_btn;

	@FindBy(xpath = "//*[@id=\"blif-parameters-grid_main\"]//td[2]//option[2]")
	WebElement Listing_type;

	@FindBy(xpath = "/html/body/div[19]//span[contains(text(),'No Listing')]")
	WebElement Listing_type_options;

	@FindBy(xpath = "//*[@id=\"features-tab\"]//span[contains(text(),'Features')]")
	WebElement Phn_feature_tab;

	@FindBy(xpath = "//*[@id=\"features-parameters-grid_main\"]/tbody/tr[6]//div//input[1]")
	WebElement Bill_to_third_feature_enable;

	@FindBy(xpath = "//span[contains(text(),'Suppression')]")
	WebElement Suppress;

	@FindBy(xpath = "//input[@id='supp-checkbox_main']")
	WebElement E911;

	@FindBy(xpath = "//option[contains(text(),'Hardware')]")
	WebElement Add_hardware;

	@FindBy(xpath = "/html[1]/body[1]/div[5]/table[1]/tbody[1]/tr[2]/td[1]/div[1]/div[1]/table[1]/tbody[1]/tr[2]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/table[1]/tbody[1]/tr[2]/td[2]/div[1]/div[1]/table[1]/tbody[1]/tr[2]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/table[1]/tbody[1]/tr[2]/td[1]/div[1]/table[1]/tbody[1]/tr[2]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/input[1]")
	WebElement Add_Ph_Features1;

	@FindBy(xpath = "//*[@id=\"telephonyCategory\"]/table/tbody/tr[2]/td[2]/div/div/table/tbody/tr/td/div/table/tbody/tr/td[2]/div/select\r\n"
			+ "")
	WebElement personalphoneselection;

	@FindBy(xpath = "//td[@class='FirstCategory']//table[@c='UIShawLinkFeature']//a[@class=\"wrench-button-style\"]")
	WebElement phoneHardwareWrench;

	@FindBy(xpath = "//td[@class='serial-number-input']/div/input")
	WebElement phoneserialnumtextbox;

	@FindBy(xpath = "//td[@class=' validate-hardware']/a/span/span")
	WebElement phoneserialnumvalidatebutton;

	@FindBy(xpath = "//*[@id=\"hardware-popup-ok-button\"]/span/span")
	WebElement phoneokbutton;

	@FindBy(xpath = "//*[@id=\"9138038348313476728091380554899134871500913805548991348715091479915143132050020_ft_main\"]")
	WebElement FeaturesUnlimitedCANUSCalling;

	@FindBy(xpath = "//*[@id=\"9138038348313476728091380383483134767200913803834831347672091340048839139851800_ft_main\"]")
	WebElement VoicemailAndCallWaiting;

	@FindBy(xpath = "//td[@class=' FourthCategory']//div[text()='Phone Service']/../..//input[@type='checkbox']")
	WebElement XB6PhoneServiceCheckBox;

	@FindBy(xpath = "//td[@class='FirstCategory']//div[text()='Personal Phone 1000 Minutes ILD Calling']/../..//input[@type=\"checkbox\"]")
	WebElement PersonalPhone1000MinutesILDCalling;

	@FindBy(xpath = "//td[@class=\"UISpinner_inc_button\"]/a")
	WebElement distinctiveRing;

	@FindBy(xpath = "//td[@class='FirstCategory']//table[@class=\"UIDistinctiveRings\"]//a[@class=\"wrench-button-style\"]")
	WebElement distinctiveRingWrench;

	@FindBy(xpath = "//span[text()=\"Features\"]")
	WebElement featuresTab;

	@FindBy(xpath = "//div[@class=\"UIXSelect\"]")
	WebElement featureDropDown;

	@FindBy(xpath = "/html/body/div[19]/span[contains(text(),'2 short rings')]")
	WebElement featureOption;

	@FindBy(xpath = "")
	WebElement hitronModem;
	
	@FindBy(xpath="//span[text()='Directory Listing']")
	WebElement DirectoryListing;
	
	@FindBy(xpath = "//label[contains(text(),'Search for specific')]")
	WebElement vanitySearchRadioButton;
	
	@FindBy(xpath = "//*[@id='vanityInput_main']")
	WebElement vanitySearchSearchPhoneTextBox;
	
	@FindBy(xpath = "//*[@id='vanityButton']/span/span")
	WebElement vanitySearchButton;
	

	@FindBy(xpath = "//div/a[contains(text(),'Phone Features')]")
	WebElement phonefeature;
	
	@FindBy(xpath = "//div/div[2]/table/tbody/tr/td/div/table/tbody/tr[5]/td[2]/div/p/input[2]")
	WebElement collectcall;
	
	@FindBy(xpath = "//div/div[2]/table/tbody/tr/td/div/table/tbody/tr[8]/td[2]/div/p/input[2]")
	WebElement operatorreq;
	
	@FindBy(xpath = "//div/div[2]/table/tbody/tr/td/div/table/tbody/tr[9]/td[2]/div/p/input[2]")
	WebElement directorassist;
	
	
	@FindBy(xpath = "//*[@id=\"authorized-by_main\"]")
	WebElement changeauth;
	
	@FindBy(xpath = "//span[contains(text(),'Apply Changes')]")
	WebElement applychanges;	
	
	@FindBy(xpath= "//*[@id=\"ConvergedHardwareCategory_addOfferButton\"]/span/span")	
	WebElement addconvergedhardware;

	public void enterPhoneSerialNumber(String serialnumber) {

		wait.withMessage("Phone serial number text box is not visible")
				.until(ExpectedConditions.visibilityOf(phoneserialnumtextbox));
		phoneserialnumtextbox.sendKeys(serialnumber);
	}

	public void selectXB6PhoneService_oLD() throws InterruptedException {
		waitForLoading(driver);
		//WebElement XB6checkbox = driver.findElement(By.xpath("//td[@class='FourthCategory']//div[text()='Phone Service']/../..//input[@type='checkbox']"));
		waitForLoading(driver);
		waitForLoading(driver);
		if (XB6PhoneServiceCheckBox.isSelected()==false)
		{
			XB6PhoneServiceCheckBox.click();
		}
	}

	public void clickValidateButton() {
		wait.withMessage("Phone Serial Number validate button is not visible")
				.until(ExpectedConditions.visibilityOf(phoneserialnumvalidatebutton));
		phoneserialnumvalidatebutton.click();
	}

	public void clickPhoneOkButton() throws InterruptedException {
		Thread.sleep(2000);
		phoneokbutton.click();
	}

	public void Add_Phone_oLD(String phonePackage) throws InterruptedException, IOException {
		Thread.sleep(2000);
		wait.withMessage("Phone add hardware option is not visible")
				.until(ExpectedConditions.elementToBeClickable(Phone_add_hardware));
		//waitForLoading(driver);
		Thread.sleep(3000);
		Phone_add_hardware.click();
		//wait.withMessage("Personal phone option is not visible").until(ExpectedConditions.visibilityOf(PersPhone));
		//PersPhone.click();
		Thread.sleep(3000);
		//Select select = new Select(driver.findElement(By.xpath("//*[@class='UISelectList']")));
		Select select = new Select(driver.findElement(By.xpath("//*[@id='telephonyCategory']//select[@class='UISelectList white-background']")));
		select.selectByVisibleText(phonePackage);
		Thread.sleep(5000);
	}

	public void AddSecondPhone() throws InterruptedException {
		wait.withMessage("Phone add hardware option is not visible")
				.until(ExpectedConditions.elementToBeClickable(Phone_add_hardware));
		Thread.sleep(3000);
		Phone_add_hardware.click();
		wait.withMessage("Personal phone option is not visible").until(ExpectedConditions.visibilityOf(PersPhone));
		$(By.xpath("//div[@id='telephonyCategory']//div[2]//select/option[contains(text(),'Personal Phone')]")).click();
		waitForLoading(driver);

	}

	public void selectPhoneNumber() throws Exception {
		waitForLoading(driver);
		Thread.sleep(9900);
		Select_num.click();
		//Thread.sleep(3000);
		waitForLoading(driver);
                Thread.sleep(5000);
		Choose_num_radio.click();
		//takeScreenshot("AssignPhone");
		Thread.sleep(4000);
		waitForLoading(driver);
		Assign_btn.click();
		Thread.sleep(2000);
		waitForLoading(driver);
		if(prop.getProperty("matrix").equalsIgnoreCase("499")){
		Select select = new Select(driver.findElement(By.xpath("//select[contains(@id, 'blif')]")));
		select.selectByVisibleText("No Listing");
		}
		else {

		waitForVisibilityOfElement(DirectoryListing,driver);
//		$(By.xpath("//span[text()='Directory Listing']")).waitUntil(visible, 9999);
	Thread.sleep(5000);
		waitForLoading(driver);
		DirectoryListing.click();
		//$(By.xpath("//span[text()='Directory Listing']")).click();
		//Thread.sleep(5000);
		waitForLoading(driver);
		Listing_type.click();
		waitForLoading(driver);
		waitForLoading(driver);
		Thread.sleep(5000);
		//Listing_type_options.click();
		}
		//takeScreenshot("ListingTypeOptions");
		if (driver.findElements(By.xpath("//span[contains(text(),'Suppression')]")).size() > 0) {
//			Thread.sleep(2000);
//			Thread.sleep(3000);
			waitForLoading(driver);
			Suppress.click();
			waitForLoading(driver);
//			Thread.sleep(2000);
			if (!prop.getProperty("NG911", "No").equalsIgnoreCase("Yes")) {
				E911.click();
			}
			//takeScreenshot("E911Click");
//			Thread.sleep(2000);
			//addInfoInReport("E911 supression option is presented");
		} else {
			//addInfoInReport("E911 Supression option is not presented");
		}
		waitForLoading(driver);
//		Thread.sleep(2000);
		OK_btn.click();
		//takeScreenshot("PhoneServiceAdded");
		Thread.sleep(5000);
		String phoneNum = phoneNumber.getText();
		//Hooks.setFileWriter("Phone Number : " + phoneNum);
	}

	public void E911Supression() throws Exception {
//		Thread.sleep(2000);
		scrollToElementAndClick(phoneNumber, driver);	
//		phoneNumber.click();
//		Thread.sleep(2000);

		if (driver.findElements(By.xpath("//span[contains(text(),'Suppression')]")).size() > 0) {
			scrollToElementAndClick(Suppress, driver);	
			waitForLoading(driver);
//			Suppress.click();
//			Thread.sleep(5000);
			if (!prop.getProperty("NG911", "No").equalsIgnoreCase("Yes")) {
//				E911.click();
				if (!E911.isSelected()) {scrollToElementAndClick(E911, driver);}
//				Thread.sleep(5000);
				//takeScreenshot("E911Click");
			}
		}
		scrollToElementAndClick(OK_btn, driver);
//		OK_btn.click();
//		Thread.sleep(5000);
	}

	public void Add_Hardware() throws InterruptedException {
		Thread.sleep(5000);
		Phone_add_hardware.click();
		Thread.sleep(5000);
		Add_hardware.click();
		Thread.sleep(5000);
	}

	public void Add_Features() throws InterruptedException {
		Phn_feature_tab.click();
		Thread.sleep(5000);
		Bill_to_third_feature_enable.click();
		Thread.sleep(5000);
		OK_btn.click();
		Thread.sleep(5000);
	}

	public void addPersonalPhone() throws InterruptedException {
		PersPhone.click();
	}

	public void clickWrench() {
		phoneHardwareWrench.click();
	}

	public void VoicemailAndUnlimitedFeatureAndILDCalling() throws Exception {
		scrollToElementAndClick(FeaturesUnlimitedCANUSCalling, driver); //Added by Ashish
		waitForLoading(driver); // Added by Ashish
		scrollToElementAndClick(VoicemailAndCallWaiting, driver); //Added by Ashish
		waitForLoading(driver); // Added by Ashish
		scrollToElementAndClick(PersonalPhone1000MinutesILDCalling, driver); //Added by Ashish
		waitForLoading(driver); // Added by Ashish
	}

	public void addDistinctiveRing() throws InterruptedException {
		Thread.sleep(1000);
		distinctiveRing.click();
	}

	public void addDistinctiveRingFeature() throws InterruptedException {
		distinctiveRingWrench.click();
		//wait.withMessage("Personal phone option is not visible").until(ExpectedConditions.visibilityOf(featuresTab));
		waitForLoading(driver);
		featuresTab.click();
		Thread.sleep(30000);
		//wait.withMessage("Personal phone option is not visible")
				//.until(ExpectedConditions.elementToBeClickable(featureDropDown));
		//featureDropDown.click();
		//Thread.sleep(2000);
		//wait.withMessage("Personal phone option is not visible")
				//.until(ExpectedConditions.elementToBeClickable(featureOption));
		//featureOption.click();
		//Thread.sleep(2000);
		//wait.withMessage("Personal phone option is not visible").until(ExpectedConditions.elementToBeClickable(OK_btn));
		OK_btn.click();
		Thread.sleep(2000);
	}

	public void phoneListingDetails() throws InterruptedException, IOException {
		Listing_type.click();
		Thread.sleep(5000);
		Listing_type_options.click();
		// takeScreenshot("ListingTypeOptions");
		// if(prop.getProperty("NG911").equalsIgnoreCase("Yes")) {
		if (driver.findElements(By.xpath("//span[contains(text(),'Suppression')]")).size() > 0) {
			Thread.sleep(2000);
			Suppress.click();
			Thread.sleep(2000);
			if (!prop.getProperty("NG911", "No").equalsIgnoreCase("Yes")) {
				E911.click();
			}
			// takeScreenshot("E911Click");
			Thread.sleep(2000);
			//addInfoInReport("E911 supression option is presented");
		} else {
			//addInfoInReport("E911 Supression option is not presented");
		}
		Thread.sleep(2000);
		OK_btn.click();
		// takeScreenshot("PhoneServiceAdded");
		Thread.sleep(5000);
		String phoneNum = phoneNumber.getText();
		//Hooks.setFileWriter("Phone Number : " + phoneNum);
	}

	public void changePhoneNumber() throws InterruptedException, IOException {
		$(By.xpath("//a[@class='UIHyperlink line-selector']")).click();
		//waitForLoading(driver);
		Thread.sleep(3000);
		$(By.xpath("//*[@id=\"change-number-button\"]/span/span")).click();
		//waitForLoading(driver);
		Thread.sleep(3000);
		Choose_num_radio.click();
		//waitForLoading(driver);
		Thread.sleep(3000);
		Assign_btn.click();
		//waitForLoading(driver);
		Thread.sleep(3000);

		this.phoneListingDetails();
	}
	public void addPhoneProduct(String phoneProduct) throws InterruptedException, IOException {
		Thread.sleep(5000);
		Phone_add_hardware.click();
		Thread.sleep(5000);
		Select select = new Select(driver.findElement(By.xpath("//*[@class=\"UISelectList\"]")));
		select.selectByVisibleText(phoneProduct);
		}
	public void Add_Phone(String phonePackage) throws InterruptedException, IOException,Exception {
		Thread.sleep(2000);
		wait.withMessage("Phone add hardware option is not visible")
				.until(ExpectedConditions.elementToBeClickable(Phone_add_hardware));
		//waitForLoading(driver);
		Thread.sleep(5000);
		scrollToElementAndClick(Phone_add_hardware,driver);
		//wait.withMessage("Personal phone option is not visible").until(ExpectedConditions.visibilityOf(PersPhone));
		//PersPhone.click();
		Thread.sleep(3000);
		//Select select = new Select(driver.findElement(By.xpath("//*[@class='UISelectList']")));
		Select select = new Select(driver.findElement(By.xpath("//*[@id='telephonyCategory']//select[@class='UISelectList white-background']")));
		select.selectByVisibleText(phonePackage);
		Thread.sleep(5000);
	}


public void selectPhoneNumberByVanitySearch() throws Exception {
		waitForLoading(driver);
		Select_num.click();
		waitForLoading(driver);
                Thread.sleep(5000);
                vanitySearchRadioButton.click();
                waitForLoading(driver);
                
                //Code to fetch the TN from the excel
                
//        		File file =    new File("C:\\Users\\shota\\Shaw\\VanitySearch.xlsx");
                File file =    new File(System.getProperty("user.dir")+"\\src\\test\\resources\\VanitySearch.xlsx");
        		FileInputStream inputStream = new FileInputStream(file);
        		XSSFWorkbook wb=new XSSFWorkbook(inputStream);
        		XSSFSheet sheet=wb.getSheet("TNs");
        		
        		int rowCount=sheet.getLastRowNum()-sheet.getFirstRowNum();
        		for(int i=0;i<=rowCount;i++){
                    
                    //get cell count in a row
//                    int cellcount=sheet.getRow(i).getLastCellNum();
                    
                    //iterate over each cell to print its value
//                    System.out.println("Row"+ i+" data is :");
                    
//                    for(int j=0;j<cellcount;j++){
                    	 System.out.print("Cell Type is " + sheet.getRow(i).getCell(0).getCellType());
//                        System.out.print("Cell Value is" + sheet.getRow(i).getCell(j).getNumericCellValue() +",");
                        System.out.print("Cell Value is " + sheet.getRow(i).getCell(0).getStringCellValue() +",");
                        String Tn= sheet.getRow(i).getCell(0).getStringCellValue();
                        //To enter the last 7 digits of the number
                        String tnSubstring=Tn.substring(3,10);
                        vanitySearchSearchPhoneTextBox.clear();
                        Thread.sleep(5000);
                        vanitySearchSearchPhoneTextBox.sendKeys(tnSubstring);
                        vanitySearchButton.click();
                        waitForLoading(driver);
                        waitForLoading(driver);
		                if(driver.findElements(By.xpath("//*[@id='vanityList_main']/option[contains(text(),'no matches found')]")).size()>0)
		                {
		                	System.out.println("Phone no not displayed");
		                }
	                else 
	                {
		            		waitForLoading(driver);
//		            		Assign_btn.click();
		            		scrollToElementAndClick(Assign_btn, driver); //Added by Ashish
		            		Thread.sleep(2000);
		            		waitForLoading(driver);
		            		break;
		                }
//                        if(!(driver.findElement(By.xpath("//*[@id='assign-tn-btn']")).getAttribute("class").contains("disabled")))
//                        {
//                        	tb.addScreenshot(driver, this.scenario,"TN found");
//		            		waitForLoading(driver);
//		            		waitForLoading(driver);
//		            		Assign_btn.click();
//		            		Thread.sleep(2000);
//		            		waitForLoading(driver);
//		            		break;
//                        }
//                        else
//                        	tb.addScreenshot(driver, this.scenario,"Phone no not displayed");
                
                }
                    System.out.println();
                
        		


                
//		Choose_num_radio.click();

		if(prop.getProperty("matrix").equalsIgnoreCase("499")){
		Select select = new Select(driver.findElement(By.xpath("//select[contains(@id, 'blif')]")));
		select.selectByVisibleText("No Listing");
		}
		else {
		waitForVisibilityOfElement(DirectoryListing,driver);
//		$(By.xpath("//span[text()='Directory Listing']")).waitUntil(visible, 9999);
		waitForLoading(driver);
		Thread.sleep(5000);
		DirectoryListing.click();
		waitForLoading(driver);
//		$(By.xpath("//span[text()='Directory Listing']")).click();
		waitForLoading(driver);
		Listing_type.click();
		waitForLoading(driver);
		waitForLoading(driver);
		Thread.sleep(5000);
		//Thread.sleep(5000);
		//Listing_type_options.click();
		}
//		takeScreenshot(driver,"ListingTypeOptions");
		if (driver.findElements(By.xpath("//span[contains(text(),'Suppression')]")).size() > 0) {
			Thread.sleep(2000);
			waitForLoading(driver);
			Suppress.click();
			Thread.sleep(2000);
			if (!prop.getProperty("NG911", "No").equalsIgnoreCase("Yes")) {
				E911.click();
			}
//			takeScreenshot(driver,"E911Click");
			Thread.sleep(2000);
//			addInfoInReport("E911 supression option is presented");
		} else {
//			addInfoInReport("E911 Supression option is not presented");
		}
		Thread.sleep(2000);
		OK_btn.click();
//		takeScreenshot(driver,"PhoneServiceAdded");
		Thread.sleep(5000);
		String phoneNum = phoneNumber.getText();
		Hooks.setFileWriter("Phone Number : " + phoneNum);
	}
public void selectXB6PhoneService() throws InterruptedException {
	waitForLoading(driver);
	//WebElement XB6checkbox = driver.findElement(By.xpath("//td[@class='FourthCategory']//div[text()='Phone Service']/../..//input[@type='checkbox']"));
	waitForLoading(driver);
	waitForLoading(driver);
	if (XB6PhoneServiceCheckBox.isSelected()==false)
	{
		XB6PhoneServiceCheckBox.click();
	}
}
	public void selectPhoneNumberByVanitySearch_oLD() throws Exception {
		waitForLoading(driver);
		Select_num.click();
		waitForLoading(driver);
                Thread.sleep(5000);
                vanitySearchRadioButton.click();
                waitForLoading(driver);
                
                //Code to fetch the TN from the excel
                
        		File file =    new File("C:\\Users\\shota\\Shaw\\VanitySearch.xlsx");
        		FileInputStream inputStream = new FileInputStream(file);
        		XSSFWorkbook wb=new XSSFWorkbook(inputStream);
        		XSSFSheet sheet=wb.getSheet("TNs");
        		
        		int rowCount=sheet.getLastRowNum()-sheet.getFirstRowNum();
        		for(int i=0;i<=rowCount;i++){
                    
                    //get cell count in a row
//                    int cellcount=sheet.getRow(i).getLastCellNum();
                    
                    //iterate over each cell to print its value
//                    System.out.println("Row"+ i+" data is :");
                    
//                    for(int j=0;j<cellcount;j++){
                    	 System.out.print("Cell Type is " + sheet.getRow(i).getCell(0).getCellType());
//                        System.out.print("Cell Value is" + sheet.getRow(i).getCell(j).getNumericCellValue() +",");
                        System.out.print("Cell Value is " + sheet.getRow(i).getCell(0).getStringCellValue() +",");
                        String Tn= sheet.getRow(i).getCell(0).getStringCellValue();
                        //To enter the last 7 digits of the number
                        String tnSubstring=Tn.substring(3,10);
                        vanitySearchSearchPhoneTextBox.clear();
                        vanitySearchSearchPhoneTextBox.sendKeys(tnSubstring);
                        vanitySearchButton.click();
                        waitForLoading(driver);
                        waitForLoading(driver);
		                if(driver.findElements(By.xpath("//*[@id='vanityList_main']/option[contains(text(),'no matches found')]")).size()>0)
		                {
		                	System.out.println("Phone no not displayed");
//		                	takeScreenshot(driver,"Phone no not displayed");
		                }
		                else 
		                {
//		                	takeScreenshot(driver,"AssignPhone");
		            		waitForLoading(driver);
		            		Assign_btn.click();
		            		Thread.sleep(2000);
		            		waitForLoading(driver);
		            		break;
		                }
                        
                       
//                    }
                    System.out.println();
                }
        		
//        		 System.out.println("TN Value is "+ Tn);

        		


                
//		Choose_num_radio.click();

		if(prop.getProperty("matrix").equalsIgnoreCase("499")){
		Select select = new Select(driver.findElement(By.xpath("//select[contains(@id, 'blif')]")));
		select.selectByVisibleText("No Listing");
		}
		else {
		waitForVisibilityOfElement(DirectoryListing,driver);
//		$(By.xpath("//span[text()='Directory Listing']")).waitUntil(visible, 9999);
		waitForLoading(driver);
		Thread.sleep(5000);
		DirectoryListing.click();
		waitForLoading(driver);
//		$(By.xpath("//span[text()='Directory Listing']")).click();
		waitForLoading(driver);
		Listing_type.click();
		waitForLoading(driver);
		waitForLoading(driver);
		Thread.sleep(5000);
		//Thread.sleep(5000);
		//Listing_type_options.click();
		}
//		takeScreenshot(driver,"ListingTypeOptions");
		if (driver.findElements(By.xpath("//span[contains(text(),'Suppression')]")).size() > 0) {
			Thread.sleep(2000);
			waitForLoading(driver);
			Suppress.click();
			Thread.sleep(2000);
			if (!prop.getProperty("NG911", "No").equalsIgnoreCase("Yes")) {
				E911.click();
			}
//			takeScreenshot(driver,"E911Click");
			Thread.sleep(2000);
//			addInfoInReport("E911 supression option is presented");
		} else {
//			addInfoInReport("E911 Supression option is not presented");
		}
		Thread.sleep(2000);
		OK_btn.click();
//		takeScreenshot(driver,"PhoneServiceAdded");
		Thread.sleep(5000);
		String phoneNum = phoneNumber.getText();
		Hooks.setFileWriter("Phone Number : " + phoneNum);
	}
	
	public void changephonefeature() throws InterruptedException {
		Thread.sleep(2000);
		phonefeature.click();
		Thread.sleep(2000);
		collectcall.click();
		Thread.sleep(2000);
		operatorreq.click();
		Thread.sleep(2000);
		directorassist.click();
		Thread.sleep(2000);
		changeauth.sendKeys("Test");
		Thread.sleep(2000);
		applychanges.click();
		
		
	}
	}

