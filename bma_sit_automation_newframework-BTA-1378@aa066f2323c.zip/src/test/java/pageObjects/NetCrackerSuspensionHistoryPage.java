package pageObjects;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


//import util.TestBase;

public class NetCrackerSuspensionHistoryPage extends BaseUIPage {

	private WebDriver driver;
	
	public NetCrackerSuspensionHistoryPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//*[@id=\"id_tab_0\"]/a")
	WebElement suspensionhistory;

	@FindBy(xpath = "//*[@id=\"t9137911292713429241_0_t\"]/tbody/tr[1]/td[7]")
	WebElement firstlobsuspensionstatus;

	@FindBy(xpath = "//*[@id=\"t9137911292713429241_0_t\"]/tbody/tr[2]/td[7]")
	WebElement secondlobsuspensionstatus;

	@FindBy(xpath = "//*[@id=\"t9137911292713429241_0_t\"]/tbody/tr[3]/td[7]")
	WebElement thirdlobsuspensionstatus;
	
	@FindBy(xpath="//a[text()='Suspend']")
	WebElement suspend;
	
	@FindBy(xpath="//label[text()='Internet']")
	WebElement suspenInternetRadio;
	
	@FindBy(xpath="//label[text()='TV']")
	WebElement suspenTvRadio;
        
	@FindBy(xpath="//label[text()='Digital Phone']")
	WebElement suspenPhoneRadio;

	@FindBy(xpath="//*[@id=\"workAuthorizedByInput\"]/input")
	WebElement workAuthBy;
	
	@FindBy(xpath="//a[text()='Return to suspension history']")
	WebElement retTransactionHistory;
	
	@FindBy(xpath="//span[text()='Submit request']")
	WebElement subRequest;
	
//	@FindBy(xpath="//a[text()='Resume']")
//	WebElement resume;
	
	@FindBy(xpath="//table[@class='ControlPanel']//a[text()='Resume']")
	WebElement resume;
	
	@FindBy(xpath="//*[@id=\"resumeWorkAuthorizedByInput_main\"]")
	WebElement resWorkAuthBy;
	
	@FindBy(xpath="/html/body/div[4]/div[1]/div[1]/div[1]/div/a[4]")
	WebElement idLink;
	
	@FindBy(xpath="//a[text()='Return to suspension history record']")
	WebElement returnToSuspHistRecord;

	public void suspensionHistory() throws Exception {
//	    Thread.sleep(2000);
		scrollToElementAndClick(suspensionhistory, driver); //4/3/2024
//		suspensionhistory.click();
	}

	public void validateFirstLobSuspendStatus() {
		String firstlobstatus = firstlobsuspensionstatus.getText();
		Assert.assertEquals(firstlobstatus, "Active");
	}

	public void valiateSecondLobSuspendStatus() {
		String secondlobstatus = secondlobsuspensionstatus.getText();
		Assert.assertEquals(secondlobstatus, "Active");
	}

	public void validateThirdLobSuspendStatus() {
		String thirdlobstatus = thirdlobsuspensionstatus.getText();
		Assert.assertEquals(thirdlobstatus, "Active");
	}

	public void validateSuspensionStatus() {
//		SoftAssert softAssert = new SoftAssert();
		//List<WebElement> services = driver.findElements(By.xpath("//td[@class='Default itemCheckboxAlign']"));
		List<WebElement> services = driver.findElements(By.xpath("//a[text()='Suspension History Record']/ancestor::tr"));
		
		String status;
		for (WebElement suspension_table_row : services) {
			if (suspension_table_row.findElements(By.xpath("//a[text()='Suspension History Record']")).size() > 0 )
			//	services.findElements(By.xpath("//a[text()='Suspension History Record']/ancestor::tr//a[text() = 'Suspension History Record']")).size() > 0 )
			{ continue;
			}
			
			String service =driver.findElement(By.xpath("//a[text()='Suspension History Record']/ancestor::tr//a[contains(text(),'Internet') or contains(text(), 'TV')]")).getText();
			 status = driver.findElement(By.xpath("//*[@id=\"t9137911292713429241_0_t\"]/tbody/tr/td[7]"))
					.getText();
			 Assert.assertEquals(status, "Active", "Suspension Status of " + service + status);
				//softAssert.assertEquals(status, "Active");
		}
		
//		softAssert.assertAll();
	}
	
	public void validateResumeStatus() {
//		SoftAssert softAssert = new SoftAssert();
		//List<WebElement> services = driver.findElements(By.xpath("//td[@class='Default itemCheckboxAlign']"));
		List<WebElement> services = driver.findElements(By.xpath("//a[text()='Suspension History Record']/ancestor::tr"));
		
		String status;
		for (WebElement suspension_table_row : services) {
			if (suspension_table_row.findElements(By.xpath("//a[text()='Suspension History Record']")).size() > 0 )
			//	services.findElements(By.xpath("//a[text()='Suspension History Record']/ancestor::tr//a[text() = 'Suspension History Record']")).size() > 0 )
			{ continue;
			}
			
			String service =driver.findElement(By.xpath("//a[text()='Suspension History Record']/ancestor::tr//a[contains(text(),'Internet') or contains(text(), 'TV')]")).getText();
			 status = driver.findElement(By.xpath("//*[@id=\"t9137911292713429241_0_t\"]/tbody/tr/td[7]"))
					.getText();
			 Assert.assertEquals(status, "Inactive", "Resume Status of " + service + status);
		}
		
//		softAssert.assertAll();
	}

	public void validateFirstLobResumeStatus() {
		String firstlobstatus = firstlobsuspensionstatus.getText();
		Assert.assertEquals(firstlobstatus, "Inactive");
	}

	public void validateSecondLobResumeStatus() {
		String secondlobstatus = secondlobsuspensionstatus.getText();
		Assert.assertEquals(secondlobstatus, "Inactive");
	}

	public void validateThirdLobResumeStatus() {
		// String thirdlobstatus = thirdlobsuspensionstatus.getText();
		// Assert.assertEquals(thirdlobstatus, "Inactive");
	}
	
	public void clickSuspend() throws InterruptedException {
	        Thread.sleep(2000);
		suspend.click();
	}
	
	public void suspendIntRadio() throws InterruptedException {
	        Thread.sleep(2000);
	        suspenInternetRadio.click();
	}
	
	public void suspendTvRadio() throws InterruptedException {
	        Thread.sleep(2000);
	        suspenTvRadio.click();
	}
	
	public void suspendPhoneRadio() throws InterruptedException {
	        Thread.sleep(2000);
	        suspenPhoneRadio.click();
	}
	
	public void submitSuspensionRequest() throws InterruptedException {
	        Thread.sleep(2000);
	        subRequest.click();
	}
	
	public void workAuthBy() throws InterruptedException {
	        Thread.sleep(2000);
	        workAuthBy.sendKeys("Tester");
	}
	
	public void returnToSuspHistory() throws InterruptedException {
	    Thread.sleep(2000);
	    retTransactionHistory.click();
	}
	
	public void aupSuspendService(String serviceType) throws InterruptedException {
	    clickSuspend();
	    if(serviceType.equalsIgnoreCase("internet"))
		suspendIntRadio();
	    else if(serviceType.equalsIgnoreCase("tv"))
		suspendTvRadio();
	    else
		suspendPhoneRadio();
	    workAuthBy(); 
	    submitSuspensionRequest();
	    Thread.sleep(7000);
	    returnToSuspHistory();
	    Thread.sleep(7000);	    
	}
	
	public void clickResume() throws InterruptedException {
	    Thread.sleep(2000);
	    resume.click();
	}
	
	public void setResumeWorkAuthBy() throws InterruptedException {
	    Thread.sleep(2000);
	    resWorkAuthBy.sendKeys("Tester");
	}
	
	public void clickIdLink() throws InterruptedException {
	    Thread.sleep(2000);
	    idLink.click();
	}
	
	public void clickSuspHistRecord() throws InterruptedException {
	    Thread.sleep(2000);
	    returnToSuspHistRecord.click();
	}
	
	public void aupResume(String serviceType) throws Exception {
	    switch (serviceType.toUpperCase()) {
		case "INTERNET":
		    serviceType = "Internet";
			break;
		case "TV":
		    serviceType = "TV";
			break;
		case "PHONE":
		    serviceType = "Phone";
			break;
		}
	    Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[text()='Suspension History Record']/ancestor::tr//a[contains(text(),'"+serviceType+"')]/parent::td/parent::tr/td/a/span")).click();
		 waitForLoading(driver);
		 clickResume();
		setResumeWorkAuthBy();
		submitSuspensionRequest();
		clickSuspHistRecord();
		clickIdLink();
		suspensionHistory();
	}
			
		
}


