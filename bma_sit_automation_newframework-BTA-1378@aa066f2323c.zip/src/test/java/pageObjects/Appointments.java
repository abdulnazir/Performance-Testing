package pageObjects;

import java.io.IOException;
import java.util.Calendar;
import java.util.List;

import org.apache.commons.lang.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;

import io.cucumber.java.Scenario;
import stepDefinitions.StepData;
import util.TestUtil;



public class Appointments extends BaseUIPage {
	private WebDriver driver;
	TestUtil utils;
	public BaseUIPage tb=new BaseUIPage();
	
	public Appointments(WebDriver driver, Scenario scenario) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
		 this.sd=new StepData();			
		sd.setScenario(scenario);		
		this.scenario=sd.getScenario();
	}
	@FindBy(xpath = "//*[@id='appointmetTab']/div/a")
	WebElement appointmenttablink;

	@FindBy(xpath = "//*[@id=\"method-of-confirmation_main\"]")
	WebElement methodofconfirmation;

	@FindBy(xpath = "//*[@id=\"method-of-confirmation-additional_main\"]")
	WebElement acceptanceid;

	@FindBy(xpath = "//*[@id='is-self-connect__item_1']")
	WebElement selfconnectno;

	@FindBy(xpath = "//*[@id='is-self-connect__item_0']")
	WebElement SelfconnectYes;

	@FindBy(xpath = "//*[@id='tech-required-options-list__item_0'] ")
	WebElement techreqyes;

	@FindBy(xpath = "//*[@id=\"tech-required-options-list__item_1\"]")
	WebElement techreqno;

	@FindBy(xpath = "//*[@id=\"customer-opted-out-checkbox_main\"]")
	WebElement customeroptedsmsservice;

	@FindBy(xpath = "//*[@id='manual-appointment-checkbox_main']")
	WebElement forceappointment;

	@FindBy(xpath = "//*[@id='input_workAuthorizedBy_main']")
	WebElement authorizedby;

	@FindBy(xpath = "//*[@id=\"active-directory-id-text-input_main\"]")
	WebElement activedirID;

	@FindBy(xpath = "//*[@id=\"active-directory-id-validate-button\"]/span/span")
	WebElement activedirvalidatebtn;

	@FindBy(xpath = "//*[@id=\"self-connect-options__item_1\"]")
	WebElement directFulfillmentMailOut;

	@FindBy(xpath = "//*[@id='self-connect-options__item_0']")
	WebElement RetailPickup;

	@FindBy(xpath = "//*[@id=\"retailLocationInput\"]")
	WebElement retailPickupDropDown;

//	@FindBy(xpath = "//*[@class=\"UIXSelect-select\"]/option[2]")
//	WebElement retailPickupAddress;

	@FindBy(xpath = "//*[@class=\"calendar\"]")
	WebElement calendar;

	@FindBy(xpath = "//a[@class='UIShawDateTime_img']")
	WebElement Future_date;

	@FindBy(xpath = "//td[@id='zpCal1DateCell1-4-5']")
	WebElement Date_choose;

	@FindBy(xpath = "//*[@id='special-instr-body_main']/tbody//tr[2]//div//td[2]//select")
	WebElement MethOfConf;

	@FindBy(xpath = "//*[@id='special-instr-body_main']/tbody//tr[2]//div//td[2]//select/option[2]")
	WebElement MethOfConf_Voice;

	@FindBy(xpath = "//*[@id=\"special-instr-body_main\"]/tbody//tr[2]//div/textarea")
	WebElement Acceptance_Id;

	@FindBy(xpath = "//*[@id=\"checkbox_unknown_main\"]/label")
	WebElement disconnectionreason;

	@FindBy(xpath = "//*[@id=\"disconnection-date_dateSelector\"]/a | //*[@id='order-action-date_dateSelector']/a")
	WebElement disconnectdatecalendar;

	@FindBy(xpath = "//td[contains(@class, 'today')] | //td[contains(@class, ' day false selected')]")
	WebElement disconnectiondate;

	@FindBy(xpath = "//*[@id=\"manual-appointment-date_dateSelector\"]/a")
	WebElement calendarWidgetWithTech;

	@FindBy(xpath = "//*[@id=\"order-action-date_dateSelector\"]/a")
	WebElement calendarWidgetNoTech;

	@FindBy(xpath = "//*[@id=\"zpCal1NextMonthButtonStatus\"]")
	WebElement nextMonth;

	@FindBy(xpath = "//div[@class='calendar']/table/tbody/tr[2]/td[7][contains(@id,'DateCell1-1-5')]")
	WebElement futureDate;

	@FindBy(xpath = "//*[@id=\"agreement-details-tab\"]/div/a")
	WebElement agreementDetails;

	@FindBy(xpath = "//*[@id=\"shipping-service-address__item_0\"]")
	WebElement serviceLocationAddress;

//	@FindBy(xpath = "//*[@id=\"old-service-location\"]")
//	WebElement dfAddresstext;
	
	@FindBy(xpath = "//*[@id='old-service-locationDetail']")
	WebElement dfAddresstext;

//	@FindBy(xpath = "//input[@hint=\"Enter new shipping address\"]") 'Commented on 4/10
	@FindBy(xpath = "//*[contains(@for,'shipping-special-address')]/following::input[contains(@hint,'Enter new shipping')]")
	WebElement dfAddressInputField;

	@FindBy(xpath = "//*[@id=\"premise-disconnect-date_dateSelector\"]/a")
	WebElement premiseMoveDisconnectionCalendar;

	@FindBy(xpath = "//*[@id=\"disconnect-date-options-list__item_1\"]")
	WebElement continueBillingNo;

	@FindBy(xpath = "//*[@id=\"order-action-date_dateSelector\"]/a")
	WebElement activationCalendar;

	@FindBy(xpath = "//label[text()='Existing H/W (Including Premise Move)']")
	WebElement exisitingHardware;

	@FindBy(xpath = "//*[@id=\"zpCal0PrevMonthButtonStatus\"]")
	WebElement previousMonth;

	@FindBy(xpath = "//label[text()=\"Shaw Delivery\"]")
	WebElement shawDelivery;
	
    @FindBy(xpath="//*[@id=\"contact-Number-opted-out-checkbox_main\"]")
    WebElement customeroptout;
    
    @FindBy(xpath="//td[contains(text(),'Today')]")
    WebElement todaydate;
    
    @FindBy(xpath="//*[contains(text(),'Reason Category')]/ancestor::tr[1]/descendant::select")
    WebElement disconnectReasonCategory;
    
    String disconnectionReasonXpath = "//input[@id='disconnect-reasons__item_0']";
	
    @FindBy(xpath="//input[@id='special-shipping-city-name_main']")
    WebElement city;
    
    @FindBy(xpath="//input[@id='special-shipping-postal-code-input_main']")
    WebElement postalCode;
    
    @FindBy(xpath="//*[@id='shipping-addr-mismatch-checkbox']/label")
    WebElement shippingAlertMsg;
    
    @FindBy(xpath="//*[@id='shipping-addr-mismatch-checkbox_main']")
    WebElement shippingAlertMsgCheckBox;
    
	public void selectPremiseMove() throws InterruptedException {
		//waitForLoading();
		Thread.sleep(7000);
		SelfconnectYes.click();
		Thread.sleep(2000);
		directFulfillmentMailOut.click();
		Thread.sleep(2000);
		continueBillingNo.click();
		Thread.sleep(3000);
	}

	public void enterActivationDate(String dayOfMonth) throws InterruptedException {
		activationCalendar.click();
		Thread.sleep(2000);
		String dateSelection = dayOfMonth.split(":")[1];
		String monthSelection = dayOfMonth.split(":")[0].toUpperCase();
		WebElement nextMonthLink = driver.findElement(By.xpath("//*[@id=\"zpCal0NextMonthButtonStatus\"]"));

		if (monthSelection.equals("MONTHPLUSONE")) {
			nextMonthLink.click();
			Thread.sleep(1000);
		} else if (monthSelection.equals("MONTHPLUSTWO")) {
			nextMonthLink.click();
			Thread.sleep(1000);
			nextMonthLink.click();
		} else if (monthSelection.equals("MONTHMINUSONE")) {
			previousMonth.click();
			Thread.sleep(1000);
		}
		driver.findElement(By.xpath("//td[text() = " + dateSelection + " and contains(@id, 'Date')]")).click();
		Thread.sleep(2000);

	}

	public void enterPremiseMoveDisconnectionDate() throws InterruptedException {
		premiseMoveDisconnectionCalendar.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//td[@class=\" day false selected today\"]")).click();
	}

	public void enterDFAddress() throws Exception {
		waitForLoading(driver);
		isLoaderSpinnerVisible(driver);	//AddedShweta
		String dfAddress = dfAddresstext.getText();

		if (dfAddress.equalsIgnoreCase("88 Signature Heights SW, Calgary, AB, T3H 3B9")
				|| prop.getProperty("matrix").equalsIgnoreCase("499")) {
			dfAddress = "88 Signature hts";
		} else if (dfAddress.equals("MAIN-802 Heritage Boulevard, North vancouver, BC, V7J 3K7")) {
			dfAddress = "802 Heritage Blvd";
		}

//		for (char c : dfAddress.toCharArray()) {
//			Thread.sleep(500);
//			dfAddressInputField.click();
//			dfAddressInputField.sendKeys(String.valueOf(c));
//		}
		enterValueInField(dfAddressInputField, dfAddress, driver);
		Thread.sleep(1000);
		dfAddressInputField.click();
		dfAddressInputField.sendKeys(Keys.HOME+" ");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//div[@class=\"pcaitem pcafirstitem pcalastitem pcaselected\"]")).click();
	}
	
	public void changeDFAddress() throws InterruptedException
	{
		String dfAddress = "94 Signature Hts SW, Calgary, AB, T3H 3B9" ;
	
		for (char c : dfAddress.toCharArray()) {
			Thread.sleep(500);
		dfAddressInputField.sendKeys(String.valueOf(c));
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@class='pcaitem pcafirstitem pcalastitem pcaselected']")).click();
	}

	public void clickAppointmentlink() throws Exception {
		//waitForLoading(driver);
		scrollToElementAndClick(appointmenttablink, driver);
		waitForLoading(driver);
		goToFrame(driver, "ncOrderEntry");
	}

	public void selectDisconnectionDateToday() throws InterruptedException {
		Thread.sleep(2000);
		todaydate.click();
		driver.findElement(By.xpath("//td[@class=' day false selected today']")).click();	
	}
	public void selectSelfConnectNo() throws Exception {
		waitForVisibilityOfElement(selfconnectno,driver);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		waitForLoading(driver);
		while(!selfconnectno.isDisplayed())
		{
			js.executeScript("window.scrollTo(0, -document.body.scrollHeight);");
		}
		js.executeScript("window.scrollTo(0, -document.body.scrollHeight);");
		js.executeScript("window.scrollTo(0, -document.body.scrollHeight);");
		js.executeScript("window.scrollTo(0, -document.body.scrollHeight);");
		scrollToElementAndClick(selfconnectno, driver);
		Thread.sleep(2000);
		dismissFFMIntegrationMessage();
	}

	public void dismissFFMIntegrationMessage() throws InterruptedException,Exception {
		if (driver.findElements(By.xpath("//a[@id='desktop-error-popup_closeButton']")).size() > 0) {
			//addInfoInReport("FFM Integration Error. Dismissing dialog");
			Thread.sleep(5000);
			driver.findElement(By.xpath("//a[@id='desktop-error-popup_closeButton']")).click();
		}

	}

	public void selectSelfconnect() throws Exception {
		waitForLoading(driver);
		scrollToElementAndClick(SelfconnectYes, driver);
	}

	public void selectRetailPickup() throws Exception {
		wait.withMessage("Retail pickup button not visible")
				.until(ExpectedConditions.not(ExpectedConditions.stalenessOf(RetailPickup)));
		waitForLoading(driver);
		scrollToElementAndClick(RetailPickup, driver);
	}

	public void selectRetailPickupAddress(String address) throws Exception {
//		scrollToElement(retailPickupDropDown, driver);
		waitForLoading(driver);
		isLoaderSpinnerVisible(driver);	//AddedShweta
		wait.withMessage("Retail pickup button not visible")
		.until(ExpectedConditions.not(ExpectedConditions.stalenessOf(retailPickupDropDown)));
		retailPickupDropDown.click();
		WebElement retailPickupAddress=driver.findElement(By.xpath("//*[@id='retailLocationInput']/following::*[contains(@class,'UIXSelect-options')]/*[contains(text(),'"+address+"')]"));
		scrollToElement(retailPickupAddress, driver);
		retailPickupAddress.click();
//		selectElementFromDropdown(retailPickupAddress, driver, "VisibleText", address);
//		selectElementFromDropdown(RefundLocationChannel, driver, "VisibleText", refundLocationChannel);
	}

	public void selectDirectFulfillmentMailOut() throws Exception {
		waitForLoading(driver);
		scrollToElementAndClick(directFulfillmentMailOut, driver);
		// serviceLocationAddress.click();
	}

	public void TechReqNo() throws Exception {
		isLoaderSpinnerVisible(driver);	//AddedShweta
		scrollToElementAndClick(techreqno, driver);
	}

	public void Techreq() throws Exception {
		waitForLoading(driver);
		List TechReq=driver.findElements(By.xpath("//*[@id='tech-required-options-list__item_0' and class='UIRadioList_checked']"));
		if(TechReq.size()<0)
		{
			isLoaderSpinnerVisible(driver);	//AddedShweta
			scrollToElementAndClick(techreqyes, driver);
		}
	}

	public void setAuthorisedby() throws Exception {
//		Thread.sleep(2000);
		waitForLoading(driver);
		isLoaderSpinnerVisible(driver);	//AddedShweta
		scrollToElementAndClick(authorizedby, driver);
		authorizedby.sendKeys("Tester");
	}

	public void setActivedirectory() {
		if (prop.getProperty("environment", "non-timeshifter").equalsIgnoreCase("timeshifter")) {
//			addInfoInReport("Setting active directory user as lruser002 in case of sysadm login for timeshifter");
			if (prop.getProperty("matrix").equalsIgnoreCase("499")) {
				driver.findElement(By.xpath("//a[@id='active-directory-id-X-button']")).click();
			}
			
			driver.findElement(By.xpath("//*[@id='active-directory-id-text-input_main']")).isEnabled();
			activedirID.clear();
			activedirID.sendKeys("lruser002");
			activedirvalidatebtn.click();
		}
	}

	public void MethodOfConfirmation() throws InterruptedException {
		MethOfConf.click();
		Thread.sleep(5000);
		MethOfConf_Voice.click();
		Thread.sleep(3000);
		Acceptance_Id.click();
		Thread.sleep(3000);
		Acceptance_Id.sendKeys("0199");
		Thread.sleep(3000);
	}

	

	public void selectTechNotRequired() throws Exception {
//		WebElement TechRequired =driver.findElement(By.id("tech-required-options-list__item_1"));	CommentedShweta
		waitForLoading(driver);
		WebDriverWait w = new WebDriverWait(driver, 120);
		w.until(ExpectedConditions.invisibilityOfAllElements(driver.findElements(By.xpath("//*[contains(text(),'Loading')]"))));
		dismissFFMIntegrationMessage();
		driver.findElement(By.id("tech-required-options-list__item_1")).click();
		waitForLoading(driver);
		isLoaderSpinnerVisible(driver);	//AddedShweta
		scrollToElementAndClick(driver.findElement(By.id("input_workAuthorizedBy_main")), driver);
	}

	public void selectSMSNumberOptedOut() throws Exception {
		WebElement smsOptedOutCheckbox = driver.findElement(By.xpath("//*[@id=\"customer-opted-out-checkbox_main\"]"));
		if (!smsOptedOutCheckbox.isSelected()) {
//			Thread.sleep(2000);
			scrollToElementAndClick(customeroptedsmsservice, driver);
//			customeroptedsmsservice.click();
		}
	}

	public void methodOfConfirmationSelection(String lmethodOfConfirmation) throws Exception {
			agreementDetails.click();
			wait.withMessage("methodofconfirmation button not found")
					.until(ExpectedConditions.visibilityOf(methodofconfirmation));
			Select select = new Select(driver.findElement(By.id("method-of-confirmation_main")));
			select.selectByVisibleText(lmethodOfConfirmation);
	}

	public void setAcceptanceId(String AcceptanceId) throws Exception {
		if(acceptanceid.isEnabled())
		enterValueInField(acceptanceid, AcceptanceId, driver);
	}

	public void setDisconnectionReason() throws InterruptedException {
		driver.findElement(By.xpath(disconnectionReasonXpath)).click();
	}
	public void selectDisconnectionReason(String reasonCategory, String reason) throws Exception {
		selectElementFromDropdown(disconnectReasonCategory, driver, "VisibleText", reasonCategory);
		scrollToElementAndClick(driver.findElement(By.xpath("//*[contains(@id,'disconnect-reasons')]/descendant::*[contains(text(),'"+reason+"')]")), driver);
	}
	public void selectDisconnectCalendar() throws Exception {
		scrollToElementAndClick(disconnectdatecalendar, driver);
	}

	public void selectDisconnectionDate() throws Exception {
		scrollToElement(driver.findElement(By.xpath("//*[@class='calendar']//td[contains(text(),'Today')]")), driver);
		driver.findElement(By.xpath("//*[@class='calendar']//td[contains(text(),'Today')]")).click();
		scrollToElement(disconnectiondate, driver);
		disconnectiondate.click();
	}

	public void selectforceappointment() throws Exception {
		scrollToElementAndClick(forceappointment, driver);
//		forceappointment.click();
	}

	public void selectFutureDateWithoutTech(String dayOfMonth) throws Exception {
		isLoaderSpinnerVisible(driver);	//AddedShweta
		scrollToElementAndClick(calendarWidgetNoTech, driver);
		Thread.sleep(2000);
		String dateSelection = dayOfMonth.split(":")[1];
		String monthSelection = dayOfMonth.split(":")[0].toUpperCase();
		WebElement nextMonthLink = driver.findElement(By.xpath("//*[@id=\"zpCal0NextMonthButtonStatus\"]"));

		if (monthSelection.equals("MONTHPLUSONE")) {
			nextMonthLink.click();
			Thread.sleep(1000);
		} else if (monthSelection.equals("MONTHPLUSTWO")) {
			nextMonthLink.click();
			Thread.sleep(1000);
			nextMonthLink.click();
		} else if (monthSelection.equals("MONTHMINUSONE")) {
			previousMonth.click();
			Thread.sleep(1000);
		}

		driver.findElement(By.xpath("//td[text() = " + dateSelection + " and contains(@id, 'Date')]")).click();

	}

	public void selectFutureDateWithTech(String dayOfMonth) throws Exception {
		isLoaderSpinnerVisible(driver);	//AddedShweta
		scrollToElementAndClick(calendarWidgetWithTech, driver);
		calendarWidgetWithTech.click();
		Thread.sleep(2000);

		String dateSelection = dayOfMonth.split(":")[1];
		String monthSelection = dayOfMonth.split(":")[0].toUpperCase();
		WebElement nextMonthLink = driver.findElement(By.xpath("//*[@id=\"zpCal1NextMonthButtonStatus\"]"));

		if (monthSelection.equals("MONTHPLUSONE")) {
			nextMonthLink.click();
			Thread.sleep(1000);
		} else if (monthSelection.equals("MONTHPLUSTWO")) {
			nextMonthLink.click();
			Thread.sleep(1000);
			nextMonthLink.click();
		} else if (monthSelection.equals("MONTHMINUSONE")) {
			previousMonth.click();
			Thread.sleep(1000);
		}

		driver.findElement(By.xpath("//td[text() = " + dateSelection + " and contains(@id, 'Date')]")).click();

	}

	public void selectAppointmentFutureDate() throws InterruptedException {
		Thread.sleep(2000);
		futureDate.click();
	}

	public void selectExisitingHardware() throws Exception {
		
		waitForLoading(driver);	
		isLoaderSpinnerVisible(driver);	//AddedShweta
		if (driver.findElements(By.xpath("//label[text()='Existing H/W (Including Premise Move)']")).size() > 0) {
			scrollToElementAndClick(exisitingHardware, driver);}
//			exisitingHardware.click();}
	}

	public void selectFutureDisconnectedDate(String dayOfMonth) throws InterruptedException {
		Thread.sleep(3000);
		disconnectdatecalendar.click();
		Thread.sleep(2000);

		String dateSelection = dayOfMonth.split(":")[1];
		String monthSelection = dayOfMonth.split(":")[0].toUpperCase();
		WebElement nextMonthLink = driver.findElement(By.xpath("//*[@id=\"zpCal0NextMonthButtonStatus\"]"));

		if (monthSelection.equals("MONTHPLUSONE")) {
			nextMonthLink.click();
			Thread.sleep(1000);
		} else if (monthSelection.equals("MONTHPLUSTWO")) {
			nextMonthLink.click();
			Thread.sleep(1000);
			nextMonthLink.click();
		} else if (monthSelection.equals("MONTHMINUSONE")) {
			previousMonth.click();
			Thread.sleep(1000);
		}

		driver.findElement(By.xpath("//td[text() = " + dateSelection + " and contains(@id, 'Date')]")).click();

	}
	public void selectShawDelivery() throws InterruptedException,Exception
	{
		isLoaderSpinnerVisible(driver);
		scrollToElementAndClick(shawDelivery,driver);
		Thread.sleep(10000);
	}
public void selectServiceLocationCheckbox() throws Exception
{
//	if(driver.findElements(By.xpath("//*[@id=\\\"shipping-service-address__item_0\\\"]")).size()!=0)
	waitForLoading(driver);	
	scrollToElementAndClick(serviceLocationAddress, driver);
}
public void selectcustomerOptOutCheckbox() throws Exception
{
	scrollToElementAndClick(customeroptout, driver);
}
//Vivek Added for DF Shipping Task @BTA-990
public void setActiveDir() throws InterruptedException, IOException {
	activedirID.clear();
	activedirID.sendKeys("lruser003");
	activedirvalidatebtn.click();
}

public void navigateToAppointmentpage() throws Exception{
//	driver.switchTo().frame("ncOrderEntry");
	scrollToElementAndClick(appointmenttablink,driver);
}

public void changeToDifferentDFAddress(String dfAddress) throws Exception
{
//	String dfAddress = "5600 7 westhill Dr waterloo, Ontario,N2TOC4";
//	String dfAddress = "3344 26 Ave NW, Edmonton, AB, T6T 1R1";	

//	for (char c : dfAddress.toCharArray()) {
//		Thread.sleep(500);
//	dfAddressInputField.sendKeys(String.valueOf(c));
//	}
	enterValueInField(dfAddressInputField, dfAddress, driver);
	Thread.sleep(1000);
//	dfAddressInputField.click();
	dfAddressInputField.sendKeys(Keys.END);
	dfAddressInputField.sendKeys(Keys.SPACE);
//	dfAddressInputField.sendKeys(" ");
//	Thread.sleep(1000);
	WebDriverWait w = new WebDriverWait(driver,30);
	w.withMessage("Checking visiblity of element").until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"pcaitem pcafirstitem pcalastitem pcaselected\"]")));
	driver.findElement(By.xpath("//div[@class=\"pcaitem pcafirstitem pcalastitem pcaselected\"]")).click();
	driver.findElement(By.xpath("//*[contains(text(),'Contact Number')]/following::input[1]")).click();
//	Thread.sleep(2000);
	tb.addScreenshot(driver, this.scenario, "Shiping Address change");
//	int valuePresent=driver.findElements(By.xpath("//div[@class='pcaitem pcafirstitem pcalastitem pcaselected']")).size();
//	if (valuePresent>0)
//	{
//		driver.findElement(By.xpath("//div[@class='pcaitem pcafirstitem pcalastitem pcaselected']")).click();
//
//	}
//	else
//	{
//		enterValueInField(city, "Edmonton", driver);
////		city.click();
////		city.sendKeys("Waterloo"); ///Change below in R24.3
////		city.sendKeys("Edmonton");		
//		for(int i=6;i>=1;i--)
//		{
//			char postalCodeValue=dfAddress.charAt(dfAddress.length() - i);
//			postalCode.sendKeys(String.valueOf(postalCodeValue));
//		}
//	}
	try{
//		WebDriverWait w = new WebDriverWait(driver, 120);
//		w.until(ExpectedConditions.elementToBeClickable(shippingAlertMsgCheckBox));
		scrollToElementAndClick(shippingAlertMsgCheckBox, driver);
//		shippingAlertMsgCheckBox.click();
		tb.addScreenshot(driver, this.scenario, "Error Address change");
		ExtentCucumberAdapter.addTestStepLog("Message shown : " + shippingAlertMsg.getText());
	}
	catch(Exception exc)
	{
		exc.printStackTrace();
		throw new Exception(exc + "Error while clicking");
	
	}
	//driver.findElement(By.xpath("//b[contains(text(),'187')]")).click();
	
}
}
