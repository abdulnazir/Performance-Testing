package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;

import util.TestUtil;

public class ReviewPage extends BaseUIPage {
	private WebDriver driver;
	TestUtil utils;
	public ReviewPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	@FindBy(xpath = "//*[@id=\"review-tab\"]/div/a")
	WebElement reviewtab;

	@FindBy(xpath = "//*[@id=\"sendSummaryRadio__item_1\"]")
	WebElement emailordersummaryno;

	@FindBy(xpath = "//*[@id=\"sendSummaryRadio__item_0\"]")
	WebElement emailOrderSummaryYes;

	@FindBy(xpath = "//div[@id='one-time-installation-fee-key']/label")
	WebElement installationfee;
	

	@FindBy(xpath = "//div[@id='one-time-installation-fee-value']")
	WebElement installationfeevalue;
	
	

	
	
	public void clickReviewTab() throws Exception {
		isLoaderSpinnerVisible(driver);	//AddedShweta
		waitForLoading(driver);	
		scrollToElementAndClick(reviewtab, driver);
//		reviewtab.click();  //CommentedbyShweta on 14/9/2023
	}


	
	public void setEmailOrderSummary() throws InterruptedException {
		String emailOrderSummary = " did not appear";
		
		System.out.println(emailOrderSummary);
		waitForLoading(driver);	
		isLoaderSpinnerVisible(driver);	//AddedShweta
		JavascriptExecutor js = (JavascriptExecutor) driver;
		while(	emailordersummaryno.isDisplayed()==false)
		{
			js.executeScript("window.scrollTo(0, -document.body.scrollHeight);");
		}
		js.executeScript("window.scrollTo(0, -document.body.scrollHeight);");
		js.executeScript("window.scrollTo(0, -document.body.scrollHeight);");
		
		for (char c : "123".toCharArray()) {
			if (driver.findElements(By.xpath("//*[@id='sendSummaryRadio__item_1']")).size() > 0) {
				driver.findElement(By.xpath("//*[@id='sendSummaryRadio__item_1']")).click();
				emailOrderSummary = " appeared";
//				waitForLoading();
				Thread.sleep(3000);
				break;
			}
			Thread.sleep(2000);
		}
		
		
//		addInfoInReport("Email order Summary selection option" + emailOrderSummary);
}

	public void setEmailOrderSummaryYes() throws InterruptedException {
//		waitForLoading();
		emailOrderSummaryYes.click();
		System.out.println("Clicking Email Yes");
	}
	
	public String getinstallationfee() throws Exception {
		
		scrollToElement(installationfee,driver);
		String installatnfee = installationfee.getText();
		scrollToElement(installationfeevalue,driver);
		String installatnfeeval = installationfeevalue.getText();
		String instfee = installatnfee + installatnfeeval;
		return (instfee);
		

		
	}
}
