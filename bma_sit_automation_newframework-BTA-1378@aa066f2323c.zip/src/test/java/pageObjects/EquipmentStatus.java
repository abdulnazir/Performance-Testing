package pageObjects;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.*;
import org.testng.Assert;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;

import io.cucumber.java.Scenario;
import stepDefinitions.StepData;
import util.TestUtil;

public class EquipmentStatus extends BaseUIPage {

	private WebDriver driver;
	public BaseUIPage tb=new BaseUIPage();

public EquipmentStatus(WebDriver driver,Scenario scenario) {
	this.driver=driver;
	PageFactory.initElements(driver, this);
	 this.sd=new StepData();			
	sd.setScenario(scenario);		
	this.scenario=sd.getScenario();
	}
	
@FindBy(xpath = "//a[@id='dropdownMenuTv'] | //*[@id='televisonstatus']/div/a/div[contains(@class,'d-flex')]/i")
WebElement equipmentStatus;

@FindBy(xpath = "//*[@id='televisonstatus']/div[1]/div/table/tr[11]/td[2]/span")
WebElement changeStatusLink;

@FindBy(xpath = "//*[@id='internetstatus']/div[1]/div/table/tr[10]/td[2]/span")
WebElement internetchangeStatusLink;

@FindBy(xpath = "//*[@id='changTvStatusModalLabel']/parent::div/parent::div/div[2]//div//p[contains(text(),'Lost')]/parent::div/input")
WebElement LostRadioButton;

@FindBy(xpath = "//*[@id='changTvStatusModalLabel']/parent::div/parent::div/div[2]//div//p[contains(text(),'Stolen')]/parent::div/input")
WebElement stolenRadioButton;

@FindBy(xpath = "//*[@id='changTvStatusModalLabel']/parent::div/parent::div/div[2]//div//p[contains(text(),'Found')]/parent::div/input")
WebElement FoundRadioButton;

@FindBy(xpath = "//*[@id='changInternetStatusModalLabel']/parent::div/parent::div/div[2]//div//p[contains(text(),'Lost')]/parent::div/input")
WebElement internetLostRadioButton;

@FindBy(xpath = "//*[@id='changInternetStatusModalLabel']/parent::div/parent::div/div[2]//div//p[contains(text(),'Stolen')]/parent::div/input")
WebElement internetstolenRadioButton;

@FindBy(xpath = "//*[@id='changInternetStatusModalLabel']/parent::div/parent::div/div[2]//div//p[contains(text(),'Found')]/parent::div/input")
WebElement internetFoundRadioButton;

@FindBy(xpath = "//div[@class='modal-content']//div[@class='mt-1 mb-2']/textarea")
WebElement TextArea;

@FindBy(xpath = "(//div[@class='modal-content']//*[contains(text(),'Change Equipment Status')]/following::button[contains(text(),'Submit')])[1]")
WebElement SubmitButton;

@FindBy(xpath = "//*[@id='changInternetStatusModalLabel']/parent::div/parent::div//div[2]//div[@class='mt-1 mb-2']/textarea")
WebElement internetTextArea;

@FindBy(xpath = "//*[@id='changInternetStatusModalLabel']/parent::div/parent::div//div[2]/div[2]/div/button[contains(text(),'Submit')]")
WebElement internetSubmitButton;

@FindBy(xpath ="//*[@id='televisonstatus']/div[1]/div/table/tr[10]/td[2]")
WebElement Status;

@FindBy(xpath ="//*[@id='internetstatus']/div[1]/div/table/tr[9]/td[2]")
WebElement internetStatus;

@FindBy(xpath = "//a[@id='dropdownMenuInternet'] | //*[@class='dropdown']/a")
WebElement equipmentInternetdropdown;

@FindBy(xpath = "//*[@id='televisonstatus']/div[1]/div//p/a/span[contains(text(),'Return Equipment')]")
WebElement returnTvEquipmentLink;

@FindBy(xpath = "//*[@id='retailLocations']")
WebElement retailLocationDropdown;

@FindBy(xpath = "//*[@class='modal fade modalchangees show']//div[@class='modal-content']//div[@class='bttn']/button[contains(text(),'Return Equipment')]")
WebElement returnEquipmentButton;

@FindBy(xpath = "//*[@class='modal fade show']//div[@class='modal-content mdlcontent1']//div[@class='bttn dvbtngroup']/button[contains(text(),'Return Equipment')]")
WebElement returnConvergedEquipmentButton;	

@FindBy(xpath = "//a[@id='dropdownMenuConverged'] | //*[@id='suspstatus']/div/a/div[@class='d-flex flex-nowrap ms-auto']/i")
WebElement convergedDropdown;

@FindBy(xpath = "//ul[@class='dropdown-menu drpinternet show']/li[2]/div/div/div[2]/p/a/span | //*[@id='suspstatus']/div/ul/li[2]//*[@id='internetstatus']/div[@class='card dvcardinternet']//span[contains(text(),'Return Equipment')]")
WebElement returnConvergedEquipmentLink;

@FindBy(xpath = "//*[@id='returnConvergedModal']/div/div/div[2]/div[1]/b | //b[contains(text(),'Return Equipment Successsful')]")
WebElement convergedreturnEqipmentStatus;	

@FindBy(xpath = "//*[@id='returnConvergedModal']//button[contains(text(),'Close')] | //*[@class='dvhwrstatus']//button[contains(text(),'Close')]")
WebElement convergedCloseButton;

@FindBy(xpath = "//*[@id='televisonstatus']//div/div/div[2]/div[1]/b")
WebElement TVreturnEqipmentStatus;	

@FindBy(xpath = "//*[@id='televisonstatus']//button[contains(text(),'Close')]")
WebElement TVCloseButton;	

//@FindBy(xpath="//div[@class='full-row user-info bg-white']/img[4]")
@FindBy(xpath="//div[@class='full-row user-info bg-white']/descendant::*[contains(@class,'Refresh')]")
WebElement webudRefreshIcon;

@FindBy(xpath="//*[@id='televisonstatus']/div[@class='card']//div[contains(text(),'Birth Certificate')]")
WebElement birthCertificate;

@FindBy(xpath="//*[@id='televisonstatus']/div[@class='card']//div[contains(text(),'Birth Certificate')]/span[contains(@class,'Provision_White')]")
WebElement birthCertificateProvision;	

@FindBy(xpath="//*[@id='televisonstatus']/div[@class='card']/div//a[contains(text(),'View Equipment Details')]")
WebElement viewEquipmentDetailsLink;

@FindBy(xpath="//*[contains(text(),'Retrieve equipment by:')]/following::select[1]")
WebElement serialNumberDropdown;

@FindBy(xpath="//*[@class='mar mar1 ml-35 ng-valid ng-touched ng-dirty']")
WebElement searchValue;	

@FindBy(xpath="//*[contains(text(),'Retrieve equipment by:')]/parent::div/parent::div/parent::div//button[contains(text(),'Search')]")
WebElement searchButton;	

@FindBy(xpath="//b[contains(text(),'Provisioned')]/parent::div/p")
WebElement provisionDate;

@FindBy(xpath="//*[@id='suspstatus']/div/ul/li[2]/div/div/p[contains(text(),'Birth Certificate')]/img[2]")
WebElement birthCertificateConvergedProvision;	

@FindBy(xpath="//*[@id='suspstatus']/div/ul/li[2]/div/div/pc | //*[@id='suspstatus']/div/ul/li[2]/div/app-converged-equipmentdetails/div[1]//div[contains(text(),'Birth Certificate')]")
WebElement birthCertificateConverged;


@FindBy(xpath="//*[@id='suspstatus']/div/ul/li[2]/div/app-converged-equipmentdetails/div[1]//a[contains(text(),'View Equipment Details')]")
WebElement viewEquipmentDetailsConvergedLink;

@FindBy(xpath="//div[@class='Notify card card-body col-5']/b/button[contains(@class,'close')]")
WebElement closeEquipmentTab;

@FindBy(xpath="//button[contains(text(),'Provision')]/parent::div[@class='col-4']/button")
WebElement ProvisionButton;

@FindBy(xpath="//*[@id='suspstatus']/div/ul/li[2]/div/app-converged-equipmentdetails/div/div[@class='card-body dvcardbodyintr']/table//td[contains(text(),'Status:')]/parent::tr/td[2]")
WebElement convergedStatus;

@FindBy(xpath = "//*[@id='internetstatus']/div[1]/div/table/tr[11]/td[2]/span")
WebElement convergedChangeStatusLink;

	public void tvEquipmentDetails() throws Exception {
//		waitForLoading(driver);
			Thread.sleep(1000);
			//Minimizing the NC window to view the equipment
			waitForLoading(driver);
			driver.switchTo().defaultContent();
			downArrowClick(driver);
			scrollToElementAndClick(equipmentStatus, driver);
//		equipmentStatus.click();
		String statusShown=Status.getText();
		tb.addScreenshot(driver, this.scenario, "Equipment Status");
		ExtentCucumberAdapter.addTestStepLog("Current Status : " + statusShown);
//		System.out.println(statusShown);
//		TestBase.takeScreenshot(" Current Status Shown");
		}
	
	public void lostTvEquipment() throws Exception {
		waitForLoading(driver);
		scrollToElementAndClick(changeStatusLink, driver);
		waitForLoading(driver);
		scrollToElementAndClick(LostRadioButton, driver);
		LostRadioButton.click();
		TextArea.clear();
		TextArea.sendKeys("Lost Equipment");
		tb.addScreenshot(driver, this.scenario, "Status updated to Lost");
		scrollToElementAndClick(SubmitButton, driver);
//		SubmitButton.click();		
	}
	
	public void stolenTvEquipment() throws Exception {
		waitForLoading(driver);
		scrollToElementAndClick(changeStatusLink, driver);
		waitForLoading(driver);
		scrollToElementAndClick(stolenRadioButton, driver);
		stolenRadioButton.click();
		TextArea.clear();
		TextArea.sendKeys("Stolen Equipment");
		tb.addScreenshot(driver, this.scenario, "Status updated to Stolen");
		scrollToElementAndClick(SubmitButton, driver);
//		SubmitButton.click();
		
	}
	
	public void foundTvEquipment() throws Exception {
		waitForLoading(driver);
		scrollToElementAndClick(changeStatusLink, driver);
		waitForLoading(driver);
		scrollToElementAndClick(FoundRadioButton, driver);
		TextArea.clear();
		TextArea.sendKeys("Found Equipment");
		tb.addScreenshot(driver, this.scenario, "Status updated to Found");
		scrollToElementAndClick(SubmitButton, driver);
//		SubmitButton.click();
		scrollToElementAndClick(equipmentStatus, driver);
	}
	
	public void internetEquipmentDetails() throws Exception {
		waitForLoading(driver);
		scrollToElementAndClick(equipmentInternetdropdown, driver);
		tb.addScreenshot(driver, this.scenario, "Equipment dropdown");
	String statusShown=internetStatus.getText();
	System.out.println(statusShown);
	}
	public void convergedEquipmentDetails() throws Exception {
		waitForLoading(driver);
		scrollToElementAndClick(webudRefreshIcon, driver);
		scrollToElementAndClick(convergedDropdown, driver);
		tb.addScreenshot(driver, this.scenario, "Equipment dropdown");
		String statusShown=convergedStatus.getText();
	System.out.println(statusShown);
//	TestBase.takeScreenshot(" Current Status Shown");
	}
	
	public void lostInternetEquipment() throws Exception {
		waitForLoading(driver);
		scrollToElementAndClick(internetchangeStatusLink, driver);
		waitForLoading(driver);
		scrollToElementAndClick(internetLostRadioButton, driver);
		internetTextArea.clear();
		internetTextArea.sendKeys("Lost Equipment");
		tb.addScreenshot(driver, this.scenario, "Status updated to Lost");
//		TestBase.takeScreenshot("Lost Poup");
		scrollToElementAndClick(internetSubmitButton, driver);
//		internetSubmitButton.click();	
	}
	
	public void stolenInternetEquipment() throws Exception {
		waitForLoading(driver);
		scrollToElementAndClick(internetchangeStatusLink, driver);
		waitForLoading(driver);
		scrollToElementAndClick(internetstolenRadioButton, driver);
		internetTextArea.clear();
		internetTextArea.sendKeys("Stolen Equipment");
		tb.addScreenshot(driver, this.scenario, "Status updated to Stolen");
//		TestBase.takeScreenshot("Lost Poup");
		scrollToElementAndClick(internetSubmitButton, driver);
//		internetSubmitButton.click();
//		Assert.assertEquals(Status.getText(),"Active - Stolen");
//		TestBase.takeScreenshot("Status shown");
		
	}
	
	public void foundinternetEquipment() throws Exception {
		waitForLoading(driver);
		scrollToElementAndClick(internetchangeStatusLink, driver);
		waitForLoading(driver);
		scrollToElementAndClick(internetFoundRadioButton, driver);
		internetTextArea.clear();
		internetTextArea.sendKeys("Found Equipment");
		tb.addScreenshot(driver, this.scenario, "Status updated to Found");
//		TestBase.takeScreenshot("Lost Poup");
		scrollToElementAndClick(internetSubmitButton, driver);
//		internetSubmitButton.click();
//		Assert.assertEquals(Status.getText(),"Active");
//		TestBase.takeScreenshot("Status shown");
		
	}

	public void returnTvEquipment() throws Exception {
		scrollToElementAndClick(returnTvEquipmentLink, driver);
//		returnTvEquipmentLink.click();
//		retailLocationDropdown.click();
		WebDriverWait w = new WebDriverWait(driver, 30);
		w.until(ExpectedConditions.visibilityOf(retailLocationDropdown));
		Select selectRetailLocation = new Select(retailLocationDropdown);
		selectRetailLocation.selectByIndex(1);
		w.until(ExpectedConditions.visibilityOf(returnEquipmentButton));
//		String address="AB-Calgary Barlow";
//		selectRelatilLocation.selectByVisibleText(address);
//		selectRelatilLocation.selectByValue(address);
//		waitForLoading(driver);
		tb.addScreenshot(driver, this.scenario, "Return Equipment");
		scrollToElementAndClick(returnEquipmentButton, driver);
		isLoaderSpinnerVisible(driver);	//AddedShweta
		w.until(ExpectedConditions.visibilityOf(TVreturnEqipmentStatus));
//		returnEquipmentButton.click();
//		Thread.sleep(5000);
		Assert.assertEquals(TVreturnEqipmentStatus.getText(), "Return Equipment Successsful");
		scrollToElementAndClick(TVCloseButton, driver);
//		TVCloseButton.click();
//		Thread.sleep(2000);
		scrollToElementAndClick(webudRefreshIcon, driver);
//		webudRefreshIcon.click();
//		TestBase.takeScreenshot("Status shown");
		
	}
	public void returnConvergedEquipment() throws Exception {
		waitForLoading(driver);
		//Minimizing the TV dropdown
//		equipmentStatus.click();
		// click the converged dropdown
		driver.switchTo().defaultContent();
		scrollToElementAndClick(convergedDropdown, driver);
//		convergedDropdown.click();
		waitForLoading(driver);
		scrollToElementAndClick(returnConvergedEquipmentLink, driver);
//		returnConvergedEquipmentLink.click();
//		waitForLoading(driver);
//		retailLocationDropdown.click();
		WebDriverWait w = new WebDriverWait(driver, 90);
		w.until(ExpectedConditions.visibilityOf(retailLocationDropdown));
		Select selectRelatilLocation = new Select(retailLocationDropdown);
		selectRelatilLocation.selectByIndex(1);
//		String address="AB-Calgary Barlow";
//		selectRelatilLocation.selectByVisibleText(address);
//		waitForLoading(driver);
		tb.addScreenshot(driver, this.scenario, "Return Converged");
		scrollToElementAndClick(returnConvergedEquipmentButton, driver);
		isLoaderSpinnerVisible(driver);	//AddedShweta
		w.until(ExpectedConditions.visibilityOf(convergedreturnEqipmentStatus));
//		returnConvergedEquipmentButton.click();
//		Thread.sleep(5000);
		Assert.assertEquals(convergedreturnEqipmentStatus.getText(),"Return Equipment Successsful");
		driver.switchTo().defaultContent();
		scrollToElementAndClick(convergedCloseButton, driver);
//		convergedCloseButton.click();
//		Thread.sleep(2000);
//		TestBase.takeScreenshot("Status shown");
		
	}
	
	public void validatebirthCertificate() throws InterruptedException
	{
		waitForLoading(driver);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView(true);", birthCertificate);
		waitForLoading(driver);
		if(birthCertificate.isDisplayed())
		{
			ExtentCucumberAdapter.addTestStepLog("Birth Certicate is Displayed");
			tb.addScreenshot(driver, this.scenario, "Birth Certificate");
			String src=birthCertificateProvision.getAttribute("src");
//			Assert.assertEquals(src,"/assets/images/Provision_Green.png");
		}
	}
	
	public void enterSerialNumber()
	{
		viewEquipmentDetailsLink.click();
		Select serialNoDropdown = new Select(serialNumberDropdown);
		serialNoDropdown.selectByValue("Serial Number");
		searchValue.clear();
		searchValue.sendKeys("");
		tb.addScreenshot(driver, this.scenario, "Serial Number");
		searchButton.click();
	}	
	
	public void provisionTVDetails() throws Exception
	{
		viewEquipmentDetailsLink.click();
		waitForLoading(driver);
		scrollToElementAndClick(provisionDate, driver);
		waitForLoading(driver);
		String dateProvisioned=provisionDate.getText();
		tb.addScreenshot(driver, this.scenario, "Provisioning");
		ExtentCucumberAdapter.addTestStepLog("Date Provisioned : " + dateProvisioned);
		String[] DateDisplayed=dateProvisioned.split("-");
	    Date date = new Date();
	    SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yy");
	    String str = formatter.format(date);
	    String[] splitDisplayedDate=str.split("/");
		String[] dateDisplayed=DateDisplayed[0].split(",");
		String[] currentDate=dateDisplayed[0].split(" ");
		Assert.assertEquals(splitDisplayedDate[1], currentDate[1]);
				
	}	

	public void validateConvergedbirthCertificate() throws Exception
	{
		scrollToElementAndClick(webudRefreshIcon, driver);
//		webudRefreshIcon.click();
//		equipmentStatus.click();
		waitForLoading(driver);
		scrollToElementAndClick(convergedDropdown, driver);
//		convergedDropdown.click();
		waitForLoading(driver);
		waitForLoading(driver);
		waitForLoading(driver);
//		scrollToElement(birthCertificateConverged,driver);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView(true);", birthCertificateConverged);
		waitForLoading(driver);
		if(birthCertificateConverged.isDisplayed())
		{
			
			ExtentCucumberAdapter.addTestStepLog("Birth Certicate is Displayed");
			tb.addScreenshot(driver, this.scenario, "Birth Certicate");
//			String src=birthCertificateConvergedProvision.getAttribute("src");
//			Assert.assertEquals(src, "https://tstwebud-ag.sjrb.ca/assets/images/Provision_Green.png");
		}
	}
	
	public void enterConvergedSerialNumber(String serialNumber) throws Exception
	{
		waitForLoading(driver);
		scrollToElementAndClick(viewEquipmentDetailsConvergedLink, driver);
		waitForLoading(driver);
//		viewEquipmentDetailsConvergedLink.click();
		if(!provisionDate.isDisplayed())
		{
			Select serialNoDropdown = new Select(serialNumberDropdown);
			serialNoDropdown.selectByValue("Serial Number");
			searchValue.clear();
			searchValue.sendKeys(serialNumber);
			tb.addScreenshot(driver, this.scenario, "serialNumber");
			searchButton.click();
		}

	}	
	
	public void provisionConvergedDetails() throws Exception
	{
//		viewEquipmentDetailsConvergedLink.click();
		scrollToElementAndClick(provisionDate, driver);
		waitForLoading(driver);
		String dateProvisioned=provisionDate.getText();
		ExtentCucumberAdapter.addTestStepLog("Date Provisioned : " + dateProvisioned);
		tb.addScreenshot(driver, this.scenario, "Date Provisioned");
		String[] DateDisplayed=dateProvisioned.split("-");
	    Date date = new Date();
	    SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yy");
	    String str = formatter.format(date);
	    String[] splitDisplayedDate=str.split("/");
		String[] dateDisplayed=DateDisplayed[0].split(",");
		String[] currentDate=dateDisplayed[0].split(" ");
		Assert.assertEquals(splitDisplayedDate[1], currentDate[1]);
				
	}	
	
	public void closeEquipment()
	{
		closeEquipmentTab.click();
		
	}
	
	public void clickProvisionButton() throws Exception
	{
//		JavascriptExecutor js = (JavascriptExecutor) driver;
//		js.executeScript("arguments[0].scrollIntoView(true);", ProvisionButton);
//		ProvisionButton.click();
//		waitForLoading(driver);
//		js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
		waitForLoading(driver);
		scrollToElementAndClick(ProvisionButton, driver);
//		Thread.sleep(10000);
		isLoaderSpinnerVisible(driver);	//AddedShweta
		waitForLoading(driver);
//		wait.withMessage("Checking visiblity of element").until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//p[contains(text(),'Processing of the request has completed')]")));
//		js.executeScript("arguments[0].scrollIntoView(true);", driver.findElement(By.xpath("//p[contains(text(),'Processing of the request has completed')]")));
		scrollToElement(driver.findElement(By.xpath("//p[contains(text(),'Processing of the request has completed')]")), driver);
//		waitForLoading(driver);
//		waitForLoading(driver);
//		wait.withMessage("Checking visiblity of element").until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//p[contains(text(),'Processing of the request has started')]")));
//		waitForLoading(driver);
		
	}
	
	public void lostConvergedEquipment() throws Exception {
		waitForLoading(driver);
		scrollToElementAndClick(convergedChangeStatusLink, driver);
//		convergedChangeStatusLink.click();
//		TestBase.takeScreenshot(" Pop up ");
		waitForLoading(driver);
		scrollToElementAndClick(internetLostRadioButton, driver);
		internetLostRadioButton.click();
		internetTextArea.clear();
		internetTextArea.sendKeys("Lost Equipment");
		tb.addScreenshot(driver, this.scenario, "Status updated to Lost");
//		TestBase.takeScreenshot("Lost Poup");
		scrollToElementAndClick(internetSubmitButton, driver);
//		Assert.assertEquals(Status.getText(),"Active - Lost");
//		TestBase.takeScreenshot("Status shown");
		
	}
	
	public void stolenConvergedEquipment() throws Exception {
		waitForLoading(driver);
//		internetchangeStatusLink.click();
		scrollToElementAndClick(convergedChangeStatusLink, driver);
//		TestBase.takeScreenshot(" Pop up ");
		waitForLoading(driver);
		scrollToElementAndClick(internetstolenRadioButton, driver);
//		internetstolenRadioButton.click();
		internetTextArea.clear();
		internetTextArea.sendKeys("Stolen Equipment");
		tb.addScreenshot(driver, this.scenario, "Status updated to Stolen");
//		TestBase.takeScreenshot("Lost Poup");
		scrollToElementAndClick(internetSubmitButton, driver);
//		Assert.assertEquals(Status.getText(),"Active - Stolen");
//		TestBase.takeScreenshot("Status shown");
		
	}
	
	public void foundConvergedEquipment() throws Exception {
		waitForLoading(driver);
		scrollToElementAndClick(convergedChangeStatusLink, driver);
//		internetchangeStatusLink.click();
//		convergedChangeStatusLink.click();
//		TestBase.takeScreenshot(" Pop up ");
		waitForLoading(driver);
		scrollToElementAndClick(internetFoundRadioButton, driver);
		internetTextArea.clear();
		internetTextArea.sendKeys("Found Equipment");
		tb.addScreenshot(driver, this.scenario, "Status updated to Found");
//		TestBase.takeScreenshot("Lost Poup");
		scrollToElementAndClick(internetSubmitButton, driver);
//		Assert.assertEquals(Status.getText(),"Active");
//		TestBase.takeScreenshot("Status shown");
		
	}
	
//	public void viewEquipmentDetails(String strViewEquipmentDetailsin) throws Exception {
//		waitForLoading(driver);
//		scrollToElementAndClick(driver.findElement(By.xpath("(//*[contains(text(),'"+strViewEquipmentDetailsin+"')]/following::i[1])[1]")), driver);
//		scrollToElementAndClick(driver.findElement(By.xpath("(//a[contains(text(),'View Equipment Details')])[1]")), driver);
//	}

}
