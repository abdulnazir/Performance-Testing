package pageObjects;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Database reader class having components related to database connection and execution
  *
 */
public class DatabaseReader extends BaseUIPage {

	//Resultdata of database query
	public static ResultSet resultData;
	public String environment = System.getProperty("environment");
	public String databaseURL = prop.getProperty(environment + "_Database_URL");
	public String databaseUsername = prop.getProperty(environment + "_Username");
	public String databasePassword = prop.getProperty(environment + "_Password");
	public String databaseDriver = prop.getProperty(environment + "_Driver");
	//Returning list of map values from Execution of query
	public static List<HashMap<String,Object>> databaseReturnList= new ArrayList<HashMap<String,Object>>();
	
	/**
	 * Connect the database by retrieving database details from AppUrls.properties file
	 * Execute the provided query
	 * @param databaseQuery Query for database execution
	 * @return List of Map having row and column values of executed query
	 */
	public List<HashMap<String,Object>> databaseConnectorExecutor(String databaseQuery) {
		Connection con;
		try {
			con = DriverManager.getConnection(databaseURL, databaseUsername, databasePassword);

			Class.forName(databaseDriver);
			Statement stmt = con.createStatement();
			// Execute the SQL Query. Store results in ResultSet
			resultData = stmt.executeQuery(databaseQuery);
			databaseReturnList =convertResultSetToList(resultData);

		} catch (SQLException e) {
			System.out.println("SQLException");
		} catch (ClassNotFoundException e) {
			System.out.println("ClassNotFoundException");
		}

		return databaseReturnList;

	}
	
	/**
	 * Convert the ResultSet from executeQuery and format it to List<HashMap<String,Object>>
	 * @param rs Resultset from executQuery
	 * @return List of Map having row and column values of executed query
	 * @throws SQLException
	 */
	public List<HashMap<String,Object>> convertResultSetToList(ResultSet rs) throws SQLException {
		ResultSetMetaData md = resultData.getMetaData();
	    int columns = md.getColumnCount();
	    List<HashMap<String,Object>> list = new ArrayList<HashMap<String,Object>>();

	    while (rs.next()) {
	        HashMap<String,Object> row = new HashMap<String, Object>(columns);
	        for(int i=1; i<=columns; ++i) {
	            row.put(md.getColumnName(i),rs.getObject(i));
	        }
	        list.add(row);
	    }

	    return list;
	}

}
