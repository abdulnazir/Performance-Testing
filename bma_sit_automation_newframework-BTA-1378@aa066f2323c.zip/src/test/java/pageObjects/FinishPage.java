package pageObjects;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.*;
import util.TestUtil;



public class FinishPage extends BaseUIPage {
	private WebDriver driver;
	TestUtil utils;
	AddServicesAndFeatures as;
	public FinishPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	@FindBy(xpath = "//*[text()='Finish']")
	WebElement finishtab;

//	@FindBy(xpath = "//table[@class=\"UIXTable\"]/tbody/tr[1]/td[3]")
	
	@FindBy(xpath = "//table[@id='quote-submission-flow-table']/tbody/tr[1]/td[3]")
	WebElement accountnum;

	@FindBy(xpath = "//table[@id=\"quote-submission-flow-table\"]/tbody/tr[3]/td[3]")
	WebElement workordernumber;

	@FindBy(xpath = "//span[text()=\"Order Management:\"]/ancestor::table[@id='quote-submission-flow-table']//span[text()='Started']")
	WebElement orderManagementTask;
	
	@FindBy(xpath = "//*[@id=\"hardware-recoverypopup-ok-button\"]/span/span")
	WebElement hardwareReturnPopup;
	
	@FindBy(xpath = "//*[@id=\"exampleModalPopup0\"]//input[@value='RefundCheque']")
	WebElement disconnectrefundpref;
	

	@FindBy(xpath="//div[@id='exampleModalPopup0']//button[2]")
	WebElement disconnectRefundSave;
	

	public void clickFinishTab() throws Exception {
		//waitForLoading();
		Thread.sleep(2000);
		as= new AddServicesAndFeatures(driver);
		System.out.println("entering finish tab method");
		if (prop.getProperty("bulkAddressCheck", "false").equalsIgnoreCase("true")) {
			scrollToElementAndClick(finishtab, driver);
//			finishtab.click();
			System.out.println("Inside---------------------");
			Boolean bulkAddressMessageVisible = as.isBulkAddressMessageVisible();
			if (!bulkAddressMessageVisible) {
				//addErrorInReport("Bulk Address Message not visible in To-Do list");
			}
			System.out.println("Bulk address property-----------");
			Assert.assertTrue("Bulk Address Message not visible in To-Do list",bulkAddressMessageVisible);
			//TestBase.takeScreenshot("BulkAddressCheckBoxNotSelected");
			//addInfoInReport("Bulk Address Message is visible");
			System.out.println("entering tab method");
			as.selectBulkAddressCheckBox();
			//TestBase.takeScreenshot("BulkAddressCheckBoxSelected");
			scrollToElementAndClick(finishtab, driver);
		} else {
			scrollToElementAndClick(finishtab, driver);
			isLoaderSpinnerVisible(driver);
		}
	}

	public String retrieveAccountnumber() throws Exception {
		int lwait = Integer.parseInt(prop.getProperty("waitForOrderSubmission", "63000"));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		if(System.getProperty("environment").equalsIgnoreCase("webud"))
		{
			driver.switchTo().defaultContent();	
			js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
			driver.switchTo().frame("ncOrderEntry");
		}
		while (driver.findElements(By.xpath("//*[text()='OK']")).size() > 0) {
			//takeScreenshot("deleting device");
			waitForLoading(driver);
			if(driver.findElements(By.xpath("//span[text()='OK']")).size()!=0) {
			js.executeScript("arguments[0].scrollIntoView();",driver.findElement(By.xpath("//span[text()='OK']")));
			driver.findElement(By.xpath("//span[text()='OK']")).click();}
			waitForLoading(driver);
//			Thread.sleep(5000);
		}
		if(driver.findElements(By.xpath("//table[@id=\"promotion-list_main\"]/tbody//a[contains(text(),'removed numbers ported')]")).size()!=0)
		{
			driver.findElement(By.xpath("//span[text()='OK']")).click();
			clickFinishTab();
			if (driver.findElements(By.xpath("//span[text()='OK']")).size() > 0) {
				//takeScreenshot("deleting device");
				waitForLoading(driver);
				js.executeScript("arguments[0].scrollIntoView();",driver.findElement(By.xpath("//span[text()='OK']")));
				driver.findElement(By.xpath("//span[text()='OK']")).click();
				waitForLoading(driver);
//				Thread.sleep(5000);
			}
		}
		isLoaderSpinnerVisible(driver);	//AddedShweta
		WebDriverWait w = new WebDriverWait(driver, 240);
		w.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(
				"//span[text()='Order Management:']/ancestor::table[@id='quote-submission-flow-table']//span[text()='Started']")));
//		waitForVisibilityOfElement(driver.findElement(By.xpath(
//				"//span[text()='Order Management:']/ancestor::table[@id='quote-submission-flow-table']//span[text()='Started']")),driver);
		driver.findElement(By.xpath(
				"//span[text()='Order Management:']/ancestor::table[@id='quote-submission-flow-table']//span[text()='Started']")).isDisplayed();
						
		// wait.withMessage("account number not
		// generated").until(ExpectedConditions.visibilityOf(orderManagementTask));
		return accountnum.getText();
	}
	public String retrieveworkOrderNumber() throws Exception {
		wait.withMessage("Work order number number not generated")
				.until(ExpectedConditions.visibilityOf(workordernumber));
		scrollToElementAndClick(workordernumber, driver);
		return workordernumber.getText();

	}
	
	public void clickHardwareReturnPopup() {
	    wait.withMessage("Popup doesn't appear")
		.until(ExpectedConditions.visibilityOf(hardwareReturnPopup));
	    hardwareReturnPopup.click();
	}
	
	
	public void clickDisconnectRefundPopup() throws InterruptedException {
//	    wait.withMessage("Popup doesn't appear")
//		.until(ExpectedConditions.visibilityOf(disconnectRefundPreference));
	   
		driver.switchTo().defaultContent();
	   // driver.switchTo().frame("ncframeOrderHistory");
	  Thread.sleep(15000);
	//	disconnectClose.click();
	  disconnectrefundpref.click();
	    Thread.sleep(7000);
	    disconnectRefundSave.click();
	    
	  
	}
}
