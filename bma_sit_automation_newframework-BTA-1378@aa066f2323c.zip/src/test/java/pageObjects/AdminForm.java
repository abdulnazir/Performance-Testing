package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class AdminForm extends BaseUIPage
{
	private WebDriver driver;

	public AdminForm(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//*[contains(text(),'Perform Assignments')]")
	public WebElement PerformAssignments;

	@FindBy(xpath = "//input[@placeholder='Account Number']")
	public WebElement CollectionAssignment_AccNo;
	
	@FindBy(xpath = "//input[@placeholder='Hold End Date']")
	public WebElement CollectionAssignment_HoldEndDate;	
	
	@FindBy(xpath = "(//*[@for='adminlogin']/select)[1]")
	public WebElement CollectionAssignment_Agency;	
	
	@FindBy(xpath = "(//*[@for='adminlogin']/select)[2]")
	public WebElement CollectionAssignment_AgencyStatus;	

	@FindBy(xpath = "//*[@ngbtooltip='Add New Assignment']")
	public WebElement CollectionAssignment_AddNewAssignment;
	
	@FindBy(xpath = "//*[@id='dele']/descendant::td[contains(text(),'Your changes have been saved.')]")
	public WebElement Message;
	
	public void validateAdminForm(String accountnumber, String agency, String collectionagencystatus, String holdenddate) throws Exception {
		waitForLoading(driver);
		WebDriverWait w = new WebDriverWait(driver, 30);
		CollectionAssignment_AccNo.sendKeys(accountnumber);
		Select s1= new Select(CollectionAssignment_AgencyStatus); 	
		w.until(ExpectedConditions.textToBePresentInElement(CollectionAssignment_AgencyStatus, collectionagencystatus));
		s1.selectByVisibleText(collectionagencystatus);	
		switch (collectionagencystatus){
			case "Assigned":
				Select s= new Select(CollectionAssignment_Agency); 
				w.until(ExpectedConditions.textToBePresentInElement(CollectionAssignment_Agency, agency));
				s.selectByVisibleText(agency);	
				break;
			case "Hold From Collections":
				CollectionAssignment_HoldEndDate.sendKeys(holdenddate);
				break;
			default:
				break;
		}	
		CollectionAssignment_AddNewAssignment.click();
		PerformAssignments.click();
		waitForLoading(driver);
		w.until(ExpectedConditions.visibilityOf(Message));
		Assert.assertEquals(Message.getText(), "Your changes have been saved.");		
		WebUD_HomePage hp=new WebUD_HomePage(driver,this.scenario);
		hp.selectExistingAccounts();
	}
	
}
