package pageObjects;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;


/** 
 * CSVFileREader class having all the components for connecting with CSV File 
 * Read and Retrieve it in an efficient form
 *
 */
public class CSVFileReader {

	/**
	 * Read and retrieve the information in csv file as list of list
	 * @param filename csv file path with name
	 * @return list of list value with row and column values
	 */
	public List<List<String>> csvreader(String filename)
	{
		List<List<String>> csvValue=new ArrayList<List<String>>();
		try {
	        // Create an object of file reader
	        // class with CSV file as a parameter.
	        FileReader filereader = new FileReader(filename);
	 
	        // create csvReader object and skip first Line
	        CSVReader csvReader = new CSVReaderBuilder(filereader)
	                                  .withSkipLines(1)
	                                  .build();
	        List<String[]> allData = csvReader.readAll();
	 
	       for (String[] row : allData) {
	        	List<String> sam=new ArrayList<>();
	        	for (String cell : row) {
	                sam.add(cell);
	            }
	        	csvValue.add(sam);
	           
	        }

	    }
	    catch (Exception e) {
	        e.printStackTrace();
	    }
		
		return csvValue;
	}
}
