package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import util.TestUtil;

public class ReinstatePage extends BaseUIPage {
	
	private WebDriver driver;

	public ReinstatePage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//*[text()='Reinstate Account with Past Resources']")
	WebElement reinstatepastresources;
	
	@FindBy(xpath="//*[text()='Retrieve order information']")
	WebElement retrieveOrder;
	
	@FindBy(xpath="//*[@id=\"newOrder\"]/span/span")
	WebElement reinstatenew;

	public void selectReinstateWithPastResources() throws Exception {
//		reinstatepastresources.click();
		scrollToElementAndClick(reinstatepastresources, driver);	
		isLoaderSpinnerVisible(driver);
		waitForLoading(driver);
//		Thread.sleep(5000);
		
	}
	
	public void selectReinstateWithnewResources() throws InterruptedException {
	    reinstatenew.click();
		Thread.sleep(5000);
		
	}
	
	public void selectRetrieveAccountInformation() throws Exception{
		Thread.sleep(5000);
		scrollToElementAndClick(retrieveOrder,driver);
	}
}
