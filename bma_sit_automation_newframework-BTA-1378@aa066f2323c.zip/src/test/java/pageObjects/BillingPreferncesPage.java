package pageObjects;

import java.util.List;
import java.util.Set;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import io.cucumber.java.Scenario;
import stepDefinitions.StepData;
import util.TestUtil;

public class BillingPreferncesPage extends BaseUIPage {

	private WebDriver driver;
	TestUtil utils;
	public BaseUIPage tb=new BaseUIPage();
	public BillingPreferncesPage(WebDriver driver, Scenario scenario) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
		this.sd=new StepData();
		sd.setScenario(scenario);
		this.scenario=sd.getScenario();
	}
	@FindBy(xpath="//*[@id=\"billingTab\"]/div/a")
	WebElement billingpreferencetab;
	
	@FindBy(xpath="//*[@id=\"billing-service-address__item_0\"]")
	WebElement mailingaddresscheckbox;
	
	@FindBy(xpath="//*[@id=\"billing-bill-type__item_0\"]")
	WebElement ebill;
	
	@FindBy(xpath="//*[@id=\"billing-bill-type__item_1\"]")
	WebElement paper;
	
	@FindBy(xpath = "//*[contains(@id,'Bill-tab')]")
	public WebElement Billing;

	@FindBy(xpath = "//*[@role='tablist']//a[contains(text(),'Delinquent')]")
	public WebElement Delinquent;	
	
	@FindBy(xpath = "//a[text()='Payment Arrangements']")
	public WebElement PaymentArrangementsTab;	
	
	@FindBy(xpath = "//*[contains(text(),'Refunds')]")
	public WebElement Refunds;	

	@FindBy(xpath = "//a[contains(text(),'Transactions')]")
	public WebElement Transactions;	
	
	@FindBy(xpath = "//*[contains(text(),'Refund Amount')]/following-sibling::div/input")
	public WebElement RefundAmount;	
	
	@FindBy(xpath = "//*[contains(text(),'Reason for Refund')]/following::textarea[@name='refunnNotes']")
	public WebElement ReasonforRefund;
	
	@FindBy(xpath = "//select[@name='refundtype']")
	public WebElement RefundType;
	
	@FindBy(xpath = "//label[contains(text(),'Refund Location')]/following::select[@name='province']")
	public WebElement RefundLocationProvince;
	
	@FindBy(xpath = "//label[contains(text(),'Refund Location')]/following::select[@name='city']")
	public WebElement RefundLocationCity;
	
	@FindBy(xpath = "//label[contains(text(),'Refund Location')]/following::select[@name='location']")
	public WebElement RefundLocation;
	
	@FindBy(xpath = "//label[contains(text(),'Refund Location')]/following::select[@name='channel']")
	public WebElement RefundLocationChannel;	

	@FindBy(xpath = "//button[contains(@class,'btn btn-Light')  and contains(text(),'Submit')]")
	public WebElement RefundSubmit;		
	
	@FindBy(xpath = "//*[contains(text(),'Bill Cycle History')]")
	public WebElement BillCycleHistory;
	
	@FindBy(xpath = "//*[contains(text(),'Assign to Agency')]")
	public WebElement AssigntoAgency;	

	@FindBy(xpath = "//*[contains(text(),'Collection Agency Status')]/ancestor::table/descendant::select")
	public WebElement AssigntoAgency_AgencyStatus;	

	@FindBy(xpath = "//*[contains(text(),'Collection Agency Name')]/ancestor::table/descendant::select")
	public WebElement AssigntoAgency_AgencyName;	
	
	@FindBy(xpath = "//*[contains(text(),'Hold End Date')]/ancestor::table/descendant::input")
	public WebElement AssigntoAgency_HoldEndDate;		

	@FindBy(xpath = "//th[contains(text(),'Bill Cycle')]//ancestor::table/tbody/tr[1]/td[1]")
	public WebElement BillCycle;	

	@FindBy(xpath = "//*[contains(text(),'Payments & Preferences')]")
	public WebElement PaymentPref;	
	
	@FindBy(xpath = "//button[contains(@id,'v-pills-credit-tab')]/parent::div/button[contains(text(),'Make a Payment')]")
	public WebElement btn_MakeaPayment;	
	
	@FindBy(xpath = "//button[contains(@id,'v-pills-credit-tab')]/parent::div/button[contains(text(),'Preauthorized Payments')]")
	public WebElement btn_PreauthorizedPay;	

	@FindBy(xpath = "//button[contains(text(),'Activate Preauthorized Payment')]")
	public WebElement btn_ActivatePreAuthPayment;		

	@FindBy(xpath = "//button[contains(text(),'Verify Credit Card Details')]")
	public WebElement btn_VerifyCreditCardDetails;	

	@FindBy(xpath = "//button[@class='delete-card btn btn-danger']")
	public WebElement btn_RemoveCard;	

	@FindBy(xpath = "//*[contains(text(),'Yes, delete this card')]")
	public WebElement btn_deleteCreditCard;	
		
	@FindBy(xpath = "//label[contains(text(),'Payment Type')]/following-sibling::select")
	public WebElement select_PreAuthPaymentType;	

	@FindBy(xpath = "//input[@id='institutionNo']")
	public WebElement Bank_Inst;
	
	@FindBy(xpath = "//input[@id='branchNo']")
	public WebElement Branch_Tansit;
	
	@FindBy(xpath = "//input[@id='preAuthBankAccount']")
	public WebElement PreAuth_Account;
	
	@FindBy(xpath = "//label[contains(text(),'Receive Invoice')]/following-sibling::select[@name='payments']")
	public WebElement select_ReceiveInvoice;

	@FindBy(xpath = "//div[@id='v-pills-preauth0']/descendant::button[contains(text(),'Submit')]")
	public WebElement PreAuth_Submit;
	
	@FindBy(xpath = "//button[contains(@id,'v-pills-credit-tab')]")
	public WebElement btn_CreditCardProfile;	

	@FindBy(xpath = "//button[contains(text(),'Create Credit Card Profile')]")
	public WebElement btn_CreateCreditCardProfile;

	@FindBy(xpath = "//*[@id='Email']")
	public WebElement AddCard_email;	
	
	@FindBy(xpath = "//*[@id='mobile']")
	public WebElement AddCard_mobile;	
	
	@FindBy(xpath = "//button[contains(text(),'Send SMS')]")
	public WebElement AddCard_btnSendSMS;	
	
	@FindBy(xpath = "//div[@role='tabpanel' and  @id='addCard']/span/following-sibling::button[contains(text(),'Send Email')]")
	public WebElement AddCard_btnSendEmail;		

	@FindBy(xpath = "//button[@id='saveCard']")
	public WebElement btn_AddCreditCard;	

	@FindBy(xpath = "//*[@id='sendMobile']")
	public WebElement btn_SendSMS;

	@FindBy(xpath = "//*[@id='sendEmail']")
	public WebElement btn_SendEmail;

	@FindBy(xpath = "//*[contains(@id,'printReceipt')]")
	public List<WebElement> btn_PrintReceipt;	
	
//	@FindBy(xpath = "//*[contains(text(),'New Credit Card:')]/preceding-sibling::input")
//	public WebElement radio_NewCreditCard;

	@FindBy(xpath = "//*[contains(text(),'New Credit Card')]/preceding-sibling::input")
	public WebElement radio_NewCreditCard;
	
	@FindBy(xpath = "//label[contains(text(),'Payment Method')]/following::div[@role='combobox']/parent::div/following-sibling::span")
	public WebElement PaymentMethod;	

	@FindBy(xpath = "//label[contains(text(),'Cheque Number')]/parent::div/following-sibling::div/input[@id='cnumber']")
	public WebElement PaymentChequeNo;
	
	@FindBy(xpath = "//label[contains(text(),'Payment Amount')]/parent::div/following-sibling::div/input[@id='cash']")
	public WebElement PaymentAmount;	
	
	@FindBy(xpath = "(//*[text()='Province']/following::select[@name='province'])[1]")
	public WebElement PaymentProvince;					

	@FindBy(xpath = "(//*[text()='City']/following::select[@name='city'])[1]")
	public WebElement PaymentCity;
	
	@FindBy(xpath = "(//*[text()='Location']/following::select[@name='location'])[1]")
	public WebElement PaymentLocation;
	
	@FindBy(xpath = "(//*[text()='Channel']/following::select[@name='channel'])[1]")
	public WebElement PaymentChannel;
	
	@FindBy(xpath = "//button[contains(text(),'Process Payment')]")
	public WebElement ProcessPayment;

	@FindBy(xpath = "//*[text()='Pay Amount']/preceding-sibling::input[@name='payAmount']")
	public WebElement radiobtn_CreditCardPayAmount;
	
	@FindBy(xpath = "//*[@id='payAmountValue']")
	public WebElement CreditCardPayAmountValue;

//	@FindBy(xpath = "//*[text()='Payment Amount']/following::input[@id='payAmountValue']")
//	public WebElement CreditCardPayAmountValue;	
	
	@FindBy(xpath = "//*[contains(text(),'Name On Card')]/following::input[@name='CcOwnerName']")
	public WebElement CreditCardOwner;
	
	@FindBy(xpath = "//input[@id='bambora-card-number']")
	public WebElement CreditCardNumber;
	
	@FindBy(xpath = "//input[@id='bambora-expiry']")
	public WebElement CreditCardExpiry;
	
	@FindBy(xpath = "//input[@id='bambora-cvv']")
	public WebElement CreditCardCVD;

	@FindBy(xpath = "//*[@id='saveCheck']")
	public WebElement SaveCreditCard;
	
	@FindBy(xpath = "//*[@id='submitPayment']")
	public WebElement btn_CreditCardPayNow;	

	@FindBy(xpath = "//button[contains(text(),'Reverse Payment')]")
	public WebElement btn_ReversePayment;	

	@FindBy(xpath = "//*[contains(text(),'Reverse Payment')]/following::button[contains(text(),'Reverse Payment')]")
	public WebElement btn_ConfirmReversePayment;
	
	@FindBy(xpath = "//span[contains(text(),'You are reversing a payment on an account.')]/following-sibling::div/button[contains(text(),'Yes')]")
	public WebElement btn_ReversePayment_Yes;	
	
	@FindBy(xpath = "//button[contains(text(),'Reverse Adjustment')]")
	public WebElement btn_ReverseAdjustment;	

	@FindBy(xpath = "//*[contains(text(),'Reverse Adjustment')]/following::label[contains(text(),'Notes:(required)')]/following::textarea[1]")
	public WebElement ReversalNotes;
	
	@FindBy(xpath = "//*[contains(text(),'Apply Reversal')]")
	public WebElement btn_ApplyReversal;

//	@FindBy(xpath="//*[contains(@src,'Refresh') and @tooltipclass='tolrefClass']")
	@FindBy(xpath="//div[@class='full-row user-info bg-white']/descendant::*[contains(@class,'Refresh')]")
	WebElement Refresh;	
	
	@FindBy(xpath = "//th[contains(text(),'Amount')]/ancestor::table/descendant::input")
	public WebElement PayArr_Amount;
	
	@FindBy(xpath = "//th[contains(text(),'Method')]/ancestor::table/descendant::select[@name='payments']")
	public WebElement PayArr_Method;
	
	@FindBy(xpath = "//th[contains(text(),'Location')]/ancestor::table/descendant::select[@name='payments']")
	public WebElement PayArr_Location;
	
	@FindBy(xpath = "//th[contains(text(),'Expiry Date')]/ancestor::table/descendant::input")
	public WebElement PayArr_ExpiryDate;
	
	@FindBy(xpath = "//button[text()='Note']")
	public WebElement PayArr_Note;
	
	@FindBy(xpath = "//button[text()='Note']/following::textarea[1]")
	public WebElement PayArr_CreateNote;
	
	@FindBy(xpath = "//button[contains(text(),'Create') and contains(@style,'rgb(218, 238, 247)')]")
	public WebElement PayArr_Create;

	@FindBy(xpath = "//button[contains(text(),'Edit Arrangement')]")
	public WebElement PayArr_EditArrangement;
	
	@FindBy(xpath = "//table[@class='editpatable']/descendant::select[1]")
	public WebElement PayArr_EditMethod;
	
	@FindBy(xpath = "//table[@class='editpatable']/descendant::select[2]")
	public WebElement PayArr_EditLocation;
	
	@FindBy(xpath = "//table[@class='editpatable']/following::textarea[1]")
	public WebElement PayArr_EditNote;
	
	@FindBy(xpath = "//button[contains(text(),'Save Arrangement')]")
	public WebElement PayArr_SaveArrangement;

	@FindBy(xpath = "//button[contains(text(),'Miscellaneous Account Adjustment')]")
	public WebElement MiscAccountAdjustment;

	@FindBy(xpath = "//span[contains(text(),'Miscellaneous Account Adjustment')]/ancestor::div[@class='modal-content']/descendant::label[starts-with(text(),'Type')]/following::select[1]")
	public WebElement AdjustmentType;
	
	@FindBy(xpath = "//span[contains(text(),'Miscellaneous Account Adjustment')]/ancestor::div[@class='modal-content']/descendant::label[starts-with(text(),'Sub Type')]/following::select[1]")
	public WebElement AdjustmentSubType;
	
	@FindBy(xpath = "//span[contains(text(),'Miscellaneous Account Adjustment')]/ancestor::div[@class='modal-content']/descendant::label[contains(text(),'Amount')]/parent::div/descendant::input")
	public WebElement AdjustmentAmount;
	
	@FindBy(xpath = "//span[contains(text(),'Miscellaneous Account Adjustment')]/ancestor::div[@class='modal-content']/descendant::label[contains(text(),'Notes')]/parent::div/descendant::textarea")
	public WebElement AdjustmentNotes;
	
	@FindBy(xpath = "//button[contains(text(),'Apply Adjustment')]")
	public WebElement btn_ApplyAdjustment;	

	@FindBy(xpath = "//*[text()='Edit']")
	public WebElement edit_PreAuthPay;
	
	@FindBy(xpath = "//*[contains(text(),'Cancel Changes')]")
	public WebElement cancelPreAuthChange;
	
	@FindBy(xpath = "//*[contains(text(),'Save Changes')]")
	public WebElement savePreAuthChange;
	
	@FindBy(xpath = "//*[text()='Remove']")
	public WebElement remove_PreAuthPay;
	
	@FindBy(xpath = "//*[contains(text(),'Warning')]/following::*[contains(text(),\"This will permanently delete this account's Preauthorized Payment Plan\")]/following::button[text()='Yes']")
	public WebElement removePreAuthWarningYes;	
	
	@FindBy(xpath="//p[contains(text(),'Description')]")
	WebElement descriptiontable;
	
//	@FindBy(xpath="//div[@id='transaction0']/table/tbody/tr[2]/td/div/div[5]/i")
	@FindBy(xpath="(//p[contains(text(),'Bill')]/following::i)[1]")	
	WebElement billTransaction;
	
	@FindBy(xpath="(//p[contains(text(),'Current Monthly Services')]/following::i)[1]")
	WebElement currentMonthlyService;
	
	@FindBy(xpath="//label[contains(text(),' (Select All)')]/../input")
	WebElement selectAllCheckBox;
		
	@FindBy(xpath="//button[contains(text(),'Adjust Item(s)')]")
	WebElement AdjustItemsButton;
	
	@FindBy(xpath="//div[@id='adjustitems0']//select")
	WebElement selectReason;
		
	@FindBy(xpath="//textarea[@id='isNoOfUnitstxt']")
	WebElement inputNotes;
		
	@FindBy(xpath="//div[@id='adjustitems0']//button[contains(text(),'Apply Adjustment')]")
	WebElement applyAdjustmentButton;
	
	@FindBy(xpath="//*[contains(text(),'Make An Adjustment to Current Monthly Services')]/following::*[text()='Cancel'][1]")
	WebElement cancelButton;	
	
	@FindBy(xpath="//div[@id='adjustitems0']//p[2]")
	WebElement adjustmentErrorText;	

	@FindBy(xpath="//button[@id='v-pills-pref-tab']")
	WebElement disconnectRefundPreference;

	@FindBy(xpath="//span[contains(text(),'Refund Cheque')]")
	WebElement refundCheque;
	
	@FindBy(xpath="//div[@id='v-pills-pref0']//button[1]")
	WebElement disconnectRefundSave;
	
	String AdjustmentError ="Adjustment failed at item marked 'X' with error 'unknown'. Try again OR Cancel to go back and remove the failed item from those selected for adjustment. Report Problem";
	String strMessagewithPCIURL;
	
//Added by Raj	
	@FindBy(xpath="//*[contains(text(),' Financed Devices ')]")
	WebElement deviceFinacetab;
	
	@FindBy(xpath="//div[@id='financedDevices0']//button[2]")
	WebElement deviceFinace_doorbell;
	
	@FindBy(xpath = "//div[@id='Bill-tab']")
	public WebElement billingtab;
	
	@FindBy(xpath = "//tbody/tr[2]//div/i")
	public WebElement expandbill;
	
	@FindBy(xpath = "//li[@class='nav-item dropdown bg-white']/button")
	public WebElement uparrow;
	
	@FindBy(xpath = "//*[@id='transaction0']/table/tbody/tr[2]/td/div[1]/div[4]/p/span")
	public WebElement billingvalue;

					
	public void clickBillingPreferenceTab() throws InterruptedException,Exception
	{
		//waitForLoading(driver)();
		scrollToElementAndClick(billingpreferencetab,driver);
	}
	public void selectMailingAddress() throws Exception
	{
	    waitForLoading(driver);
	    scrollToElementAndClick(mailingaddresscheckbox, driver);
//		mailingaddresscheckbox.click();
		waitForLoading(driver);
	}
	
	public void selectEbill() throws InterruptedException
	{
	    Thread.sleep(2000);
		ebill.click();
	}
	
	public void selectpaperbill() throws InterruptedException
	{
	    Thread.sleep(2000);
		paper.click();
	}
	
	public void selectBillingtab() throws Exception {
		waitForLoading(driver);
		if(HostUrls.webUDroutingChanges.contains("Yes")) {
			if((driver.findElements(By.xpath("//title[contains(text(),'Order History')]")).size()!=0) | (driver.findElements(By.xpath("//title[contains(text(),'Order Entry')]")).size()!=0)) {}
			else {switchtoWindow("| WebUD", driver);}
			}
		else switchtoWindow("Shaw", driver);
		driver.switchTo().defaultContent();
//		WebDriverWait w = new WebDriverWait(driver, 10);	
//		w.until(ExpectedConditions.visibilityOf(Billing));
		scrollToElementAndClick(Billing, driver);
//		Billing.click();
	}	
	
	public void selectBillCycleHistorytab() throws Exception {
		waitForLoading(driver);
		waitForVisibilityOfElement(BillCycleHistory,driver); 
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView();", BillCycleHistory);	
		BillCycleHistory.click();
	}
	
	public void validateAssigntoAgencytabdetails(String agency, String collectionagencystatus, String holdenddate) throws Exception {
		waitForLoading(driver);
		WebDriverWait w = new WebDriverWait(driver, 30);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		w.until(ExpectedConditions.elementToBeClickable(AssigntoAgency));
		AssigntoAgency.click();
		waitForLoading(driver);
		w.until(ExpectedConditions.visibilityOf(AssigntoAgency_AgencyStatus));
		Select s= new Select(AssigntoAgency_AgencyStatus); 	
		Assert.assertEquals(s.getFirstSelectedOption().getText(), collectionagencystatus);		
		js.executeScript("arguments[0].scrollIntoView();", AssigntoAgency_AgencyStatus);	
		WebElement eleUser =driver.findElement(By.xpath("//*[@id='assignagency0']/descendant::tr[@class='tdhov'][1]/th/p[1]"));
		//String checkDetail=FormatDate("dd-MMM-YYYY")+" Rep: SJRB\\"+WebUD_HomePage.getUser();
		WebUD_HomePage webudHomePage = new WebUD_HomePage(driver,this.scenario);
		String User= webudHomePage.getUser();
		String checkDetail=FormatDate("dd-MMM-YYYY")+" Rep: SJRB\\"+User;
		Assert.assertEquals(eleUser.getText(), checkDetail);		
		Select s1= new Select(AssigntoAgency_AgencyName); 		
		WebElement eleAgency =driver.findElement(By.xpath("//*[@id='assignagency0']/descendant::tr[@class='tdhov'][1]/th/p[2]"));	
		switch (collectionagencystatus){
			case "Assigned":
				Assert.assertEquals(s1.getFirstSelectedOption().getText(), agency);	
				Assert.assertTrue(eleAgency.getText().contains(s1.getFirstSelectedOption().getAttribute("value")), eleAgency.getText());
				break;
			case "Hold From Collections":
				Assert.assertEquals(AssigntoAgency_HoldEndDate.getAttribute("value"), holdenddate);
				Assert.assertTrue(eleAgency.getText().contains(s.getFirstSelectedOption().getAttribute("value")), eleAgency.getText());
				break;			
			default:
				break;
		}		
	}

	public String retrieveBillCycle() throws Exception {
		selectBillingtab();
		selectBillCycleHistorytab();
		waitForVisibilityOfElement(BillCycle,driver);
		return BillCycle.getText();
	}
	
	public void selectRefundstab() throws Exception {
		scrollToElementAndClick(Refunds, driver);
	}
	
	public void makeRefund(String PaymentTransactionID, String refundAmount, String reasonforRefund, String refundType,
			String refundLocationProvince, String refundLocationCity, String refundLocation,
			String refundLocationChannel) throws Exception {
		enterValueInField(RefundAmount, "0.00", driver);
		enterValueInField(RefundAmount, refundAmount, driver);
		enterValueInField(ReasonforRefund, " ", driver);
		enterValueInField(ReasonforRefund, reasonforRefund, driver);
		selectElementFromDropdown(RefundType, driver, "VisibleText", refundType);
		switch(refundType) {
		case "Credit Card": 
			Thread.sleep(2000);
			WebDriverWait w = new WebDriverWait(driver, 120);
			w.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//table[@id='paymenthistory']"))));
			waitForLoading(driver);	
			scrollToElementAndClick(driver.findElement(By.xpath("//table[@id='paymenthistory']/tbody/tr/td[contains(text(),'"+PaymentTransactionID+"')]/following-sibling::td[3]/input[@name='radiogroup']")), driver);
			break;
		case "Cheque":
			break;
		}
		selectElementFromDropdown(RefundLocationProvince, driver, "VisibleText", refundLocationProvince);
		selectElementFromDropdown(RefundLocationCity, driver, "VisibleText", refundLocationCity);
		selectElementFromDropdown(RefundLocation, driver, "VisibleText", refundLocation);
		selectElementFromDropdown(RefundLocationChannel, driver, "VisibleText", refundLocationChannel);
	}
	
	public void submitRefundandvalidate(String refundAmount) throws Exception {
		scrollToElementAndClick(RefundSubmit, driver);	
		WebDriverWait w = new WebDriverWait(driver, 120);
		w.until(ExpectedConditions.invisibilityOfAllElements(driver.findElements(By.xpath("//img[contains(@src,'spinner.gif')][1]"))));	
		waitForLoading(driver);		
		w.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath("//*[contains(text(),'Refund of $"+refundAmount+" Processed Successfully.')]"))));
		scrollToElement(driver.findElement(By.xpath("//*[contains(text(),'Refund of $"+refundAmount+" Processed Successfully.')]")), driver);
		Assert.assertTrue(driver.findElement(By.xpath("//*[contains(text(),'Refund of $"+refundAmount+" Processed Successfully.')]")).isDisplayed(), "Refund Amount Processed Successfully should be present");
	}
	
	public void selectTransactionstab() throws Exception {
		if(driver.getWindowHandle().contains("PCI Web"))
			driver.close();
//		WebUDRoutingChange
		if(HostUrls.webUDroutingChanges.contains("Yes")) switchtoWindow("| WebUD", driver);
		else switchtoWindow("Shaw", driver);
		scrollToElementAndClick(Transactions, driver);	
	}
	
	public void validateRefundTransaction(String paymentMethod, String refundAmount, String reasonforRefund, String refundLocation) throws Exception {
		String formatedDate = FormatDate("dd-MMM-YY");
		WebDriverWait w = new WebDriverWait(driver, 120);
		w.until(ExpectedConditions.invisibilityOf(driver.findElement(By.xpath("//img[contains(@src,'spinner.gif')]"))));		
		waitForLoading(driver);	
		if(paymentMethod.toLowerCase().contains("credit")) paymentMethod="CreditCard";
		String refundTransactionPlusIcon="(//*[contains(text(),'"+formatedDate+"')]/parent::div/following-sibling::div/p[contains(text(),'Refund - "+paymentMethod+"')]/parent::div/following-sibling::div/p/span[contains(text(),'"+refundAmount+"')]/following::i[contains(@class,'plus-circle')])[1]";
		w.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(refundTransactionPlusIcon))));
		Assert.assertTrue(driver.findElements(By.xpath(refundTransactionPlusIcon)).size()!=0);	
		scrollToElementAndClick(driver.findElement(By.xpath(refundTransactionPlusIcon)), driver);
		Assert.assertTrue(driver.findElement(By.xpath("//b[contains(text(),'Location')]/parent::div/following-sibling::div/span[contains(text(),'"+refundLocation+"')]")).isDisplayed(), "Refund Location should be present");
		Assert.assertTrue(driver.findElement(By.xpath("//b[contains(text(),'Notes:')]/parent::div/following-sibling::div/span[contains(text(),'"+reasonforRefund+"')]")).isDisplayed(), "Reason for Refund should be present");
	}
	
	public void PaymentsandPreferences() throws Exception {
		if(driver.getTitle().contains("Web Tool"))
			driver.close();
//		WebUDRoutingChange
		if(HostUrls.webUDroutingChanges.contains("Yes")) switchtoWindow("| WebUD", driver);
		else switchtoWindow("Shaw", driver);
		waitForLoading(driver);
		scrollToElementAndClick(PaymentPref, driver);	
	}
	
	public void makePayment(String paymentMethod, String chequeNo, String chequeAmount, String cCProvince, String cCLocationCity, String cCLocation,
			String cCChannel) throws Exception {
		if(driver.getWindowHandle().contains("Pci Web"))
			driver.close();
//		WebUDRoutingChange
		if(HostUrls.webUDroutingChanges.contains("Yes")) switchtoWindow("| WebUD", driver);
		else switchtoWindow("Shaw", driver);
		waitForLoading(driver);	
		Actions action=new Actions(driver);
		action.moveToElement(btn_MakeaPayment).perform();
		btn_MakeaPayment.click();
		scrollToElement(PaymentMethod, driver);
		driver.findElement(By.xpath("//label[contains(text(),'Payment Method')]/following::div[@role='combobox']/parent::div/following-sibling::span")).click();
		driver.findElement(By.xpath("//label[contains(text(),'Payment Method:')]/following::div[@role='combobox']/following::span[@class='ng-option-label' and contains(text(),'"+paymentMethod+"')]")).click();
		switch(paymentMethod) {
		case "Cheque":
			enterValueInField(PaymentAmount, "0.00", driver);
			enterValueInField(PaymentAmount, chequeAmount, driver);
			enterValueInField(PaymentChequeNo, " ", driver);
			enterValueInField(PaymentChequeNo, chequeNo, driver);
			break;
		}
		selectElementFromDropdown(PaymentProvince, driver, "VisibleText", cCProvince);
		selectElementFromDropdown(PaymentCity, driver, "VisibleText", cCLocationCity);
		selectElementFromDropdown(PaymentLocation, driver, "VisibleText", cCLocation);
		selectElementFromDropdown(PaymentChannel, driver, "VisibleText", cCChannel);
	}
	
	public void submitPayment() throws Exception {
		scrollToElementAndClick(ProcessPayment, driver);	
		waitForLoading(driver);	
	}
	
	public void enterCreditCardDetailstoMakePayment(String payAmount, String cCNameOnCard, String cCNumber,
			String cCExpiry,String cCCVD, String saveCard) throws Exception { 
		waitForLoading(driver);	
		switchtoWindow("Web Tool |", driver);
		driver.manage().window().maximize();
		WebDriverWait w = new WebDriverWait(driver, 90);
//		while(!(driver.findElements(By.xpath("//*[contains(@value,'Print Receipt')]")).size()!=0))
//		{	
			driver.navigate().refresh();
			waitForLoading(driver);	
			scrollToElementAndClick(radiobtn_CreditCardPayAmount, driver);
			enterValueInField(CreditCardPayAmountValue, "0.00", driver);
			enterValueInField(CreditCardPayAmountValue, "2.00", driver);
			if(!(radio_NewCreditCard.isSelected()))
			scrollToElementAndClick(radio_NewCreditCard, driver);
			scrollToElementAndClick(CreditCardOwner, driver);
			Actions action=new Actions(driver);
			action.moveToElement(CreditCardOwner).click().build().perform();
//			CreditCardOwner.click();
			scrollToElement(driver.findElement(By.xpath("//*[text()='The minimum amount allowed is $3.']")), driver);
			Assert.assertTrue(driver.findElement(By.xpath("//*[text()='The minimum amount allowed is $3.']")).isDisplayed(), "Error Meassage should be present");
			enterValueInField(CreditCardPayAmountValue, "0.00", driver);
			enterValueInField(CreditCardPayAmountValue, payAmount, driver);	
			enterValueInField(CreditCardOwner, cCNameOnCard, driver);	
			driver.switchTo().frame("bambora-card-number-iframe");
			enterValueInField(CreditCardNumber, cCNumber, driver);	
			driver.switchTo().parentFrame();
			driver.switchTo().frame("bambora-expiry-iframe");
			enterValueInField(CreditCardExpiry, cCExpiry, driver);
			driver.switchTo().parentFrame();
			driver.switchTo().frame("bambora-cvv-iframe");
			enterValueInField(CreditCardCVD, cCCVD, driver);	
			driver.switchTo().parentFrame();
			if(saveCard.toLowerCase().contains("yes")) SaveCreditCard.click();
			btn_CreditCardPayNow.click();
			w.until(ExpectedConditions.invisibilityOfAllElements(driver.findElements(By.xpath("//*[contains(@class,'loader')]"))));
			waitForLoading(driver);				
//		}
//		w.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath("//*[contains(@id,'printReceipt')]"))));
//		String PaymentStatus = driver.findElement(By.xpath("//*[contains(@id,'printReceipt')]/parent::div/parent::div/preceding-sibling::div")).getText();
//		if(PaymentStatus.contains("Successfully paid"))
//			Assert.assertTrue(driver.findElement(By.xpath("//*[contains(text(),'Successfully paid $"+payAmount+"')]")).isDisplayed(), "Successful payment should be present");
//		else
//			Assert.assertFalse(driver.findElement(By.xpath("//*[contains(text(),'Payment was not successful.')]")).isDisplayed(), PaymentStatus);	
	}
	
	public void validatePaymentProcessing(String payAmount) throws Exception {
		WebDriverWait w = new WebDriverWait(driver, 120);
		w.until(ExpectedConditions.invisibilityOfAllElements(driver.findElements(By.xpath("//img[contains(@src,'spinner.gif')][1]"))));			
		waitForLoading(driver);		
		w.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath("//*[contains(text(),'Refund of $"+payAmount+" Processed Successfully.')]"))));
		scrollToElement(driver.findElement(By.xpath("//*[contains(text(),'Refund of $"+payAmount+" Processed Successfully.')]")), driver);
		Assert.assertTrue(driver.findElement(By.xpath("//*[contains(text(),'Refund of $"+payAmount+" Processed Successfully.')]")).isDisplayed(), "Refund Amount Processed Successfully should be present");
	}
	
	public String validatePaymentTransaction(String paymentMethod, String payAmount, String cCLocation, String webUDusername) throws Exception {
		String formatedDate = FormatDate("dd-MMM-YY");
		String TransactionID="";
		WebDriverWait w = new WebDriverWait(driver, 120);
		w.until(ExpectedConditions.invisibilityOfAllElements(driver.findElements(By.xpath("//img[contains(@src,'spinner.gif')][1]"))));			
		waitForLoading(driver);	
		String paymentTransactionPlusIcon;
		scrollToElementAndClick(Refresh, driver);
		waitForLoading(driver);	
		scrollToElementAndClick(Billing, driver);
		scrollToElementAndClick(Transactions, driver);
		waitForLoading(driver);	
		if (driver.findElements(By.xpath("(//*[contains(@id,'transaction')]/descendant::table/descendant::*[contains(text(),'"+formatedDate+"')]/parent::div/following-sibling::div/p[contains(text(),'Payment')]/parent::div/following-sibling::div/p/span[contains(text(),'"+payAmount+"')]/following::i[contains(@class,'plus-circle')])[1]")).size()!=0)
		{
			paymentTransactionPlusIcon="(//*[contains(@id,'transaction')]/descendant::table/descendant::*[contains(text(),'"+formatedDate+"')]/parent::div/following-sibling::div/p[contains(text(),'Payment - "+paymentMethod+"')]/parent::div/following-sibling::div/p/span[contains(text(),'"+payAmount+"')]/following::i[contains(@class,'plus-circle')])[1]";
			w.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(paymentTransactionPlusIcon))));
		}
		else
		{
			paymentTransactionPlusIcon="(//*[contains(@id,'transaction')]/descendant::table/descendant::*[contains(text(),'"+formatedDate+"')]/parent::div/following-sibling::div/p[contains(text(),'Payment')]/parent::div/following-sibling::div/p/span[contains(text(),'"+payAmount+"')]/following::i[contains(@class,'plus-circle')])[1]";
			w.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(paymentTransactionPlusIcon))));
		}		
		Assert.assertTrue(driver.findElements(By.xpath(paymentTransactionPlusIcon)).size()!=0);	
		scrollToElementAndClick(driver.findElement(By.xpath(paymentTransactionPlusIcon)), driver);
		isLoaderSpinnerVisible(driver);
		waitForLoading(driver);	
		System.out.println(paymentMethod.trim().equalsIgnoreCase("Credit Card") && webUDusername.trim().equalsIgnoreCase("lruser003"));
		if(paymentMethod.trim().equalsIgnoreCase("Credit Card") && webUDusername.trim().equalsIgnoreCase("lruser003"))
			Assert.assertTrue(driver.findElement(By.xpath("//th[contains(text(),'Source')]/following::tr[1]/td[3]/span[contains(text(),'"+cCLocation+"')]")).isDisplayed(), "Payment Location should be present");
		else if(paymentMethod.trim().equalsIgnoreCase("Credit Card") && !webUDusername.trim().equalsIgnoreCase("lruser003"))
			Assert.assertTrue(driver.findElement(By.xpath("//th[contains(text(),'Source')]/following::tr[1]/td[3][contains(text(),'ECOM')]")).isDisplayed(), "Payment Location should be present");
		else
			Assert.assertTrue(driver.findElement(By.xpath("//th[contains(text(),'Source')]/following::tr[1]/td[3]/span[contains(text(),'"+cCLocation+"')]")).isDisplayed(), "Payment Location should be present");
		if(!(paymentMethod=="Cash"))
		{
			TransactionID=driver.findElement(By.xpath("//th[contains(text(),'Transaction ID')]/following::tr[1]/td[1]")).getText();
			System.out.println(TransactionID);
		}
		return TransactionID; 
	}
	
	public void selectReversePayment(String payAmount, String paymentMethod) throws Exception {
		String formatedDate = FormatDate("dd-MMM-YY");
		scrollToElementAndClick(btn_ReversePayment, driver);
		scrollToElementAndClick(btn_ReversePayment_Yes, driver);
		if(driver.findElements(By.xpath("//*[contains(text(),'Reversal of Payment - "+paymentMethod+" -"+payAmount+" made on "+formatedDate+"')]")).size()!=0)
			Assert.assertTrue(driver.findElement(By.xpath("//*[contains(text(),'Reversal of Payment - "+paymentMethod+" -"+payAmount+" made on "+formatedDate+"')]")).isDisplayed(), "Reversal message should be present");
		else
			Assert.assertTrue(driver.findElement(By.xpath("//*[contains(text(),'Reversal of Payment -"+payAmount+" made on "+formatedDate+"')]")).isDisplayed(), "Reversal message should be present");
	}
	
	public void reversePayment(String reversalReason) throws Exception {
		selectElementFromDropdown(driver.findElement(By.xpath("//*[contains(text(),'Reverse Payment')]/following::p[contains(text(),'Reason:')]/following::select")), driver, "VisibleText", reversalReason);
		scrollToElementAndClick(btn_ConfirmReversePayment, driver);
	}

//	public String getPaymentTransactionID(String Amount, String PaymentMethod) throws Exception {
//		String formatedDate = FormatDate("dd-MMM-YY");
//		WebDriverWait w = new WebDriverWait(driver, 120);
//		w.until(ExpectedConditions.invisibilityOfAllElements(driver.findElements(By.xpath("//img[contains(@src,'spinner.gif')]"))));		
//		waitForLoading(driver);				
//		String TransactionPlusIcon="(//*[contains(text(),'"+formatedDate+"')]/parent::div/following-sibling::div/p[contains(text(),'Payment - "+PaymentMethod+"')]/parent::div/following-sibling::div/p/span[contains(text(),'"+Amount+"')]/following::i[contains(@class,'plus-circle')])[1]";
//		w.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(TransactionPlusIcon))));
//		Assert.assertTrue(driver.findElements(By.xpath(TransactionPlusIcon)).size()!=0);	
//		scrollToElementAndClick(driver.findElement(By.xpath(TransactionPlusIcon)), driver);
//		String TransactionID=driver.findElement(By.xpath("//th[contains(text(),'Transaction ID')]/following::tr[1]/td[1]")).getText();
//		return TransactionID;
//	}
	public void validateReversedPayment(String TransactionID, String reversalReason, String payAmount) throws Exception {
		String formatedDate = FormatDate("dd-MMM-YY");
		isLoaderSpinnerVisible(driver);	//AddedShweta
		waitForLoading(driver);	
		WebDriverWait w = new WebDriverWait(driver, 120);
		w.until(ExpectedConditions.invisibilityOfAllElements(driver.findElements(By.xpath("//img[contains(@src,'spinner.gif')]"))));
		waitForLoading(driver);	
		scrollToElement(driver.findElement(By.xpath("(//*[contains(text(),'Payment - Reversal')])[1]")), driver);
//		w.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("(//*[contains(text(),'Payment - Reversal')])[1]"))));
		String paymentTransactionPlusIcon="(//*[contains(text(),'"+formatedDate+"')]/parent::div/following-sibling::div/p[contains(text(),'Payment - Reversal')]/parent::div/following-sibling::div/p/span[contains(text(),'"+payAmount+"')]/following::i[contains(@class,'plus-circle')])[1]";
		w.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(paymentTransactionPlusIcon))));
		Assert.assertTrue(driver.findElements(By.xpath(paymentTransactionPlusIcon)).size()!=0);	
		scrollToElementAndClick(driver.findElement(By.xpath(paymentTransactionPlusIcon)), driver);	
		isLoaderSpinnerVisible(driver);	//AddedShweta
		waitForLoading(driver);
		String strTransactionID=driver.findElement(By.xpath("//th[contains(text(),'Transaction ID')]/following::tr[1]/td[1]")).getText();
		if (TransactionID.contains(strTransactionID))
			Assert.assertTrue(driver.findElement(By.xpath("//th[contains(text(),'Transaction ID')]/following::tr[1]/td[3]")).getText().contains("MISAPPLIED PAYMENT"), "Payment should be reversed.");
		else
			Assert.fail("Payment with Transaction ID doesn't exist");
	}
	
	public void selectCreditCardProfile(String option) throws Exception {
		scrollToElementAndClick(Billing, driver);
		scrollToElementAndClick(PaymentPref, driver);
		scrollToElementAndClick(btn_CreditCardProfile, driver);	
		if(option.contains("CREATE"))scrollToElementAndClick(btn_CreateCreditCardProfile, driver);
		else if(option.contains("VERIFY"))scrollToElementAndClick(btn_VerifyCreditCardDetails, driver);
	}
	
	public String addCardtoCreditCardProfile(String emailOrMobile) throws Exception {
		waitForLoading(driver);
		switchtoWindow("Pci Web Tool |", driver);	
		driver.manage().window().maximize();
		WebDriverWait w = new WebDriverWait(driver, 120);
		String emailOrMobileOption[] = emailOrMobile.split(",");
		switch(emailOrMobileOption[0]) {
		case "Email":
			enterValueInField(AddCard_email, emailOrMobileOption[1], driver);
			AddCard_btnSendEmail.click();
			w.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath("//div[@id='messagePane']"))));
			Assert.assertTrue(driver.findElement(By.xpath("//*[contains(text(),'An email was successful')]")).isDisplayed(), "Email was submitted successfully");
			strMessagewithPCIURL=driver.findElement(By.xpath("//div[@id='messagePane']")).getText();
			break;
		case "Mobile":
			enterValueInField(AddCard_mobile, emailOrMobileOption[1], driver);
			AddCard_btnSendSMS.click();
			w.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath("//div[@id='messagePane']"))));
			Assert.assertTrue(driver.findElement(By.xpath("//*[@id=\"messagePane\"]/div[contains(text(),'A SMS was successfully submitted')]")).isDisplayed(), "SMS was submitted successfully");
			strMessagewithPCIURL=driver.findElement(By.xpath("//div[@id='messagePane']")).getText();
			System.out.println(strMessagewithPCIURL);
			break;
		}	
		return StringUtils.substringAfter(strMessagewithPCIURL, "URL sent is ");
	}
	
	public void setupCreditCardProfile(String get_PCIURL, String cCNameOnCard, String cCNumber, String cCExpiry, String cCCVD) throws Exception {
		launchPCIwebToolURL(get_PCIURL);
		WebDriverWait w = new WebDriverWait(driver, 120);
		w.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath("//*[contains(text(),'Set Up Credit Card Profile')]"))));
		enterValueInField(CreditCardOwner, cCNameOnCard, driver);	
		driver.switchTo().frame("bambora-card-number-iframe");
		enterValueInField(CreditCardNumber, cCNumber, driver);	
		driver.switchTo().parentFrame();
		driver.switchTo().frame("bambora-expiry-iframe");
		enterValueInField(CreditCardExpiry, cCExpiry, driver);	
		driver.switchTo().parentFrame();
		driver.switchTo().frame("bambora-cvv-iframe");
		enterValueInField(CreditCardCVD, cCCVD, driver);	
		driver.switchTo().parentFrame();
		scrollToElementAndClick(btn_AddCreditCard, driver);
		waitForLoading(driver);	
		w.until(ExpectedConditions.invisibilityOfAllElements(driver.findElements(By.xpath("//*[contains(@class,'loader')]"))));
		waitForLoading(driver);	
		if (driver.findElements(By.xpath("//*[contains(text(),'Successfully added card')]")).size()!=0)
		{
			scrollToElement(driver.findElement(By.xpath("//*[contains(text(),'Successfully added card')]")), driver);
			Assert.assertTrue(driver.findElement(By.xpath("//*[contains(text(),'Successfully added card')]")).isDisplayed(), "Card should be added successfully");
		}
	}
	
	public void validateCreatedCreditCardProfile(String profileCreationStatus) throws Exception {
		waitForLoading(driver);
		if(driver.getTitle().contains("Web Tool"))
			driver.close();
//		WebUDRoutingChange
		if(HostUrls.webUDroutingChanges.contains("Yes")) switchtoWindow("| WebUD", driver);
		else switchtoWindow("Shaw", driver);
		driver.switchTo().defaultContent();
		scrollToElementAndClick(Refresh, driver);
//		Refresh.click();
		waitForLoading(driver);
		while(!(driver.findElements(By.xpath("//span[contains(text(),'Credit Card Profile')]")).size()!=0))
		{		
		scrollToElement(Billing, driver);	
		scrollToElementAndClick(Refresh, driver);
		}
		WebDriverWait w = new WebDriverWait(driver, 120);
		profileCreationStatus = profileCreationStatus.replace("\"", "");
		switch(profileCreationStatus) {
		case "YES":
			waitForLoading(driver);
			w.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//span[contains(text(),'Credit Card Profile')]/i[contains(@class,'check')])[1]")));
//			w.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath("(//span[contains(text(),'Credit Card Profile')]/i[contains(@class,'check')])[1]"))));
			Assert.assertTrue(driver.findElement(By.xpath("(//span[contains(text(),'Credit Card Profile')]/i[contains(@class,'check')])[1]")).isDisplayed(), "Credit Card Profile should exist");
			break;
		case "NO":	
			waitForLoading(driver);	
			w.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//span[contains(text(),'Credit Card Profile')]/i[contains(@class,'ban')])[1]")));
			Assert.assertTrue(driver.findElement(By.xpath("(//span[contains(text(),'Credit Card Profile')]/i[contains(@class,'ban')])[1]")).isDisplayed(), "Credit Card Profile should not exist");
			break;
		}
		
	}
	public void enterEmailIdorMobiletomakePayment(String emailorSMS) throws Exception {
		waitForLoading(driver);	
		switchtoWindow("Pci Web Tool |", driver);
		driver.manage().window().maximize();
		driver.navigate().refresh();
		scrollToElementAndClick(radio_NewCreditCard, driver);
		String emailOrMobileOption[] = emailorSMS.split(",");
		switch(emailOrMobileOption[0]) {
		case "Email":
			enterValueInField(AddCard_email, emailOrMobileOption[1], driver);
			break;
		case "Mobile":
			enterValueInField(AddCard_mobile, emailOrMobileOption[1], driver);
			break;
		}		
	}
	public String validateEmailorSMSSubmissionandfetchURL(String emailorSMS) throws Exception {
		WebDriverWait w = new WebDriverWait(driver, 120);
		String emailOrMobileOption[] = emailorSMS.split(",");
		switch(emailOrMobileOption[0]) {
		case "Email":
			radio_NewCreditCard.click();
			btn_SendEmail.click();
			w.until(ExpectedConditions.invisibilityOfAllElements(driver.findElements(By.xpath("//*[contains(@class,'loader')]"))));
			waitForLoading(driver);	
			switchtoWindow("Pci Web Tool | Payment", driver);	
			waitForLoading(driver);
			w.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath("//*[contains(@value,'Make Another Payment')]"))));
			while(!driver.findElement(By.xpath("//*[contains(text(),'An email was successful')]")).isDisplayed())
			{	
				waitForLoading(driver);
			}			
			Assert.assertTrue(driver.findElement(By.xpath("//*[contains(text(),'An email was successful')]")).isDisplayed(), "Email was submitted successfully");
			strMessagewithPCIURL=driver.findElement(By.xpath("//*[contains(text(),'An email was successful')]")).getText();
			break;
		case "Mobile":
			radio_NewCreditCard.click();
			btn_SendSMS.click();
			waitForLoading(driver);	
			w.until(ExpectedConditions.invisibilityOfAllElements(driver.findElements(By.xpath("//*[contains(@class,'loader')]"))));
			waitForLoading(driver);	
			switchtoWindow("Pci Web Tool | Payment", driver);	
			waitForLoading(driver);	
			isLoaderSpinnerVisible(driver);	//AddedShweta
			waitForLoading(driver);	
			while(!driver.findElement(By.xpath("//*[contains(text(),'A SMS was successfully submitted')]")).isDisplayed())
			{	
				waitForLoading(driver);
			}
			Assert.assertTrue(driver.findElement(By.xpath("//*[contains(text(),'A SMS was successfully submitted')]")).isDisplayed(), "SMS was submitted successfully");
			strMessagewithPCIURL=driver.findElement(By.xpath("//*[contains(text(),'A SMS was successfully submitted')]")).getText();				
			break;
		}	
		return StringUtils.substringAfter(strMessagewithPCIURL, "URL sent is ");		
	}
	
	public void launchPCIwebToolURL(String get_PCIURL) throws Exception {
		System.out.println(get_PCIURL);
		driver.get(get_PCIURL);
		switchtoWindow("Pci Web Tool |", driver);			
	}

	public void enterCreditCardDetailstoMakeOneTimePayment(String payAmount, String cCNameOnCard, String cCNumber,
			String cCExpiry,String cCCVD) throws Exception { 
		waitForLoading(driver);
		switchtoWindow("Pci Web Tool |", driver);
		enterValueInField(CreditCardPayAmountValue, payAmount, driver);	
		enterValueInField(CreditCardOwner, cCNameOnCard, driver);	
		driver.switchTo().frame("bambora-card-number-iframe");
		enterValueInField(CreditCardNumber, cCNumber, driver);	
		driver.switchTo().parentFrame();
		driver.switchTo().frame("bambora-expiry-iframe");
		enterValueInField(CreditCardExpiry, cCExpiry, driver);	
		driver.switchTo().parentFrame();
		driver.switchTo().frame("bambora-cvv-iframe");
		enterValueInField(CreditCardCVD, cCCVD, driver);	
		driver.switchTo().parentFrame();
		scrollToElementAndClick(btn_CreditCardPayNow, driver);
		WebDriverWait w = new WebDriverWait(driver, 120);
		w.until(ExpectedConditions.invisibilityOfAllElements(driver.findElements(By.xpath("//*[contains(@class,'loader')]"))));
		waitForLoading(driver);	
		switchtoWindow("Pci Web Tool | Payment", driver);	
		waitForLoading(driver);	
		w.until(ExpectedConditions.visibilityOfAllElements(btn_PrintReceipt));
		String PaymentStatus = driver.findElement(By.xpath("//*[contains(@id,'printReceipt')]/parent::div/parent::div/preceding-sibling::div")).getText();
		System.out.println(PaymentStatus);
		if(PaymentStatus.contains("Successfully paid"))
			Assert.assertTrue(driver.findElement(By.xpath("//*[contains(text(),'Successfully paid $"+payAmount+"')]")).isDisplayed(), "Successful payment should be present");
		else
			Assert.assertFalse(driver.findElement(By.xpath("//*[contains(text(),'Payment was not successful.')]")).isDisplayed(), PaymentStatus);	
	}
	
	public void selectPreauthorizedPaymentandActivate(String paymentType) throws Exception {
		if(driver.getTitle().contains("Web Tool"))
			driver.close();
//		WebUDRoutingChange
		if(HostUrls.webUDroutingChanges.contains("Yes")) switchtoWindow("| WebUD", driver);
		else switchtoWindow("Shaw", driver);
		waitForLoading(driver);
		scrollToElementAndClick(btn_PreauthorizedPay, driver);	
		waitForLoading(driver);	
		selectElementFromDropdown(select_PreAuthPaymentType, driver, "VisibleText", paymentType);
		if(paymentType.contains("Bank Account"))
		{scrollToElementAndClick(btn_ActivatePreAuthPayment, driver);}		
	}
	
	public void submitPreauthorizedPaymentPlan(String BankOrInst, String BranchorTransit, String PreAuthAccount, String ReceiveInvoice) throws Exception {
		waitForLoading(driver);	
		if(driver.findElements(By.xpath("//input[@id='institutionNo']")).size()!=0)
		{
		enterValueInField(Bank_Inst, BankOrInst, driver);
		enterValueInField(Branch_Tansit, BranchorTransit, driver);
		enterValueInField(PreAuth_Account, PreAuthAccount, driver);
		}
		selectElementFromDropdown(select_ReceiveInvoice, driver, "VisibleText", ReceiveInvoice);
		if(PreAuth_Submit.isEnabled())
		scrollToElementAndClick(PreAuth_Submit, driver);
		else
			Assert.assertTrue(PreAuth_Submit.isEnabled(), "Pre-auth submit button is disabled");
	}
	
	public void validateenabledPreauthorizedPayment(String preauthoziedPayStatus) throws Exception {
		waitForLoading(driver);
		if(driver.getTitle().contains("Web Tool"))
			driver.close();
//		WebUDRoutingChange
		if(HostUrls.webUDroutingChanges.contains("Yes")) switchtoWindow("| WebUD", driver);
		else switchtoWindow("Shaw", driver);
		waitForLoading(driver);
		scrollToElement(Billing, driver);	
		waitForLoading(driver);
		WebDriverWait w = new WebDriverWait(driver, 120);
		switch(preauthoziedPayStatus) {
		case "YES":
			w.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath("(//span[contains(text(),'Preauthorized Payment')]/i[contains(@class,'check')])[1]"))));
			Assert.assertTrue(driver.findElement(By.xpath("(//span[contains(text(),'Preauthorized Payment')]/i[contains(@class,'check')])[1]")).isDisplayed(), "Preauthorized Payment should be enabled");
			break;
		case "NO":	
			w.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath("(//span[contains(text(),'Preauthorized Payment')]/i[contains(@class,'check')])[1]"))));
			Assert.assertTrue(driver.findElement(By.xpath("(//span[contains(text(),'Preauthorized Payment')]/i[contains(@class,'ban')])[1]")).isDisplayed(), "Preauthorized Payment should not be enabled");
			break;
		}
	}
	
	public void verifySavedCreditCard(String cCNumber) throws Exception {
		waitForLoading(driver);
		switchtoWindow("Pci Web Tool |", driver);
		driver.manage().window().maximize();
		String lastfourCCChar = cCNumber.substring(cCNumber.length() - 4);
		if(driver.findElements(By.xpath("//*[contains(text(),'Card was saved successfully to this account.')]")).size()>0)
			driver.findElement(By.xpath("//*[contains(@value,'Make Another Payment')]")).click();
		isLoaderSpinnerVisible(driver);
		scrollToElement(driver.findElement(By.xpath("//span[contains(text(),'"+lastfourCCChar+"')]")), driver);
		Assert.assertTrue(driver.findElement(By.xpath("//span[contains(text(),'"+lastfourCCChar+"')]")).isDisplayed(), "Preauthorized Payment should not be enabled");
	}
	
	public void verifyDeleteCreditCard(String cCNumber) throws Exception {
		waitForLoading(driver);
		switchtoWindow("Pci Web Tool |", driver);
		driver.manage().window().maximize();
		driver.navigate().refresh();
		waitForLoading(driver);	
		String lastfourCCChar = cCNumber.substring(cCNumber.length() - 4);
		scrollToElement(driver.findElement(By.xpath("//*[@title='Delete Credit Card']")), driver);
		Assert.assertTrue(driver.findElement(By.xpath("//*[@title='Delete Credit Card']/parent::span[contains(text(),'"+lastfourCCChar+"')]")).isDisplayed(), "Preauthorized Payment should not be enabled");
		scrollToElementAndClick(driver.findElement(By.xpath("//*[@title='Delete Credit Card']")), driver);
		waitForLoading(driver);	
		WebDriverWait w = new WebDriverWait(driver, 90);
		w.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'successfully deleted')]")));		
//		scrollToElement(driver.findElement(By.xpath("//*[contains(text(),'successfully deleted')]")), driver);
	}
	
	public void selectDelinquentTab() throws Exception {
		scrollToElementAndClick(Delinquent, driver);	
	}
	
	public void selectPaymentArrangementsTab() throws Exception {
		scrollToElementAndClick(PaymentArrangementsTab, driver);	
	}
	
	public void createPaymentArrangement(String method, String location, String expiryDate, String createNote) throws Exception {
		String getAmount=PayArr_Amount.getAttribute("value");
		selectElementFromDropdown(PayArr_Method, driver, "VisibleText", method);
		selectElementFromDropdown(PayArr_Location, driver, "VisibleText", location);
//		if(!expiryDate.isEmpty())		-----Check Later
		if(!createNote.isEmpty())
		{
			PayArr_Note.click();	
			enterValueInField(PayArr_CreateNote, createNote, driver);
		}
		PayArr_Create.click();
		waitForLoading(driver);
		isLoaderSpinnerVisible(driver);	//AddedShweta
		waitForLoading(driver);
		WebDriverWait w = new WebDriverWait(driver, 90);
		w.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//label[contains(text(),'Created By:')])/following::label[contains(text(),'"+getAmount+"')][1]/following::label[contains(text(),'"+method+"')]/following::label[contains(text(),'"+location+"')]")));
		Assert.assertTrue(driver.findElement(By.xpath("(//label[contains(text(),'Created By:')])/following::label[contains(text(),'"+getAmount+"')][1]/following::label[contains(text(),'"+method+"')]/following::label[contains(text(),'"+location+"')]")).isDisplayed(), "The details to be displayed correctly.");
		
	}
	public void editandvalidatePaymentArrangement(String method, String location, String expiryDate, String editNote) throws Exception {
		
		waitForLoading(driver);
		PayArr_EditArrangement.click();
		if(!method.isEmpty())
			selectElementFromDropdown(PayArr_EditMethod, driver, "VisibleText", method);
		if(!location.isEmpty())
			selectElementFromDropdown(PayArr_EditLocation, driver, "VisibleText", location);
//		if(!expiryDate.isEmpty())
//			enterValueInField(PayArr_ExpiryDate, expiryDate, driver);
		if(!editNote.isEmpty())	
			enterValueInField(PayArr_EditNote, editNote, driver);
		PayArr_SaveArrangement.click();
		waitForLoading(driver);
		scrollToElement(PayArr_Create, driver);
		WebDriverWait w = new WebDriverWait(driver, 90);
		w.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//label[contains(text(),'"+method+"')]/following::label[contains(text(),'"+location+"')]/following::label[contains(text(),'"+editNote+"')]")));
		Assert.assertTrue(driver.findElement(By.xpath("//label[contains(text(),'"+method+"')]/following::label[contains(text(),'"+location+"')]/following::label[contains(text(),'"+editNote+"')]")).isDisplayed(), "The details to be displayed correctly.");
	}
	
	public void makeMiscellaneousAccountAdjustment(String webUDusername, String adjustmentType, String adjustmentSubType, String adjustmentAmount,
			String adjustmentNotes) throws Exception {
		scrollToElementAndClick(MiscAccountAdjustment, driver);
		if(webUDusername.equalsIgnoreCase("lruser023") || webUDusername.equalsIgnoreCase("lruser002"))
		{
			selectElementFromDropdown(AdjustmentType, driver, "VisibleText", adjustmentType);
			if(adjustmentType.equalsIgnoreCase("Tax Adjustment")) selectElementFromDropdown(AdjustmentSubType, driver, "VisibleText", adjustmentSubType);
			enterValueInField(AdjustmentAmount, adjustmentAmount, driver);
			enterValueInField(AdjustmentNotes, adjustmentNotes, driver);
			tb.addScreenshot(driver, this.scenario, "Enter the details for Adjustment");
			btn_ApplyAdjustment.click();
			WebDriverWait w = new WebDriverWait(driver, 120);
			w.until(ExpectedConditions.invisibilityOfAllElements(driver.findElements(By.xpath("//img[contains(@src,'spinner.gif')][1]"))));	
			waitForLoading(driver);
			scrollToElement(driver.findElement(By.xpath("//div[contains(text(),'"+adjustmentType+"')]")), driver);
			Assert.assertTrue(driver.findElement(By.xpath("//div[contains(text(),'"+adjustmentType+"')]/following::span[contains(text(),'Transcation Successful')]")).isDisplayed(), "User should have permission to perform Tax adjustment.");
		}
		else
		{
			selectElementFromDropdown(AdjustmentType, driver, "VisibleText", adjustmentType);
		}
	}
	
	public void validateAdjustment(String webUDusername, String adjustmentType, String adjustmentSubType, String adjustmentAmount,
			String adjustmentNotes, String reasonCode, String adjustmentamountwithouttax) throws Exception {
		if(webUDusername.equalsIgnoreCase("lruser023") || webUDusername.equalsIgnoreCase("lruser002"))
		{		
			if(driver.findElements(By.xpath("//div[contains(text(),'"+adjustmentType+"')]/following::button[@class='adjust btn-sm' and text()='OK']")).size()!=0)
				scrollToElementAndClick(driver.findElement(By.xpath("//div[contains(text(),'"+adjustmentType+"')]/following::button[@class='adjust btn-sm' and contains(text(),'OK')")), driver);
//			driver.findElement(By.xpath("//div[contains(text(),'"+adjustmentType+"')]/following::button[@class='adjust btn-sm' and text()='OK']")).click();
			String formatedDate = FormatDate("dd-MMM-YY");
			WebUD_HomePage webudHomePage = new WebUD_HomePage(driver,this.scenario);
			String User= webudHomePage.getUser();
			WebDriverWait w = new WebDriverWait(driver, 120);
			w.until(ExpectedConditions.invisibilityOfAllElements(driver.findElements(By.xpath("//img[contains(@src,'spinner.gif')][1]"))));		
			waitForLoading(driver);	
			String paymentTransactionPlusIcon;
			if(adjustmentType.equalsIgnoreCase("Tax Adjustment"))
				paymentTransactionPlusIcon="(//*[contains(text(),'"+formatedDate+"')]/parent::div/following-sibling::div/p[contains(text(),'Adjustment - "+adjustmentSubType+" - "+adjustmentType+"')]/parent::div/following-sibling::div/p/span[contains(text(),'"+adjustmentAmount+"')]/following::i[contains(@class,'plus-circle')])[1]";
			else
				paymentTransactionPlusIcon="(//*[contains(text(),'"+formatedDate+"')]/parent::div/following-sibling::div/p[contains(text(),'Adjustment - "+adjustmentType+"')]/parent::div/following-sibling::div/p/span[contains(text(),'"+adjustmentAmount+"')]/following::i[contains(@class,'plus-circle')])[1]";	
			w.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(paymentTransactionPlusIcon))));
			Assert.assertTrue(driver.findElements(By.xpath(paymentTransactionPlusIcon)).size()!=0);	
			scrollToElementAndClick(driver.findElement(By.xpath(paymentTransactionPlusIcon)), driver);
			Assert.assertTrue(driver.findElement(By.xpath("//b[contains(text(),'Agent:')]/following::span[contains(text(),'"+User+"')]")).isDisplayed(), "Agent should be user with which we are logged in");
			waitForLoading(driver);	
			if(adjustmentType.equalsIgnoreCase("Tax Adjustment"))
				Assert.assertTrue(driver.findElement(By.xpath("//b[contains(text(),'Type:')]/following::span[contains(text(),'"+adjustmentSubType+" - "+adjustmentType+"')]")).isDisplayed(), "Agent should be have the Type as Tax Adjustment with selected Sub Type");
			else if (adjustmentType.equalsIgnoreCase("Current Monthly Services"))
			{
				String totalAdjustedAmount=driver.findElement(By.xpath("(//*[contains(text(),'"+formatedDate+"')]/parent::div/following-sibling::div/p[contains(text(),' Adjustment - "+adjustmentType+"')]/parent::div/following-sibling::div/p/span)[1]")).getText();
				String adjustmenttax=driver.findElement(By.xpath("//td[contains(text(),'Tax')]/following-sibling::td")).getText();
				double adjtax=Double.parseDouble(adjustmenttax);
				double adjwithouttax=Double.parseDouble(adjustmentamountwithouttax);
				double checktotalAdjustedAmount=adjwithouttax+adjtax;
				boolean Present = false;
				if(totalAdjustedAmount.contains(Double.toString(checktotalAdjustedAmount))) Present = true;
				Assert.assertEquals(Present, true);
				Assert.assertTrue(driver.findElement(By.xpath("//b[contains(text(),'Reason Code:')]/following::span[contains(text(),'"+reasonCode+"')]")).isDisplayed(), "Agent should be have the Reason Code given in example");
				Assert.assertTrue(driver.findElement(By.xpath("//b[contains(text(),'Notes:')]/following::span[contains(text(),'"+adjustmentNotes+"')]")).isDisplayed(), "Agent should be have the Type as Tax Adjustment with selected Sub Type");
				Assert.assertTrue(driver.findElement(By.xpath("//b[contains(text(),'Adjusted Items:')]/ancestor::div[2]/descendant::*[contains(text(),'"+adjustmentType+"')]")).isDisplayed(), "Agent should be have the Type as Tax Adjustment with selected Sub Type");
			}
			else
				Assert.assertTrue(driver.findElement(By.xpath("//b[contains(text(),'Type:')]/following::span[contains(text(),'"+adjustmentType+"')]")).isDisplayed(), "Agent should be have the Type as Tax Adjustment with selected Sub Type");
			Assert.assertTrue(driver.findElement(By.xpath("//b[contains(text(),'Notes:')]/following::span[contains(text(),'"+adjustmentNotes+"')]")).isDisplayed(), "Notes entered while doing Tax Adjustment should be displayed");
		}
		else
		{
			Assert.assertTrue(driver.findElement(By.xpath("//*[contains(text(),'User is unable to apply Tax Adjustment')]")).isDisplayed(), "lruser003 should not have permission to perform Tax adjustment.");
		}
	}
	
	public void performandvalidateAdjustmentReversal(String adjustmentType, String adjustmentSubType, String adjustmentAmount,
			String adjustmentNotes) throws Exception {
	
			scrollToElementAndClick(btn_ReverseAdjustment, driver);
			enterValueInField(ReversalNotes, adjustmentNotes, driver);
			scrollToElementAndClick(btn_ApplyReversal, driver);
			String formatedDate = FormatDate("dd-MMM-YY");
			WebUD_HomePage webudHomePage = new WebUD_HomePage(driver,this.scenario);
			String User= webudHomePage.getUser();
			WebDriverWait w = new WebDriverWait(driver, 120);
			w.until(ExpectedConditions.invisibilityOfAllElements(driver.findElements(By.xpath("//img[contains(@src,'spinner.gif')][1]"))));		
			waitForLoading(driver);	
			String paymentTransactionPlusIcon;
			if(adjustmentType.equalsIgnoreCase("Tax Adjustment"))
				paymentTransactionPlusIcon="(//*[contains(text(),'"+formatedDate+"')]/parent::div/following-sibling::div/p[contains(text(),'Adjustment - "+adjustmentSubType+" - "+adjustmentType+"')]/parent::div/following-sibling::div/p/span[contains(text(),'-"+adjustmentAmount+"')]/following::i[contains(@class,'plus-circle')])[1]";
			else
				paymentTransactionPlusIcon="(//*[contains(text(),'"+formatedDate+"')]/parent::div/following-sibling::div/p[contains(text(),'Adjustment - "+adjustmentType+"')]/parent::div/following-sibling::div/p/span[contains(text(),'-"+adjustmentAmount+"')]/following::i[contains(@class,'plus-circle')])[1]";	
			w.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(paymentTransactionPlusIcon))));
			Assert.assertTrue(driver.findElements(By.xpath(paymentTransactionPlusIcon)).size()!=0);	
			scrollToElementAndClick(driver.findElement(By.xpath(paymentTransactionPlusIcon)), driver);
			Assert.assertTrue(driver.findElement(By.xpath("//b[contains(text(),'Agent:')]/following::span[contains(text(),'"+User+"')]")).isDisplayed(), "Agent should be user with which we are logged in");
			if(adjustmentType.equalsIgnoreCase("Tax Adjustment"))
				Assert.assertTrue(driver.findElement(By.xpath("//b[contains(text(),'Type:')]/following::span[contains(text(),'"+adjustmentSubType+" - "+adjustmentType+"')]")).isDisplayed(), "Agent should be have the Type as Tax Adjustment with selected Sub Type");
			else
				Assert.assertTrue(driver.findElement(By.xpath("//b[contains(text(),'Type:')]/following::span[contains(text(),'"+adjustmentType+"')]")).isDisplayed(), "Agent should be have the Type as Tax Adjustment with selected Sub Type");
			Assert.assertTrue(driver.findElement(By.xpath("//b[contains(text(),'Notes:')]/following::span[contains(text(),'"+adjustmentNotes+"')]")).isDisplayed(), "Notes entered while doing Tax Adjustment should be displayed");
	}
	
	public String getBillAmountfromTransactionstab() throws Exception {
		WebDriverWait w = new WebDriverWait(driver, 120);
		w.until(ExpectedConditions.invisibilityOfAllElements(driver.findElements(By.xpath("//img[contains(@src,'spinner.gif')][1]"))));			
		waitForLoading(driver);	
		String paymentAmount="";
		if(driver.findElements(By.xpath("(//*[contains(text(),'Bill')]/parent::div/following-sibling::div/p/span)[1]")).size()!=0)
			paymentAmount="(//*[contains(text(),'Bill')]/parent::div/following-sibling::div/p/span)[1]";
		else if(driver.findElements(By.xpath("(//*[contains(text(),'Unbill')]/parent::div/following-sibling::div/p/span)[1]")).size()!=0)
			paymentAmount="(//*[contains(text(),'Unbill')]/parent::div/following-sibling::div/p/span)[1]";
		w.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath(paymentAmount))));
		String getAmount= driver.findElement(By.xpath(paymentAmount)).getText();
		double a =Double.parseDouble(getAmount);
		double amount = a-100.00;
		String payAmount = Double.toString(amount);
		return payAmount;
	}
	
	public void selectVerifyCreditCardDetails() throws Exception {
		scrollToElementAndClick(btn_VerifyCreditCardDetails, driver);
	}
	
	public void verifyExistingCardDetails(String cCNameOnCard, String cCNumber, String cCExpiry) throws Exception {
//		selectVerifyCreditCardDetails();
//		scrollToElementAndClick(btn_CreditCardProfile, driver);
		waitForLoading(driver);	
		switchtoWindow("Pci Web Tool |", driver);
		driver.manage().window().maximize();
		driver.navigate().refresh();
		waitForLoading(driver);	
		String lastfourCCChar = cCNumber.substring(cCNumber.length() - 4);
		Assert.assertTrue(driver.findElement(By.xpath("//div[contains(text(),'Card Number')]/following-sibling::div[contains(text(),'"+lastfourCCChar+"')]")).isDisplayed(), "Existing Card details should be present.");
		Assert.assertTrue(driver.findElement(By.xpath("//div[contains(text(),'Expiry Date')]/following-sibling::div[contains(text(),'"+cCExpiry+"')]")).isDisplayed(), "Existing Card details should be present.");
		Assert.assertTrue(driver.findElement(By.xpath("//div[contains(text(),'Name On Card')]/following-sibling::div[contains(text(),'"+cCNameOnCard+"')]")).isDisplayed(), "Existing Card details should be present.");
		
	}
	
	public void removeExistingCard(String strRemove) throws Exception {
		if(strRemove.contains("YES")) 
		{
			switchtoWindow("Pci Web Tool |", driver);
			driver.manage().window().maximize();
			driver.navigate().refresh();
			waitForLoading(driver);	
			scrollToElementAndClick(btn_RemoveCard, driver);
			scrollToElementAndClick(btn_deleteCreditCard, driver);
		}
	}
	
	public void edit_remove_PreauthorizedPayment(String strOption, String receiveInvoice) throws Exception {
		if(strOption.contains("Edit"))
		{
			if(driver.findElements(By.xpath("//*[text()='Edit']")).size()!=0)
			scrollToElementAndClick(edit_PreAuthPay, driver);
			receiveInvoice=receiveInvoice.replace("\"", "");
			selectElementFromDropdown(select_ReceiveInvoice, driver, "VisibleText", receiveInvoice);
			scrollToElementAndClick(cancelPreAuthChange, driver);
			if(driver.findElements(By.xpath("//*[text()='Edit']")).size()!=0)
			scrollToElementAndClick(edit_PreAuthPay, driver);
			selectElementFromDropdown(select_ReceiveInvoice, driver, "VisibleText", receiveInvoice);
			scrollToElementAndClick(savePreAuthChange, driver);
		}
		else if(strOption.contains("Remove")) 
		{
			scrollToElementAndClick(remove_PreAuthPay, driver);
			scrollToElementAndClick(removePreAuthWarningYes, driver);
		}
	}

	public String clickBillTransaction(String reasonCode, String notes) throws Exception
	{
		waitForLoading(driver);	
		scrollToElementAndClick(billTransaction, driver);
		try {
			if(currentMonthlyService.isDisplayed())
				scrollToElementAndClick(currentMonthlyService, driver);
		}catch(NoSuchElementException e) {
			scrollToElementAndClick(billTransaction, driver);
			scrollToElementAndClick(driver.findElement(By.xpath("(//p[contains(text(),'Bill')]/following::i)[2]")), driver);
			scrollToElementAndClick(currentMonthlyService, driver);
		}
		scrollToElementAndClick(selectAllCheckBox, driver);
		scrollToElementAndClick(AdjustItemsButton, driver);
		waitForLoading(driver);	
		driver.switchTo().defaultContent();
		Select reasonDropdown = new Select(driver.findElement(By.xpath("//div[@id='adjustitems0']//select")));
		reasonDropdown.selectByVisibleText(reasonCode);
		enterValueInField(inputNotes, notes, driver);
		String adjustmentamountwithouttax;
		adjustmentamountwithouttax=driver.findElement(By.xpath("//*[contains(text(),'Make An Adjustment to Current Monthly Services')]/parent::div/parent::div/descendant::*[contains(text(),'Total Adjustment')]/following-sibling::strong/span[1]")).getText();		
		scrollToElementAndClick(applyAdjustmentButton, driver);
		isLoaderSpinnerVisible(driver);	//AddedShweta
		if(driver.findElements(By.xpath("//*[contains(text(),'Adjustment failed')]")).size()!=0  ) {
				scrollToElementAndClick(cancelButton, driver);
				scrollToElementAndClick(Refresh, driver);	
				selectBillingtab();
				selectTransactionstab();
				clickBillTransaction(reasonCode, notes);	
				Assert.assertFalse(driver.findElements(By.xpath("//*[contains(text(),'Adjustment failed')]")).size()!=0);
		}
		isLoaderSpinnerVisible(driver);	//AddedShweta
		return adjustmentamountwithouttax;
	}

	public void clickRefundTab() throws Exception
	{
	    selectRefundstab();
	    scrollToElementAndClick(disconnectRefundPreference, driver);
	    scrollToElementAndClick(refundCheque, driver);
	    scrollToElementAndClick(disconnectRefundSave, driver);
	    driver.switchTo().frame("ncOrderEntry");
	}
	
	public void validateAdjustmentReversal(String reversalReason, String reasonCode) throws Exception {
		WebDriverWait w = new WebDriverWait(driver, 120);
		w.until(ExpectedConditions.invisibilityOfAllElements(driver.findElements(By.xpath("//img[contains(@src,'spinner.gif')][1]"))));		
		waitForLoading(driver);	
		isLoaderSpinnerVisible(driver);	//AddedShweta
		scrollToElementAndClick(driver.findElement(By.xpath("(//*[contains(text(),'Adjustment - Current Monthly Services')]/following::i)[1]")), driver);
		WebUD_HomePage webudHomePage = new WebUD_HomePage(driver,this.scenario);
		String User= webudHomePage.getUser();
		w.until(ExpectedConditions.invisibilityOfAllElements(driver.findElements(By.xpath("//img[contains(@src,'spinner.gif')][1]"))));		
		waitForLoading(driver);	
		Assert.assertTrue(driver.findElement(By.xpath("//b[contains(text(),'Agent:')]/following::span[contains(text(),'"+User+"')]")).isDisplayed(), "Agent should be user with which we are logged in");
		Assert.assertTrue(driver.findElement(By.xpath("//b[contains(text(),'Reason Code:')]/following::span[contains(text(),'"+reasonCode+"')]")).isDisplayed(), "Agent should be have the Reason Code given in example");
		Assert.assertTrue(driver.findElement(By.xpath("//b[contains(text(),'Notes:')]/following::span[contains(text(),'"+reversalReason+"')]")).isDisplayed(), "Agent should be have the Type as Tax Adjustment with selected Sub Type");
	}

	public void reverseAdjustment(String reversalReason) throws Exception {
		scrollToElementAndClick(btn_ReverseAdjustment, driver);
		enterValueInField(ReversalNotes, reversalReason, driver);		
		scrollToElementAndClick(btn_ApplyReversal, driver);			
	}
	
	
	public void selectFinancedevicetab() throws Exception {
		WebDriverWait w = new WebDriverWait(driver, 120);
		w.until(ExpectedConditions.visibilityOf(deviceFinacetab));
		scrollToElementAndClick(deviceFinacetab, driver);
		w.until(ExpectedConditions.visibilityOf(deviceFinace_doorbell));
		scrollToElementAndClick(deviceFinace_doorbell, driver);
		Thread.sleep(5000);
	}
	
	public String billingtab() throws Exception {
		
		WebDriverWait w = new WebDriverWait(driver, 90);
		waitForLoading(driver);
		driver.switchTo().defaultContent();
		w.until(ExpectedConditions.visibilityOf(Billing));
		Billing.click();		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,350)", "");
//		js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
		w.until(ExpectedConditions.elementToBeClickable(expandbill));
		scrollToElementAndClick(expandbill,driver);
		String billvalue = billingvalue.getText();
		System.out.println(billvalue);
		
		WebElement tbl = driver.findElement(By.xpath("//div[@class='tab-content inner-tabs-content']//table[@style='border: 0.5px ridge; margin-top: 10px; padding-left: 0px; overflow: auto; width: 100%;']"));
		List<WebElement> rows = tbl.findElements(By.tagName("tr"));
		for(int i=0; i<rows.size(); i++) {
		    List<WebElement> cols = rows.get(i).findElements(By.tagName("td"));
		    for(int j=0; j<cols.size(); j++) {
		        System.out.println(cols.get(0).getText());
		    }

		}
		
		return billvalue;
		}


}

