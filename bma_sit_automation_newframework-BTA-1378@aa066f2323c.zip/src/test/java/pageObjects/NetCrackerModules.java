package pageObjects;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import io.cucumber.java.Scenario;
import pageObjects.TestBase;
import stepDefinitions.StepData;

public class NetCrackerModules extends BaseUIPage{
	private WebDriver driver;
	public NetCrackerModules(WebDriver driver,Scenario scenario) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
		 this.sd=new StepData();			
		sd.setScenario(scenario);		
		this.scenario=sd.getScenario();
	}
	
	@FindBy(xpath = "//*[@id=\"user\"]")
	WebElement ncUserName;

	@FindBy(xpath = "//*[@role='button' and text()='Apply']")
	WebElement ncbtnApply;

	@FindBy(xpath = "//td/a[text()='Name']/ancestor::tr[1]/descendant::td[2]/descendant::a")
	WebElement ncfilterbyName;	
	
	@FindBy(xpath = "//td/a[text()='Customer Account Number']/ancestor::tr[1]/descendant::td[2]/descendant::a")
	WebElement ncfilterbyCustomerAccNo;	
	
	@FindBy(xpath = "//*[contains(@name,'inp')]")
	WebElement ncInputProjectName;	
	
	@FindBy(xpath = "//input[contains(@aria-labelledby,'filtering_label')]")
	WebElement ncCustomerAccountNumber;

	@FindBy(xpath = "(//select[@aria-labelledby='sorting_label'])[1]")
	WebElement ncfiltersorting;
	
	@FindBy(xpath = "//*[@id=\"fvalues\"]/li/a")
	WebElement ncFilterAccount;
	
	@FindBy(xpath = "//*[contains(text(),'Customer Orders')]/following::*[text()='Integration Report']")
	WebElement ncIntegrationReport;

	@FindBy(xpath = "//*[contains(text(),'360 View')]")
	WebElement nc360View;
	
	
	
	public void enterProjectName(String strprojectname) throws Exception {
		waitForLoading(driver);
//		ncInputProjectName.click();
//		WebDriverWait w = new WebDriverWait(driver, 120);
//		w.withMessage("Input field is not visible").until(ExpectedConditions.visibilityOf(ncInputProjectName));
//		waitForVisibilityOfElement(ncInputProjectName,driver);
		enterValueInField(ncInputProjectName, strprojectname, driver);
//		ncInputProjectName.sendKeys(strprojectname);
	}

	public void filterandselect_projectnameinNC(String strmodulename, String strprojectname) throws Exception {
		
		switch(strmodulename) {
		case "Documents":
			wait.withMessage("Time Out. Document Projects header is not present in the screen.").until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//h1/a[contains(text(),'Document Projects')]"))));
			scrollToElementAndClick(ncfilterbyName, driver);	
//			ncfilterbyName.click();
			enterProjectName(strprojectname);
			scrollToElementAndClick(ncbtnApply, driver);	
			WebDriverWait w = new WebDriverWait(driver, 120);
			isLoaderSpinnerVisible(driver);
			w.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//tr/descendant::*[contains(text(),'"+strprojectname+"')]"))));
//			ncbtnApply.click();
//			waitForVisibilityOfElement(driver.findElement(By.xpath("//tr/descendant::*[contains(text(),'"+strprojectname+"')]")),driver); 
//			driver.findElement(By.xpath("//tr/descendant::*[contains(text(),'"+strprojectname+"')]")).click();
			scrollToElementAndClick(driver.findElement(By.xpath("//tr/descendant::*[contains(text(),'"+strprojectname+"')]")), driver);
			waitForLoading(driver); 
		}
	}
	
	public ArrayList<String> fetchCustomerPronounsinNC() {
		List <WebElement> labels = driver.findElements(By.xpath("//table[contains(@aria-labelledby,'t9165883122013355702_0_title')]/descendant::td[@aria-readonly='true']/a"));
		ArrayList<String> Options = new ArrayList<String>();		
		for(int j=0;j<=labels.size()-1;j++) Options.add(labels.get(j).getText());
		return Options;
	}

	public void filterandselect_customeraccountnumberinNC(String accountnumber) throws Exception {
		wait.withMessage("Time Out. Document Projects header is not present in the screen.").until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//a[contains(text(),'Customer Accounts')]"))));
		scrollToElementAndClick(driver.findElement(By.xpath("//a[contains(text(),'Customer Accounts')]")), driver);
		waitForLoading(driver); 
		scrollToElementAndClick(ncfilterbyCustomerAccNo, driver);
		waitForLoading(driver); 
		selectElementFromDropdown(ncfiltersorting, driver, "VisibleText", "Customer Account Number");
		enterValueInField(ncCustomerAccountNumber, accountnumber, driver);
		scrollToElementAndClick(ncFilterAccount, driver);
		waitForLoading(driver); 
		scrollToElementAndClick(driver.findElement(By.xpath("//td/a[text()='Name']/ancestor::thead/following-sibling::tbody/descendant::td[2]/a")), driver);
	}

	public void view_IntegrationReport(String accountnumber, ArrayList<String> strCheckPronounsinIntReport) throws Exception {
		scrollToElementAndClick(nc360View, driver);
		while(!(driver.findElements(By.xpath("//*[contains(text(),'Customer Orders')]/following::*[text()='Integration Report']")).size()!=0))
		{
			driver.navigate().refresh();
			waitForLoading(driver); 
		}
		Assert.assertTrue(ncIntegrationReport.isDisplayed(), "Integration Report should be present");
		scrollToElementAndClick(ncIntegrationReport, driver);
		waitForLoading(driver); 
		strCheckPronounsinIntReport.size();
		for(int i=0;i<strCheckPronounsinIntReport.size();i++) 
			Assert.assertTrue(driver.findElements(By.xpath("//*[contains(@value,'"+strCheckPronounsinIntReport.get(i)+"')][1]")).size()!=0,"Pronoun added in WebUD should be present in NC");			
	}
	
}
