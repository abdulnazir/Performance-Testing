package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class TechConfirmPage extends BaseUIPage {

	private WebDriver driver;
    public TechConfirmPage(WebDriver driver) {
    	this.driver=driver;	
	PageFactory.initElements(driver, this);
    }

//    @FindBy(xpath = "//*[contains(text(),'New Customer Order')]")
//    WebElement ncNewCustomerOrder;
   
    @FindBy(xpath = "//tbody/tr[7]/td[2]/a/span")
    WebElement ncNewCustomerOrder;
    
  

    @FindBy(xpath = "//*[contains(text(),'Modify Customer Order')]")
    WebElement nc_modify_Customer_Order;

    @FindBy(xpath = "//*[contains(text(),'Tasks')]")
    WebElement nc_Task_Tab;

    @FindBy(xpath = "//*[@id=\"div_t9081206362013599750_9081206362013599751____9063044064013246277\"]/img")
    WebElement nc_Status_Filter;

    @FindBy(xpath = "//*[@id=\"attrIDDiv\"]/div[3]/input")
    WebElement nc_Status_Input;

    @FindBy(xpath = "//*[@id='fvalues']/li/a")
    WebElement nc_Waiting_Task;

    @FindBy(xpath = "//*[@id=\"t9081206362013599750_9081206362013599751_t\"]/tbody/tr/td[2]/a")
    WebElement nc_Tech_Confirm_Task;

    @FindBy(xpath = "//*[@id=\"t9081206362013599750_9081206362013599751_t\"]/tbody/tr/td[1]/label/input")
    WebElement nc_Tech_Confirm_Task_Checkbox;

    @FindBy(xpath = "//*[@id=\"9091657030013905523\"]")
    WebElement nc_MarkFinish;

    @FindBy(xpath = "//*[@id=\"manual-action-description\"]")
    WebElement nc_MarkFinish_Description_Box;

    @FindBy(xpath = "//*[@id=\"manual-action-submit-button\"]")
    WebElement nc_MarkFinish_Description_Box_Submit_Button;

    @FindBy(xpath = "//*[@id=\"t9081206362013599750_9081206362013599751_t\"]/tbody/tr[27]/td[2]/a")
    WebElement ncEffectiveDate;

    public void clickModifyCustomerOrder() {
	nc_modify_Customer_Order.click();
    }

    public void clickNewCustomerOrder() {
	ncNewCustomerOrder.click();
    }

    public void click_Nc_Task() {
	nc_Task_Tab.click();
    }

    public void clickNcStatusFiler() {
	nc_Status_Filter.click();
    }

    public void enterNcStatusInput() throws InterruptedException {
    	Thread.sleep(2000);
	nc_Status_Input.sendKeys("Waiting");
    }

    public void clickNcWaitingTask() throws InterruptedException {
    	Thread.sleep(5000);
	nc_Waiting_Task.click();
    }

    public void clickNcTechConfirmTask() {
	String expectedwaitingtask = "Wait for Tech Confirm";
	String actualwaitingtask = nc_Tech_Confirm_Task.getText();
	if (expectedwaitingtask.equals(actualwaitingtask)) {
	    nc_Tech_Confirm_Task_Checkbox.click();
	}
    }

    public void click_MarkFinish() throws InterruptedException {
	Thread.sleep(5000);
	nc_MarkFinish.click();
	Thread.sleep(5000);
	if(!prop.getProperty("matrix").equals("preprod"))
	{
	nc_MarkFinish_Description_Box.sendKeys("completing task");
	Thread.sleep(2000);
	nc_MarkFinish_Description_Box_Submit_Button.click();
	}
    }
}
