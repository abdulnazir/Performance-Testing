package pageObjects;

import javax.swing.JOptionPane;



import java.io.File;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.PageLoadStrategy;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriver.Timeouts;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
//import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;
import com.aventstack.extentreports.gherkin.model.ScenarioOutline;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import com.google.common.net.HostSpecifier;

//import org.openqa.selenium.remote.DesiredCapabilities;
import pageObjects.NetCrackerLoginPage;
import stepDefinitions.Hooks;

//import manager.pageObjectManager;

public class TestBase {

	public static WebDriver driver;
	public static Properties prop;
	public static Properties configprop;
	public static WebDriverWait wait;
	//public static pageObjectManager pageObjManager;

	@FindBy(xpath = "//div[@class='shadowDiv']")
	static WebElement loader;

	public TestBase() {

		ExtentSparkReporter spark = new ExtentSparkReporter("sparkreport");
		spark.config().setTheme(com.aventstack.extentreports.reporter.configuration.Theme.DARK);
		ExtentReports extent = new ExtentReports();
		extent.attachReporter(spark);

		FileInputStream fis = null;
		FileInputStream fmatrix = null;
		prop = new Properties();
		configprop = new Properties();

		try {
			fmatrix = new FileInputStream("System.getProperty(\"user.dir\")+\"\\\\src\\\\test\\\\resources\\\\matrix");
			prop.load(fmatrix);
			System.out.println(prop.getProperty("matrix"));
			try {
				fis = new FileInputStream(("user.dir")+"\\src\\test\\resources\\properties\\config_" + System.getProperty("environment")+ ".properties");
				configprop.load(fis);
				System.out.println(prop.getProperty("browser"));
			} catch (Exception e) {
				System.out.println("\n\n ERROR: ################     Config file not loaded ################ \n\n ");
				System.exit(1);
			}
//			fmatrix = new FileInputStream("D:\\BDDCucumberFramework\\src\\test\\resources\\matrix");
//			prop.load(fmatrix);
		} catch (Exception e) {
			System.out.println("\n\n ERROR: ################     Matrix file not loaded     ################ \n\n ");
			System.exit(1);
		}

//		if (TestBase.prop.getProperty("skipBackendValidations", "false").equalsIgnoreCase("true")) {
//			TestBase.prop.setProperty("skipCPE", "true");
//			TestBase.prop.setProperty("skipDSA", "true");
//			TestBase.prop.setProperty("skipFDB", "true");
//			TestBase.prop.setProperty("skipUIR", "true");
//			TestBase.prop.setProperty("skipXRAY", "true");
//		}

//		if (Hooks.chromeBrowser) {
//			TestBase.prop.setProperty("browser", "chrome");
//		}
//		if (Hooks.retailpickupCase) {
//			TestBase.prop.setProperty("selfinstall", "true");
//		}
	}

	public WebDriver initialization() {
		String browserName = System.getProperty("browser");
		System.out.println("browser name = " + browserName);

		if (browserName.equalsIgnoreCase("chrome")) {
			System.out.println("Chrome Browser is configured");
			System.setProperty("webdriver.chrome.driver", "src\\test\\resources\\drivers\\chromedriver.exe");

			ChromeOptions chromeOptions = new ChromeOptions();

			// chromeOptions.addArguments("--whitelisted-ips=''");
//			if (TestBase.prop.getProperty("isHeadless", "no").equalsIgnoreCase("yes")) {
//				System.out.println("\n\n####  Browser launched in headless mode  ####\n\n");
//				//addDebugInReport("Browser launched in headless mode");
//				chromeOptions.addArguments("--headless");
//				chromeOptions.addArguments("--window-size=" + prop.getProperty("headlessWindowSize", "1920x1080"));
//				chromeOptions.addArguments("--whitelisted-ips=''");
//				chromeOptions.addArguments("--start-maximized");
//			} else {
				chromeOptions.addArguments("--verbose");
				chromeOptions.addArguments("--whitelisted-ips=''");
				chromeOptions.addArguments("--start-maximized");
			//}
			chromeOptions.addArguments("--ignore-certificate-errors");
			chromeOptions.setPageLoadStrategy(PageLoadStrategy.NORMAL);
			chromeOptions.addArguments("--disable-gpu");
			chromeOptions.addArguments("--disable-extensions");
			chromeOptions.addArguments("--dns-prefetch-disable");
			// chromeOptions.addArguments("--incognito");
			chromeOptions.addArguments("enable-automation");
			chromeOptions.addArguments("--no-sandbox");
			// chromeOptions.addArguments("--window-size=1920,1080");
			chromeOptions.addArguments("--disable-features=VizDisplayCompositor"); // For future analysis of timeout
																					// error
			// chromeOptions.addArguments("--user-data-dir=C:/Users/lruser003/AppData/Local/Google/Chrome/User
			// Data/Profile 1");
			driver = new ChromeDriver(chromeOptions);

		} else if (browserName.equalsIgnoreCase("firefox")) {
//			FirefoxProfile ffprofile = new FirefoxProfile(new File("C:\\Users\\lruser003\\AppData\\Local\\Mozilla\\Firefox\\Profiles\\l8iubkts.default-release"));
//			ffoptions.setProfile(ffprofile);
//			ffprofile.setPreference("network.automatic-ntlm-auth.trusted-uris", "oss.lab");
			System.out.println("Firefox Browser is configured");
			FirefoxOptions ffoptions = new FirefoxOptions();
			if (TestBase.prop.getProperty("isHeadless", "no").equalsIgnoreCase("yes")) {
				System.out.println("\n\n####  Browser launched in headless mode  ####\n\n");
				ffoptions.addArguments("--width=1920");
				ffoptions.addArguments("--height=1080");
				//addDebugInReport("Browser launched in headless mode");
				//ffoptions.setHeadless(true);
			}
			System.setProperty("webdriver.gecko.driver", "src\\test\\resources\\drivers\\geckodriver.exe");
			driver = new FirefoxDriver(ffoptions);
			driver.manage().window().maximize();
		}

		TestBase.prop.setProperty("disablePhoneSteps",
				TestBase.prop.getProperty("disablePhoneSteps", "false").toLowerCase());

		wait = new WebDriverWait(driver, 180);
		driver.manage().deleteAllCookies();
		//driver.manage().timeouts().pageLoadTimeout(TestUtil.PAGE_LOAD_TIME, TimeUnit.SECONDS);

		driver.get(HostUrls.getNCUrl());

		//WebDriverRunner.setWebDriver(driver);
		//pageObjManager = new pageObjectManager(driver);
		//addInfoInReport("Browser = " + prop.getProperty("browser"));
	return driver;
	}

//	public static boolean getScreenshotFlag() {
//		boolean screenshotFlag = true;
//		screenshotFlag = Boolean.parseBoolean(prop.getProperty("screenshotFlag"));
//		return screenshotFlag;
//
//	}
//
//	private static void addURLAsTestLog(String pagetext) {
//		addURLAsTestLog(driver.getCurrentUrl(), pagetext);
//	}
//
//	private static void addURLAsTestLog(String url, String pagetext) {
//		String page_links = String.format(
//				"</br><div><span class='label green darken-4'><a href=' %s ' style='color:white'> Order Management Page </a></span> &nbsp&nbsp&nbsp&nbsp<span class='label green darken-4'>"
//						+ "<a href=' %s ' style='color:white'> Order Entry Page </a></span> &nbsp&nbsp&nbsp&nbsp<span class='label green darken-4'>"
//						+ "<a href=' %s ' style='color:white'> %s </a></span></div></br>",
//				HostUrls.getNCUrl(), HostUrls.getOEUrl(), url, pagetext);
//		//ExtentCucumberAdapter.addTestStepLog(page_links);
//	}
//
//	public static void lbackdoor() {
//		if (TestBase.prop.getProperty("lbackdoor", "false").equalsIgnoreCase("true")) {
//			JOptionPane.showMessageDialog(null, "Should I stay or should I go?");
//		}
//	}
//
//	public static void lbackdoor(String lmsg) {
//		if (TestBase.prop.getProperty("lbackdoor", "false").equalsIgnoreCase("true")) {
//			JOptionPane.showMessageDialog(null, lmsg);
//		}
//	}
//
//	public static void addURLInReport(String url, String pagetext) {
//		addURLAsTestLog(url, pagetext);
//	}
//
//	public static void addURLInReport(String pagetext) {
//		addURLAsTestLog(pagetext);
//	}
//
//	public static void addURLInReport() {
//		addURLAsTestLog("Current Page");
//	}
//
//	public static void manualStep(String message) {
////		ExtentCucumberAdapter
////				.addTestStepLog("</br><span class='label orange darken-4'>" + "Pending: " + message + "</span></br>");
//		throw new cucumber.api.PendingException();
//	}
//
//	public static void addCheckScreenshotMessage(String message) {
//		System.out.println("TookScreenShot : " + message);
//		//ExtentCucumberAdapter.addTestStepLog("</br><span class='label orange darken-4'>" + message + "</span></br>");
//	}
//
//	public static void addInfoInReport(String message) {
//		System.out.println("AddInfoInReport : " + message);
//		//ExtentCucumberAdapter.addTestStepLog("</br><span class='label blue darken-4'>" + message + "</span></br>");
//	}
//
//	public static void addInfoInReportOrange(String message) {
//		System.out.println("AddInfoInReport : " + message);
//		//ExtentCucumberAdapter.addTestStepLog("</br><span class='label orange darken-4'>" + message + "</span></br>");
//	}
//
//	public static void addDebugInReport(String message) {
//		if (TestBase.prop.getProperty("enableDebugStatements", "false").equalsIgnoreCase("true")) {
//			//ExtentCucumberAdapter.addTestStepLog("</br><span class='label blue darken-4'> "
//				//	+ LocalDateTime.now().toString() + " : " + message + "</span></br>");
//		}
//	}
//
//	public static void addErrorInReport(String message) {
//		System.out.println("AddErrorInReport : " + message);
//		//ExtentCucumberAdapter.addTestStepLog("</br><span class='label red darken-4'>" + message + "</span></br>");
//	}
//
//	public static void checkPageLoading() throws InterruptedException {
//		(new WebDriverWait(driver, 240)).withMessage("Page still loading")
//				.until(ExpectedConditions.invisibilityOf(loader));
//		Thread.sleep(1000);
//	}
//
////	public static void embedScreenshotInReport() throws InterruptedException {
////		try {
////			if (TestBase.prop.getProperty("waitForLoadingInScreenshot", "false").equalsIgnoreCase("true")) {
////				waitForLoading();
////			}
////			TakesScreenshot ts = (TakesScreenshot) driver;
////			String base64_image = "data:image/png;base64, " + ts.getScreenshotAs(OutputType.BASE64);
////			//ExtentCucumberAdapter.addTestStepScreenCaptureFromPath(base64_image);
////		} catch (IOException e) {
////			System.out.println(e.getMessage());
////		}
////	}
//
//	public static void takeScreenshot(String name) throws IOException, InterruptedException {
//
//		addDebugInReport("Counter = " + String.valueOf(Hooks.example_count));
//		TakesScreenshot ts = (TakesScreenshot) driver;
//		if (TestBase.prop.getProperty("screenshottype", "base64").equalsIgnoreCase("base64")) {
//			//TestBase.embedScreenshotInReport();
//		} else {
//			boolean screenshotFlag = TestBase.getScreenshotFlag();
//			if (screenshotFlag == true) {
//				if (TestBase.prop.getProperty("waitForLoadingInScreenshot", "false").equalsIgnoreCase("true")) {
//					waitForLoading();
//				}
//				File src = ts.getScreenshotAs(OutputType.FILE);
//				String dest = "test-output\\ScreenShots\\" + Hooks.scenarioName.replaceAll(" ", "_") + "\\" + name + "_"
//						+ Hooks.example_count++ + ".png";
//				File target = new File(dest);
//				FileUtils.copyFile(src, target);
//				//ExtentCucumberAdapter.addTestStepScreenCaptureFromPath(target.getAbsolutePath());
//			}
//		}
//	}
//
//	public static void waitForLoading() throws InterruptedException {
//		WebDriverWait lwait = new WebDriverWait(driver, 1);
//		for (int x = 0; x++ < 2;) {
//			try {
//				lwait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//div[@id='LOADER_DIV']"))));
//				break;
//			} catch (WebDriverException e) {
//				Thread.sleep(509);
//			}
//		}
//		for (int x = 0; x++ < 90;) {
//			try {
//				lwait.until(ExpectedConditions.invisibilityOf(driver.findElement(By.xpath("//div[@id='LOADER_DIV']"))));
//				break;
//			} catch (WebDriverException e) {
//				Thread.sleep(9);
//			}
//		}
//		Thread.sleep(2000);
//	}
//
//	public static void waitForSpinner() throws InterruptedException {
//		Thread.sleep(2000);
//		WebElement loadingText = driver.findElement(By.xpath("//*[@id=\"LOADER_DIV\"]/div/table/tbody/tr/td[2]"));
//		wait.withMessage("LoadingTab").until(ExpectedConditions.invisibilityOf(loadingText));
//	}
//
////	public static void waitUntilVisible(SelenideElement lelm) throws InterruptedException {
////		lelm.waitUntil(visible, 60000);
////		Thread.sleep(2000);
////	}
////
////	public static void waitUntilVisible(WebElement lelm) throws InterruptedException {
////		$(lelm).waitUntil(visible, 60000);
////		Thread.sleep(2000);
////	}
}
