package pageObjects;

import static com.codeborne.selenide.Selenide.*;

import java.io.IOException;
import java.time.Duration;
import java.time.Instant;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;



import util.TestUtil;

public class FFMPage extends BaseUIPage {

	private WebDriver driver;
	TestUtil utils;
	public FFMPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//*[@id=\"SearchText\"]")
	WebElement ffmSearchBox;

	@FindBy(xpath = "//*[@id=\"search-panel\"]/form/div[1]/span[2]/label")
	WebElement serviceCall;

	@FindBy(xpath = "//*[@id=\"submit\"]")
	WebElement searchButton;

	@FindBy(xpath = "//*[@id=\"job-summary-wrapper\"]/div/div[3]/div/div/div/span/a/span/span[1]")
	WebElement ffmactiveaccount;

	@FindBy(xpath = "//*[@id=\"changedservices\"]/div/div[2]")
	WebElement ffm_Hardware;

//	@FindBy(xpath = "//*[@id=\"job-details-wrapper\"]/div[7]/div[2]")
	@FindBy(xpath = "//div[starts-with(text(),'Hardware') and @class='title']")
	WebElement existing_Hardware;

	@FindBy(xpath = "//span[text()=\"HITRON\"]/ancestor::div[@class='mFMsc_ProvisioningItem']//a[text()=\"Return Hardware\"]")
	WebElement first_Return_Hardware;

	@FindBy(xpath = "//span[text()=\"MOTOROLA\"]/ancestor::div[@class='mFMsc_ProvisioningItem']//a[text()=\"Return Hardware\"]")
	WebElement second_Return_Hardware;

	@FindBy(xpath = "//span[text()=\"ARRIS\"]/ancestor::div[@class='mFMsc_ProvisioningItem']//a[text()=\"Return Hardware\"]")
	WebElement third_Return_Hardware;

	@FindBy(xpath = "//div[@class=\"mFMsc_ProvisioningItem\"]//div[contains(text(), 'XG1v4')]/ancestor::div[@class='leftEquipmentPanel']//div[contains(text(),'Enter Serial Number')]")
	WebElement Xg1V4_Enter_Serial_Number;

	@FindBy(xpath = "//div[@class=\"mFMsc_ProvisioningItem\"]//div[contains(text(), 'XG1v4')]/ancestor::div[@class='leftEquipmentPanel']//input[@id=\"SerialNumber\"]")
	WebElement Xg1V4_Serial_Number_Textbox;

	@FindBy(xpath = "//div[@class=\"mFMsc_ProvisioningItem\"]//div[contains(text(), 'XG1v4')]/ancestor::div[@class='leftEquipmentPanel']/div[2]/button")
	WebElement Xg1V4_Provision_button;

	@FindBy(xpath = "//div[@class=\"mFMsc_ProvisioningItem\"]//div[contains(text(), 'XB6')]/ancestor::div[@class='leftEquipmentPanel']//div[contains(text(),'Enter Serial Number')] | //div[@class='mFMsc_ProvisioningItem']//div[contains(text(), 'XB7')]/ancestor::div[@class='leftEquipmentPanel']//div[contains(text(),'Enter Serial Number')]")
	WebElement XB6_Enter_Serial_Number;

	@FindBy(xpath = "//div[@class=\"mFMsc_ProvisioningItem\"]//div[contains(text(), 'XB6')]/ancestor::div[@class='leftEquipmentPanel']//input[@id=\"SerialNumber\"] | //div[@class='mFMsc_ProvisioningItem']//div[contains(text(), 'XB7')]/ancestor::div[@class='leftEquipmentPanel']//input[@id='SerialNumber']")
	WebElement XB6_Serial_Number_Textbox;

	@FindBy(xpath = "//div[@class=\"mFMsc_ProvisioningItem\"]//div[contains(text(), 'XB6')]/ancestor::div[@class='leftEquipmentPanel']/div[2]/button | //div[@class='mFMsc_ProvisioningItem']//div[contains(text(), 'XB7')]/ancestor::div[@class='leftEquipmentPanel']/div[2]/button")
	WebElement XB6_Provision_button;

	@FindBy(xpath = "//div[@class=\"mFMsc_ProvisioningItem\"]//div[contains(text(), 'Hitron')]/ancestor::div[@class='leftEquipmentPanel']//div[contains(text(),'Enter Serial Number')]")
	WebElement hitron_Enter_Serial_Number;

	@FindBy(xpath = "//div[@class=\"mFMsc_ProvisioningItem\"]//div[contains(text(), 'Hitron')]/ancestor::div[@class='leftEquipmentPanel']//input[@id=\"SerialNumber\"]")
	WebElement hitron_Serial_Number_Textbox;

	@FindBy(xpath = "//div[@class=\"mFMsc_ProvisioningItem\"]//div[contains(text(), 'Hitron')]/ancestor::div[@class='leftEquipmentPanel']/div[2]/button")
	WebElement hitron_Provision_button;

	@FindBy(xpath = "//div[@class=\"mFMsc_ProvisioningItem\"]//div[contains(text(), 'Hitron')]/ancestor::div[@class='leftEquipmentPanel']//div[@class=\"mFMsc_ProvisioningItem mcPart_Error\"]")
	WebElement hitronmessage;

	@FindBy(xpath = "//div[@class=\"mFMsc_ProvisioningItem\"]//div[contains(text(), 'Hitron')]/ancestor::div[@class='leftEquipmentPanel']//button[@class=\"mb_SmallButton swapBtn\"]")
	WebElement hitronSwapButton;

	@FindBy(xpath = "//div[@class=\"mFMsc_ProvisioningItem\"]//div[contains(text(), 'XiD')]/ancestor::div[@class='leftEquipmentPanel']//div[contains(text(),'Enter Serial Number')]")
	WebElement XiD_Enter_Serial_Number;

	@FindBy(xpath = "//div[@class=\"mFMsc_ProvisioningItem\"]//div[contains(text(), 'XiD')]/ancestor::div[@class='leftEquipmentPanel']//input[@id=\"SerialNumber\"]")
	WebElement XiD_Serial_Number_Textbox;

	@FindBy(xpath = "//div[@class=\"mFMsc_ProvisioningItem\"]//div[contains(text(), 'XiD')]/ancestor::div[@class='leftEquipmentPanel']/div[2]/button")
	WebElement XiD_Provision_Button;

	@FindBy(xpath = "//div[@class=\"mFMsc_ProvisioningItem\"]//div[contains(text(), 'XG1v3')]/ancestor::div[@class='leftEquipmentPanel']//div[contains(text(),'Enter Serial Number')]")
	WebElement Xg1v3_Enter_Serial_Number;

	@FindBy(xpath = "//div[@class=\"mFMsc_ProvisioningItem\"]//div[contains(text(), 'XG1v3')]/ancestor::div[@class='leftEquipmentPanel']//input[@id=\"SerialNumber\"]")
	WebElement Xg1v3_Serial_Number_Textbox;

	@FindBy(xpath = "//div[@class=\"mFMsc_ProvisioningItem\"]//div[contains(text(), 'XG1v3')]/ancestor::div[@class='leftEquipmentPanel']/div[2]/button")
	WebElement Xg1v3_Provision_Button;

	@FindBy(xpath = "//*[@id=\"swapBtn2\"]/button")
	WebElement swapButton;

	@FindBy(xpath = "//div[text()='BlueCurve TV Wireless 4K Player - 418 (Fibre+ 150 and above + IPTV Mkt only)']/ancestor::div[@class='leftEquipmentPanel']//div[@class='mb_SmallButton' and contains(text(), 'Enter Serial Number')] | //div[@class='mFMsc_ProvisioningItem']//div[contains(text(), 'Xi6')]/ancestor::div[@class='leftEquipmentPanel']//div[contains(text(),'Enter Serial Number')]") 
	WebElement Xi6EnterSerialNumber;

	@FindBy(xpath = "//div[text()='BlueCurve TV Wireless 4K Player - 418 (Fibre+ 150 and above + IPTV Mkt only)']/ancestor::div[@class='leftEquipmentPanel']//input[@id='SerialNumber'] | //div[@class='mFMsc_ProvisioningItem']//div[contains(text(), 'Xi6')]/ancestor::div[@class='leftEquipmentPanel']//input[@id='SerialNumber']")
	WebElement Xi6SerialNumberTextBox;

	@FindBy(xpath = "//div[text()='BlueCurve TV Wireless 4K Player - 418 (Fibre+ 150 and above + IPTV Mkt only)']/ancestor::div[@class='leftEquipmentPanel']//button[@name='provisionEquipmentAction' and contains(text(), 'Provision & Activate')] | //div[@class='mFMsc_ProvisioningItem']//div[contains(text(), 'Xi6')]/ancestor::div[@class='leftEquipmentPanel']/div[2]/button")
	WebElement Xi6ProvisionButton;

	@FindBy(xpath = "//div[@class=\"mFMsc_ProvisioningItem\"]//div[contains(text(), 'DCX')]/ancestor::div[@class='leftEquipmentPanel']//div[contains(text(),'Enter Serial Number')]")
	WebElement DCX3400EnterSerialNumber;

	@FindBy(xpath = "//div[@class=\"mFMsc_ProvisioningItem\"]//div[contains(text(), 'DCX')]/ancestor::div[@class='leftEquipmentPanel']//input[@id=\"SerialNumber\"]")
	WebElement DCX3400SerialNumberTextBox;

	@FindBy(xpath = "//div[@class=\"mFMsc_ProvisioningItem\"]//div[contains(text(), 'DCX')]/ancestor::div[@class='leftEquipmentPanel']/div[2]/button")
	WebElement DCX3400ProvisionButton;

	@FindBy(xpath = "//div[@class=\"mFMsc_ProvisioningItem\"]//div[contains(text(), 'DCX')]/ancestor::div[@class='leftEquipmentPanel']//button[@class=\"mb_SmallButton swapBtn\"]")
	WebElement DCXSwapButton;

	@FindBy(xpath = "//div[@class=\"mFMsc_ProvisioningItem\"]//div[contains(text(), 'DCT')]/ancestor::div[@class='leftEquipmentPanel']//button[@class=\"mb_SmallButton swapBtn\"]")
	WebElement DCTSwapButton;

	@FindBy(xpath = "//div[@class=\"mFMsc_ProvisioningItem\"]//div[contains(text(), 'DCT')]/ancestor::div[@class='leftEquipmentPanel']//div[contains(text(),'Enter Serial Number')]")
	WebElement DCTEnterSerialNumber;

	@FindBy(xpath = "//div[@class=\"mFMsc_ProvisioningItem\"]//div[contains(text(), 'DCT')]/ancestor::div[@class='leftEquipmentPanel']//input[@id=\"SerialNumber\"]")
	WebElement DCTSerialNumberTextBox;

	@FindBy(xpath = "//div[@class=\"mFMsc_ProvisioningItem\"]//div[contains(text(), 'DCT')]/ancestor::div[@class='leftEquipmentPanel']/div[2]/button")
	WebElement DCTProvisionButton;

	@FindBy(xpath = "//*[@id='body']/section/form/div[2]/div[2]/p/input")
	WebElement updateBranchId;

	@FindBy(xpath = "//*[@id=\"FFMMobileLocal_SharedNavigation\"]/ul/li[1]/a/span")
	WebElement searchOrderButton;

	@FindBy(xpath = "//div[@class=\"mFMsc_ProvisioningItem\"]//div[contains(text(), 'XB6')]/ancestor::div[@class='leftEquipmentPanel']//div[@class=\"mFMsc_ProvisioningItem mcPart_Success\"]")
	WebElement XB6ProvisionMessage;

	@FindBy(xpath = "//*[@id=\"job-details-wrapper\"]/div[1]/div[text()=\"Post\"]")
	WebElement postButton;

	@FindBy(xpath = "//*[@id=\"post-notes-container\"]/div/div[2]/textarea")
	WebElement postTextArea;

	@FindBy(xpath = "//*[@id=\"completion-code\"]")
	WebElement tbcCode;

	@FindBy(xpath = "//*[@id=\"submit-order-button\"]")
	WebElement postCode;

	@FindBy(xpath = "//*[@id=\"job-details-wrapper\"]/div[2]/div[text()=\"Activation\"]")
	WebElement activationButton;

	@FindBy(xpath = "//*[@id=\"completionButtonsContainer\"]/button[text()=\"Start/Update Billing\"]")
	WebElement startUpdateBilling;

//	@FindBy(xpath = "//div[@class=\"mFMsc_ProvisioningItem\"]//div[contains(text(), 'Phone')]/ancestor::div[@class='leftEquipmentPanel']//div[contains(text(),'Enter Serial Number')] | //div[text()='Home Phone Terminal']/ancestor::div[@class='leftEquipmentPanel']//div[@class='mb_SmallButton' and contains(text(), 'Enter Serial Number')]")
//	WebElement phoneEnterSerialNumber;
	
	@FindBy(xpath = "//div[text()='Home Phone Terminal']/ancestor::div[@class='leftEquipmentPanel']//div[@class='mb_SmallButton' and contains(text(), 'Enter Serial Number')]")
	WebElement phoneEnterSerialNumber;

//	@FindBy(xpath = "//div[@class=\"mFMsc_ProvisioningItem\"]//div[contains(text(), 'Phone')]/ancestor::div[@class='leftEquipmentPanel']//input[@id=\"SerialNumber\"] | //div[text()='Home Phone Terminal']/ancestor::div[@class='leftEquipmentPanel']//input[@id='SerialNumber']")
//	WebElement phoneSerialNumberTextBox;
	
	@FindBy(xpath = "//div[text()='Home Phone Terminal']/ancestor::div[@class='leftEquipmentPanel']//input[@id='SerialNumber']")
	WebElement phoneSerialNumberTextBox;

//	@FindBy(xpath = "//div[@class=\"mFMsc_ProvisioningItem\"]//div[contains(text(), 'Phone')]/ancestor::div[@class='leftEquipmentPanel']/div[2]/button | //div[text()='Home Phone Terminal']/ancestor::div[@class='leftEquipmentPanel']//button[@name='provisionEquipmentAction' and contains(text(), 'Provision & Activate')]")
//	WebElement phoneProvisionButton;
	
	@FindBy(xpath = "//div[text()='Home Phone Terminal']/ancestor::div[@class='leftEquipmentPanel']//button[@name='provisionEquipmentAction' and contains(text(), 'Provision & Activate')]")
	WebElement phoneProvisionButton;
	
//	@FindBy(xpath = "//*[@id='dropdownSerialNumberDiv1011']/div[@class='inputSwitcher mb_LinkButton']/div")
//	WebElement XB7_Enter_Serial_Number;	
	
	@FindBy(xpath = "//div[text()='Rental Ignite WiFi Gateway (Gen 2) modem (XB7)']/ancestor::div[@class='leftEquipmentPanel']//div[@class='mb_SmallButton' and contains(text(), 'Enter Serial Number')]")
	WebElement XB7_Enter_Serial_Number;	
	
//	@FindBy(xpath = "//*[@id='inputFields1011']/div[@class='textSerialNumberDiv']/div/input[@id='SerialNumber']")
//	WebElement XB7_Serial_Number_Textbox;

	@FindBy(xpath = "//div[text()='Rental Ignite WiFi Gateway (Gen 2) modem (XB7)']/ancestor::div[@class='leftEquipmentPanel']//input[@id='SerialNumber']")
	WebElement XB7_Serial_Number_Textbox;
	
//	@FindBy(xpath = "//*[@id='provisionBtn1011']")
//	WebElement XB7_Provision_button;
	@FindBy(xpath = "//div[text()='Rental Ignite WiFi Gateway (Gen 2) modem (XB7)']/ancestor::div[@class='leftEquipmentPanel']//button[@name='provisionEquipmentAction' and contains(text(), 'Provision & Activate')]")
	WebElement XB7_Provision_button;
	
//	@FindBy(xpath="//*[@id='lblEquipmentInformationSerialNumber1011']")
//	WebElement Xb7SerialNumber;
	
//	@FindBy(xpath="//div[text()='Rental Ignite WiFi Gateway (Gen 2) modem (XB7)']/ancestor::div[@class='leftEquipmentPanel']//span[contains(@id, 'lblEquipmentInformationSerialNumber')]")
//	WebElement Xb7SerialNumber;
	
	@FindBy(xpath="//div[text()='Rental Ignite WiFi Gateway (Gen 2) modem (XB7)']/ancestor::div[@class='leftEquipmentPanel']//span[contains(@id, 'lblEquipmentInformationSerialNumber')]")
	WebElement Xb7SerialNumber;
	
	//div[text()='Rental Ignite WiFi Gateway (Gen 2) modem (XB7)']/ancestor::div[@class='leftEquipmentPanel']//input[@id='SerialNumber']
//	@FindBy(xpath="//*[@id='lblEquipmentInformationSerialNumber1004']")
//	WebElement Xi6SerialNumber;
	
	@FindBy(xpath="//div[text()='Ignite Entertainment Box (Xi6/XiOne) - 418']/ancestor::div[@class='leftEquipmentPanel']//span[contains(@id, 'lblEquipmentInformationSerialNumber')]")
	WebElement Xi6SerialNumber;
	
	@FindBy(xpath = "//div[text()='Legacy Fibre Modem (310)']/ancestor::div[@class='leftEquipmentPanel']//div[@class='mb_SmallButton' and contains(text(), 'Enter Serial Number')]")
	WebElement FibreModem_Enter_Serial_Number;	
	
	@FindBy(xpath = "//div[text()='Legacy Fibre Modem (310)']/ancestor::div[@class='leftEquipmentPanel']//input[@id='SerialNumber']")
	WebElement FibreModem_Serial_Number_Textbox;
	
	@FindBy(xpath = "//*[@id='provisionBtn1003'] | //div[text()='Legacy Fibre Modem (310)']/ancestor::div[@class='leftEquipmentPanel']//button[@name='provisionEquipmentAction' and contains(text(), 'Provision & Activate')]")
	WebElement FibreModem_Provision_button;
	
	@FindBy(xpath="//div[text()='Legacy Fibre Modem (310)']/ancestor::div[@class='leftEquipmentPanel']//span[contains(@id, 'lblEquipmentInformationSerialNumber')]")
	WebElement fibreModemSerialNumber;
	
	@FindBy(xpath="//div[text()='Home Phone Terminal']/ancestor::div[@class='leftEquipmentPanel']//span[contains(@id, 'lblEquipmentInformationSerialNumber')]")
	WebElement PhoneSerialNumber;

	public void postTBCCode() throws IOException, InterruptedException {
		postButton.click();
		postTextArea.sendKeys("TechOrder");
		tbcCode.sendKeys("099");
		postCode.click();
		//TestBase.takeScreenshot("postcode");
		activationButton.click();
		startUpdateBilling.click();
		driver.switchTo().alert().accept();
		//TestBase.takeScreenshot("ffmactivation");
	}

	public void enterWorkOrderNumber(String workordernumber) throws Exception {
//		Thread.sleep(5000);
	//	workordernumber="WO0000013100188";
		enterValueInField(ffmSearchBox, workordernumber, driver);
//		ffmSearchBox.sendKeys(workordernumber);
	}

	public void clickSearchButton() {
		searchButton.click();
	}

	public void clickSwapButton() throws IOException, InterruptedException {
		swapButton.click();
		//TestBase.takeScreenshot("FFMHardwareSwap");
	}

	public void clickDCXSwapButton() {
		DCXSwapButton.click();
	}

	public void clickActiveAccount() throws Exception {
		scrollToElementAndClick(ffmactiveaccount, driver);	
//		ffmactiveaccount.click();
	}

	public void clickFfmHardware() throws InterruptedException {
		Thread.sleep(10000);
		ffm_Hardware.click();
	}

	public void clickExistingHardware() throws Exception {
		scrollToElementAndClick(existing_Hardware, driver);
//		existing_Hardware.click();

	}

	public void clickFirstReturnHardware() throws InterruptedException {
		first_Return_Hardware.click();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
	}

	public void clickSecondReturnHardware() throws InterruptedException {
		second_Return_Hardware.click();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
	}

	public void clickThirdReturnHardware() throws InterruptedException {
		third_Return_Hardware.click();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
	}

	public void provision_Xg1V4(String serialnumtv) throws InterruptedException {
		Xg1V4_Enter_Serial_Number.click();
		Thread.sleep(2000);
		Xg1V4_Serial_Number_Textbox.sendKeys(serialnumtv);
		Thread.sleep(2000);
		Xg1V4_Provision_button.click();
		Thread.sleep(120000);

	}

	public void provision_XB6(String serialNumInternet) throws InterruptedException {
		XB6_Enter_Serial_Number.click();
		Thread.sleep(2000);
		XB6_Serial_Number_Textbox.sendKeys(serialNumInternet);
		Thread.sleep(2000);
		XB6_Provision_button.click();
		Thread.sleep(90000);
		// driver.navigate().refresh();
		// Thread.sleep(5000);

	}

	public void provision_Device(String device, String serialNum) throws Exception
	{
		if(driver.findElements(By.xpath("//div[@class='mFMsc_ProvisioningItem']//div[contains(text(),'"+device+"')]/ancestor::div[@class='leftEquipmentPanel']//div[contains(text(),'Enter Serial Number')]")).size()!=0)
		{
		WebElement eleEnterSerialNum = driver.findElement(By.xpath("//div[@class='mFMsc_ProvisioningItem']//div[contains(text(),'"+device+"')]/ancestor::div[@class='leftEquipmentPanel']//div[contains(text(),'Enter Serial Number')]"));
		scrollToElementAndClick(eleEnterSerialNum, driver);
		}
		WebElement eleEnterSerialNumtxtbox = driver.findElement(By.xpath("//div[@class='mFMsc_ProvisioningItem']//div[contains(text(),'"+device+"')]/ancestor::div[@class='leftEquipmentPanel']//input[@id='SerialNumber']"));
		enterValueInField(eleEnterSerialNumtxtbox, serialNum, driver);
		WebElement eleProvisionbtn = driver.findElement(By.xpath("//div[@class='mFMsc_ProvisioningItem']//div[contains(text(),'"+device+"')]/ancestor::div[@class='leftEquipmentPanel']/div[2]/button"));
		scrollToElementAndClick(eleProvisionbtn, driver);
	}
	
	public void provision_Hitron(String serialNumHitron) throws InterruptedException {
//		Thread.sleep(10000);
		hitron_Enter_Serial_Number.click();
		hitron_Serial_Number_Textbox.sendKeys(serialNumHitron);
		hitron_Provision_button.click();

	}

	public void provision_XiD(String serialNum) throws InterruptedException {
		XiD_Enter_Serial_Number.click();
		Thread.sleep(2000);
		XiD_Serial_Number_Textbox.sendKeys(serialNum);
		Thread.sleep(2000);
		XiD_Provision_Button.click();
	}

	public void readHitronMessage() {
		String msg = hitronmessage.getAttribute("value");

		System.out.println(msg);
	}

	public void provision_xg1v3(String serialNum) throws InterruptedException {
		Xg1v3_Enter_Serial_Number.click();
		Thread.sleep(2000);
		Xg1v3_Serial_Number_Textbox.sendKeys(serialNum);
		Thread.sleep(2000);
		Xg1v3_Provision_Button.click();
	}

	public void clickServiceCall() {
		wait.withMessage("service call tab is  not visible").until(ExpectedConditions.visibilityOf(serviceCall));
		serviceCall.click();
	}

	public void provisionXi6(String serialNum) throws InterruptedException {
		Xi6EnterSerialNumber.click();
		Thread.sleep(2000);
		Xi6SerialNumberTextBox.sendKeys(serialNum);
		Thread.sleep(2000);
		Xi6ProvisionButton.click();
	}

	public void provisionDCX3400(String serialNum) throws InterruptedException {
		DCX3400EnterSerialNumber.click();
		Thread.sleep(2000);
		DCX3400SerialNumberTextBox.sendKeys(serialNum);
		Thread.sleep(2000);
		DCX3400ProvisionButton.click();
	}

	public void clickHitronSwapButton() {
		wait.withMessage("Hitron swap button is  not visible").until(ExpectedConditions.visibilityOf(hitronSwapButton));
		hitronSwapButton.click();
	}

	public void clickDCTSwapButton() throws InterruptedException {
		Thread.sleep(3000);
		DCTSwapButton.click();
	}

	public void provisionDCT(String serialNum) throws InterruptedException {
		DCTEnterSerialNumber.click();
		Thread.sleep(2000);
		DCTSerialNumberTextBox.sendKeys(serialNum);
		Thread.sleep(2000);
		DCTProvisionButton.click();
	}

	public void updateActiveBranchId() throws Exception {
	
//		if ($(By.xpath("//*[@id='body']/section/form/div[2]/div[2]/p/input")).exists()) {
//			updateBranchId.click();
//		}
//		if (updateBranchId.isDisplayed())
//		{
//			updateBranchId.click();
//		}
		while(!((driver.findElements(By.xpath("//*[@id='body']/section/form/div[2]/div[2]/p/input")).size())!=0))
		{	
			driver.navigate().refresh();
		}
		waitForLoading(driver);
		scrollToElementAndClick(updateBranchId, driver);
	}

	public void orderSearch() throws Exception {
//		Thread.sleep(5000);
		scrollToElementAndClick(searchOrderButton, driver);
//		searchOrderButton.click();
	}

	public void provisionDPT(String serialNum) throws InterruptedException {
		phoneEnterSerialNumber.click();
		Thread.sleep(2000);
		phoneSerialNumberTextBox.sendKeys(serialNum);
		Thread.sleep(2000);
		phoneProvisionButton.click();
	}

	public void provisionXB7() throws InterruptedException,Exception {
		//waitForLoading(driver);
		Thread.sleep(5000);
		scrollToElementAndClick(XB7_Enter_Serial_Number,driver);
		String serialNumXb7=Xb7SerialNumber.getText();

		Thread.sleep(5000);
		XB7_Serial_Number_Textbox.sendKeys(serialNumXb7);
		XB7_Provision_button.click();
		waitForLoading(driver);
		waitForLoading(driver);
		waitForLoading(driver);
	}

	public void provisionExisitngXi6() throws InterruptedException,Exception {
		Thread.sleep(5000);
		Xi6EnterSerialNumber.click();
		String serialNumXi6=Xi6SerialNumber.getText();
		Thread.sleep(5000);
		Xi6SerialNumberTextBox.sendKeys(serialNumXi6);
		Xi6ProvisionButton.click();
		waitForLoading(driver);
		waitForLoading(driver);
		waitForLoading(driver);
	}

	public void provisionFibremodem() throws InterruptedException {
		FibreModem_Enter_Serial_Number.click();
		String serialNumXb7=fibreModemSerialNumber.getText();
		FibreModem_Serial_Number_Textbox.sendKeys(serialNumXb7);
		FibreModem_Provision_button.click();
		waitForLoading(driver);
		waitForLoading(driver);
		waitForLoading(driver);

	}
	
	public void provisionPhone() throws InterruptedException {
		phoneEnterSerialNumber.click();
		String serialNumPhone=PhoneSerialNumber.getText();
		phoneSerialNumberTextBox.sendKeys(serialNumPhone);
		phoneProvisionButton.click();
		waitForLoading(driver);
		waitForLoading(driver);
		waitForLoading(driver);

	}

	public void clickFFMSwapButton(String device) throws Exception {
		waitForLoading(driver);
		WebElement ele = driver.findElement(By.xpath("//div[@class='mFMsc_ProvisioningItem']//div[contains(text(),'"+device+"')]/ancestor::div[@class='leftEquipmentPanel']//button[@class='mb_SmallButton swapBtn']"));
		scrollToElementAndClick(ele, driver);
		
	}

	
}
/*
 * public void getXB6ProvisionMessage() { String
 * XB6provisioningStatus="Provisioning Successful. Added Successfully."; String
 * XB6provisioningStatus = XB6ProvisionMessage.getText();
 * System.out.println(XB6provisioningStatus); String hello=
 * XB6provisioningStatus.substring(0,23); System.out.println(hello);
 * 
 * 
 * 
 * }
 */
/*
 * public String checkffmtaskCompleted(int waitForffmtaskCompletion) throws
 * InterruptedException {
 * 
 * String orderStatusText = ""; String errorText = "";
 * 
 * Instant startTime; for (startTime = Instant.now();
 * Duration.between(startTime, Instant.now()) .toMillis() <
 * waitForffmtaskCompletion;) { driver.navigate().refresh(); Thread.sleep(5000);
 * ffmactiveaccount.click(); String XB6provisioningStatus =
 * XB6ProvisionMessage.getText(); String hello=
 * XB6provisioningStatus.substring(0,23);
 * 
 * if (hello.contains("Provisioning Successful")) { return hello; }
 * 
 * return XB6provisioningStatus; }
 * 
 * public String retrieveOrderStatus() throws InterruptedException, IOException
 * { String ffmStatus;
 * 
 * return ffmStatus =
 * checkffmtaskCompleted(Integer.parseInt(prop.getProperty("ffmStatusTime")) *
 * 60 * 1000); } }
 */
