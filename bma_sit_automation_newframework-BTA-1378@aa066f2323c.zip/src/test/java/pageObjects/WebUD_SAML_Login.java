package pageObjects;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;

import io.cucumber.java.Scenario;
import stepDefinitions.StepData;

public class WebUD_SAML_Login extends BaseUIPage {
	
	private WebDriver driver;
	Scenario scenario;
	StepData sd;
	public WebUD_SAML_Login(WebDriver driver,Scenario scenario) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
		this.sd=new StepData();
		sd.setScenario(scenario);
		this.scenario=sd.getScenario();
	}
	
	@FindBy(xpath = "//input[@name='loginfmt']")
	public WebElement saml_login;
	
	@FindBy(xpath = "//input[@type='submit']")
	public WebElement saml_submit;
	
	@FindBy(xpath = "//input[@name='passwd']")
	public WebElement saml_loginpswd;
	
	@FindBy(xpath = "//input[@name='DontShowAgain']")
	public WebElement chkbx_DontShowAgain;
	
//	@FindBy(xpath = "//input[@name='lname']")
//	public WebElement Lastname_click;
	
	@FindBy(xpath = "//select[@id='membership']/parent::div/following-sibling::div[1]/input")
	public WebElement Lastname_click;	
	
	@FindBy(xpath = "//div[@class='float-child']/button[@type='button' and @class='btn' and contains(text(), 'Search')]")
	public WebElement Search_btn;
	
//	@FindBy(xpath = "//a[contains(text(),'94 SIGNATURE HTS SW CALGARY AB')]")
//	public WebElement AddresslinkClick_StaffAcct;
	
//	@FindBy(xpath = "//div[@class='rightclickdate']/div/div/a")
	@FindBy(xpath = "//div[@class='rightclickdate']/div/div/descendant::a[1]")
	public WebElement AddresslinkClick_StaffAcct;
	
	
//	@FindBy(xpath = "//div[@class='rightclickdate']/div/div/a[2]")
	@FindBy(xpath = "//a[starts-with(text(),'Create New Customer at this service address')]")
	public WebElement CreateNewCustomer;
	
//	@FindBy(xpath = "//ul[@class='nav nav-tabs lock-list-wrap']/preceding-sibling::ul[1]//span[2] | //span[@class='bs-remove-tab']")
//	public WebElement closeAccountPage;
	
	@FindBy(xpath = "//li[@id='user-unlocklist-0']/a[@class='nav-link']/span[2]	| //div[@class='full-row user-info bg-white']/img[8]")
	public WebElement closeAccountPage;	
	
	@FindBy(xpath="//div[@class='float-child']/button[contains(text(),'Clear')]")
	public WebElement clearButton;
	
	@FindBy(xpath="//select[@id='membership']")
	public WebElement searchDropdown;
	
//	@FindBy(xpath="//div[@id='calculatorModal']/following-sibling::div[2]")
//	public WebElement searchIcon;
	@FindBy(xpath="//*[@tile='search']")
	public WebElement searchIcon;
	
	@FindBy(xpath = "//*[@id='txtscratchpad1']")
	//span[contains(text(),'SCRATCHPAD')]//	::div/following-sibling::div[1]/div/textarea
	public WebElement Scratchpad;
	
	
	@FindBy(xpath = "//div[@role='tablist']//span[contains(text(),'Notes')]")
	public WebElement Notes_tab;	
	
	@FindBy(xpath = "//span[contains(text(),'Create Note')]")
	public WebElement CreateNote_Directlink;	

	@FindBy(xpath = "//*[contains(text(),'Customer Notes')]/following::textarea[1]")
	public WebElement CustomerNotes_text;	

	@FindBy(xpath = "//*[contains(text(),'Customer Notes')]/following::label[contains(text(),'Create Note')]")
	public WebElement CreateNote_link;
	
	
	@FindBy(xpath = "//*[contains(text(),'Customer Notes')]/following::button[contains(text(),'Save')][1]")
	public WebElement CustomerNotes_Save;		

	@FindBy(xpath = "//*[contains(text(),'View/Edit All Notes')]")
	public WebElement CustomerNotes_ViewEdit;		
	
	@FindBy(xpath = "//button[contains(text(),'Modify')]")
	public WebElement CustomerNotes_Modify;		

	@FindBy(xpath = "//*[contains(text(),'Customer Notes')]//parent::div/button[@aria-label='Close']")
	public WebElement CustomerNotes_Close;	

	@FindBy(xpath = "//button[contains(text(),'Delete')]")
	public WebElement CustomerNotes_Delete;		

	@FindBy(xpath = "//*[contains(text(),'Confirm Delete')]")
	public WebElement CustomerNotes_Delete_PopUp;	
	
	@FindBy(xpath = "//*[contains(text(),'Confirm Delete')]//parent::div/following::button[contains(text(),'Yes')]")
	public WebElement CustomerNotes_Delete_Yes;	
	
	//*[contains(text(),'View/Edit All Notes')]//ancestor::li//following-sibling::div[2]/li	
	//li[@class='showNotes']//preceding::li[1]   ----- 23-Jan-2023 (SJRB\spaliwal)

	@FindBy(xpath = "//li[@class='showNotes']")
	public WebElement CustomerNotes_ShowText;	
	
	@FindBy(xpath = "//*[contains(text(),'Activity History') and @class=\"modal-title\"]/following::table[1]")
	public WebElement ActivityHistory_table;		

	@FindBy(xpath = "//*[contains(text(),'Welcome')]")
	public WebElement Welcome_Text;
	
	@FindBy(xpath = "//input[@id='user']")
	public WebElement ncUserName;
	
	@FindBy(xpath = "//input[@id='pass']")
	public WebElement ncPassword;
	
	@FindBy(xpath = "//div[@id='login_button']/div/input")
	public WebElement ncSubmitButton;

	@FindBy(xpath="//ul[@class='headers-icons ulheaders-icons']//img[@ng-reflect-ngb-tooltip='Account History']")
	public WebElement accountHistoryIcon;	
	
	@FindBy(xpath="//*[@class='accountHistory']/following::div/table[@class='Edit']/tr[2]/td[3]")
	public WebElement accountHistoryAccountDisplayed;
	
	@FindBy(xpath="//*[@id=\"WarningId\"]//span[contains(text(),'SC-')]/parent::label")
	public WebElement serviceCallLogo;
	
	@FindBy(xpath="//*[@id='WarningId']//span[contains(text(),'SA-')]/parent::label")
	public WebElement serviceAlertLogo;
	
	@FindBy(xpath="//div[@class='full-row user-info bg-white']//button[@class='nav-link alertstip']/following::span[9] ")
	public WebElement EBlogo;
	
	@FindBy(xpath="//div[@class='full-row user-info bg-white']//b[1]")
	public WebElement AccountNoDisplayed;
	
	@FindBy(xpath = "//button[@class='close']")
	public WebElement closeVersionPopup;
	
	//Ayush
	
	@FindBy(xpath="//*[@id=\"identifierNext\"]/div/button/span")
	public WebElement champemailConfirm;
	
	@FindBy(xpath="//*[@id=\"passwordNext\"]/div/button/span")
	public WebElement champPassSubmit;
	
	@FindBy(xpath="//*[@id=\"yDmH0d\"]/c-wiz/div/div[3]/div/div/div[2]/div/div/button/span")
	public WebElement champContinue;
	
	@FindBy(xpath="//input[@id='ds-form-input-id-0']")
	public WebElement dealerCode;
	
	@FindBy(xpath="//*[@id=\"dsa-accordion-panel-0-body-0\"]/div/raap-dealer-code-auth/section/form/button/span/span")
	public WebElement champSubmit;
	
	//*[@id="dsa-accordion-panel-0-body-0"]/div/raap-dealer-code-auth/section/form/button/span/span
	@FindBy(xpath="//input[@name='loginfmt']")
	public WebElement champEmail;
	
	@FindBy(xpath="//input[@name='Passwd']")
	public WebElement champPassword;
	
	@FindBy(xpath="//*[@id=\"passwordNext\"]/div/button/span")
	public WebElement champpassNext;
	
	@FindBy(xpath="//*[@id=\"yDmH0d\"]/c-wiz/div/div[3]/div/div/div[2]/div/div/button/div[3]")
	public WebElement champContinuebutton;
	
	@FindBy(xpath="//*[@id=\"dsa-accordion-panel-0-body-0\"]/div/div/div[2]/div/div/raap-tile/ds-tile/div/div/div")
	public WebElement champStart;
	
	
	public void login(String webUDUserName, String webUDUserPswd) throws Exception
	{
		WebDriverWait w = new WebDriverWait(driver, 120);
		w.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//*[contains(text(),'Can’t access your account?')]"))));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		waitForLoading(driver);
		isLoaderSpinnerVisible(driver);
		if(driver.findElements(By.xpath("//input[@name='loginfmt']")).size()>0)
		{
//			Thread.sleep(1000);
//			js.executeScript("arguments[0].value ='';", saml_login);
//			js.executeScript("arguments[0].value='"+webUDUserName+"';", saml_login);
//			saml_login.
			enterValueInField(saml_login, webUDUserName, driver);
			saml_submit.click();
			isLoaderSpinnerVisible(driver);
			waitForLoading(driver);			
			while(!(driver.findElements(By.xpath("//input[@name='passwd']")).size()!=0))
			{
				waitForLoading(driver);	
				isLoaderSpinnerVisible(driver);
				if(!saml_login.isDisplayed()) 
				{	driver.navigate().refresh();}
				waitForLoading(driver);	
				saml_login.clear();
				enterValueInField(saml_login, webUDUserName, driver);
				saml_submit.click();
				isLoaderSpinnerVisible(driver);
				waitForLoading(driver);	
			}
			w.until(ExpectedConditions.visibilityOf(saml_loginpswd));
			if(driver.findElements(By.xpath("//input[@name='passwd']")).size()!=0)
			{
				enterValueInField(saml_loginpswd, webUDUserPswd, driver);
				saml_submit.click();
				waitForLoading(driver);
				isLoaderSpinnerVisible(driver);
			}
			else
			{
				System.out.println("Check work/personal message");
			}
			w.until(ExpectedConditions.visibilityOf(chkbx_DontShowAgain));
			if(driver.findElements(By.xpath("//input[@name='DontShowAgain']")).size()!=0)
			{
				chkbx_DontShowAgain.click();
				saml_submit.click();
				waitForLoading(driver);
				isLoaderSpinnerVisible(driver);
			}

		}

	}
	
	
	public void accountIdDropdown(String searchBy) throws Exception {		
		Select addressIdDropdown = new Select(driver.findElement(By.id("membership")));
		addressIdDropdown.selectByValue(searchBy);
	}
	
	public void searchCustomer(String searchBy) throws Exception {
		ArrayList tabs = new ArrayList (driver.getWindowHandles());
	//	driver.switchTo().window((String) tabs.get(0));
		driver.navigate().refresh();
		waitForLoading(driver);
		WebUD_HomePage hp = new WebUD_HomePage(driver,this.scenario);
		if (driver.findElements(By.xpath("//*[contains(text(),'Latest Release Notes')]/following::*[contains(@aria-label,'Close')][1]")).size()!=0)
			scrollToElementAndClick(hp.CloseReleaseNotes, driver);
//		waitForLoading(driver);	
//		Select SearchCustomerBy = new Select(searchDropdown);
//		if(clearButton.isEnabled())
//		{
//			clearButton.click();	
//			waitForLoading(driver);
//			isLoaderSpinnerVisible(driver);	//AddedShweta
//		}
		scrollToElementAndClick(clearButton, driver);
		isLoaderSpinnerVisible(driver);
		waitForLoading(driver);
		selectElementFromDropdown(searchDropdown, driver, "VisibleText", searchBy);
//		isLoaderSpinnerVisible(driver);
//		searchDropdown.click();
//		SearchCustomerBy.selectByValue(searchBy);
		waitForLoading(driver);
		isLoaderSpinnerVisible(driver);
	}

	public void searchCustomerfurther(String searchBy) throws Exception {
		ArrayList tabs = new ArrayList (driver.getWindowHandles());
//		driver.switchTo().window((String) tabs.get(0));
		driver.navigate().refresh();
		waitForLoading(driver);
		WebUD_HomePage hp = new WebUD_HomePage(driver,this.scenario);
		if (driver.findElements(By.xpath("//*[contains(text(),'Latest Release Notes')]/following::*[contains(@aria-label,'Close')][1]")).size()!=0)
			scrollToElementAndClick(hp.CloseReleaseNotes, driver);
		scrollToElementAndClick(clearButton, driver);
		isLoaderSpinnerVisible(driver);
		selectElementFromDropdown(searchDropdown, driver, "VisibleText", searchBy);
		waitForLoading(driver);
		isLoaderSpinnerVisible(driver);
	}
	public void searchCustomerValue(String searchValue) throws Exception
	{		
		Lastname_click.click();
		Lastname_click.clear();
		Lastname_click.sendKeys(searchValue);
		WebUD_HomePage hp = new WebUD_HomePage(driver,this.scenario);
		if (driver.findElements(By.xpath("//*[contains(text(),'Latest Release Notes')]/following::*[contains(@aria-label,'Close')][1]")).size()!=0)
			scrollToElementAndClick(hp.CloseReleaseNotes, driver);
		waitForLoading(driver);	
		scrollToElementAndClick(Search_btn, driver);
		waitForLoading(driver);
		isLoaderSpinnerVisible(driver);
//		WebUDRoutingChange
		if(HostUrls.webUDroutingChanges.contains("Yes")) {
		String tab = driver.getWindowHandle();
		Set<String> tabs = driver.getWindowHandles();
		System.out.println(tabs);
		for(String handle : tabs) {
			if(!handle.equals(tab)) {
				driver.switchTo().window(handle);
				break;
			}}
		Thread.sleep(5000);
		waitForLoading(driver);	
		}
	}
	
	
	public void searchCbaCustomerValue(String searchValue) throws Exception
	{		
		
		Lastname_click.click();
		Lastname_click.clear();
		Lastname_click.sendKeys(searchValue);
		WebUD_HomePage hp = new WebUD_HomePage(driver,this.scenario);
		if (driver.findElements(By.xpath("//*[contains(text(),'Latest Release Notes')]/following::*[contains(@aria-label,'Close')][1]")).size()!=0)
			scrollToElementAndClick(hp.CloseReleaseNotes, driver);
		waitForLoading(driver);	
		scrollToElementAndClick(Search_btn, driver);
		waitForLoading(driver);
		isLoaderSpinnerVisible(driver);
//		WebUDRoutingChange
		if(HostUrls.webUDroutingChanges.contains("")) {
		String tab = driver.getWindowHandle();
		Set<String> tabs = driver.getWindowHandles();
		List<String> windowString = new ArrayList<>(tabs);
//		String reqstring = windowString.get(2);
		System.out.println(tab);
		System.out.println(tabs);
		for(String handle : tabs) {
			if(!handle.equals(tab)) {
				Thread.sleep(8000);
				driver.switchTo().window(windowString.get(2));
				break;
			}}
		Thread.sleep(5000);
		waitForLoading(driver);	
		}
	}
	
	public void clickAddressLink() throws InterruptedException
	{
		waitForLoading(driver);
		waitForLoading(driver);
		
		wait.withMessage("Checking visiblity of element").until(ExpectedConditions.visibilityOf(AddresslinkClick_StaffAcct));
		Thread.sleep(5000);	
		AddresslinkClick_StaffAcct.click();
		System.out.println("Address link is clicked");
		waitForLoading(driver);
		isLoaderSpinnerVisible(driver);	//AddedShweta
	}
	
	public void createNewCustomer() throws Exception
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		isLoaderSpinnerVisible(driver);
		waitForLoading(driver);
//		w.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@class='Edit']/tr/th[contains(text(),'Account Status')]"))));
//		waitForVisibilityOfElement(driver.findElement(By.xpath("//*[@class='Edit']/tr/th[contains(text(),'Account Status')]")),driver); 
//		wait.withMessage("Checking visiblity of element").until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@class='Edit']/tr/th[contains(text(),'Account Status')]"))));
//		
		WebElement NotePageBottom = driver.findElement(By.linkText("Create New Customer at this service address"));
//				("Due to performance impact"));
		System.out.println("Scrolling the page down");
		js.executeScript("arguments[0].scrollIntoView();",NotePageBottom );
		js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
		CreateNewCustomer.click();		
		String tab = driver.getWindowHandle();
		Set<String> tabs = driver.getWindowHandles();
		System.out.println(tab);
		for(String handle : tabs) {
			if(!handle.equals(tab)) {
				driver.switchTo().window(handle);
				break;
			}
		}
		Thread.sleep(5000);
		waitForLoading(driver);
	}
	
	public void createNewCustomerwohandle() throws Exception
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		isLoaderSpinnerVisible(driver);
		waitForLoading(driver);
//		w.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@class='Edit']/tr/th[contains(text(),'Account Status')]"))));
//		waitForVisibilityOfElement(driver.findElement(By.xpath("//*[@class='Edit']/tr/th[contains(text(),'Account Status')]")),driver); 
//		wait.withMessage("Checking visiblity of element").until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@class='Edit']/tr/th[contains(text(),'Account Status')]"))));
//		
		WebElement NotePageBottom = driver.findElement(By.linkText("Create New Customer at this service address"));
//				("Due to performance impact"));
		System.out.println("Scrolling the page down");
		js.executeScript("arguments[0].scrollIntoView();",NotePageBottom );
		js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
		CreateNewCustomer.click();		
//		String tab = driver.getWindowHandle();
//		Set<String> tabs = driver.getWindowHandles();
//		System.out.println(tab);
//		for(String handle : tabs) {
//			if(!handle.equals(tab)) {
//				driver.switchTo().window(handle);
//				break;
//			}
		//}
		waitForLoading(driver);
	}
	
	public void closeAccount() throws Exception
	{
//		WebUDRoutingChange
		if(HostUrls.webUDroutingChanges.contains("Yes")) {
			ArrayList tabs = new ArrayList (driver.getWindowHandles());
			driver.switchTo().window((String) tabs.get(0));
		}
		else {
			driver.switchTo().defaultContent();
			scrollToElementAndClick(closeAccountPage, driver);
		}
//		driver.switchTo().defaultContent();
//		scrollToElementAndClick(closeAccountPage, driver);
	}
	
	public void searchIcon() throws Exception
	{
		driver.switchTo().defaultContent();
		scrollToElementAndClick(searchIcon, driver);
	}
	
	
	public void searchIconreferesh() throws Exception
	{
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,-800)");
		driver.switchTo().defaultContent();
		js.executeScript("window.scrollBy(0,-800)");
		waitForLoading(driver);
		scrollToElementAndClick(searchIcon, driver);
//		searchIcon.click();
		waitForLoading(driver);
		Thread.sleep(5000);	
		String tab = driver.getWindowHandle();
		Set<String> tabs = driver.getWindowHandles();
		System.out.println(tab);
		for(String handle : tabs) {
			if(!handle.equals(tab)) {
				driver.switchTo().window(handle);
				break;
		
			}}
	//	Search_btn.click();
	}
	

	public void writenotes(String notes) throws InterruptedException
	{
			waitForLoading(driver);
			Scratchpad.click();
			WebDriverWait w= new WebDriverWait(driver,10);
			w.until(ExpectedConditions.visibilityOf(Scratchpad));
			Scratchpad.sendKeys(notes);
			waitForLoading(driver);
	}
	
	public String CreateCustomerNotes(String notes) throws InterruptedException
	{
		waitForLoading(driver);
		Notes_tab.click();
		CustomerNotes_ViewEdit.click();
		WebDriverWait w= new WebDriverWait(driver,20);
		w.until(ExpectedConditions.visibilityOf(CreateNote_link));			
		CreateNote_link.click();
		w.until(ExpectedConditions.visibilityOf(CustomerNotes_Save));	
		CustomerNotes_text.sendKeys(notes);
		CustomerNotes_Save.click();
		CustomerNotes_Close.click();
		Date date = new Date();
		DateFormat df = new SimpleDateFormat("DD-MMM-YYYY HH:mm");
		String formatedDate= df.format(date);
		waitForLoading(driver);
		w.until(ExpectedConditions.textToBePresentInElement(CustomerNotes_ShowText, notes));
		String NotesText = CustomerNotes_ShowText.getText();
		Assert.assertEquals(NotesText, notes);
		return formatedDate;
	
	}	

	public void ModifyCustomerNotes(String notes) throws InterruptedException {
		waitForLoading(driver);
		String GetUser=Welcome_Text.getText();
		Notes_tab.click();
		CustomerNotes_ViewEdit.click();
		waitForLoading(driver);
		String User[] = GetUser.split(" ");
		String modifynote="(//*[contains(text(),'"+User[1]+"')]/following::button[contains(text(),'Modify')])[1]";
		WebElement CustomerNotes_Modify1= driver.findElement(By.xpath(modifynote));
		WebDriverWait w= new WebDriverWait(driver,20);
		w.until(ExpectedConditions.visibilityOf(CustomerNotes_Modify1));
		CustomerNotes_Modify1.click();
		waitForLoading(driver);
		w.until(ExpectedConditions.visibilityOf(CustomerNotes_Save));
		CustomerNotes_text.click();
		CustomerNotes_text.clear();
		CustomerNotes_text.sendKeys(notes);
		CustomerNotes_Save.click();
		CustomerNotes_Close.click();
		w.until(ExpectedConditions.textToBePresentInElement(CustomerNotes_ShowText, notes));
		String modifiedtext=CustomerNotes_ShowText.getText();
		Assert.assertEquals(modifiedtext, notes);
	}	
	
	public void DeleteCustomerNotes(String notes) throws InterruptedException
	{
		waitForLoading(driver);
		String GetUser1=Welcome_Text.getText();
		Notes_tab.click();
		CustomerNotes_ViewEdit.click();
		waitForLoading(driver);
		String User[] = GetUser1.split(" ");
		String deletenote="(//*[contains(text(),'"+User[1]+"')]/following::button[contains(text(),'Delete')])[1]";
		WebElement CustomerNotes_Delete1= driver.findElement(By.xpath(deletenote));
		WebDriverWait w= new WebDriverWait(driver,20);
		w.until(ExpectedConditions.visibilityOf(CustomerNotes_Delete1));
		CustomerNotes_Delete1.click();
		waitForLoading(driver);
		w.until(ExpectedConditions.visibilityOf(CustomerNotes_Delete_PopUp));
		w.until(ExpectedConditions.elementToBeClickable(CustomerNotes_Delete_Yes));
		CustomerNotes_Delete_Yes.click();	
		CustomerNotes_Close.click();
		Thread.sleep(5000);
		Boolean verifyNotesText= CustomerNotes_ShowText.getText().equalsIgnoreCase(notes);
		Assert.assertFalse(verifyNotesText);
	}
	
	public String retrieveNotes() throws InterruptedException
	{
		return Scratchpad.getAttribute("value");
	}

	public void clickAccountHistoryIcon() throws Exception
	{
//		accountHistoryIcon.click();
		scrollToElementAndClick(accountHistoryIcon, driver);
//		Thread.sleep(10000);
		WebDriverWait w = new WebDriverWait(driver, 120);
		w.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//table[@class='Edit']"))));
	}	
	
	public String validateAccountDisplayed()
	{
		//Click on the Account Number
		String accountNoDisplayed=accountHistoryAccountDisplayed.getText();
		driver.findElement(By.xpath("//*[@class='accountHistory']/following::div/table[@class='Edit']/tr[2]/td[3]")).click();
		return accountNoDisplayed;
	}
	
	public String validateAccountonSearchPage()
	{
		String fetchaccntDisplayed=driver.findElement(By.xpath("//table[@class='Edit']/tr[2]/td[2]/a")).getText();
		String[] accontNo=fetchaccntDisplayed.split("-");
		String accountDisplayed=accontNo[0]+accontNo[1]+accontNo[2];
		return accountDisplayed;
	}
	public void validateAccountDetails()
	{
		if(serviceCallLogo.isDisplayed())
			ExtentCucumberAdapter.addTestStepLog("ServiceCall"+" "+serviceCallLogo.getText());
		
		if(EBlogo.isDisplayed())
			ExtentCucumberAdapter.addTestStepLog("EB Logo Displayed");
		
		if(AccountNoDisplayed.isDisplayed())
			ExtentCucumberAdapter.addTestStepLog("AccountNo is Displayed");
		
		if(serviceAlertLogo.isDisplayed())
			ExtentCucumberAdapter.addTestStepLog("ServiceAlert" + serviceAlertLogo.getText());
	}
	
	public void ncLogin(String ncUsername,String ncPswd) throws Exception
	{
		waitForLoading(driver);
//		isLoaderSpinnerVisible(driver);	//AddedShweta
		WebDriverWait w = new WebDriverWait(driver,90);
//		if(driver.findElement(By.xpath("//button[contains(@class,'Chevron')]")).getAttribute("class").equalsIgnoreCase("ChevronDown"))
//		{
//			WebElement upArrow=driver.findElement(By.xpath("//button[contains(@class,'Chevron')]"));
//			upArrow.click();
//			waitForLoading(driver);
//		}
		isLoaderSpinnerVisible(driver);	//AddedShweta
		driver.switchTo().parentFrame();
//		List <WebElement> iframes = driver.findElements(By.tagName("iframe"));	
//		for(WebElement iframe: iframes)
//		{
//			if (iframe.getAttribute("id").equals("ncOrderEntry"))
//			{
//				Thread.sleep(1000);
//				w.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(@class,'iframe-container-oe')]")));
//				scrollToElement(driver.findElement(By.xpath("//*[contains(@class,'iframe-container-oe')]")), driver);
//				driver.switchTo().frame("ncOrderEntry");
//				break;
//			}
//		}
		waitForLoading(driver);
		goToFrame(driver, "ncOrderEntry");
//		w.until(ExpectedConditions.invisibilityOfAllElements(driver.findElements(By.xpath("//img[contains(@src,'spinner.gif')]"))));

		waitForLoading(driver);
		isLoaderSpinnerVisible(driver);	//AddedShweta
		w.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//select[@id='user-role_main']"))));
		isLoaderSpinnerVisible(driver);	//AddedShweta
		if(driver.findElements(By.xpath("//input[@id='user']")).size()>0)
		{
			ncUserName.clear();
			ncUserName.sendKeys(ncUsername);
			ncPassword.clear();
			ncPassword.sendKeys(ncPswd);
			ncSubmitButton.click();
			waitForLoading(driver);
			waitForLoading(driver);			
		}

	}
	
	public void validateCustomerDetailsPage() throws InterruptedException
	{
		waitForLoading(driver);
		isLoaderSpinnerVisible(driver);
		if(driver.findElements(By.xpath("//table[@class='Edit']")).size()!=0)
			isLoaderSpinnerVisible(driver);	
		Assert.assertTrue(driver.findElements(By.xpath("//table[@class='Edit']")).size()!=0);
	}
	public void validateTableDisplayed() throws InterruptedException
	{
		waitForLoading(driver);
		isLoaderSpinnerVisible(driver);
		Assert.assertTrue(driver.findElements(By.xpath("//table[@class='Edit']/tr/th[contains(text(),'Account Status')]")).size()!=0);
		Assert.assertTrue(driver.findElements(By.xpath("//table[@class='Edit']/tr/th[contains(text(),'Name')]")).size()!=0);
		Assert.assertTrue(driver.findElements(By.xpath("//table[@class='Edit']/tr/th[contains(text(),'Phone')]")).size()!=0);
		Assert.assertTrue(driver.findElements(By.xpath("//table[@class='Edit']/tr/th[contains(text(),'Account Status')]")).size()!=0);
		Assert.assertTrue(driver.findElements(By.xpath("//table[@class='Edit']/tr/th[contains(text(),'Account Status')]")).size()!=0);
		String accountName=driver.findElement(By.xpath("//table[@class='Edit']/tr/th[contains(text(),'Phone')]/following-sibling::th[1]")).getText();
		Assert.assertEquals(accountName, "Account"+"\n"+"Number");
		String accountType=driver.findElement(By.xpath("//table[@class='Edit']/tr/th[contains(text(),'Phone')]/following-sibling::th[2]")).getText();
		Assert.assertEquals(accountType, "Account"+"\n"+"Type");	
	}
	
	
	 public void champLogin(String champUsername, String champPassword) throws Exception
		{
			WebDriverWait w = new WebDriverWait(driver, 120);
			w.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//*[contains(text(),'Can’t access your account?')]"))));
			JavascriptExecutor js = (JavascriptExecutor) driver;
			waitForLoading(driver);
			isLoaderSpinnerVisible(driver);
			if(driver.findElements(By.xpath("//input[@name='loginfmt']")).size()>0)
			{
				
				enterValueInField(saml_login, champUsername, driver);
				saml_submit.click();
				isLoaderSpinnerVisible(driver);
				waitForLoading(driver);			
				while(!(driver.findElements(By.xpath("//input[@name='passwd']")).size()!=0))
				{
					waitForLoading(driver);	
					isLoaderSpinnerVisible(driver);
					if(!saml_login.isDisplayed()) 
					{	driver.navigate().refresh();}
					waitForLoading(driver);	
					saml_login.clear();
					enterValueInField(saml_login, champUsername, driver);
					saml_submit.click();
					isLoaderSpinnerVisible(driver);
					waitForLoading(driver);	
				}
				w.until(ExpectedConditions.visibilityOf(saml_loginpswd));
				if(driver.findElements(By.xpath("//input[@name='passwd']")).size()!=0)
				{
					enterValueInField(saml_loginpswd, champPassword, driver);
					saml_submit.click();
					waitForLoading(driver);
					isLoaderSpinnerVisible(driver);
				}
				else
				{
					System.out.println("Check work/personal message");
				}
				w.until(ExpectedConditions.visibilityOf(chkbx_DontShowAgain));
				if(driver.findElements(By.xpath("//input[@name='DontShowAgain']")).size()!=0)
				{
					chkbx_DontShowAgain.click();
					saml_submit.click();
					waitForLoading(driver);
					isLoaderSpinnerVisible(driver);
				}
				
			}
			isLoaderSpinnerVisible(driver);
			waitForLoading(driver);	
		Thread.sleep(5000);
			js.executeScript("arguments[0].scrollIntoView();", dealerCode);
			dealerCode.sendKeys("8IBAA");
			scrollToElementAndClick(champSubmit,driver);
			isLoaderSpinnerVisible(driver);
			waitForLoading(driver);
			scrollToElementAndClick(champStart,driver);
			isLoaderSpinnerVisible(driver);
			waitForLoading(driver);
			if(HostUrls.webUDroutingChanges.contains("Yes")) {
			String tab = driver.getWindowHandle();
			Set<String> tabs = driver.getWindowHandles();
			System.out.println(tabs);
			for(String handle : tabs) {
				if(!handle.equals(tab)) {
					driver.switchTo().window(handle);
					System.out.println("qweqrr");
					break;
				}
			}
			}
		

		
			
	}	
}
