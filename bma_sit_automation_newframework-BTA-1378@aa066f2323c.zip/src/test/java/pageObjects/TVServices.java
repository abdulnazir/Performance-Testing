package pageObjects;

//import java.sql.Driver;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import util.TestUtil;



public class TVServices extends BaseUIPage {
	private WebDriver driver;
	TestUtil utils;
	public TVServices(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	@FindBy(xpath = "//*[@id=\"addHardware9149849110413360189\"]/span/span")
	WebElement XI6;

	@FindBy(xpath = "//*[text()='Large TV Prebuilt']")
	WebElement LargeTV;

	@FindBy(xpath = "//*[text()='Medium TV Prebuilt']")
	WebElement mediumtv;

	@FindBy(xpath = "//*[starts-with(@id,'wrench-button-9152553')]")
	WebElement HardwareWrenchButton;

	@FindBy(xpath = "//*[text()='Grandfathered Medium TV Pick 8']")
	WebElement grandfatheredMediumTV;

	@FindBy(xpath = "//*[text()='Grandfathered Large TV Pick 12']")
	WebElement grandfatheredLargeTV;

//	@FindBy(xpath = "//td[@class=' ThirdCategory']//table[@c='UIShawLinkFeature']//a[@class='wrench-button-style']")
	@FindBy(xpath = "//label[text()='TV Product']/ancestor::td[1]/following-sibling::td[1]/following::div[text()='Hardware'][1]/following::a[contains(@class,'wrench')][1]")
	WebElement tvwrench;
	
	@FindBy(xpath = "//td[@class=' ThirdCategory']//table[@class='UIShawLinkFeature CID_9131254459313896134 hardware-line']//div[@c='UIHyperlink']/a[@class='wrench-button-style']")
	WebElement classicTvWrench;

	@FindBy(xpath = "//td[@class=' ThirdCategory']//table[@c='UICPEFeature']//a[@class=\"wrench-button-style\"]")
	WebElement digitalChannelSelectionWrench;

	@FindBy(xpath = "//*[text()='Delete']")
	WebElement deletedevice;

	@FindBy(xpath = "//*[@id=\"addHardware9148141001813665729\"]/span/span")
	WebElement xg1v4;

//	@FindBy(xpath = "//*[@id='hardware-popup-ok-button']/span/span")
	@FindBy(xpath = "//*[@id='hardware-popup-ok-button']")
	WebElement OkButton;

	@FindBy(xpath = "//*[text()='Limited TV']")
	WebElement limitedTV;

	@FindBy(xpath = "//*[text()='Flex Employee Trial']")
	WebElement FlexTV;

	@FindBy(xpath = "//*[text()='Total TV']")
	WebElement TotalTV;

	@FindBy(xpath = "//*[text()='Small TV Prebuilt']")
	WebElement smallTVPrebuilt;

	@FindBy(xpath = "//*[text()='Ignite Total TV']")
	WebElement igniteTotalTV;

	
	
	@FindBy(xpath = "//*[text()='Digital Basic']")
	WebElement digitalBasic;

	@FindBy(xpath = "//*[@id=\"addHardware9149849110413360189\"]/span/span | //*[@class='hardware-grid']/tbody/tr[5]//td[3]/div/table/tbody/tr/td[2]/a/span/span")
	WebElement xi6;

	@FindBy(xpath = "//*[@id=\"addHardware9138588991513976674\"]/span/span")
	WebElement shawGateway;

	@FindBy(xpath = "//*[@id=\"addHardware9138588991513976686\"]/span/span")
	WebElement shawMoxiPortal;

	@FindBy(xpath = "//*[@id=\"addHardware9143914640013001769\"]/span/span")
	WebElement xid;

	@FindBy(xpath = "//*[@id=\"addHardware9138615380013988822\"]/span/span")
	WebElement DCX3510;

	@FindBy(xpath = "//*[@id=\"addHardware9131272219013049000\"]/span/span")
	WebElement DCX3200;

	@FindBy(xpath = "//*[@id=\"addHardware9131272219013049014\"]/span/span")
	WebElement DCX3400;

	@FindBy(xpath = "//td[@class='serial-number-input']/div/input")
	WebElement enterSerialNumber;

	@FindBy(xpath = "//td[@class=' validate-hardware']/a/span/span")
	WebElement clickValidateButton;

	@FindBy(xpath = "//*[@id='addHardware9157608046713103671']/span/span")
	WebElement flexxi6;

	@FindBy(xpath = "//*[@id=\"addHardware9143914640013001733\"]/span/span")
	WebElement xg1v3;

	@FindBy(xpath = "//*[@id=\"addHardware9131255265013902984\"]/span/span")
	WebElement DCT700;

	@FindBy(xpath = "//*[@id=\"addHardware9146887018213714540\"]/span/span")
	WebElement shawMoxiGateway;

	@FindBy(xpath = "//a[text()='Multicultural']")
	WebElement multiCulturalChannelPackage;

	@FindBy(xpath = "//*[text()=' OK ']")
	WebElement digitalChannelOkButton;

	@FindBy(xpath = "//label[text()='Employee TV']")
	WebElement employeeTV;

	@FindBy(xpath = "//*[text()='Re-assign/Level Up']")
	WebElement levelupTv;

	@FindBy(xpath = "//*[@id=\"addHardware9131272219013049033\"]/span/span")
	WebElement DCX3400250GB;

	@FindBy(xpath = "//*[@id=\"addHardware9138669380013245061\"]/span/span")
	WebElement DCX3200P2M;

	@FindBy(xpath = "//*[@id=\"addHardware9138615380013988813\"]/span/span")
	WebElement DCX3200HDGuide;
	
	@FindBy(xpath = "//a[@id='addHardware9161289744713751387']")
	WebElement Xione;

	public void selectEmployeeTV() throws Exception {
//		Thread.sleep(2000);
		scrollToElementAndClick(employeeTV, driver);
//		employeeTV.click();
		//waitForLoading();
//		Thread.sleep(2000);
		
	}

	public void selectDigitalChannelWrench() throws Exception {
		//waitForLoading();
//		Thread.sleep(2000);
//		digitalChannelSelectionWrench.click();
		scrollToElementAndClick(digitalChannelSelectionWrench, driver);
	}

	public void addChannels(String channelSet) throws Exception {
		
		System.out.println("Add Channel Method" + channelSet);
		String delim = channelSet.split("(?i)DELIMITER")[0].trim();
		System.out.println("Delim" + delim);
		System.out.println("Add Channel Method");
		String channelSetSpecified = channelSet.split("(?i)DELIMITER")[1].trim();

		String channelSetSeparator = Character.toString(delim.charAt(0));
		String channelThemeSeparator = Character.toString(delim.charAt(1));
		String channelSeparator = Character.toString(delim.charAt(2));

//		addInfoInReport("SetSeparator " + channelSetSeparator + "         ThemeSeparator " + channelThemeSeparator
//				+ "         channelSeparator " + channelSeparator);
//		addInfoInReport("channelSelection " + channelSetSpecified);

		for (String channelTheme : channelSetSpecified.split(channelSetSeparator)) {
			if (channelTheme.matches("^\\s*$")) {
				System.out.println("Skipping ChannelTheme " + channelTheme + " : no channels specified");
				continue;
			}
//			addInfoInReport("#####   ChannelTheme " + channelTheme + "   #####");

			String channelPackage = channelTheme.split(channelThemeSeparator)[0].trim();
			selectChannelPackage(channelPackage);
			String channelsList = channelTheme.split(channelThemeSeparator)[1].trim();
			Boolean WrenchOKFlag = true;
			for (String channel : channelsList.split(channelSeparator)) {
				if (channel.matches("^\\s*$")) {
					System.out.println("empty string in channel list, skipping");
					continue;
				}
				String thisChannel = channel.trim();
				//waitForLoading();
				

				if (thisChannel.equalsIgnoreCase("wrenchok")) {
					driver.findElement(
							By.xpath("//div[@id='aggregation-offering-dialog']//span[contains(text(),'OK')]")).click();
				} else {
					String ChannelXpath = "//table[@c='UITVChannelCheckBox' or @c='UITVAggregationChannelCheckBox']//label[text()='"
							+ thisChannel + "']/../input";
					WebElement channelElement = driver.findElement(By.xpath(ChannelXpath));

					Boolean lthis = Boolean.valueOf(channelElement.getAttribute("checked"));
					if (channelElement.getAttribute("checked") != null) {
//						addInfoInReportOrange("Unselecting channel " + thisChannel);
					} else {
//						addInfoInReport("Selecting channel " + thisChannel);
					}
//					Thread.sleep(4000);
					waitForLoading(driver);	
					isLoaderSpinnerVisible(driver);	//AddedShweta
					scrollToElementAndClick(channelElement, driver);
//					channelElement.click();
//					Thread.sleep(4009);
					waitForLoading(driver);	
					isLoaderSpinnerVisible(driver);	//AddedShweta
					//TestBase.takeScreenshot("");
					String wrenchXpath = ChannelXpath + "/ancestor::tr[1]//div[contains(@id, 'wrench-button')]";
					if (driver.findElements(By.xpath(wrenchXpath)).size() != 0) {
//						Thread.sleep(2000);
						scrollToElementAndClick(driver.findElement(By.xpath(wrenchXpath)), driver);
//						driver.findElement(By.xpath(wrenchXpath)).click();
						//TestBase.takeScreenshot("");
					}
				}
			}
			//waitForLoading();
//			Thread.sleep(2000);
		}
		scrollToElementAndClick(driver.findElement(By.xpath("//span[contains(text(),'OK')]")), driver);
//		driver.findElement(By.xpath("//span[contains(text(),'OK')]")).click();
	}

	public void selectMultiCulturalChannel() throws InterruptedException {

		multiCulturalChannelPackage.click();
		Thread.sleep(2000);
	}

	public void selectChannelPackage(String channelSet) throws InterruptedException {

		String ChannelPackageXpath = "//*[text()='" + channelSet + "']";
		//waitForLoading();
		Thread.sleep(2000);
		Thread.sleep(2000);
		driver.findElement(By.xpath(ChannelPackageXpath)).click();
	}

	public void selectChannel(String channel) throws InterruptedException {
		Thread.sleep(2000);
		String ChannelXpath = "//table[@c='UITVChannelCheckBox' or @c='UITVAggregationChannelCheckBox']//label[text()='"
				+ channel + "']";
		driver.findElement(By.xpath(ChannelXpath)).click();
	}

	public void selectTVChannels() throws InterruptedException {

		for (int num = 0; num < 4; num++) {
			WebElement tvChannel = driver.findElements(By.xpath("//input[@class=\"UICheckBox\"]")).get(num);
			tvChannel.click();
		}

		digitalChannelOkButton.click();
	}

	public String selectSmallTVPrebuilt() throws InterruptedException {
		wait.withMessage("DCX3200 is not visible").until(ExpectedConditions.elementToBeClickable(smallTVPrebuilt));
		Thread.sleep(2000);
		smallTVPrebuilt.click();
		return "smallTV";
	}
	
	public String selectIgniteTotalTV() throws Exception {
		wait.withMessage("Ignite Total TV is not visible").until(ExpectedConditions.elementToBeClickable(igniteTotalTV));
		scrollToElementAndClick(igniteTotalTV, driver);
		return "smallTV";
	}

	public void selectTotalTV() {
		TotalTV.click();
	}

	public void selectDCX3200() throws InterruptedException {
		DCX3200.click();
	}

	public void selectDCT700() {
		DCT700.click();
	}

	public void selectDCX3400() throws InterruptedException {
		DCX3400.click();
	}

	public void selectDCX3510() {
		DCX3510.click();

	}

	public void selectFlexXi6() {
		flexxi6.click();
	}

	public void selectXG1V3() {
		xg1v3.click();
	}

	public void selectShawMoxiGateway() {
		shawMoxiGateway.click();
	}

	public void enterSerialNumber(String serialnumber) {
		wait.withMessage("Enter Serial Number button is not visible")
				.until(ExpectedConditions.visibilityOf(enterSerialNumber));
		enterSerialNumber.sendKeys(serialnumber);
	}

	public void clickValidateButton() throws Exception {
//		wait.withMessage("Validatebutton").until(ExpectedConditions.visibilityOf(clickValidateButton));
		scrollToElementAndClick(clickValidateButton, driver);
//		clickValidateButton.click();
	}

	public void selectLargeTV() throws InterruptedException {
		LargeTV.click();
		Thread.sleep(2000);
		HardwareWrenchButton.click();
		Thread.sleep(2000);
		XI6.click();
		Thread.sleep(2000);
		OkButton.click();
	}

	

	public void selectTvWrench() throws Exception {
		isLoaderSpinnerVisible(driver);	//AddedShweta during 23.10
		waitForLoading(driver);
		scrollToElementAndClick(tvwrench, driver);
	}

	public void deletetv() throws Exception {
		isLoaderSpinnerVisible(driver);	//AddedShweta during 23.10
		waitForLoading(driver);
		scrollToElementAndClick(deletedevice, driver);
		waitForLoading(driver);
//		deletedevice.click();
	}

	public void selectXg1v4() throws InterruptedException {
		xg1v4.click(); 
	}

	public void selectTVHardware(String tvhardware) throws Exception {
		WebElement renttvhardware=driver.findElement(By.xpath("//div[text()='Hardware' and contains(@class,'Popup')]/following::label[contains(text(),'"+tvhardware+"')]/following::span[contains(text(),'Rent')][1]"));
		waitForLoading(driver);
		scrollToElementAndClick(renttvhardware, driver);
		waitForLoading(driver);
	}
	
	public void selectXid() throws InterruptedException {
		//waitForLoading();
		Thread.sleep(2000);
		xid.click();
	}

	public void selectXi6() {
		xi6.click();
	}

	public void selectOkButton() throws Exception {
		waitForLoading(driver);
		scrollToElementAndClick(OkButton, driver);
	}

	public void selectMediumTvPrebuilt() {

		wait.withMessage("medium tv button not found").until(ExpectedConditions.visibilityOf(mediumtv));
		mediumtv.click();
	}

	public void selectGranFatherMediumTv() throws InterruptedException {
		Thread.sleep(5000);
		wait.withMessage("Grandfather medium tv button not found")
				.until(ExpectedConditions.elementToBeClickable(grandfatheredMediumTV));
		grandfatheredMediumTV.click();
	}

	public void selectGranFatherLargeTv() {
		wait.withMessage("Grandfather Large button not found")
				.until(ExpectedConditions.visibilityOf(grandfatheredLargeTV));
		grandfatheredLargeTV.click();
	}

	public void selectLargeTvPrebuilt() {
		LargeTV.click();
	}

	public void selectFlexTV() throws InterruptedException {
		 //wait.withMessage("Limited TV not found").until(ExpectedConditions.visibilityOf(limitedTV));
		
		Thread.sleep(2000);
		FlexTV.click();
		//waitForLoading();
		Thread.sleep(3000);
	}

	public void selectLimitedTV() throws Exception {
		 //wait.withMessage("Limited TV not found").until(ExpectedConditions.visibilityOf(limitedTV));
		//waitForLoading();
//		Thread.sleep(4000);
		scrollToElementAndClick(limitedTV, driver);
//		limitedTV.click();
	}

	public void selectShawGateway() {
		shawGateway.click();
	}

	public void selectShawMoxiPortal() throws InterruptedException {
		wait.withMessage("Limited TV not found").until(ExpectedConditions.elementToBeClickable(shawMoxiPortal));
		Thread.sleep(2000);
		shawMoxiPortal.click();
	}

	public void waitForXid(WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.visibilityOf(xid));
		wait.withMessage("xid not found");
	}

	public void levelupTV() {
		levelupTv.click();
	}

	public void selectBulkTV() {
		driver.findElement(By.xpath("//*[text()='Bulk Total TV']")).click();
	}

	public void selectDCX3400250GB() throws InterruptedException {
		DCX3400250GB.click();
		//waitForLoading();
		Thread.sleep(3000);
	}

	public void selectDCX3200P2M() throws InterruptedException {
		DCX3200P2M.click();
		//waitForLoading();
		Thread.sleep(3000);
	}


	public void selectTVPackage(String tvPackage) throws Exception {
		waitForLoading(driver);
		isLoaderSpinnerVisible(driver);	
	scrollToElementAndClick(driver.findElement(By.xpath("//div[@id='tvCategory']//label[text() = '" + tvPackage + "']/preceding-sibling::input")), driver);
	}


	public void UnselectDefaultHardware(String tvPackage) throws Exception {
		if (tvPackage.equals("Digital Classic"))
			scrollToElementAndClick(classicTvWrench, driver);
		else
			scrollToElementAndClick(tvwrench, driver);	
	//	waitForLoading(driver);
		if (driver.findElements(By.xpath("//*[text()='Delete']")).size() > 0)
		{
			scrollToElement(deletedevice, driver);	
			scrollToElementAndClick(deletedevice, driver);
		}
	}


	public void selectDCX3200HDGuide() throws InterruptedException {
		DCX3200HDGuide.click();
		//waitForLoading();
		Thread.sleep(4000);
	}
	
	public void selectXiOne() throws Exception {
//		Xione.click();
		scrollToElementAndClick(Xione, driver);
	}
	
	public void selectOTTSubscription(String strOTTSubscription) throws Exception {
		WebElement strOTT=driver.findElement(By.xpath("(//*[contains(text(),'OTT Subscription')]/following::*[text()='"+strOTTSubscription+"'])[1]/preceding::td[1]/descendant::input"));
		waitForLoading(driver);
		scrollToElementAndClick(strOTT, driver);
		waitForLoading(driver);
	}
}
