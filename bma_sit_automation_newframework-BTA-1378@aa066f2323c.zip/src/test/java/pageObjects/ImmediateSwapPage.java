package pageObjects;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import util.FakeHardwareGeneration;

public class ImmediateSwapPage extends BaseUIPage {
	
	String orderStatusText;
	String randomEmail;
	String serialNumberXB6;
	String serialNumberXB7;
	private WebDriver driver;
	public ImmediateSwapPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	OverviewPage overviewpage = new OverviewPage(driver, this.scenario);
	
	@FindBy(xpath="//*[text()='Hardware']")
	WebElement hardware;
	
	@FindBy(xpath="//label[contains(text(), 'DCT')]/ancestor::table[@class=\"hardware-grid\"]//span[text()='Swap']")
	WebElement swapDCTDevice;
	
	@FindBy(xpath="//label[contains(text(), '(XB6) ')]/ancestor::table[@class=\"hardware-grid\"]//span[text()='Swap']")
	WebElement swapXB6Device;
	
	@FindBy(xpath="//label[contains(text(), '(XB7)')]/ancestor::table[@class=\"hardware-grid\"]//span[text()='Swap']")
	WebElement swapXB7Device;
	
	
	@FindBy(xpath="//label[contains(text(), 'Shaw')]/ancestor::table[@class='hardware-grid']//span[text()='Swap'] | //label[contains(text(), 'BlueCurve TV Wireless 4K Player - 418 (Fibre+ 150 and above + IPTV Mkt only)')]/ancestor::table[@class='hardware-grid']//span[text()='Swap']")
	WebElement swapShawDevice;
	
	@FindBy(xpath="//p[@class='UIRadioList']//label[contains(text(),'Technician')]")
	WebElement methodOfReturnTechnician;
	
	@FindBy(xpath="//*[contains(@id,'technicianIdInput')]/input")
	WebElement techIdInputBox;
	
	@FindBy(xpath="//*[contains(@id,'validateTechnicianId')]")
	WebElement validateTechIdButton;
	
	@FindBy(xpath="//table[@class=\"hardware-grid\"]//input[@hint=' - Serial Number - ']")
	WebElement inputSerialNumber;
	
	@FindBy(xpath="//*[text()='Validate']")
	WebElement validateButton;
	
	@FindBy(xpath="//*[@id=\"authorized-by_main\"]")
	WebElement authorizedByInputBox;
	
	@FindBy(xpath="//*[@id=\"apply-changes\"]/span/span")
	WebElement applyChanges;
	
	@FindBy(xpath="//*[text()='Return to list']")
	WebElement returnToListButton;
	
	@FindBy(xpath="//*[@id=\"ordersViewSelector_main\"]")
	WebElement workOrderSummary;
	
	@FindBy(xpath="//table[@id=\"features-parameters-grid_main\"]//input[@class=\"UIRadioList\"]")
	WebElement collectCalls;
	
	@FindBy(xpath="//a[text()=\"Phone Features\"]")
	WebElement phoneFeature;
	
	@FindBy(xpath="//a[text()=\"Customer Information\"]")
	WebElement customerInformation;
	
	@FindBy(xpath = "//a[text()=\"E-mail\"]")
	WebElement emailButton;

	@FindBy(xpath = "//span[text()=\"Create/Transfer E-mail Address\"]")
	WebElement createEmail;

	@FindBy(xpath = "//*[@id=\"emailUsername_main\"]")
	WebElement emailAddressInputBox;

	@FindBy(xpath = "//*[@id=\"emailFirstName_main\"]")
	WebElement firstName;

	@FindBy(xpath = "//*[@id=\"emailLastName_main\"]")
	WebElement lastName;

	@FindBy(xpath = "//table[@id=\"emailParametersLayout_main\"]//td[@class=\"UIGridLayoutRow emailsParamsSecond\"]//input")
	WebElement accountNumberInput;

	@FindBy(xpath = "//div[text()=\"Email\"]/ancestor::table[@c=\"UIQtyFeature\"]//a[contains(@id,\"UIHyperlink_selectorButton\")]")
	WebElement emailWrench;

	@FindBy(xpath = "//*[contains(text(),\"Transfer\")]")
	WebElement transferEmail;

	@FindBy(xpath = "//*[@id=\"email-popup-ok-button\"]/span/span")
	WebElement okButton;

	@FindBy(xpath = "//*[text()=\"Account Number: \"]")
	WebElement accountNumberText;

	@FindBy(xpath = "//*[text()=\"E-mail Address: \"]")
	WebElement emailAddressText;

	@FindBy(xpath = "//span[text()=\"Delete\"]")
	WebElement deleteButton;

	
	@FindBy(xpath = "//*[@id='cur-order-status-link_main']")
	WebElement orderstatus;
	
	@FindBy(xpath="//*[@id='imm-tab']")
	WebElement immidateScenarioTab;
	
	@FindBy(xpath="//*[contains(text(),'Transfer E-mail')]/following::select[1]")
//	@FindBy(xpath="//*[@id='transferSelect_main']")
	WebElement selectTranferOption;	

	@FindBy(xpath="//*[contains(text(),'E-mail Address')]/following::input[1]")
	WebElement immEmailAddress;	
	
	@FindBy(xpath="//*[contains(text(),'Validate')]")
	WebElement btn_Validate;	

	@FindBy(xpath="//*[contains(text(),'First Name')]/following::input[1]")
	WebElement immFirstName;	
	
	@FindBy(xpath="//*[contains(text(),'Last Name')]/following::input[1]")
	WebElement immLastName;	

	@FindBy(xpath="//*[contains(@hint,'Changes authorized by')]")
	WebElement immAuthorizedby;	
		
	@FindBy(xpath="//*[contains(text(),'Apply Changes')]")
	WebElement btn_ApplyChanges;	
	
	@FindBy(xpath="//*[contains(text(),'Return to list')]")
	WebElement btn_ReturntoList;
	
	@FindBy(xpath="//div[@class='full-row user-info bg-white']/descendant::*[contains(@class,'Refresh')]")
	WebElement Refresh;		
	
	public void SwapDCT700(String serialNumber) throws InterruptedException
	{
		hardware.click();
		wait.withMessage("SwapXb6 option not found").until(ExpectedConditions.visibilityOf(swapXB6Device));
//Thread.sleep(9000);
		swapDCTDevice.click();
		//waitForLoading();
		methodOfReturnTechnician.click();
		Thread.sleep(2000);
		techIdInputBox.sendKeys("5353");
		Thread.sleep(2000);
		validateTechIdButton.click();
		Thread.sleep(15000);
		inputSerialNumber.sendKeys(serialNumber);
		Thread.sleep(15000);
		validateButton.click();
		Thread.sleep(15000);
		authorizedByInputBox.sendKeys("Tester");
		Thread.sleep(2000);
		applyChanges.click();
		Thread.sleep(8000);
	}
	
	/*public void returnToList() throws InterruptedException
	{
		returnToListButton.click();
		Thread.sleep(2000);
	}*/
	
	public void clickOrderSummary()
	{
		workOrderSummary.click();        
	}
	public void clickOrderSummaryinwebud() throws Exception
	{
//		WebUDRoutingChange
//		if(HostUrls.matrix.contains("182")) switchtoWindow("WebUD", driver);
//		else switchtoWindow("Shaw", driver);
		ArrayList tabs = new ArrayList (driver.getWindowHandles());
		if(HostUrls.webUDroutingChanges.contains("Yes")) {
			driver.switchTo().window((String) tabs.get(1));}
		else
			driver.switchTo().window((String) tabs.get(0));	
		OverviewPage op1 = new OverviewPage(driver, this.scenario);
		driver.switchTo().defaultContent();
		scrollToElementAndClick(Refresh, driver);	
//		Refresh.click();
		scrollToElementAndClick(op1.Overviewtab, driver);
		driver.switchTo().frame("ncframeOrderHistory");
		scrollToElementAndClick(workOrderSummary, driver);	
	}	
	public void SwapXB6(String serialNumber) throws InterruptedException
	{
		hardware.click();
		//Thread.sleep(9000);
		wait.withMessage("SwapXb6 option not found").until(ExpectedConditions.visibilityOf(swapXB6Device));
		swapXB6Device.click();
		waitForLoading(driver);
		waitForLoading(driver);
		waitForLoading(driver);
		methodOfReturnTechnician.click();
		Thread.sleep(2000);
		techIdInputBox.click();
		
		techIdInputBox.sendKeys("5353");
		Thread.sleep(2000);
		validateTechIdButton.click();
		Thread.sleep(15000);
		inputSerialNumber.sendKeys(serialNumber);
		Thread.sleep(15000);
		validateButton.click();
		Thread.sleep(10000);
		authorizedByInputBox.sendKeys("Tester");
		//waitForLoading();
		Thread.sleep(10000);
		applyChanges.click();
		Thread.sleep(10000);
	}
	
	
	public String checkImmediateSwapStatus() throws Exception {
		
		//String swapStatusXpath = "//td[text()=\\\"Immediate � Hardware Swap\\\"]/ancestor::tr[contains(@id,\\\"customerOrders\\\")]//span[text()=\\\"Completed\\\"]";
//		String workOrderNumberXpath= "//a[@class=\"UITableHyperlink QuoteDifferenceLink\"]";
		waitForLoading(driver);	
		goToFrame(driver, "ncframeOrderHistory");
		waitForLoading(driver);
		List<WebElement> swapStatus = driver.findElements(By.xpath("(//*[contains(text(),'Immediate – Hardware Swap')]/ancestor::tr[contains(@id,'customerOrders')]//a[@class='UITableHyperlink QuoteDifferenceLink'])[1]"));
		//WebElement customerOrderLastRow = (WebElement) swapStatus.toArray()[-1];
		int customerOrderLastRowNum = swapStatus.size();
		System.out.println(customerOrderLastRowNum);
		WebElement customerOrderLastRow = swapStatus.get(customerOrderLastRowNum-1);  // Check it		
		scrollToElementAndClick(customerOrderLastRow, driver);
//		customerOrderLastRow.click();
		isLoaderSpinnerVisible(driver);	//AddedShweta
		waitForLoading(driver);		
//		Thread.sleep(50000);		
		scrollToElement(orderstatus, driver);
		orderStatusText = orderstatus.getText();
		if (orderStatusText.equalsIgnoreCase("Completed")) {
			return orderStatusText;
		}

		if (orderStatusText.equalsIgnoreCase("Processing")) {
			System.out.println(orderStatusText);
			return orderStatusText;
		}
		return orderStatusText;
	}
	
	public void swapShawMoxiGateway(String serialNumber) throws InterruptedException
	{
		hardware.click();
		wait.withMessage("SwapXb6 option not found").until(ExpectedConditions.visibilityOf(swapXB6Device));
		Thread.sleep(9000);
		swapShawDevice.click();
		Thread.sleep(2000);
		methodOfReturnTechnician.click();
		//waitForLoading();
		Thread.sleep(5000);
		techIdInputBox.sendKeys("5353");
//		waitForLoading();
		Thread.sleep(6000);
		validateTechIdButton.click();
//		waitForLoading();
		Thread.sleep(5000);
		inputSerialNumber.sendKeys(serialNumber);
//		waitForLoading();
		Thread.sleep(5000);
		validateButton.click();
//		waitForLoading();
		Thread.sleep(2000);
		authorizedByInputBox.sendKeys("Tester");
//		waitForLoading();
		Thread.sleep(2000);
		applyChanges.click();
//		waitForLoading();
		Thread.sleep(2000);
	}

public void clickCollectCalls()
{
	phoneFeature.click();
	wait.withMessage("Collect Calls radio button")
	.until(ExpectedConditions.visibilityOf(collectCalls));
	collectCalls.click();
}

public void authorisedBy() throws InterruptedException
{
	Thread.sleep(1000);
	authorizedByInputBox.sendKeys("Tester");
	Thread.sleep(8000);
	applyChanges.click();
	Thread.sleep(4000);
}
public void clickCustomerInformation()
{
	wait.withMessage("Customer information visibility")
	.until(ExpectedConditions.visibilityOf(customerInformation));
	customerInformation.click();	
}
public void addEmail() throws InterruptedException {
		emailButton.click();
//		waitForLoading();
		Thread.sleep(5000);
		createEmail.click();
//		waitForLoading();
		Thread.sleep(5000);
	}

public String createortransferEmailAddress() throws Exception {
	//		scrollToElementAndClick(createEmail, driver);
			try {
				Assert.assertFalse(driver.findElement(By.xpath("//*[contains(text(),'Reset Password')]")).isDisplayed(), "Reset Password should not be displayed");
			}catch(NoSuchElementException e)
			{
				System.out.println("No Element present which is expected.");
			}
//			String randomEmail = RandomStringUtils.randomAlphabetic(6);
//			enterValueInField(immEmailAddress, randomEmail, driver);		
//			String immemailadd = immEmailAddress.getAttribute("value");
			String immemailadd = transferEmailAddress();
			scrollToElementAndClick(btn_Validate, driver);
			String randomFirstName = RandomStringUtils.randomAlphabetic(5);
			String randomLastName = "S" + (RandomStringUtils.randomAlphabetic(5).toLowerCase());
			enterValueInField(immFirstName, randomFirstName, driver);
			enterValueInField(immLastName, randomLastName, driver);
			enterValueInField(immAuthorizedby, "Tester", driver);
			scrollToElementAndClick(btn_ApplyChanges, driver);	
		//	System.out.println(immemailadd);
			return immemailadd;			
		}

		public String transferEmailAddress() throws Exception {
			
			String randomEmail = RandomStringUtils.randomAlphabetic(6);
			enterValueInField(immEmailAddress, randomEmail, driver);		
			return randomEmail;
		}
		
		public String immEmailadd()throws Exception {
			String immemailadd = immEmailAddress.getText();
			System.out.println(immemailadd);
			return immemailadd;
		
		}


	public void emailAddress() throws InterruptedException {
		randomEmail = RandomStringUtils.randomAlphabetic(6);
		emailAddressInputBox.sendKeys(randomEmail);
		validateButton.click();
//		waitForLoading();
		Thread.sleep(2000);
		String randomFirstName = RandomStringUtils.randomAlphabetic(5);
		firstName.sendKeys(randomFirstName);
		String randomLastName = "S" + (RandomStringUtils.randomAlphabetic(5).toLowerCase());
		lastName.sendKeys(randomLastName);
		authorizedByInputBox.sendKeys("Tester");
		applyChanges.click();
	}

	public void transferEmailInOE(String accountnumber) throws InterruptedException {
		//accountnumber = "45678998767";
		Thread.sleep(2000);
		emailWrench.click();
		Thread.sleep(2000);
		transferEmail.click();
		wait.withMessage("Checking visiblity of element").until(ExpectedConditions.visibilityOf(accountNumberText));
		Select select = new Select(driver.findElement(By.id("transferSelect_main")));
		Thread.sleep(2000);
		select.selectByVisibleText("Transfer from another account");
		Thread.sleep(2000);
		accountNumberInput.click();
//		WebElement laccountNumberInput = driver.findElement(By.xpath(
//				"//table[@id='emailParametersLayout_main']//td[@class='UIGridLayoutRow emailsParamsSecond']/input"));
//		laccountNumberInput.click();
//		SelenideElement lacc = $(By.xpath(
//				"//table[@id='emailParametersLayout_main']//td[@class='UIGridLayoutRow emailsParamsSecond']/input"))
//						.waitUntil(enabled, 5000);
//
//		for (char c : "1234678901234".toCharArray()) {
//			laccountNumberInput.sendKeys(Keys.ARROW_LEFT);
//			Thread.sleep(200);
//		}
		for (char c : accountnumber.toCharArray()) {
			accountNumberInput.sendKeys(String.valueOf(c));
			Thread.sleep(200);
		}
		emailAddressInputBox.sendKeys(randomEmail);
		validateButton.click();
//		waitForLoading();
		Thread.sleep(2000);
		okButton.click();
		//wait.withMessage("waiting for second ok button").until(ExpectedConditions.visibilityOf(deleteButton));
		Thread.sleep(4000);
		okButton.click();
	}

	public void transferEmailInOE(String accountnumber,String transferemail) throws InterruptedException {
		//	accountnumber = "08200010051";
			Thread.sleep(2000);
			emailButton.click();
			Thread.sleep(20000);
			createEmail.click();
			Thread.sleep(5000);
			//transferEmail.click();
		//	wait.withMessage("Checking visiblity of element").until(ExpectedConditions.visibilityOf(accountNumberText));
			Select select = new Select(driver.findElement(By.id("transferSelect_main")));
			Thread.sleep(5000);
			select.selectByVisibleText("Transfer from another account");
			Thread.sleep(5000);
			accountNumberInput.click();

			for (char c : accountnumber.toCharArray()) {
				accountNumberInput.sendKeys(String.valueOf(c));
				Thread.sleep(2000);
			}
			System.out.println(transferemail);
			emailAddressInputBox.sendKeys(transferemail);
			validateButton.click();
//			waitForLoading();
			Thread.sleep(2000);
			authorizedByInputBox.sendKeys("Tester");
			applyChanges.click();
			//wait.withMessage("waiting for second ok button").until(ExpectedConditions.visibilityOf(deleteButton));
			Thread.sleep(4000);
		//	okButton.click();
		}
		public void transferEmailInImmediatePage(String email, String accountnumber) throws InterruptedException {

		emailButton.click();
//		waitForLoading();
		Thread.sleep(2000);
		transferEmail.click();
		wait.withMessage("Checking visiblity of element").until(ExpectedConditions.visibilityOf(emailAddressText));
		Select select = new Select(driver.findElement(By.id("transferSelect_main")));
		select.selectByVisibleText("Transfer from CBS");
//		waitForLoading();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"branchSelect\"]/input[1]")).click();
		driver.findElement(By.xpath("/html/body/div[22]/span[text()=\"QAC\"]")).click();
		Thread.sleep(2000);
		accountNumberInput.click();
		System.out.println(accountnumber);
		for (char c : accountnumber.toCharArray()) {
			accountNumberInput.sendKeys(String.valueOf(c));
			Thread.sleep(90);
		}
		emailAddressInputBox.sendKeys(email);
		validateButton.click();
//		waitForLoading();
		Thread.sleep(2000);

		
		authorizedByInputBox.sendKeys("Tester");
		applyChanges.click();
//		boolean errorDisplayed = driver.findElement(By.xpath("//*[@id=\"emailUsername_errorDiv\"]")).isDisplayed();
//		if (errorDisplayed) {
//			driver.findElement(By.xpath("//*[@id=\"emailUsername_main\"]")).click();
//			String errorMessage = driver.findElement(By.xpath("//div[@class=\"embeddedAssistanceMessage\"]")).getText();
//	
//			addErrorInReport(errorMessage);
//		} else {
//			
//		}
//		return errorDisplayed;

	}
		
		public void navigateToImmScenarioTab() throws Exception{
			if(HostUrls.webUDroutingChanges.contains("Yes")) {
				if(driver.findElements(By.xpath("//title[contains(text(),'Order History')]")).size()!=0) {}
				else {switchtoWindow("| WebUD", driver);}
				}
			else switchtoWindow("Shaw", driver);
			driver.switchTo().defaultContent();
			waitForLoading(driver);
			scrollToElement(immidateScenarioTab, driver);
			immidateScenarioTab.click();
			isLoaderSpinnerVisible(driver);	//AddedShweta during 23.10
			waitForLoading(driver);
			goToFrame(driver, "ncurlSand");	
			isLoaderSpinnerVisible(driver);
		}
		
		public void SwapXB7inWebUD(String serialNumberXB6) throws Exception
		{
//			serialNumber = "M1VXM0000H6T0000";
			serialNumberXB7 = FakeHardwareGeneration.generateSerialNum("XB7");
			
//			hardware.click();
			scrollToElementAndClick(hardware, driver);
			isLoaderSpinnerVisible(driver);	//AddedShweta during 23.10
			//Thread.sleep(9000);
			wait.withMessage("SwapXb7 option not found").until(ExpectedConditions.visibilityOf(swapXB7Device));
			swapXB7Device.click();
			waitForLoading(driver);
			isLoaderSpinnerVisible(driver);	//AddedShweta  during 23.10
			methodOfReturnTechnician.click();
			isLoaderSpinnerVisible(driver);	//AddedShweta
			enterValueInField(techIdInputBox, "5353", driver);
//			techIdInputBox.click();
//			
//			techIdInputBox.sendKeys("5353");
			isLoaderSpinnerVisible(driver);	//AddedShweta
			scrollToElementAndClick(validateTechIdButton, driver);
//			validateTechIdButton.click();
			isLoaderSpinnerVisible(driver);	//AddedShweta
			waitForLoading(driver);
			scrollToElement(inputSerialNumber, driver);
			inputSerialNumber.sendKeys(serialNumberXB7);
			isLoaderSpinnerVisible(driver);	//AddedShweta
			scrollToElementAndClick(validateButton, driver);
			enterValueInField(authorizedByInputBox, "Tester", driver);
//			authorizedByInputBox.sendKeys("Tester");
			waitForLoading(driver);	
			isLoaderSpinnerVisible(driver);	//AddedShweta
			applyChanges.click();
			isLoaderSpinnerVisible(driver);	//AddedShweta
			driver.switchTo().defaultContent();
		}

		public void SwapdeviceinImmScenarioninWebUD(String device) throws Exception
		{			
			scrollToElementAndClick(hardware, driver);
			isLoaderSpinnerVisible(driver);	//AddedShweta during 23.10
			String devices[] = device.split(",");
			for(int i=0;i<=devices.length-1;i++)
			{
				String serialNumber = FakeHardwareGeneration.generateSerialNum(devices[i]);
				WebElement eleswapdevice = driver.findElement(By.xpath("//*[contains(text(),'"+devices[i]+"')]/ancestor::table[@class='hardware-grid']//span[text()='Swap']"));
				wait.withMessage("Swap option not found").until(ExpectedConditions.visibilityOf(eleswapdevice));
				eleswapdevice.click();
				waitForLoading(driver);
				isLoaderSpinnerVisible(driver);	//AddedShweta  during 23.10
				methodOfReturnTechnician.click();
				isLoaderSpinnerVisible(driver);	//AddedShweta
				enterValueInField(techIdInputBox, "5353", driver);
				isLoaderSpinnerVisible(driver);	//AddedShweta
				scrollToElementAndClick(validateTechIdButton, driver);
				isLoaderSpinnerVisible(driver);	//AddedShweta
				scrollToElementAndClick(inputSerialNumber, driver);
				waitForLoading(driver);
				inputSerialNumber.sendKeys(serialNumber);
				isLoaderSpinnerVisible(driver);	//AddedShweta
				scrollToElementAndClick(validateButton, driver);
			}
			enterValueInField(authorizedByInputBox, "Tester", driver);
			waitForLoading(driver);	
			isLoaderSpinnerVisible(driver);	//AddedShweta
			applyChanges.click();
			isLoaderSpinnerVisible(driver);	//AddedShweta
			driver.switchTo().defaultContent();
		}
		
		public void selectChangeInImmediateScenario(String change) throws Exception {
//			isLoaderSpinnerVisible(driver);	//AddedShweta
//			WebElement eleChange=driver.findElement(By.xpath("//*[text()='"+change+"']"));
			waitForLoading(driver);
			isLoaderSpinnerVisible(driver);	//AddedShweta
			try {
			while(driver.findElement(By.xpath("//*[contains(text(),'Check the order status')]")).isDisplayed())
			{
				driver.switchTo().defaultContent();
				scrollToElementAndClick(Refresh, driver);
				navigateToImmScenarioTab();
				waitForLoading(driver);
				scrollToElementAndClick(driver.findElement(By.xpath("//*[text()='E-mail']")), driver);
				isLoaderSpinnerVisible(driver);
			}}catch(NoSuchElementException e) {System.out.println("Element not present anymore which is expected");}
			driver.switchTo().defaultContent();
			scrollToElement(immidateScenarioTab, driver);
			if(driver.findElement(By.xpath("//*[@id='imm-tab' and @aria-selected='true']")).isDisplayed())
			{
				goToFrame(driver, "ncurlSand");
				//driver.switchTo().frame("ncurlSand");
				if(driver.findElements(By.xpath("//*[contains(text(),'Return to list')]")).size()!=0)
				{
					isLoaderSpinnerVisible(driver);
					waitForLoading(driver);
//					goToFrame(driver, "ncurlSand");
					scrollToElementAndClick(btn_ReturntoList, driver);
				}
			}
			driver.switchTo().defaultContent();
			if(driver.findElement(By.xpath("//*[@id='imm-tab' and @aria-selected='true']")).isDisplayed())
			{
				isLoaderSpinnerVisible(driver);
				goToFrame(driver, "ncurlSand");
//				//driver.switchTo().frame("ncurlSand");
			}
			while(!((driver.findElements(By.xpath("//*[text()='"+change+"']")).size())!=0))
			{	
				driver.switchTo().defaultContent();
				scrollToElementAndClick(Refresh, driver);	
				navigateToImmScenarioTab();
			}
			isLoaderSpinnerVisible(driver);
			waitForLoading(driver);
			goToFrame(driver, "ncurlSand");		
			waitForLoading(driver);
			
//			//driver.switchTo().frame("ncurlSand");
			scrollToElementAndClick(driver.findElement(By.xpath("//*[text()='"+change+"']")), driver);
//			driver.findElement(By.xpath("//*[text()='"+change+"']")).click();
			isLoaderSpinnerVisible(driver);	//AddedShweta
		}

//		public void createortransferEmailAddress() throws Exception {
//			scrollToElementAndClick(createEmail, driver);
//			try {
//				Assert.assertFalse(driver.findElement(By.xpath("//*[contains(text(),'Reset Password')]")).isDisplayed(), "Reset Password should not be displayed");
//			}catch(NoSuchElementException e)
//			{
//				System.out.println("No Element present which is expected.");
//			}
//			String randomEmail = RandomStringUtils.randomAlphabetic(6);
//			enterValueInField(immEmailAddress, randomEmail, driver);
//			scrollToElementAndClick(btn_Validate, driver);
//			String randomFirstName = RandomStringUtils.randomAlphabetic(5);
//			String randomLastName = "S" + (RandomStringUtils.randomAlphabetic(5).toLowerCase());
//			waitForLoading(driver);
//			enterValueInField(immFirstName, randomFirstName, driver);
//			enterValueInField(immLastName, randomLastName, driver);
//			enterValueInField(immAuthorizedby, "Tester", driver);
//			scrollToElementAndClick(btn_ApplyChanges, driver);			
//		}

		public void validateResetPswdNotPresentinImmScenariotab(String transferemailoption) throws Exception {
			if(driver.findElements(By.xpath("//*[contains(@class,'Popup-title')]")).size()!=0)
			scrollToElementAndClick(driver.findElement(By.xpath("//a[contains(@class,'closeButton')]")), driver);
			try {
			while(driver.findElement(By.xpath("//*[contains(text(),'Check the order status')]")).isDisplayed())
			{
				driver.switchTo().defaultContent();
				scrollToElementAndClick(Refresh, driver);
				navigateToImmScenarioTab();
				scrollToElement(driver.findElement(By.xpath("//*[text()='E-mail']")), driver);
				driver.findElement(By.xpath("//*[text()='E-mail']")).click();
			}}catch(NoSuchElementException e) {System.out.println("Element not present anymore which is expected");}
			driver.switchTo().defaultContent();
			scrollToElement(immidateScenarioTab, driver);
			waitForLoading(driver);	
			if(driver.findElement(By.xpath("//*[@id='imm-tab' and @aria-selected='true']")).isDisplayed())
			{
				goToFrame(driver, "ncurlSand");
				//driver.switchTo().frame("ncurlSand");
				selectChangeInImmediateScenario("E-mail");
			}
			WebDriverWait w = new WebDriverWait(driver, 120);
			w.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//a[contains(@class,'RedButton')]/descendant::*[text()='Delete']"))));
			Assert.assertTrue(driver.findElements(By.xpath("//a[contains(@class,'RedButton')]/descendant::*[text()='Delete']")).size()!=0);
			driver.findElement(By.xpath("//a[contains(text(),'@shaw.ca')][1]")).click();
			try {
			w.until(ExpectedConditions.refreshed(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'First Name')]"))));	
			}catch(StaleElementReferenceException e){System.out.println("");}
			Thread.sleep(1000);
			selectElementFromDropdown(selectTranferOption, driver, "VisibleText", transferemailoption);
			try {
				Assert.assertFalse(driver.findElement(By.xpath("//*[contains(text(),'Reset Password')]")).isDisplayed(), "Reset Password should not be displayed");
			}catch(NoSuchElementException e)
			{
				System.out.println("No Element present which is expected.");
			}
			driver.switchTo().defaultContent();
			scrollToElement(immidateScenarioTab, driver);
			if(driver.findElement(By.xpath("//*[@id='imm-tab' and @aria-selected='true']")).isDisplayed())
			{
				//driver.switchTo().frame("ncurlSand");
				goToFrame(driver, "ncurlSand");
				scrollToElementAndClick(btn_ReturntoList, driver);
			}
		}

		public void validateResetPswdNotPresentinOrderEntrytab(String transferemailoption) throws Exception {
			waitForLoading(driver);
			WebDriverWait w = new WebDriverWait(driver, 120);
			goToFrame(driver, "ncOrderEntry");
			isLoaderSpinnerVisible(driver);	//AddedShweta
			waitForLoading(driver);
//			w.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//img[contains(@src,'spinner.gif')]")));
			w.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[contains(@class,'SecondCategory')]/descendant::*[text()='Email']/following::a[contains(@class,'wrench')][1]"))));
			WebElement EmailWrench= driver.findElement(By.xpath("//*[contains(@class,'SecondCategory')]/descendant::*[text()='Email']/following::a[contains(@class,'wrench')][1]"));
			scrollToElementAndClick(EmailWrench, driver);	
			scrollToElement(driver.findElement(By.xpath("//*[contains(text(),'E-mail Addresses')]")), driver);
			Assert.assertTrue(driver.findElements(By.xpath("//a[contains(@class,'RedButton')]/descendant::*[text()='Delete']")).size()!=0);
			driver.findElement(By.xpath("//a[contains(text(),'@shaw.ca')][1]")).click();
			isLoaderSpinnerVisible(driver);	//AddedShweta
			waitForLoading(driver);
			//Commented 24.7
//			w.until(ExpectedConditions.invisibilityOf(driver.findElement(By.xpath("//a[contains(@class,'RedButton')]/descendant::*[text()='Delete']"))));
			Thread.sleep(1000);
			selectElementFromDropdown(selectTranferOption, driver, "VisibleText", transferemailoption);
			try {
				Assert.assertFalse(driver.findElement(By.xpath("//*[contains(text(),'Reset Password')]")).isDisplayed(), "Reset Password should not be displayed");
			}catch(NoSuchElementException e)
			{
				System.out.println("No Element present which is expected.");
			}
			scrollToElementAndClick(driver.findElement(By.xpath("//a[contains(@class,'closeButton')]")), driver);
			scrollToElementAndClick(driver.findElement(By.xpath("//a[contains(@class,'closeButton')]")), driver);
			driver.switchTo().defaultContent();
		}
}
