package pageObjects;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.text.RandomStringGenerator;
//import org.junit.Assert;
import org.testng.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchSessionException;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import net.bytebuddy.utility.RandomString;
import stepDefinitions.Hooks;
//import util.HostUrls;
import pageObjects.HostUrls;

import util.TestUtil;

public class CustomerDetails extends BaseUIPage {

	private WebDriver driver;
	TestUtil utils;
	public CustomerDetails(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//*[@id='identificationTab']/descendant::*[contains(text(),'Customer & ID')]")
	WebElement customerandidtab;

	@FindBy(xpath = "//*[@id=\"customer-cdi-account-type-list-individual_main\"]")
	WebElement accounttypesel;
	
	@FindBy(xpath = "//*[@id=\"customerPronounList_main\"]")
	WebElement pronounsel;

	@FindBy(xpath = "//*[@id=\"customer-first-name_main\"]")
	WebElement firstName;

	@FindBy(xpath = "//*[@id=\"customer-last-name_main\"]")
	WebElement lastName;

	@FindBy(id = "customer-email_main")
	WebElement email;

	@FindBy(id = "customer-primary-phone-value")
	WebElement phoneNumber;

	@FindBy(id = "authentication-type-list_main")
	WebElement authenticationType;

	@FindBy(id = "customer-pin_main")
	WebElement pinNumber;

	@FindBy(xpath = "//*[@id=\"customer-cdi-account-type-list-individual_main\"]/option[2]")
	WebElement Staff;

	@FindBy(xpath = "//*[@id=\"customerEntityTypeIndividual_main\"]")
	WebElement accountSubTypesel;

	@FindBy(xpath = "//a[@id='clone-additional-button_main']")
	WebElement addAdditional;

	@FindBy(xpath = "//input[@id='additional-contact-0-first-name-UIGridLayoutAdditionalContactRow_main']")
	WebElement additionalContactFirstName;

	@FindBy(xpath = "//input[@id='additional-contact-0-last-name-UIGridLayoutAdditionalContactRow_main']")
	WebElement additionalContactLastName;

	@FindBy(id = "additional-contact-0-auth-type-UIGridLayoutAdditionalContactRow_main")
	WebElement additionalAuthenticationType;

	@FindBy(xpath = "//input[@id='additional-contact-0-password-UIGridLayoutAdditionalContactRow_main']")
	WebElement additionalContactPassword;

	@FindBy(xpath = "//*[@id=\"customer-primary-phone-type_main\"]")
	WebElement primaryContact;

	@FindBy(xpath = "//*[@id=\"customer-alternate-phone-type_main\"]")
	WebElement secondaryContact;

	@FindBy(id = "customer-alternate-phone-value")
	WebElement secondaryPhoneNumber;

	@FindBy(xpath = "//input[@id='customer-declined-mobile_main']")
	WebElement declinedMobileNumber;

	@FindBy(xpath = "//*[@id=\"validate-phone-number-button\"]")
	WebElement validatePhoneNumberButton;
	
	@FindBy(xpath = "//a[@id='validate-email-button']")
	WebElement validateEmailButton;
	
//	@FindBy(xpath ="//button[@class='nav-link button-one'][contains(text(),'Order Entry')]")
//	WebElement OrderEntryTab;
	
	@FindBy(xpath ="//ul[@id='myTab']/li/div[contains(text(),'Order Entry')]")
	WebElement OrderEntryTab;
	
	@FindBy(xpath="//div[@class='full-row user-info bg-white']/descendant::*[contains(@class,'Refresh')]")
	WebElement Refresh;		
	
	@FindBy(xpath="//*[contains(@title,'Add additional authorized person')]")
	WebElement addAuthorizedPerson;	
	
	@FindBy(xpath="//a[@class='UIHyperlink options-link privacyRequested']")
	WebElement privacyrequested;	
	
	
	@FindBy(xpath="//label[contains(text(),'VIP Account')]")
	WebElement vipaccount;
	
	@FindBy(xpath="//span[contains(text(),'OK')]")
	WebElement vipok;
	
	
	
	

	public void AccountType() throws InterruptedException {
		Thread.sleep(2000);
        new Select(accounttypesel).selectByVisibleText("Staff");
	}
	
	public void AccountTypeTPIA() throws InterruptedException {
		Thread.sleep(2000);
        new Select(accounttypesel).selectByVisibleText("TPIA");
	}

	public void clickCustomerAndIdTab_Oldie() throws Exception {
		WebDriverWait w = new WebDriverWait(driver, 100);
		if(System.getProperty("environment").equalsIgnoreCase("webud"))
		{
				waitForLoading(driver);
				isLoaderSpinnerVisible(driver);
				driver.switchTo().defaultContent();
				if(driver.findElement(By.xpath("//button[contains(@class,'Chevron')]")).getAttribute("class").equalsIgnoreCase("ChevronDown"))
				{
					WebElement upArrow=driver.findElement(By.xpath("//button[contains(@class,'Chevron')]"));
					upArrow.click();
				}
			String orderEntryClassProperty=driver.findElement(By.xpath("//ul[@id='myTab']/li/div[contains(text(),'Order Entry')]")).getAttribute("class");
//			System.out.println(orderEntryClassProperty);
			if(orderEntryClassProperty.equalsIgnoreCase("active"))
				System.out.println("Already Order Entry tab selected");
			else
				scrollToElementAndClick(OrderEntryTab, driver);
//				OrderEntryTab.click();
			
			waitForLoading(driver);
			isLoaderSpinnerVisible(driver);	//AddedShweta
			//driver.switchTo().parentFrame();  //Comment6/5
			driver.switchTo().defaultContent();
			scrollToElementAndClick(driver.findElement(By.xpath("//*[contains(text(),'Order Entry')]")), driver);
			goToFrame(driver, "ncOrderEntry");
		}
//		wai.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Customer & ID']"))); 
		while(!(driver.findElements(By.xpath("//*[text()='Customer & ID']")).size()!=0)) {
			scrollToElementAndClick(Refresh, driver);	
			scrollToElementAndClick(driver.findElement(By.xpath("//*[contains(text(),'Order Entry')]")), driver);
			goToFrame(driver, "ncOrderEntry");
		}
//		try {
//			driver.findElement(By.xpath("//*[text()='Customer & ID']")).getText();
//		}catch(NoSuchElementException e) {
//			for(int i=0;i<3;i++) 																	//4/3/2024
//			{
//				if(!((driver.findElements(By.xpath("//*[text()='Customer & ID']")).size())!=0))
//				{
//					driver.switchTo().defaultContent();
//					scrollToElementAndClick(Refresh, driver);	
//					scrollToElementAndClick(driver.findElement(By.xpath("//*[contains(text(),'Order Entry')]")), driver);
//					goToFrame(driver, "ncOrderEntry");
//				}	
//			}
//		}
		isLoaderSpinnerVisible(driver);	//AddedShweta
//		Thread.sleep(2000);
		scrollToElementAndClick(customerandidtab, driver);
		waitForLoading(driver);

	}	
	public void clickCustomerAndIdTab_Latest() throws Exception {
		WebDriverWait w = new WebDriverWait(driver, 100);
		if(System.getProperty("environment").equalsIgnoreCase("webud"))
		{
			waitForLoading(driver);
			isLoaderSpinnerVisible(driver);	//AddedShweta
			driver.switchTo().defaultContent();
			scrollToElementAndClick(OrderEntryTab, driver);			
			isLoaderSpinnerVisible(driver);	//AddedShweta
			goToFrame(driver, "ncOrderEntry");
			isLoaderSpinnerVisible(driver);
		}
		w.until(ExpectedConditions.elementToBeClickable(customerandidtab));
		try {
			driver.findElement(By.xpath("//*[@id='identificationTab']/descendant::*[contains(text(),'Customer & ID')]")).getText();
		}catch(NoSuchElementException e) {
			for(int i=0;i<3;i++) 																	//4/3/2024
			{
				if(!((driver.findElements(By.xpath("//*[@id='identificationTab']/descendant::*[contains(text(),'Customer & ID')]")).size())!=0))
				{
					driver.switchTo().parentFrame();
					scrollToElementAndClick(Refresh, driver);	
					scrollToElementAndClick(driver.findElement(By.xpath("//*[contains(text(),'Order Entry')]")), driver);
					goToFrame(driver, "ncOrderEntry");
					scrollToElement(customerandidtab, driver);
					customerandidtab.click();
					if(((driver.findElements(By.xpath("//*[@id=\"customer-first-name_main\"]")).size())!=0))break;
//					else clickCustomerAndIdTab();
				}	
			}
		}
		
		if(!((driver.findElements(By.xpath("//*[@id=\"customer-first-name_main\"]")).size())!=0)) {
				goToFrame(driver, "ncOrderEntry");
				if((driver.findElements(By.xpath("//*[@id='identificationTab']/descendant::*[contains(text(),'Customer & ID')]")).size()!=0))
				{
					for(int j=0;j<3;j++) 																	//4/3/2024
					{
					try {
						scrollToElementAndClick(customerandidtab, driver);}catch(UnhandledAlertException exc) {
							driver.switchTo().defaultContent();
							scrollToElementAndClick(Refresh, driver);	
							scrollToElementAndClick(driver.findElement(By.xpath("//*[contains(text(),'Order Entry')]")), driver);
							goToFrame(driver, "ncOrderEntry");
							scrollToElement(customerandidtab, driver);
							customerandidtab.click();
							if(((driver.findElements(By.xpath("//*[@id=\"customer-first-name_main\"]")).size())!=0))break;
						}
					if(((driver.findElements(By.xpath("//*[@id=\"customer-first-name_main\"]")).size())!=0))break;
					else {
					driver.switchTo().defaultContent();
					driver.navigate().refresh();
					waitForLoading(driver);
					for(int i=0;i<3;i++) 																	//4/3/2024
					{
						if(!((driver.findElements(By.xpath("//*[text()='Customer & ID']")).size())!=0))
						{
							driver.switchTo().defaultContent();
							driver.navigate().refresh();
							waitForLoading(driver);
							scrollToElementAndClick(driver.findElement(By.xpath("//*[contains(text(),'Order Entry')]")), driver);
							goToFrame(driver, "ncOrderEntry");
						}	
					}
					goToFrame(driver, "ncOrderEntry");
					scrollToElement(customerandidtab, driver);
					customerandidtab.click();
					if(((driver.findElements(By.xpath("//*[@id=\"customer-first-name_main\"]")).size())!=0))break;
					}
					}
				}	
		}
		waitForLoading(driver);

	}	
	//Created 29/5
	public void clickCustomerAndIdTab() throws Exception {
		WebDriverWait w = new WebDriverWait(driver, 120);
		if(System.getProperty("environment").equalsIgnoreCase("webud"))
		{
			waitForLoading(driver);
			isLoaderSpinnerVisible(driver);	//AddedShweta
			driver.switchTo().defaultContent();
			scrollToElementAndClick(OrderEntryTab, driver);	
			waitForLoading(driver);
			isLoaderSpinnerVisible(driver);	//AddedShweta
			goToFrame(driver, "ncOrderEntry");
			isLoaderSpinnerVisible(driver);
			
		}
		w.until(ExpectedConditions.elementToBeClickable(customerandidtab));
		scrollToElement(customerandidtab, driver);
		Actions action=new Actions(driver);
//		if(!driver.findElement(By.xpath("//li[@role='menuitem']/descendant::*[text()='Data Mapping']")).isDisplayed())
			action.moveToElement(customerandidtab).click().build().perform();
//		customerandidtab.click();
		w.until(ExpectedConditions.elementToBeClickable(firstName));
		if(!((driver.findElements(By.xpath("//*[@id=\"customer-first-name_main\"]")).size())!=0)) {
				goToFrame(driver, "ncOrderEntry");
				if((driver.findElements(By.xpath("//*[@id='identificationTab']/descendant::*[contains(text(),'Customer & ID')]")).size()!=0))
				{
					for(int j=0;j<3;j++) 																	//4/3/2024
					{
						scrollToElementAndClick(customerandidtab, driver);
					if(((driver.findElements(By.xpath("//*[@id=\"customer-first-name_main\"]")).size())!=0))break;
					else {
					driver.switchTo().defaultContent();
					driver.navigate().refresh();
					waitForLoading(driver);
					for(int i=0;i<3;i++) 																	//4/3/2024
					{
						if(!((driver.findElements(By.xpath("//*[text()='Customer & ID']")).size())!=0))
						{
							driver.switchTo().defaultContent();
							driver.navigate().refresh();
							waitForLoading(driver);
							scrollToElementAndClick(driver.findElement(By.xpath("//*[contains(text(),'Order Entry')]")), driver);
							goToFrame(driver, "ncOrderEntry");
						}	
					}
					goToFrame(driver, "ncOrderEntry");
					scrollToElement(customerandidtab, driver);
					customerandidtab.click();
					if(((driver.findElements(By.xpath("//*[@id=\"customer-first-name_main\"]")).size())!=0))break;
					}
					}
				}	
		}
		waitForLoading(driver);

	}	
	public void setFirstName(String FirstName) throws Exception {
		// clickWhenVisible(firstName, "Could not interact with FirstName field");
		enterValueInField(firstName, FirstName, driver);
//		firstName.sendKeys(FirstName);
	}

	public void setLastName(String LastName) throws Exception {
		enterValueInField(lastName, LastName, driver);
//		lastName.sendKeys(LastName);
	}

	public void updateEmailAddress() {
		email.clear();
	}

	public void setEmailAddress(String Email) {
		String override_email = prop.getProperty("override_email", "no") ;
		if (override_email.contains("@")) {
		   // addInfoInReport("email id " + override_email + " taken from matrix file");
		    Email = override_email;
		} else {
		    //addInfoInReport("Email id used from example data in Scenario");	
		}
		email.sendKeys(Email);
	}

	public void setPhoneNumber() throws Exception {
		WebDriverWait w = new WebDriverWait(driver, 90);
		isLoaderSpinnerVisible(driver);
		phoneNumber.click();
		Thread.sleep(1000);
		w.until(ExpectedConditions.refreshed(ExpectedConditions.visibilityOf(phoneNumber)));
		w.until(ExpectedConditions.not(ExpectedConditions.stalenessOf(phoneNumber)));
		String randomNumber = RandomStringUtils.randomNumeric(10);
		for (char c : randomNumber.toCharArray()) {
			phoneNumber.sendKeys(String.valueOf(c));
			Thread.sleep(15);
		}
		
		driver.findElement(By.xpath("//*[text()='Phone numbers']")).click();
		if (prop.getProperty("str83", "no").equalsIgnoreCase("yes") != true) {
			w.until(ExpectedConditions.refreshed(ExpectedConditions.visibilityOf(declinedMobileNumber)));
			w.until(ExpectedConditions.not(ExpectedConditions.stalenessOf(declinedMobileNumber)));
			w.until(ExpectedConditions.elementToBeClickable(declinedMobileNumber));
			if(!declinedMobileNumber.isSelected())
			selectCheckbox(declinedMobileNumber, driver);	
		}
		Hooks.setFileWriter("PhoneNumber: " + randomNumber);
	}
	
	public void customerOptOutMobileNumber() throws Exception {
		WebDriverWait w = new WebDriverWait(driver, 90);
		w.until(ExpectedConditions.elementToBeClickable(declinedMobileNumber));
		if(!declinedMobileNumber.isSelected())
		selectCheckbox(declinedMobileNumber, driver);	
	}

	public void selectAuthentication(String AuthType) throws InterruptedException {
		Select select = new Select(driver.findElement(By.id("authentication-type-list_main")));
		select.selectByVisibleText(AuthType);
		waitForLoading(driver);
	}

	public void setPinNumber(String Pin) throws Exception {
		waitForLoading(driver);
		WebDriverWait w = new WebDriverWait(driver, 90);
//		WebElement ele= driver.findElement(By.xpath("//*[@id='customer-pin_main' and @disabled='true']"));
//		w.until(ExpectedConditions.stalenessOf(driver.findElement(By.xpath("//*[@id='customer-pin_main' and @disabled='true']"))));
		w.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id='customer-pin_main' and contains(@style,'red')]"))));
		isLoaderSpinnerVisible(driver);	//AddedShweta
//		boolean val=driver.findElement(By.id("customer-pin_main")).getAttribute("class").contains("disabled");
//		while(val=true){
//			if(driver.findElement(By.id("customer-pin_main")).getAttribute("disabled")=="true") break;
//			else setPinNumber(pinNumber, Pin);
//			}
//		 driver.findElement(By.id("customer-pin_main")).isEnabled();
		 setPinNumber(pinNumber, Pin);
	}

	public void setPinNumber(WebElement lElement, String Pin) throws Exception {
//		lElement.click();
		scrollToElementAndClick(lElement, driver);
		for (char c : Pin.toCharArray()) {
			Thread.sleep(100);
			lElement.sendKeys(String.valueOf(c));

		}
	}

	public void AccountTypeStaff() {
		accounttypesel.click();
		Staff.click();
	}

	
	
	public void addAdditionalMember(String firstName, String lastName) throws Exception {
		addAdditional.click();
		Thread.sleep(2000);
		additionalContactFirstName.sendKeys(firstName);
		additionalContactLastName.sendKeys(lastName);
		additionalAuthenticationType.sendKeys("PIN");
		this.setPinNumber(additionalContactPassword, "123456");
	}

	public void accessesCustomerDetailPage() throws Exception {
		utils = new TestUtil(driver);
		utils.openUrlNewTab(HostUrls.getOEUrl());
		this.clickCustomerAndIdTab();
//		takeScreenshot(driver,"customer_details_page");
	}

	public void validatePhoneFields(String primary_phone_type, String alternate_phone_type) throws IOException {
		String lprimary = driver.findElement(By.id("customer-primary-phone-type_main")).getText();
		String lalternate = driver.findElement(By.id("customer-alternate-phone-type_main")).getText();
//		SoftAssert softAssert = new SoftAssert();
//		Assert =new Assert();
		Assert.assertEquals("primary phone type not correct",lprimary, primary_phone_type);
		Assert.assertEquals("alternate phone type not correct",lalternate, alternate_phone_type);
//		softAssert.assertAll();
	}

	//Swati NGV-43462: Created Method AddStaffCustomer
	public void addStaffCustomer(String firstName, String lastName, String email, String authType, String pin)
			throws Exception {
		
		isLoaderSpinnerVisible(driver);	//AddedShweta
		waitForLoading(driver);
		isLoaderSpinnerVisible(driver);	//AddedShweta
		driver.findElement(By.linkText("Customer & ID")).isEnabled();
		this.clickCustomerAndIdTab();
		isLoaderSpinnerVisible(driver);	//AddedShweta
		//Swati - Added Account type for the staff customer
		this.AccountType();
		waitForLoading(driver);
		this.setFirstName(firstName);
		this.setLastName(lastName);
		this.setEmailAddress(email);
		this.selectPrimaryContactType("Other");
		this.setPhoneNumber();
		this.selectAuthentication(authType);
		this.setPinNumber(pin);
		validateEmailButton.click();
		Thread.sleep(500);
		String myWindowHandle = driver.getWindowHandle();
		System.out.println(myWindowHandle);
		driver.switchTo().window(myWindowHandle);
	}

	public void updateCustomer(String firstName, String lastName) throws Exception {
		Thread.sleep(5000);
		driver.findElement(By.linkText("Customer & ID")).isEnabled();
		this.clickCustomerAndIdTab();
		Thread.sleep(2000);
		this.setFirstName(firstName);
		this.setLastName(lastName);
		//this.setEmailAddress(email);
		Thread.sleep(500);
	}



	public void addCustomer(String firstName, String lastName, String email, String authType, String pin)
			throws Exception {
		Thread.sleep(7000);
		//waitForLoading(driver);
		driver.findElement(By.linkText("Customer & ID")).isEnabled();
		this.clickCustomerAndIdTab();
		Thread.sleep(2000);
		this.setFirstName(firstName);
		this.setLastName(lastName);
		this.setEmailAddress(email);
		this.selectPrimaryContactType("Other");
		waitForLoading(driver);
		this.setPhoneNumber();
		Thread.sleep(12000);
		this.selectAuthentication(authType);
		this.setPinNumber(pin);
//		takeScreenshot(driver,"CustDetailsPage");
//		takeScreenshot("CustDetailsPage");
		validateEmailButton.click();
		Thread.sleep(5000);
		String myWindowHandle = driver.getWindowHandle();
		System.out.println(myWindowHandle);
		driver.switchTo().window(myWindowHandle);
	}

	public void selectPrimaryContactType(String primaryContactType) throws InterruptedException {

		Select select = new Select(driver.findElement(By.id("customer-primary-phone-type_main")));
		select.selectByVisibleText(primaryContactType);
	}

	public void selectSecondaryContactType(String secondaryContactType, String secondaryContactValue)
			throws InterruptedException {
		Thread.sleep(4000);

		driver.findElement(By.xpath("//*[@id=\"customer-alternate-phone-type_main\"]")).click();

		String secondaryType = "//select[@id=\"customer-alternate-phone-type_main\"]/option[text()='"
				+ secondaryContactType + "']";
		driver.findElement(By.xpath(secondaryType)).click();

		secondaryPhoneNumber.click();
		Thread.sleep(500);
		if (secondaryContactType.equals("Mobile")) {
			for (char c : secondaryContactValue.toCharArray()) {
				secondaryPhoneNumber.sendKeys(String.valueOf(c));
				Thread.sleep(36);

			}
			this.validateMobileNumber();
		} else {
			String secondaryValue = "1111111111";
			for (char c : secondaryValue.toCharArray()) {

				secondaryPhoneNumber.sendKeys(String.valueOf(c));
				Thread.sleep(36);
				// secondaryPhoneNumber.sendKeys("1111111111");
			}
		}
	}

	public void addCustomerPrimaryContact(String firstName, String lastName, String email, String primaryContactType,
			String authType, String pin) throws Exception {
		this.clickCustomerAndIdTab();
		Thread.sleep(2000);
		this.setFirstName(firstName);
		this.setLastName(lastName);
		this.setEmailAddress(email);
		this.selectPrimaryContactType(primaryContactType);
		this.setPhoneNumber();
		Thread.sleep(500);
		this.selectAuthentication(authType);
		this.setPinNumber(pin);
		validateEmailButton.click();
		driver.switchTo().window("Customer Information");
//		takeScreenshot(driver,"CustDetailsPage");

	}

	public void validateMobileNumber() throws InterruptedException {
		driver.findElement(By.xpath("//div[text()=\"(one is required)\"]")).click();
		Thread.sleep(1000);
		validatePhoneNumberButton.click();
	}

	public void addValidPhoneNumber(String mobileNumber) throws InterruptedException {
		phoneNumber.click();
		Thread.sleep(1000);
		for (char c : mobileNumber.toCharArray()) {
			phoneNumber.sendKeys(String.valueOf(c));
			Thread.sleep(36);

		}
		//Hooks.setFileWriter("PhoneNumber: " + mobileNumber);
	}

	public void addCustomerDetails(String firstName, String lastName, String email, String primaryContactType,
			String mobileNumber, String authType, String pin) throws Exception {
		this.clickCustomerAndIdTab();
		Thread.sleep(2000);
		this.setFirstName(firstName);
		this.setLastName(lastName);
		this.setEmailAddress(email);
		Thread.sleep(2000);
		this.selectPrimaryContactType(primaryContactType);
		if (primaryContactType.equals("Mobile")) {
			Thread.sleep(1000);
			this.addValidPhoneNumber(mobileNumber);
			Thread.sleep(1000);
			this.validateMobileNumber();
		}
		Thread.sleep(1000);
		this.setPhoneNumber();
		this.selectAuthentication(authType);
		this.setPinNumber(pin);
		validateEmailButton.click();
		driver.switchTo().window("Customer Information");
		//TestBase.takeScreenshot("CustDetailsPage");

	}
	public void resAccountType() throws Exception {
		waitForLoading(driver);
        new Select(accounttypesel).selectByVisibleText("Residential");
        isLoaderSpinnerVisible(driver);	//AddedShweta
        waitForLoading(driver);   
        isLoaderSpinnerVisible(driver);	
//		if(System.getProperty("environment").equalsIgnoreCase("webud"))
//		{
//			driver.switchTo().defaultContent();
//			JavascriptExecutor js = (JavascriptExecutor) driver;
//			js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
//			js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
//			driver.switchTo().frame("ncOrderEntry");
//			js.executeScript("arguments[0].scrollIntoView();",driver.findElement(By.xpath("//*[@id=\"desktop-unavailiable-popup3_closeButton\"]")));
//			js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
//		}
		scrollToElementAndClick(driver.findElement(By.xpath("//*[@id=\"desktop-unavailiable-popup3_closeButton\"]")), driver);	
//        driver.findElement(By.xpath("//*[@id=\"desktop-unavailiable-popup3_closeButton\"]")).click();
}
	
	
	public void stafAccountType() throws InterruptedException {
		waitForLoading(driver);
        new Select(accounttypesel).selectByVisibleText("Staff");
   //     tb.addScreenshot(driver, this.scenario, "Account Type Changed to Residential");
        waitForLoading(driver);        
		if(prop.getProperty("matrix").equalsIgnoreCase("webud"))
		{
			driver.switchTo().defaultContent();
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
			js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
			driver.switchTo().frame("ncOrderEntry");
			js.executeScript("arguments[0].scrollIntoView();",driver.findElement(By.xpath("//*[@id=\"desktop-unavailiable-popup3_closeButton\"]")));
			js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
		}
		waitForLoading(driver);
	//	tb.addScreenshot(driver, this.scenario, "Info popup");
		wait.withMessage("Checking visiblity of element").until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='desktop-unavailiable-popup3_closeButton']")));
		driver.findElement(By.xpath("//*[@id='desktop-unavailiable-popup3_closeButton']")).click();
}

	public void selectTenantInstallationOption()
	{
		Select select = new Select(driver.findElement(By.id("master-account-install-options-individual_main")));
		select.selectByVisibleText("Mailout");
	}
	public void staffcustAndIdTab(String firstName, String lastName, String email, String authType, String pin)
			throws Exception {
		isLoaderSpinnerVisible(driver);	//AddedShweta
		waitForLoading(driver);
		String oldTab = driver.getWindowHandle();
		waitForLoading(driver);
		isLoaderSpinnerVisible(driver);	//AddedShweta
		clickCustomerAndIdTab();
		isLoaderSpinnerVisible(driver);	//AddedShweta
		AccountType();
		waitForLoading(driver);
		setFirstName(firstName);
		setLastName(lastName);
		setEmailAddress(email);
		selectPrimaryContactType("Other");
		waitForLoading(driver);
		isLoaderSpinnerVisible(driver);
		setPhoneNumber();
		Thread.sleep(500);
		selectAuthentication(authType);
		setPinNumber(pin);
		validateEmailButton.click();
		waitForLoading(driver);
		driver.switchTo().window(oldTab);
	}
	
	
	public void tpiacustAndIdTab(String firstName, String lastName, String email, String authType, String pin)
			throws Exception {
		isLoaderSpinnerVisible(driver);	//AddedShweta
		waitForLoading(driver);
		String oldTab = driver.getWindowHandle();
		waitForLoading(driver);
		isLoaderSpinnerVisible(driver);	//AddedShweta
		clickCustomerAndIdTab();
		isLoaderSpinnerVisible(driver);	//AddedShweta
		AccountTypeTPIA();    //Rajadded
		waitForLoading(driver);
		setFirstName(firstName);
		setLastName(lastName);	
		selectPrimaryContactType("Other");
		waitForLoading(driver);
		isLoaderSpinnerVisible(driver);
		setPhoneNumber();
		Thread.sleep(500);
		selectAuthentication(authType);
		setPinNumber(pin);
		waitForLoading(driver);
		driver.switchTo().window(oldTab);
	}
	
	public void custAndIdTab(String firstName, String lastName, String email, String authType, String pin)
			throws Exception {
//		isLoaderSpinnerVisible(driver);	//AddedShweta
//		waitForLoading(driver);		
//		String oldTab = driver.getWindowHandle();
//		waitForLoading(driver);
//		isLoaderSpinnerVisible(driver);	//AddedShweta
//		WebUDRoutingChange
		if(HostUrls.webUDroutingChanges.contains("Yes")) 
			switchtoWindow("Customer Information", driver);
		else switchtoWindow("Shaw", driver);	
		clickCustomerAndIdTab();
		isLoaderSpinnerVisible(driver);	//AddedShweta
		waitForLoading(driver);
		setFirstName(firstName);
		setLastName(lastName);
		setEmailAddress(email);
		selectPrimaryContactType("Other");
		waitForLoading(driver);
		isLoaderSpinnerVisible(driver);
		setPhoneNumber();
		Thread.sleep(500);
		waitForLoading(driver);
		selectAuthentication(authType);
		setPinNumber(pin);
		validateEmailButton.click();
		waitForLoading(driver);
//		driver.switchTo().window(oldTab);
		
	}
	
	public void custAndIdTabemail(String firstName, String lastName, String email, String authType, String pin)
			throws Exception {
//		isLoaderSpinnerVisible(driver);	//AddedShweta
//		waitForLoading(driver);		
//		String oldTab = driver.getWindowHandle();
//		waitForLoading(driver);
//		isLoaderSpinnerVisible(driver);	//AddedShweta
//		WebUDRoutingChange
//		if(HostUrls.webUDroutingChanges.contains("Yes")) 
//			switchtoWindow("Customer Information", driver);
//		else switchtoWindow("Shaw", driver);	
		clickCustomerAndIdTab();
		isLoaderSpinnerVisible(driver);	//AddedShweta
		waitForLoading(driver);
		setFirstName(firstName);
		setLastName(lastName);
		setEmailAddress(email);
		selectPrimaryContactType("Other");
		waitForLoading(driver);
		isLoaderSpinnerVisible(driver);
		setPhoneNumber();
		Thread.sleep(500);
		waitForLoading(driver);
		selectAuthentication(authType);
		setPinNumber(pin);
		validateEmailButton.click();
		waitForLoading(driver);
//		driver.switchTo().window(oldTab);
		
	}
	
	
	public void createNewAccountWithPronounCustomerAndIdTab(String firstName, String lastName, String email, String authType, String pin, String pronoun, String accountType, String accountSubType)
			throws Exception {
		isLoaderSpinnerVisible(driver);	//AddedShweta
//		waitForLoading(driver);		 Commented23/5
//		WebUDRoutingChange
		if(HostUrls.webUDroutingChanges.contains("Yes")) switchtoWindow("WebUD", driver);
		else switchtoWindow("Shaw", driver);	
		clickCustomerAndIdTab();
		isLoaderSpinnerVisible(driver);	//AddedShweta
		setAccountTypes(accountType,accountSubType);
		setFirstName(firstName);
		setLastName(lastName);
		Select s= new Select(pronounsel); 	
		Assert.assertEquals(s.getFirstSelectedOption().getText(), "Not Specified");	
		setEmailAddress(email);
		selectPrimaryContactType("Other");
//		waitForLoading(driver);	Commented23/5
		isLoaderSpinnerVisible(driver);
		setPhoneNumber();
		Thread.sleep(500);
//		waitForLoading(driver);	Commented23/5
		selectAuthentication(authType);
		Thread.sleep(500);
		setPinNumber(pin);
		validateEmailButton.click();
		waitForLoading(driver);
//		driver.switchTo().window(oldTab);
	}	
	

	public void createNewAccountWithVipCustomerAndIdTab(String firstName, String lastName, String email, String authType, String pin)
			throws Exception {
		isLoaderSpinnerVisible(driver);	//AddedShweta
//		waitForLoading(driver);		 Commented23/5
//		WebUDRoutingChange
		if(HostUrls.webUDroutingChanges.contains("Yes")) 
			switchtoWindow("Customer Information", driver);
		else switchtoWindow("Shaw", driver);	
		clickCustomerAndIdTab();
		isLoaderSpinnerVisible(driver);	//AddedShweta		
		waitForLoading(driver);
		setFirstName(firstName);
		setLastName(lastName);
		selectAccountprivacy();
		setEmailAddress(email);
		selectPrimaryContactType("Other");
		waitForLoading(driver);
		isLoaderSpinnerVisible(driver);
		setPhoneNumber();
		Thread.sleep(500);
		waitForLoading(driver);
		selectAuthentication(authType);
		setPinNumber(pin);
		validateEmailButton.click();
		waitForLoading(driver);
//		driver.switchTo().window(oldTab);
	}		
	
	
	public void selectAccountprivacy() throws Exception{
		
		WebDriverWait w = new WebDriverWait(driver, 90);
		w.until(ExpectedConditions.visibilityOf(privacyrequested));
		Thread.sleep(5000);
		scrollToElementAndClick(privacyrequested,driver);
		Thread.sleep(5000);
		driver.switchTo().activeElement();
		Thread.sleep(5000);
		w.until(ExpectedConditions.visibilityOf(vipaccount));
		scrollToElementAndClick(vipaccount,driver);
		Thread.sleep(5000);
		w.until(ExpectedConditions.visibilityOf(vipok));
		scrollToElementAndClick(vipok,driver);
			
	
	}
	
	public void setAccountTypes(String accountType, String accountSubType) throws Exception
	{
		selectElementFromDropdown(accounttypesel, driver, "VisibleText", accountType);
		if(accountType.contains("Residential")){selectElementFromDropdown(accountSubTypesel, driver, "VisibleText", accountSubType);}
	}

	
	
	public void modifypronounforPrimaryAccountHolder(String updatePrimaryPronoun) throws Exception {
		selectElementFromDropdown(pronounsel, driver, "VisibleText", updatePrimaryPronoun);
	}

	public void verifyCustomerPronounsinWebUDwithNClist(ArrayList<String> strNCPronounList) {
		List <WebElement> labels = driver.findElements(By.xpath("//*[@id='customerPronounList_main']/option"));
		ArrayList<String> PresentOptions = new ArrayList<String>();
		for(int i=0;i<=strNCPronounList.size()-1;i++)
		{
			boolean Present=false;			
			for(int j=0;j<=labels.size()-1;j++)
			{
					if(labels.get(j).getText().equals(strNCPronounList.get(i)))
						{
							Present=true;
							PresentOptions.add(strNCPronounList.get(i));
							break;		
						}		
			}
			if(!Present) Assert.assertTrue(Present, "Option: "+strNCPronounList.get(i)+" should be present");
		}	
		System.out.println("Array is: "+ PresentOptions); 
	}
	
	public ArrayList<String> add_additional_authorized_person(String addpersondetails) throws Exception {
		String[] addpersondet=addpersondetails.split(";");
		WebDriverWait w = new WebDriverWait(driver, 120);
		ArrayList<String> strCheckPronounsinIntReport = new ArrayList<String>();
		for(int i=0;i<addpersondet.length;i++)
		{
			scrollToElementAndClick(addAuthorizedPerson, driver);
			w.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//label[text()='Additional Authorized Person on Account']")));
			scrollToElement(addAuthorizedPerson, driver);
//			waitForVisibilityOfElement(driver.findElement(By.xpath("//a[text()='Remove person']")),driver);
//			WebElement addfirstName=driver.findElement(By.xpath("(//input[contains(@id,'additional-contact-"+i+"-first-name')])[1]"));
//			WebElement addlastName=driver.findElement(By.xpath("(//input[contains(@id,'additional-contact-"+i+"-last-name')])[1]"));
//			WebElement addaccess=driver.findElement(By.xpath("(//select[contains(@id,'additional-contact-"+i+"-access')])[1]"));
//			WebElement addpronoun=driver.findElement(By.xpath("(//select[contains(@id,'additional-contact-"+i+"-pronoun')])[1]"));
//			WebElement addauthtype=driver.findElement(By.xpath("(//select[contains(@id,'additional-contact-"+i+"-auth-type')])[1]"));
//			WebElement addpin_para=driver.findElement(By.xpath("//input[contains(@hint,'PIN') and contains(@style,'red')]"));
			String[] addpersondets=addpersondet[i].split(",");
			enterValueInField(driver.findElement(By.xpath("(//input[contains(@id,'additional-contact-"+i+"-first-name')])[1]")), addpersondets[0], driver);
			enterValueInField(driver.findElement(By.xpath("(//input[contains(@id,'additional-contact-"+i+"-last-name')])[1]")), addpersondets[1], driver);
			selectElementFromDropdown(driver.findElement(By.xpath("(//select[contains(@id,'additional-contact-"+i+"-access')])[1]")), driver, "VisibleText", addpersondets[2]);
			selectElementFromDropdown(driver.findElement(By.xpath("(//select[contains(@id,'additional-contact-"+i+"-pronoun')])[1]")), driver, "VisibleText", addpersondets[3]);
//			selectElementFromDropdown(addauthtype, driver, "VisibleText", addpersondets[4]);
			Select select = new Select(driver.findElement(By.xpath("(//select[contains(@id,'additional-contact-"+i+"-auth-type')])[1]")));
			select.selectByVisibleText(addpersondets[4]);
			Thread.sleep(500);
			w.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("(//select[contains(@id,'additional-contact-"+i+"-auth-type')])[1]/following::input[1]"))));
			setPinNumber(driver.findElement(By.xpath("(//select[contains(@id,'additional-contact-"+i+"-auth-type')])[1]/following::input[1]")), addpersondets[5]);
			strCheckPronounsinIntReport.add(addpersondets[3]);
		}	
		return strCheckPronounsinIntReport;
	}
	
	public void OrderEntryTab() throws InterruptedException
	{
		WebDriverWait w = new WebDriverWait(driver, 300);
		if(System.getProperty("environment").equalsIgnoreCase("webud") || System.getProperty("environment").equalsIgnoreCase("preprodwebud"))
		{
				Thread.sleep(8000);
				driver.switchTo().defaultContent();
				Thread.sleep(10000);
				//w.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//button[@class='nav-link b1r bg-ChevronUp']"))));
				upArrowClick(driver);
			String orderEntryClassProperty=driver.findElement(By.xpath("//ul[@id='myTab']/li/div[contains(text(),'Order Entry')]")).getAttribute("class");
			System.out.println(orderEntryClassProperty);		
			if(orderEntryClassProperty.equalsIgnoreCase("nav-link button-one active"))
			{
				System.out.println("Already Order Entry tab selected");
			}
			else
			{
				OrderEntryTab.click();

			}
			waitForLoading(driver);
			Thread.sleep(20000);
			driver.switchTo().frame("ncOrderEntry");

			
		}
	}
}
