package pageObjects;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import io.cucumber.java.Scenario;
import stepDefinitions.StepData;

public class WebUD_Alerts extends BaseUIPage
{
	private WebDriver driver;
	public BaseUIPage tb=new BaseUIPage();

	public WebUD_Alerts(WebDriver driver,Scenario scenario) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		 this.sd=new StepData();			
		sd.setScenario(scenario);		
		this.scenario=sd.getScenario();
	}	
		
	
	@FindBy(xpath = "//div[@role='tablist']//span[contains(text(),'Alerts')]")
	public WebElement Alerts_tab;

	@FindBy(xpath = "//b[contains(text(),'Account Alerts')]")
	public List<WebElement> AccountAlerts;	

	@FindBy(xpath = "//b[contains(text(),'Sales Leads')]")
	public List<WebElement> SalesLeads;
	
	@FindBy(xpath = "//b[contains(text(),'Competitive Products')]")
	public List<WebElement> CompetitiveProducts;	
	
	@FindBy(xpath = "//*[starts-with(@class,'modal-title') and contains(text(),'Account Alerts' )]//parent::div/following-sibling::div[2]/button[contains(text(),'Save')]")
	public WebElement AccountAlerts_Save;

	@FindBy(xpath = "//b[contains(text(),'Account Alerts')]//parent::li//descendant::span")
	public WebElement AccountAlerts_AddorViewEdit;	
	
	@FindBy(xpath = "//div[@role='tablist']//span[contains(text(),'Address')]")
	public WebElement Address_tab;
	
	@FindBy(xpath = "//*[@class='table dvaddress']//tr/button[contains(text(),' Transfer')]")
	public WebElement TransferButton;
	
	@FindBy(xpath = "//*[@class='modal-body dvtransferModalbody']/div/div/input")
	public WebElement addressTextBox;
	
	@FindBy(xpath = "//div[@class='modal-body dvtransferModalbody']//button[contains(text(),'Search')]")
	public WebElement searchButton;
	
	@FindBy(xpath = "//*[@class='dvsrcResult']/descendant::a")
	public WebElement addressLink;
	
	@FindBy(xpath = "//a[@class='ancsrcnoresult'][contains(text(),'Transfer Customer to this service address')]")
	public WebElement transferAdressLink;
	
	
	@FindBy(xpath="//*[@class='_span_ UIValue popup-alert-text-block']/parent::td/parent::tr/following-sibling::tr//span[contains(text(),'OK')]")
	public WebElement okButton;

	@FindBy(xpath="//div[@class='full-row user-info bg-white']/descendant::*[contains(@class,'Refresh')]")
	WebElement Refresh;		

	public void CreateAlerts(String alerts) throws Exception
	{
		isLoaderSpinnerVisible(driver);	//AddedShweta
		waitForLoading(driver);
		if(HostUrls.webUDroutingChanges.contains("Yes")) {
			if(driver.findElements(By.xpath("//title[contains(text(),'Order History')]")).size()!=0) {}
			else {switchtoWindow("| WebUD", driver);}
			}
		else switchtoWindow("Shaw", driver);
		driver.switchTo().defaultContent();
		scrollToElement(Alerts_tab, driver);
		Alerts_tab.click();
		waitForLoading(driver);
		Assert.assertTrue(AccountAlerts.size()!=0);
		Assert.assertTrue(SalesLeads.size()!=0);
		Assert.assertTrue(CompetitiveProducts.size()!=0);
		if (AccountAlerts_AddorViewEdit.getText().equalsIgnoreCase("Add")) AccountAlerts_AddorViewEdit.click();
		waitForLoading(driver);
		Assert.assertTrue(driver.findElements(By.xpath("//*[starts-with(@class,'modal-title') and contains(text(),'Account Alerts' )]")).size()!=0);
		List <WebElement> labels = driver.findElements(By.xpath("//*[starts-with(@class,'modal-title') and contains(text(),'Account Alerts' )]//parent::div/following-sibling::div[1]/div/label"));
		String alertstype[] = alerts.split(";");
		ArrayList<String> UncheckedOptions = new ArrayList<String>();
		for(int i=0;i<=alertstype.length-1;i++)
		{
			boolean Present=false;			
			for(int j=0;j<=labels.size()-1;j++)
			{
					if(labels.get(j).getText().equals(alertstype[i]))
						{
							Present=true;
							String Checkbox="//*[starts-with(@class,'modal-title') and contains(text(),'Account Alerts' )]//parent::div/following-sibling::div[1]/div/label[contains(text(),'"+labels.get(j).getText()+"')]/preceding::input[1]";
							 if(!(driver.findElement(By.xpath(Checkbox)).isSelected())) {	 UncheckedOptions.add(alertstype[i]);}
							break;		
						}		
			}
			if(!Present) Assert.assertTrue(Present, "Option: "+alertstype[i]+" should be present");
		}	
		System.out.println("Array is: "+ UncheckedOptions); 
		int counterSelcted=0;
		int counterDeselcted=0;
		int size=UncheckedOptions.size();
		
		if(size!=0)
		{
			for (int b=0;b<=size-1;b++)
			{
				String SelectCheckbox="//*[starts-with(@class,'modal-title') and contains(text(),'Account Alerts' )]//parent::div/following-sibling::div[1]/div/label[contains(text(),'"+UncheckedOptions.get(b)+"')]/preceding::input[1]";
				driver.findElement(By.xpath(SelectCheckbox)).click();
				waitForLoading(driver);
				Assert.assertTrue(driver.findElement(By.xpath(SelectCheckbox)).isSelected());
				counterSelcted=b;
			}
		}
		AccountAlerts_Save.click();
		waitForLoading(driver);
		//Verify selected alerts appears or not
		for (int b=0;b<=size-1;b++)
			Assert.assertTrue(driver.findElements(By.xpath("//b[contains(text(),'Account Alerts')]//ancestor::ul//descendant::ul/li[contains(text(),'"+UncheckedOptions.get(b)+"')]")).size()!=0);		
		
		if (AccountAlerts_AddorViewEdit.getText().equalsIgnoreCase("Add"))
			AccountAlerts_AddorViewEdit.click();
		else if(AccountAlerts_AddorViewEdit.getText().equalsIgnoreCase("View/Edit"))
			AccountAlerts_AddorViewEdit.click();
		else
			System.out.println("Option not valid");
		
		waitForLoading(driver);

		if(counterSelcted==size-1)
		{
			for (int b=0;b<=size-1;b++)
			{
				String SelectCheckbox="//*[starts-with(@class,'modal-title') and contains(text(),'Account Alerts' )]//parent::div/following-sibling::div[1]/div/label[contains(text(),'"+UncheckedOptions.get(b)+"')]/preceding::input[1]";
				driver.findElement(By.xpath(SelectCheckbox)).click();
				waitForLoading(driver);
				Assert.assertFalse(driver.findElement(By.xpath(SelectCheckbox)).isSelected());
				counterDeselcted=b;
			}
		}
		try {
			Assert.assertTrue(counterSelcted==counterDeselcted);
		}catch (Throwable t) {
			System.out.println("All options are unchecked");
		}
		AccountAlerts_Save.click();
		waitForLoading(driver);
		//Commented as this has defect
//		Assert.assertTrue(driver.findElements(By.xpath("//b[contains(text(),'Account Alerts')]/following::p[contains(text(),'No Alerts exist for this account.')]")).size()!=0);
	}		

	public void premiseMove(String premiseMoveAdd) throws Exception
	{
		driver.switchTo().defaultContent();
		if(System.getProperty("environment").equalsIgnoreCase("webud") || System.getProperty("environment").equalsIgnoreCase("preprodwebud"))
		{
			downArrowClick(driver);			
		}
		driver.switchTo().defaultContent();
		scrollToElementAndClick(Address_tab, driver);
		waitForLoading(driver);
		isLoaderSpinnerVisible(driver);	//AddedShweta
		waitForLoading(driver);
		scrollToElement(TransferButton, driver);
		waitForLoading(driver);
		if(TransferButton.isEnabled())
		TransferButton.click();
		else
		{
			while(!TransferButton.isEnabled()) {
				driver.switchTo().defaultContent();
				scrollToElementAndClick(Refresh, driver);
				scrollToElementAndClick(Address_tab, driver);
				waitForLoading(driver);
				isLoaderSpinnerVisible(driver);	//AddedShweta
				waitForLoading(driver);
				scrollToElement(TransferButton, driver);
				waitForLoading(driver);
			}
			TransferButton.click();
		}
		WebDriverWait w = new WebDriverWait(driver,90);
		w.withMessage("Checking visiblity of element").until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='summaryaccModalLabel']")));
		addressTextBox.click();
		addressTextBox.sendKeys(premiseMoveAdd);
		searchButton.click();
		w.withMessage("Checking visiblity of element").until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@class='dvsrcResult']/descendant::a")));
		addressLink.click();
		waitForLoading(driver);
		w.withMessage("Checking visiblity of element").until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[@class='ancsrcnoresult'][contains(text(),'Transfer Customer to this service address')]")));
		tb.addScreenshot(driver, this.scenario, "PremiseMove");
		transferAdressLink.click();
		driver.switchTo().defaultContent();
		upArrowClick(driver);
		driver.switchTo().frame("ncOrderEntry");
	}

}