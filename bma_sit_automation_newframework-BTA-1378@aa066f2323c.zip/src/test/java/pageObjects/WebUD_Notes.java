package pageObjects;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class WebUD_Notes extends BaseUIPage
{
	private WebDriver driver;

	public WebUD_Notes(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//div[@role='tablist']//span[contains(text(),'Notes')]")
	public WebElement Notes_tab;	
	
	@FindBy(xpath = "//span[contains(text(),'Create Note')]")
	public WebElement CreateNote_Directlink;

	@FindBy(xpath = "//*[contains(text(),'Customer Notes')]/following::textarea[1]")
	public WebElement CustomerNotes_text;

	@FindBy(xpath = "//*[contains(text(),'Customer Notes')]/following::label[contains(text(),'Create Note')]")
	public WebElement CreateNote_link;

	@FindBy(xpath = "//*[contains(text(),'Customer Notes')]/following::button[contains(text(),'Save')][1]")
	public WebElement CustomerNotes_Save;

	@FindBy(xpath = "//*[contains(text(),'View/Edit All Notes')]")
	public WebElement CustomerNotes_ViewEdit;

	@FindBy(xpath = "//button[contains(text(),'Modify')]")
	public WebElement CustomerNotes_Modify;

	@FindBy(xpath = "//*[contains(text(),'Customer Notes')]//parent::div/button[@aria-label='Close']")
	public WebElement CustomerNotes_Close;

	@FindBy(xpath = "//button[contains(text(),'Delete')]")
	public WebElement CustomerNotes_Delete;

	@FindBy(xpath = "//*[contains(text(),'Confirm Delete')]")
	public WebElement CustomerNotes_Delete_PopUp;

	@FindBy(xpath = "//*[contains(text(),'Confirm Delete')]//parent::div/following::button[contains(text(),'Yes')]")
	public WebElement CustomerNotes_Delete_Yes;

	// *[contains(text(),'View/Edit All
	// Notes')]//ancestor::li//following-sibling::div[2]/li
	// li[@class='showNotes']//preceding::li[1] ----- 23-Jan-2023 (SJRB\spaliwal)

	@FindBy(xpath = "//li[@class='showNotes']")
	public WebElement CustomerNotes_ShowText;

	@FindBy(xpath = "//*[contains(text(),'Activity History') and @class='modal-title']/following::table[1]")
	public WebElement ActivityHistory_table;

	@FindBy(xpath = "//*[contains(text(),'Activity History')]/following::span[contains(text(),'View All')]")
	public WebElement ActivityHistory_ViewAll;

	@FindBy(xpath = "//*[contains(text(),'Activity History') and @class='modal-title']//parent::div/following-sibling::div[1]/p[contains(text(),'Page')]")
	public WebElement ActivityHistory_Pagination;
		
	@FindBy(xpath = "//*[contains(text(),'Activity History') and @class='modal-title']//parent::div/following-sibling::div[1]/p/button[contains(text(),'Next')]")
	public WebElement ActivityHistory_NextPage;	

	@FindBy(xpath = "//*[contains(text(),'Activity History') and @class='modal-title']//parent::div/following-sibling::div[1]/p/button[contains(text(),'Previous')]")
	public WebElement ActivityHistory_PreviousPage;	
	
	@FindBy(xpath = "//*[contains(text(),'Activity History')]//parent::div/button[@aria-label='Close']")
	public WebElement ActivityHistory_Close;

	@FindBy(xpath = "//*[@class='modal-content']/descendant::h1[contains(text(),'Enable Analytics')]")
	public List<WebElement> EnableAnalytics;	

	@FindBy(xpath = "//*[contains(text(),'View Case Management')]")
	public WebElement ViewCaseManagement;	

	@FindBy(xpath = "//*[@class='modal-content']/descendant::button[contains(text(),'Agree')]")
	public WebElement AgreeEnableAnalytics;	

	@FindBy(xpath = "//*[contains(text(),\"403: You do not have permissions to access this page.\")]")
	public List<WebElement> NoPermissionError;
	
		
	
	public void CreateCustomerNotes(String notes) throws Exception {
		waitForLoading(driver);
		if(HostUrls.webUDroutingChanges.contains("Yes")) {
			if(driver.findElements(By.xpath("//title[contains(text(),'Order History')]")).size()!=0) {}
			else {switchtoWindow("| WebUD", driver);}
			}
		else switchtoWindow("Shaw", driver);
		driver.switchTo().defaultContent();
		scrollToElement(Notes_tab, driver);
		Notes_tab.click();
		CustomerNotes_ViewEdit.click();
		WebDriverWait w = new WebDriverWait(driver, 20);
		w.until(ExpectedConditions.visibilityOf(CreateNote_link));
		CreateNote_link.click();
		w.until(ExpectedConditions.visibilityOf(CustomerNotes_Save));		
		CustomerNotes_text.sendKeys(notes);
		CustomerNotes_Save.click();
		//String formatedDate = FormatDate("DD-MMM-YYYY HH:mm");
		//Timestamp ts_ws = Timestamp.from(new Timestamp(formatedDate).toInstant().plusSeconds(60));
		CustomerNotes_Close.click();	
		waitForLoading(driver);
		w.until(ExpectedConditions.textToBePresentInElement(CustomerNotes_ShowText, notes));
		String NotesText = CustomerNotes_ShowText.getText().trim();
		Assert.assertEquals(NotesText, notes);
	}

	public void ModifyCustomerNotes(String notes) throws InterruptedException {
		waitForLoading(driver);
		WebUD_HomePage webudHomePage = new WebUD_HomePage(driver,this.scenario);
		String User= webudHomePage.getUser();
		//String User= WebUD_HomePage.getUser();
		Notes_tab.click();
		CustomerNotes_ViewEdit.click();
		waitForLoading(driver);
		String modifynote = "(//*[contains(text(),'" + User + "')]/following::button[contains(text(),'Modify')])[1]";
		WebElement CustomerNotes_Modify1 = driver.findElement(By.xpath(modifynote));
		WebDriverWait w = new WebDriverWait(driver, 20);
		w.until(ExpectedConditions.visibilityOf(CustomerNotes_Modify1));
		CustomerNotes_Modify.click();
		waitForLoading(driver);
		w.until(ExpectedConditions.visibilityOf(CustomerNotes_Save));
		CustomerNotes_text.click();
		CustomerNotes_text.clear();
		CustomerNotes_text.sendKeys(notes);
		CustomerNotes_Save.click();
		CustomerNotes_Close.click();
		w.until(ExpectedConditions.textToBePresentInElement(CustomerNotes_ShowText, notes));
		String modifiedtext = CustomerNotes_ShowText.getText().trim();
		Assert.assertEquals(modifiedtext, notes);
	}
	
	public void DeleteCustomerNotes(String notes) throws InterruptedException {
		waitForLoading(driver);
		WebUD_HomePage webudHomePage = new WebUD_HomePage(driver,this.scenario);
		String User= webudHomePage.getUser();
		String deletenote = "(//*[contains(text(),'" + User + "')]/following::button[contains(text(),'Delete')])[1]";
		//String User= WebUD_HomePage.getUser();
		Notes_tab.click();
		CustomerNotes_ViewEdit.click();
		waitForLoading(driver);
		
		WebElement CustomerNotes_Delete1 = driver.findElement(By.xpath(deletenote));
		WebDriverWait w = new WebDriverWait(driver, 20);
		w.until(ExpectedConditions.visibilityOf(CustomerNotes_Delete1));
		CustomerNotes_Delete1.click();
		waitForLoading(driver);
		w.until(ExpectedConditions.visibilityOf(CustomerNotes_Delete_PopUp));
		w.until(ExpectedConditions.elementToBeClickable(CustomerNotes_Delete_Yes));
		CustomerNotes_Delete_Yes.click();
		CustomerNotes_Close.click();
		long starttime = System.currentTimeMillis();
		while(driver.findElements(By.xpath("//li[@class='showNotes' and contains(text(),'"+notes+"')]")).size()!=0 && (starttime+(20000)>System.currentTimeMillis()))
		{	
			if(driver.findElements(By.xpath("//li[@class='showNotes' and contains(text(),'"+notes+"')]")).size()==0)break;
		}
		Boolean verifyNotesText = CustomerNotes_ShowText.getText().trim().equalsIgnoreCase(notes);
		Assert.assertFalse(verifyNotesText);
	}

	
	public void ValidateActivityHistory() throws Exception
	{
		scrollToElementAndClick(Notes_tab, driver);
//		Notes_tab.click();
		waitForLoading(driver);
		//String formatedDate = FormatDate("dd-MMM-YYYY HH:mm");
		//String checkNoteTime[]=formatedDate.split(" ");
		Assert.assertTrue(driver.findElements(By.xpath("//b[contains(text(),'Activity History')]/parent::li//descendant::b[contains(text(),'Timezone: Mountain')]")).size()!=0);		
		//System.out.println(WebUD_HomePage.getUser());
		//Thread.sleep(10000);
		WebUD_HomePage webudHomePage = new WebUD_HomePage(driver,this.scenario);
		String User= webudHomePage.getUser();
		//String User= WebUD_HomePage.getUser();
		//String User= WebUD_HomePage.getUser();
		// String noteRow="//td[contains(text(),'"+checkNoteTime[0]+"')]/following-sibling::td[contains(text(),'"+checkNoteTime[1]+"')]/following-sibling::td[contains(text(),'"+User+"')]//parent::tr";
		String noteRow="//tbody[@class='cursorPointer']/tr[1]/span/td[contains(text(),'"+ User +"')]";
		  waitForLoading(driver);
		  WebDriverWait w = new WebDriverWait(driver, 20);
		  w.until(ExpectedConditions.visibilityOf((WebElement) driver.findElement(By.xpath("//tbody[@class='cursorPointer']"))));
		  Assert.assertTrue((driver.findElements(By.xpath(noteRow)).size()!=0), "Notes tab was accessed by "+User);
		  //ExtentCucumberAdapter.addTestStepLog("Notes tab was accessed at: "+formatedDate+" by "+User);
		  ActivityHistory_ViewAll.click();
		  waitForLoading(driver);
		  String PageText=ActivityHistory_Pagination.getText();
		  String lastpage=StringUtils.substringAfter(PageText, "of ");
		  String firsttpage=StringUtils.substringBetween(PageText, "Page ", " of");
		  int a =Integer.parseInt(firsttpage);
		  if (lastpage.contains(firsttpage) && lastpage.contains("1")) System.out.println("Only 1 page hence no Previous and Next option");
		  else
		  {
			  ActivityHistory_NextPage.click();
			  waitForLoading(driver);
			  System.out.println(ActivityHistory_Pagination.getText());
			  Thread.sleep(2000);
			  System.out.println(StringUtils.substringBetween(ActivityHistory_Pagination.getText(), "Page ", " of"));
			  System.out.println(Integer.toString(a+1));
			  if(StringUtils.substringBetween(ActivityHistory_Pagination.getText(), "Page ", " of").contains(Integer.toString(a+1)))
			  ActivityHistory_PreviousPage.click();
			  else
				  System.out.println("Page number is not updated after clicking on Next");
		  }
		  ActivityHistory_Close.click();
		  waitForLoading(driver);
			List <WebElement> rows = driver.findElements(By.xpath("//tbody[@class='cursorPointer']/tr"));
			if(rows.size()==5)
			{
				for(int j=0;j<=rows.size()-2;j++)
				{
					int c=j+1;
					int b=j+2;
					String capturedDate=driver.findElement(By.xpath("//tbody[@class='cursorPointer']/tr["+c+"]/span/td[1]")).getText();
					String capturedTime=driver.findElement(By.xpath("//tbody[@class='cursorPointer']/tr["+c+"]/span/td[2]")).getText();
					String dateTime=capturedDate+" "+capturedTime;
					SimpleDateFormat format = new SimpleDateFormat("DD-MMM-YYYY HH:mm");
					Date d1 = format.parse(dateTime);
					String capturedNextDate=driver.findElement(By.xpath("//tbody[@class='cursorPointer']/tr["+b+"]/span/td[1]")).getText();
					String capturedNextTime=driver.findElement(By.xpath("//tbody[@class='cursorPointer']/tr["+b+"]/span/td[2]")).getText();
					String dateTime1=capturedNextDate+" "+capturedNextTime;
					Date d2 = format.parse(dateTime1);
					if(d2.before(d1))
					Assert.assertTrue(d2.before(d1), "The records are in latest to oldest order.");
					//System.out.println("The records are in latest to oldest order.");	
				}
			}
	}
	
	public void launchCaseManagement() throws InterruptedException {
		waitForLoading(driver);
		Notes_tab.click();
		WebDriverWait w = new WebDriverWait(driver, 20);
		w.until(ExpectedConditions.visibilityOf(ViewCaseManagement));
		ViewCaseManagement.click();
		waitForLoading(driver);
		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		int newTab = tabs.size();
		driver.switchTo().window(tabs.get(newTab-1));		
		if (EnableAnalytics.size()!=0) {AgreeEnableAnalytics.click();}
		waitForLoading(driver);
		Assert.assertFalse(driver.getTitle().contains("logout"));
		Assert.assertFalse(NoPermissionError.size()!=0);	
		Assert.assertEquals(driver.getTitle(), "form - Service Portal");
		Assert.assertTrue(driver.findElements(By.xpath("//*[text()='Consumer']")).size()!=0);
		Assert.assertTrue(driver.findElements(By.xpath("//*[text()='Account Information']")).size()!=0);
		Assert.assertTrue(driver.findElements(By.xpath("//*[text()='Financial Information']")).size()!=0);		
		Assert.assertTrue(driver.findElements(By.xpath("//*[text()='Integration Status']")).size()!=0);	
		Assert.assertTrue(driver.findElements(By.xpath("//a[starts-with(text(),'Cases')]")).size()!=0);
		Assert.assertTrue(driver.findElements(By.xpath("//a[contains(text(),'Case Task')]")).size()!=0);
		Assert.assertTrue(driver.findElements(By.xpath("//a[contains(text(),'Salesforce Cases')]")).size()!=0);
		Assert.assertTrue(driver.findElements(By.xpath("//a[contains(text(),'Field Cases')]")).size()!=0);
	}	
}