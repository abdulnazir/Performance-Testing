package pageObjects;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class CreditCheck extends BaseUIPage
{
	private WebDriver driver;

	public CreditCheck(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

//	@FindBy(xpath = "//li[@class='nav-item dropdown no-border']/a")
	@FindBy(xpath = "//span[contains(@class,'tab_more')]")
	public WebElement MoreTabs;
		
	@FindBy(xpath = "//*[contains(text(),'Credit Check')]")
	public WebElement CreditCheck;	
	
	@FindBy(xpath = "//*[contains(text(),'Customer Accepts Terms')]/parent::div/input")
	public WebElement checkbox_CustomerAcceptTerms;	

	@FindBy(xpath = "//button[contains(text(),'Accept')]")
	public WebElement btn_Accept;
	
	@FindBy(xpath = "//*[contains(text(),'Consent Method:')]/parent::td/following-sibling::td/select")
	public WebElement ConsentMethod;
	
	@FindBy(xpath = "//*[contains(text(),'First Name:')]/parent::td/following-sibling::td/input")
	public WebElement FirstName;
	
	@FindBy(xpath = "//*[contains(text(),'Last Name:')]/parent::td/following-sibling::td/input")
	public WebElement LastName;
	
	@FindBy(xpath = "//*[contains(text(),'Date of Birth:')]/parent::td/following-sibling::td/input")
	public WebElement DateofBirth;
	
	@FindBy(xpath = "//*[contains(text(),'Address:')]/parent::td/following-sibling::td/input")
	public WebElement Address;
	
	@FindBy(xpath = "//*[contains(text(),'Province:')]/parent::td/following-sibling::td/select")
	public WebElement Province;
	
	@FindBy(xpath = "//*[contains(text(),'City:')]/parent::td/following-sibling::td/input")
	public WebElement City;
	
	@FindBy(xpath = "//*[contains(text(),'Postal Code:')]/parent::td/following-sibling::td/input")
	public WebElement PostalCode;	

	@FindBy(xpath = "//*[contains(text(),'customer has reviewed and signed')]/parent::div/input")
	public WebElement checkbox_CustomerSigned;

	@FindBy(xpath = "//button[contains(text(),'Generate Consent')]")
	public WebElement btn_GenerateConsent;

	@FindBy(xpath = "//*[contains(text(),'I confirm that I obtained and reviewed at least one valid')]/parent::div/input")
	public WebElement checkbox_IdVerifed;

	@FindBy(xpath = "//*[contains(text(),'I confirm that')]/parent::div/input/following::button[contains(text(),'Submit')]")
	public WebElement btn_Submit;

	@FindBy(xpath = "//button[contains(text(),'Run Credit Check')]")
	public WebElement btn_RunCreditCheck;
	
	
	public void openmoretabs() throws Exception {
		waitForLoading(driver);
		waitForVisibilityOfElement(MoreTabs,driver); 
		MoreTabs.click();
	}

	public void clickCreditCheck() throws Exception {
		waitForLoading(driver);
		waitForVisibilityOfElement(CreditCheck,driver); 
		CreditCheck.click();
	}

	public void customeracceptterms() throws Exception {
		selectCheckbox(checkbox_CustomerAcceptTerms, driver);	
		btn_Accept.click();
	}	

	public void runCreditCheck() throws Exception {	
		scrollToElementAndClick(btn_Submit, driver);
		waitForLoading(driver);
		selectCheckbox(checkbox_CustomerSigned, driver);
	}

	public void validateProfileApproval() throws Exception {
		scrollToElementAndClick(btn_RunCreditCheck, driver);
		WebDriverWait w = new WebDriverWait(driver, 60);
		w.until(ExpectedConditions.invisibilityOfAllElements(driver.findElements(By.xpath("//img[contains(@src,'spinner.gif')]"))));		
		waitForLoading(driver);
		w.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[text()='Credit Profile']/following-sibling::p[text()='Approved']"))));
		Assert.assertTrue(driver.findElement(By.xpath("//*[text()='Credit Profile']/following-sibling::p[text()='Approved']")).isDisplayed(), "Credit Profile with Approved status should be present");
	}

	public void selectIdentityTypesForCreditCheck(String identitytypes) throws Exception {
		scrollToElementAndClick(btn_GenerateConsent, driver);
		waitForLoading(driver);
		String alertstype[] = identitytypes.split(";");
		for(int i=0;i<=alertstype.length-1;i++)
		{
			String Checkbox="//*[contains(text(),'Acceptable identification')]/parent::div/following-sibling::div/div/label[text()=\""+alertstype[i]+"\"]/preceding::input[1]";
			waitForVisibilityOfElement(driver.findElement(By.xpath("//*[contains(text(),'Acceptable identification')]")),driver); 			
			WebElement IdentityTypes=driver.findElement(By.xpath(Checkbox));
			Assert.assertTrue(IdentityTypes.isDisplayed(), "Option: "+alertstype[i]+" should be present");
			selectCheckbox(IdentityTypes, driver);
		}
		selectCheckbox(checkbox_IdVerifed, driver);	
	}

	public void enterInformationInCreditCheck(String firstName, String lastName, String dOB, String address,
			String city, String province, String postalCode) throws Exception {
		FirstName.clear();
		FirstName.sendKeys(firstName);
		LastName.clear();
		LastName.sendKeys(lastName);
		DateofBirth.sendKeys(dOB);
		Address.sendKeys(address);
		City.sendKeys(city);
		selectElementFromDropdown(Province, driver, "VisibleText", province);
		PostalCode.sendKeys(postalCode);
	}

	public void selectConsentMethodinCreditCheck(String consentmethod) throws Exception {
		selectElementFromDropdown(ConsentMethod, driver, "VisibleText", consentmethod);	
	}
}	