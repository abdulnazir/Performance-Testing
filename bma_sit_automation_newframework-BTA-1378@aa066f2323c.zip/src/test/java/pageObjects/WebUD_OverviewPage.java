package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;

import junit.framework.Assert;

public class WebUD_OverviewPage extends BaseUIPage {
	
	private WebDriver driver;
	public WebUD_OverviewPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//li[@class='nav-item dropdown no-border']/a")
	public WebElement threeDots;
	
	@FindBy(xpath = "//ul[@class='dropdown-menu cpointer show']//a[contains(text(),'GWP Status')]")
	public WebElement gwpStatusLink;
	
	@FindBy(xpath = "//td[contains(text(),'The customer is not subscribed to Disney via Shaw')]")
	public WebElement disneyStatusMsg;
	
	@FindBy(xpath="//ul[@class='dropdown-menu cpointer show']//a[contains(text(),'View Bill')]")
	public WebElement viewbillLink;	
	
	public void clickThreeDots() throws InterruptedException
	{
		//CommentedbyShweta on 08/09/2023 due to xpath change
//		if(driver.findElement(By.xpath("//button[@class='nav-link']/img")).getAttribute("class").equalsIgnoreCase("btn-responsive"))
//		{
//			WebElement upArrow=driver.findElement(By.xpath("//button[@class='nav-link']/img[@class='btn-responsive']"));
//			upArrow.click();
//		}
		isLoaderSpinnerVisible(driver);	//AddedShweta
//		if(driver.findElement(By.xpath("//button[contains(@class,'Chevron')]")).getAttribute("class").equalsIgnoreCase("ChevronDown"))
//		{
//			WebElement upArrow=driver.findElement(By.xpath("//button[contains(@class,'Chevron')]"));
//			upArrow.click();
//		}
		threeDots.click();
		waitForLoading(driver);
	}
	
	public void gwpStatusLink() throws InterruptedException
	{
		gwpStatusLink.click();		
		waitForLoading(driver);
		isLoaderSpinnerVisible(driver);	//AddedShweta
		WebDriverWait wait=new WebDriverWait(driver, 120);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//td[contains(text(),'The customer is not subscribed to Disney via Shaw')]")));
	}
	
	public void disneyStatusMsg()
	{
		String msg=disneyStatusMsg.getText();
		ExtentCucumberAdapter.addTestStepLog("Disney Status Msg : " + msg);
		Assert.assertEquals(msg,"The customer is not subscribed to Disney via Shaw. Please check START order entry to confirm if customer is subscribed to service.");
	}
	
	public void viewBillLink() throws Exception
	{
		viewbillLink.click();		
		waitForLoading(driver);
		isLoaderSpinnerVisible(driver);	
		WebDriverWait wait=new WebDriverWait(driver, 120);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//td[contains(text(),'//td[contains(text(),'Open Bill in a New In Window')]')]")));
		//*[@id="form1"]/div[4]/table/tbody/tr[3]/td[1]
	}
}
