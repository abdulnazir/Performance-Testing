package pageObjects;

import java.util.List;
import java.util.Properties;
import java.util.ArrayList;
import java.util.Arrays;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.UnhandledAlertException;

import java.io.IOException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.interactions.*;

import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.*;
import com.codeborne.selenide.SelenideElement;

import io.cucumber.java.Scenario;
import stepDefinitions.StepData;
import stepDefinitions.Steps;

import java.time.Instant;
import java.time.Duration;


import util.TestUtil;


public class OverviewPage extends BaseUIPage {
	
	private WebDriver driver;
	TestUtil utils;
	public BaseUIPage tb=new BaseUIPage();
//	AddServicesAndFeatures as;
	public OverviewPage(WebDriver driver, Scenario scenario) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
		this.sd=new StepData();			
		sd.setScenario(scenario);		
		this.scenario=sd.getScenario();
	}
	String orderStatus;
	String Overviewpage_url;
	String equipmentdetail;
	String effectiveDate;

	String overview_url = prop.getProperty("overviewpage_url");
	
	@FindBy(xpath = "//td[@class=\"summary-cell  afterColumn\"]/div/table/tbody/tr[12]/td/div/table/tbody/tr/td/div")
	WebElement equipmentdetails;
	
	@FindBy(xpath = "//*[@id='snForRetailPickupCollectionLayout_main']")
	WebElement retailPickupHardware;

	@FindBy(xpath = "/html[1]/body[1]/div[4]/table[1]/tbody[1]/tr[2]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[2]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[2]/div[1]/input[1]")
	WebElement Xpod1;

	@FindBy(xpath = "/html[1]/body[1]/div[4]/table[1]/tbody[1]/tr[2]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[2]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/table[1]/tbody[1]/tr[2]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[2]/div[1]/input[1]")
	WebElement Xpod2;

	@FindBy(xpath = "/html[1]/body[1]/div[4]/table[1]/tbody[1]/tr[2]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[2]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/table[1]/tbody[1]/tr[3]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[2]/div[1]/input[1]")
	WebElement Xpod3;

	@FindBy(xpath = "//*[contains(text(), 'XB6')]/../../td[2]/div/input")
	WebElement XB6input;
	
	@FindBy(xpath = "//*[contains(text(), 'XB7')]/../../td[2]/div/input")
	WebElement XB7input;

	@FindBy(xpath = "//*[contains(text(), 'XB8')]/../../td[2]/div/input")
	WebElement XB8input;
	
	@FindBy(xpath = "//*[contains(text(), 'DCX')]/../../td[2]/div/input")
	WebElement DCXinput;

	@FindBy(xpath = "//*[@id=\"sn-input-layout_main\"]/tbody/tr[1]/../tr[1]/td/div/table/tbody//td[2]//input")
	WebElement XB6withXI6;

	@FindBy(xpath = "//*[contains(text(), 'Xi6')]/../../td[2]/div/input | //*[contains(text(), 'BlueCurve TV')]/../../td[2]/div/input")
	WebElement XI6;

	@FindBy(xpath = "//*[contains(text(), 'Phone')]/../../td[2]/div/input")
	WebElement DPT;

	@FindBy(xpath = "//*[contains(text(), 'Hitron')]/../../td[2]/div/input")
	WebElement Hitron;

	@FindBy(xpath = "//*[text()= 'Submit Serial Numbers']")
	WebElement SubmitBtn;

	@FindBy(xpath = "//input[@id='serial-number-input1573662593830_main']")
	WebElement HitronSer;

	@FindBy(xpath = "//*[@id='summaryViewSelector_main']")
	WebElement Backtrack;

	@FindBy(xpath = "//*[@id='activate-button']/span/span")
	WebElement ActivateBtn;

	@FindBy(xpath = "//*[@id='confirm-activation-button']/span/span")
	WebElement ConfActivBtn;

	@FindBy(xpath = "//*[@id='cur-order-status-link_main']")
	WebElement orderstatus;

	@FindBy(xpath = "//*[@id=\"cur-order-status-link_main\"]/ancestor::table[@id=\"cur-order-status-frame_main\"]//div[@id=\"cur-order-status-errors\"]")
	WebElement orderStatusHasError;

	@FindBy(xpath = "//*[@id='close-cbs-button']/span/span")
	WebElement closecbsbutton;

	@FindBy(xpath = "//*[@id=\"cur-order-status-errors\"]")
	WebElement processingError;

	@FindBy(xpath = "//*[@id=\"error-task-name-dialog-layout\"]/table/tbody/tr[2]/td/div[]/table/tbody/tr/td/div")
	WebElement errorMsg;

	@FindBy(xpath = "//*[@id=\"order-summary-tab_main\"]")
	WebElement workOrderSummary;

	@FindBy(xpath = "//td[@class=\"summary-cell beforeColumn\"]//div[@id='category-Internet Product-label']")
	WebElement currentProductInternet;

	@FindBy(xpath = "//td[@class=\"summary-cell afterColumn\"]//div[@id='category-Internet Product-label']")
	WebElement newProductInternet;

	@FindBy(xpath = "//td[@class=\"summary-cell beforeColumn\"]//div[@id='category-Television Product-label']")
	WebElement currentProductTV;

	@FindBy(xpath = "//td[@class=\"summary-cell afterColumn\"]//div[@id='category-Television Product-label']")
	WebElement newProductTV;

	@FindBy(xpath = "//td[@class=\"summary-cell beforeColumn\"]//div[@id='category-Phone Product-label']")
	WebElement currentProductPhone;

	@FindBy(xpath = "//td[@class=\"summary-cell afterColumn\"]//div[@id='category-Phone Product-label']")
	WebElement newProductPhone;

	@FindBy(xpath = "//*[@class=\"_span_ UIValue error-task-name\"]")
	WebElement errortext;

	@FindBy(xpath = "//a[text()=\"Product Summary\"]")
	WebElement productSummary;

	@FindBy(xpath = "//a[@id = 'order-processing-details-dialog_closeButton']")
	WebElement orderSummaryDialogClose;

	@FindBy(xpath = "//a[@class='UIHyperlink summary-csr-info cancel-order-label']")
	WebElement cancelOrder;

	@FindBy(xpath = "//span[text()=' Yes ']")
	WebElement confirmCancelOrder;

	@FindBy(xpath = "//div[@class=\"_span_ node-name DiffAdded node-name-3\"]")
	WebElement distinctiveRing;

	@FindBy(xpath = "//*[@id=\"close-cbs-button\"]/span/span")
	WebElement closeCBSButton;

	@FindBy(xpath = "//span[text()=\"Confirm Activation\"]")
	WebElement confirmActivationButton;

	@FindBy(xpath = "//span[text()=\"Close\"]")
	WebElement closeButton;

	@FindBy(xpath = "//a[@class=\"UITableHyperlink QuoteDifferenceLink\"]")
	WebElement orderSummary;
	
	@FindBy(xpath="//div[@class='full-row user-info bg-white']/descendant::*[contains(@class,'Refresh')]")
	WebElement webudRefreshIcon;
	
	
	@FindBy(xpath="//a[@id=\"ordersViewSelector_main\"][contains(text(),'Account Summary')] | //div[@id='summaryViewSelector']")
	WebElement accountSummary;
	
	@FindBy(xpath="//div[@id='refresh-order-status-button']/descendant::a")
	WebElement productSummaryRefreshLink;	
	
	@FindBy(xpath = "//*[@id='over-tab']")
	public WebElement Overviewtab;
	
	
	 

	public void XPOD_serNum(String SerXpod1, String SerXpod2, String SerXpod3) throws InterruptedException {
		List<WebElement> RP_xpods = driver
				.findElements(By.xpath("//*[contains(text(), 'Pods')]/../../td[2]/div/input"));
		String[] sernum = { SerXpod1, SerXpod2, SerXpod3 };

		for (int num = 0; num < (RP_xpods).size(); num++) {
			RP_xpods.get(num).sendKeys(sernum[num]);
		}

	}

	public void overviewHardTab() throws InterruptedException, IOException {
		Thread.sleep(5000);
		if(System.getProperty("environment").equalsIgnoreCase("webud"))
		{
				driver.switchTo().defaultContent();
				//CommentedbyShweta on 08/09/2023 due to xpath change
//				if(driver.findElement(By.xpath("//button[@class='nav-link']/img")).getAttribute("class").equalsIgnoreCase("btn-responsive"))
//				{
//					WebElement upArrow=driver.findElement(By.xpath("//button[@class='nav-link']/img[@class='btn-responsive']"));
//					upArrow.click();
//				}
				if(driver.findElement(By.xpath("//button[contains(@class,'Chevron')]")).getAttribute("class").equalsIgnoreCase("ChevronDown"))
				{
					WebElement upArrow=driver.findElement(By.xpath("//button[contains(@class,'Chevron')]"));
					upArrow.click();
				}
			driver.switchTo().frame("ncframeOrderHistory");
//			driver.switchTo().defaultContent();
//			JavascriptExecutor js = (JavascriptExecutor) driver;
//			js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
//			driver.switchTo().frame("ncOrderEntry");
		}
		else
		{
			driver.navigate().refresh();
		}
		wait.withMessage("Hardware retail pickup button not visible")
		.until(ExpectedConditions.visibilityOf(retailPickupHardware));
		retailPickupHardware.click();
//		TestBase.takeScreenshot("overview");
	}
	
	public void overviewshawHardTab() throws InterruptedException, IOException {
		Thread.sleep(5000);
		driver.navigate().refresh();
//		addInfoInReport("Order has been changed to Shaw Delivery");
//		TestBase.takeScreenshot("overview");
		
	}

	public void Hitsernum(String Hit) {
		HitronSer.sendKeys(Hit);
	}

//	public void XPOD_serNum(String SerXpod1, String SerXpod2,String SerXpod3) throws InterruptedException
//	{
//		Xpod1.click();
//		Thread.sleep(5000);
//		Xpod1.sendKeys(SerXpod1);
//		Thread.sleep(5000);
//		Xpod2.click();
//		Thread.sleep(5000);
//		Xpod2.sendKeys(SerXpod2);
//		Thread.sleep(5000);
//		Xpod3.click();
//		Thread.sleep(5000);
//		Xpod3.sendKeys(SerXpod3);
//	}

	public void xB6serNum(String serialnumXB6) throws InterruptedException {
		Thread.sleep(2000);
		wait.withMessage("XB6input button not visible").until(ExpectedConditions.visibilityOf(XB6input));
		XB6input.click();
		Thread.sleep(1000);
		XB6input.sendKeys(serialnumXB6);
	}
	
	public void xB7serNum(String serialnumXB7) throws InterruptedException {
		Thread.sleep(2000);
		wait.withMessage("XB6input button not visible").until(ExpectedConditions.visibilityOf(XB7input));
		//XB6input.click();
		Thread.sleep(1000);
		XB7input.sendKeys(serialnumXB7);
	}
	public void xB8serNum(String serialnumXB8) throws InterruptedException {
		Thread.sleep(2000);
		wait.withMessage("XB6input button not visible").until(ExpectedConditions.visibilityOf(XB8input));
		//XB6input.click();
		Thread.sleep(1000);
		XB8input.sendKeys(serialnumXB8);
	}

	public void dCXserNum(String serialnumDCX) throws InterruptedException {
		Thread.sleep(2000);
		wait.withMessage("DCXinput button not visible").until(ExpectedConditions.visibilityOf(DCXinput));
		DCXinput.click();
		Thread.sleep(1000);
		DCXinput.sendKeys(serialnumDCX);
	}

	public void XB6andXI6SerNum(String XB6Num, String XI6Num) throws InterruptedException {
		XB6withXI6.click();
		Thread.sleep(3000);
		XB6withXI6.sendKeys(XB6Num);
		Thread.sleep(3000);
		XI6.click();
		Thread.sleep(3000);
		XI6.sendKeys(XI6Num);
	}

	public void submitButton() {
		wait.withMessage("submitbutton not visible").until(ExpectedConditions.visibilityOf(SubmitBtn));
		SubmitBtn.click();
	}

	public void ProductSummary() throws InterruptedException {
		Thread.sleep(5000);
		Backtrack.click();
		Thread.sleep(2000);
	}

//	public void ConfirmActivate() throws Exception {
////		Thread.sleep(10000);
////		driver.navigate().refresh();
////		Thread.sleep(10000);
////		driver.navigate().refresh();
////		Thread.sleep(5000);
////		scrollToElementAndClick(Refresh, driver);
//		webudRefreshIcon.click();
//		waitForLoading(driver);	
////		driver.switchTo().frame("ncOrderEntry"); 				
//		driver.switchTo().frame("ncframeOrderHistory");
//		scrollToElementAndClick(productSummary, driver);
////		orderSummary.click();
////		Thread.sleep(5000);
//		// wait.withMessage("Activate button not
//		// visible").until(ExpectedConditions.visibilityOf(ActivateBtn));
//		scrollToElementAndClick(ActivateBtn, driver);
////		ActivateBtn.click();
//		wait.withMessage("confirm activation button not visible").until(ExpectedConditions.visibilityOf(ConfActivBtn));
////		ConfActivBtn.click();
//		scrollToElementAndClick(ConfActivBtn, driver);
//		driver.navigate().refresh();
//	}

	public void ConfirmActivate() throws Exception {
		for(int i=0; i<4;i++) {
		if(System.getProperty("environment").equalsIgnoreCase("webud"))
		{
			waitForLoading(driver);	
			driver.switchTo().parentFrame();
			scrollToElementAndClick(webudRefreshIcon, driver);
//			webudRefreshIcon.click();
			waitForLoading(driver);	
			isLoaderSpinnerVisible(driver);	//AddedShweta
			Thread.sleep(1000);
//			webudRefreshIcon.click();
//			Thread.sleep(5000);
//			webudRefreshIcon.click();
//			Thread.sleep(5000);
			goToFrame(driver, "ncframeOrderHistory");
//			List <WebElement> iframes = driver.findElements(By.tagName("iframe"));
//			for(WebElement iframe: iframes)
//			{
//				if (iframe.getAttribute("id").equals("ncframeOrderHistory"))
//				{
//					driver.switchTo().frame("ncframeOrderHistory");
//					break;
//				}
//			}
		}
		else
		{
			Thread.sleep(5000);
			driver.navigate().refresh();
			Thread.sleep(5000);
			driver.navigate().refresh();
			Thread.sleep(5000);
		}
		
		scrollToElementAndClick(productSummary,driver);
		waitForLoading(driver);	
//		orderSummary.click();
		Thread.sleep(1000);
		if(driver.findElements(By.xpath("//*[@id='activate-button']/span/span")).size()!=0)break;
		try {
		if(driver.findElements(By.xpath("//div[@id='refresh-order-status-button']/descendant::a")).size()>0)
		{
			scrollToElementAndClick(productSummaryRefreshLink, driver);
		}}catch (NoSuchElementException e) {System.out.println("The element is not present");}
		driver.switchTo().parentFrame();
		webudRefreshIcon.click();
		waitForLoading(driver);
		goToFrame(driver, "ncOrderEntry");
		waitForLoading(driver);

	}
//		wait.until(ExpectedConditions.invisibilityOfAllElements(driver.findElements(By.xpath("//div[@id='refresh-order-status-button']/descendant::a"))));
		wait.withMessage("confirm activation button not visible").until(ExpectedConditions.visibilityOf(ActivateBtn));
		// wait.withMessage("Activate button not
		// visible").until(ExpectedConditions.visibilityOf(ActivateBtn));
		tb.addScreenshot(driver, this.scenario, "Activate Button");
		scrollToElementAndClick(ActivateBtn,driver);
		wait.withMessage("confirm activation button not visible").until(ExpectedConditions.visibilityOf(ConfActivBtn));
		ConfActivBtn.click();
		if(System.getProperty("environment").equalsIgnoreCase("webud"))
		{
			driver.switchTo().parentFrame();
			webudRefreshIcon.click();
		}
		else
		{
			driver.navigate().refresh();
		}
		tb.addScreenshot(driver, this.scenario, "Confirm Activate Button");
	}
	
	
	
	public void CBSClose() throws InterruptedException {
		Thread.sleep(5000);
		closecbsbutton.click();
		Thread.sleep(120000);
		ConfActivBtn.click();
		Thread.sleep(5000);
		driver.navigate().refresh();
		Thread.sleep(5000);
	}

	
	public void launchOverviewPage() {
		driver.get(overview_url);
	}

	private WebElement getOrderSummaryDialogDetails() throws InterruptedException, IOException {
		WebElement status = driver.findElement(By.xpath("//a[text() = 'Completed' or text() = 'Processing']"));
		status.click();
		Thread.sleep(2000);
		//takeScreenshot("AccountSummary_Overview");
		orderSummaryDialogClose.click();
		Thread.sleep(200);
		// productSummary.click();
		// Thread.sleep(3000);
		//takeScreenshot("ProductSummary_Overview");

		return status;
	}

	private Boolean checkProcessingError(SelenideElement lbody) {
		return $$(lbody.findAll(By.xpath("tr/td[12]"))).texts().contains("Yes");
	}

	public String taskRetry() throws IOException, InterruptedException {
		Thread.sleep(5000);
		if(!System.getProperty("environment").equalsIgnoreCase("webud"))
		{
			driver.get(Steps.overviewpage);
		}
		SelenideElement lbody = $(By.xpath("//table[@id='customerOrders']/tbody"));
		SelenideElement lthis = $(By.partialLinkText("Processing")) == null ? $(By.partialLinkText("Completed"))
				: $(By.partialLinkText("Processing"));
		lthis.click();
		$(By.xpath("//*[text()='Order Processing Details']")).waitUntil(visible, 7000);
//		takeScreenshot("Account Summary");

		for (SelenideElement lretry : $$(lbody.findAll(By.xpath("//span[text() = 'Retry']")))) {
			if (lretry.isEnabled()) {
				lretry.click();
			}
		}
		Thread.sleep(15000);

		if (!checkProcessingError(lbody)) {
			$(By.id("order-processing-details-dialog_closeButton")).click();
			return "No Failed Tasks";
		} else {
			return "Failed Tasks are present";
		}
	}

	public String checkOrderCompleted(int waitForOrderCompletion) throws InterruptedException, IOException {

		String orderStatusText = "";
		String errorText = "";

		Instant startTime;
		for (startTime = Instant.now(); Duration.between(startTime, Instant.now())
				.toMillis() < waitForOrderCompletion;) {

			Thread.sleep(1009);
			if (prop.getProperty("overviewPageRefresh", "on").equalsIgnoreCase("on")) {

				for (char c : "12345".toCharArray()) {
					try {
						driver.get(Steps.overviewpage);
						productSummary.click();
//						waitForLoading(driver);
//						takeScreenshot("");
						errorText = orderStatusHasError.getText();
						break;
					} catch (NoSuchElementException e) {
//						addErrorInReport("ProductSummary element not found in Overview Page. Refresh Count : "
//								+ Character.toString(c));
//						takeScreenshot("");
						driver.get(Steps.overviewpage);
						Thread.sleep(4000);
					}
				}

				for (char c : "12345".toCharArray()) {
					try {
						driver.get(Steps.overviewpage);
						productSummary.click();
//						waitForLoading(driver);
//						takeScreenshot("");
						errorText = orderStatusHasError.getText();
						break;
					} catch (NoSuchElementException e) {
//						addErrorInReport("OrderStatus text not found in Overview Page. Refresh Count : "
//								+ Character.toString(c));
//						takeScreenshot("");
						Thread.sleep(9000);
					} catch (UnhandledAlertException e) {
//						addErrorInReport("Got Unhandled Alert Exception. Refresh Count : " + Character.toString(c));
//						takeScreenshot("");
						Thread.sleep(9000);
					}
				}
			} else {
				driver.get(Steps.overviewpage);
				productSummary.click();
//				takeScreenshot("");
				Thread.sleep(2000);
//				waitForLoading(driver);
				errorText = orderStatusHasError.getText();
			}

			if (errorText.toLowerCase().contains("error")) {
				orderStatusText = orderstatus.getText() + errorText;
				orderstatus.click();
				Thread.sleep(3000);
				return orderStatusText;
			} else if (orderstatus.getText().contains("Completed")) {
				return orderstatus.getText();
			}
		}

		orderstatus.click();
		return orderstatus.getText();
	}

	public String retrieveOrderStatus() throws InterruptedException, IOException {
		String orderStatus;
//		addURLInReport();
		if (prop.getProperty("CBSTOSTART", "no").equalsIgnoreCase("no")) {
			productSummary.click();
			closeCBS();
			confirmActivation();
			close();
		}

		orderStatus = checkOrderCompleted(Integer.parseInt(prop.getProperty("orderStatusTime")) * 60 * 1000);

		if (prop.getProperty("overviewPageRetry", "on").equalsIgnoreCase("on")) {
			for (char c : "12345".toCharArray()) {
				if (orderStatus.contains("Completed")) {
//					takeScreenshot("Order Completed");
					return orderStatus;
				}
				String retryStatus = taskRetry();
//				addInfoInReport("Retry Task attempt " + c + " : " + retryStatus);
				orderStatus = checkOrderCompleted(10000);
			}
		}

		return orderStatus;
	}

	public String retrieveProcessingOrderStatus() throws InterruptedException, IOException {
		Thread.sleep(4000);
		for (char c : "12345".toCharArray()) {

			try {
				driver.get(Steps.overviewpage);
//				TestBase.takeScreenshot("OrderSummary");
				productSummary.click();
				break;
			} catch (NoSuchElementException e) {
//				addErrorInReport(
//						"ProductSummary element not found in Overview Page. Refresh Count : " + Character.toString(c));
//				takeScreenshot("");
				driver.get(Steps.overviewpage);
				Thread.sleep(4000);
			}
		}
		Thread.sleep(2000);
		return orderStatus = orderstatus.getText();
	}
	
	public String webUdRetrieveProcessingOrderStatus() throws Exception {
		Thread.sleep(4000);
		for (char c : "12345".toCharArray()) {

			try {
//				driver.get(Steps.overviewpage);
//				TestBase.takeScreenshot("OrderSummary");
				driver.switchTo().defaultContent();
				scrollToElementAndClick(webudRefreshIcon,driver);
				isLoaderSpinnerVisible(driver);
				waitForLoading(driver);	
				isLoaderSpinnerVisible(driver);
//				driver.switchTo().frame("ncOrderEntry"); 				
				driver.switchTo().frame("ncframeOrderHistory");
				scrollToElementAndClick(productSummary, driver);
//				productSummary.click();
				break;
			} catch (NoSuchElementException e) {
//				addErrorInReport(
//						"ProductSummary element not found in Overview Page. Refresh Count : " + Character.toString(c));
//				takeScreenshot("");
//				driver.get(Steps.overviewpage);
				Thread.sleep(4000);
			}
		}
		Thread.sleep(2000);
		return orderStatus = orderstatus.getText();
	}

	public void errormessage() {

		String errorTextMessage = errortext.getText();
		System.out.println(errorTextMessage);
	}

	public void equipmentstatus() {
		equipmentdetail = equipmentdetails.getText();
		System.out.println(equipmentdetail);
		String expectedequipmentdetails = "Employee BlueCurve Gateway XB6 - DOCSIS";
		Assert.assertEquals(equipmentdetail, expectedequipmentdetails);

	}

	public void cancelOrder() throws InterruptedException,Exception {

		//	driver.navigate().refresh();
			driver.switchTo().frame("ncframeOrderHistory");
			Thread.sleep(10000);
			scrollToElementAndClick(productSummary,driver);
			Thread.sleep(5000);
			// wait.withMessage("Activate button not
			// visible").until(ExpectedConditions.visibilityOf(ActivateBtn));
			scrollToElementAndClick(cancelOrder,driver);
			Thread.sleep(2000);
			
			WebElement RetunHarware = driver.findElement(By.xpath("//*[@id='recoverypopup-ok-after-cancel-order']/span/span"));
			if(RetunHarware.isDisplayed()) 
				{
				RetunHarware.click();
				}
			waitForLoading(driver);
			waitForLoading(driver);
			scrollToElementAndClick(confirmCancelOrder,driver);
			Thread.sleep(27000);
		}
	public String verifyDistinctiveRing() {
		String distinctiveRingText = distinctiveRing.getText();
		return distinctiveRingText;
	}

	public void closeCBS() {
		wait.withMessage("closeCBSButton not visible").until(ExpectedConditions.visibilityOf(closeCBSButton));
		closeCBSButton.click();
	}

	public void confirmActivation() throws InterruptedException {
		Thread.sleep(120000);
		// wait.withMessage("confirm Activation not
		// visible").until(ExpectedConditions.visibilityOf(confirmActivationButton));
		confirmActivationButton.click();
	}

	public void close() throws InterruptedException {
		Thread.sleep(1000);
		closeButton.click();
	}

	public String getEffectiveDate() throws InterruptedException {
		Thread.sleep(2000);
		productSummary.click();
//		waitForLoading(driver);
		effectiveDate = driver.findElement(By.xpath("//table[@class=\"UIGridLayout appointment-info\"]//td[2]/div"))
				.getText();
		String[] date = effectiveDate.split(" ");
		String month = date[4];
		System.out.println(month);
		return month;

	}

	public void Xi6serNum(String serialnumXI6) throws InterruptedException {
		// Thread.sleep(2000);
		wait.withMessage("Xi6 input button not visible").until(ExpectedConditions.visibilityOf(XI6));
		XI6.click();
		Thread.sleep(1000);
		XI6.sendKeys(serialnumXI6);
	}

	public void DPTserNum(String serialnumDPT) throws InterruptedException {
		// Thread.sleep(2000);
		wait.withMessage("Xi6 input button not visible").until(ExpectedConditions.visibilityOf(DPT));
		DPT.click();
		Thread.sleep(1000);
		DPT.sendKeys(serialnumDPT);
	}

	public void HitronserNum(String serialnumHitron) throws InterruptedException {
		// Thread.sleep(2000);
		//wait.withMessage("Xi6 input button not visible").until(ExpectedConditions.visibilityOf(Hitron));
		Hitron.click();
		Thread.sleep(1000);
		Hitron.sendKeys(serialnumHitron);
	}
	
	public String webUDretrieveOrderStatus() throws Exception {
			driver.switchTo().defaultContent();
			//CommentedbyShweta on 08/09/2023 due to xpath change
//			if(driver.findElement(By.xpath("//button[@class='nav-link']/img")).getAttribute("class").equalsIgnoreCase("btn-responsive"))
//			{
//				WebElement upArrow=driver.findElement(By.xpath("//button[@class='nav-link']/img[@class='btn-responsive']"));
//				upArrow.click();
//			}

//			if(driver.findElement(By.xpath("//button[contains(@class,'Chevron')]")).getAttribute("class").equalsIgnoreCase("ChevronDown"))
//			{
//				WebElement upArrow=driver.findElement(By.xpath("//button[contains(@class,'Chevron')]"));
//				upArrow.click();
//			}
			waitForLoading(driver);
			if (driver.findElement(By.xpath("//*[@id='exampleModalPopup0']//span[contains(text(),'Refund Cheque')]/parent::div/input")).isDisplayed())
			{
				driver.findElement(By.xpath("//*[@id='exampleModalPopup0']//span[contains(text(),'Refund Cheque')]/parent::div/input")).click();
				driver.findElement(By.xpath("//*[@id='exampleModalPopup0']//button[contains(text(),'Save')]")).click();
				waitForLoading(driver);
			}
			waitForLoading(driver);
			goToFrame(driver, "ncframeOrderHistory");
			waitForLoading(driver);
			scrollToElementAndClick(accountSummary, driver);
//			accountSummary.click();
			waitForLoading(driver);
			if (prop.getProperty("CBSTOSTART", "no").equalsIgnoreCase("no")) {
				productSummary.click();
				closeCBS();
				confirmActivation();
				close();
			}
			String orderStatus = webUDcheckOrderCompleted(Integer.parseInt(prop.getProperty("orderStatusTime")) * 60 * 1000);
			if (prop.getProperty("overviewPageRetry", "on").equalsIgnoreCase("on")) {
				for (char c : "12345".toCharArray()) {
					if (orderStatus.contains("Completed")) {
						return orderStatus;
					}
					String retryStatus = taskRetry();
					orderStatus = webUDcheckOrderCompleted(10000);
				}
			}
		return orderStatus;
	}
	
	public String webUDcheckOrderCompleted(int waitForOrderCompletion) throws Exception {

		String orderStatusText = "";
		String errorText = "";

		Instant startTime;
		JavascriptExecutor js = (JavascriptExecutor) driver;
		for (startTime = Instant.now(); Duration.between(startTime, Instant.now())
				.toMillis() < waitForOrderCompletion;) {

//			Thread.sleep(1009);
			if (prop.getProperty("overviewPageRefresh", "on").equalsIgnoreCase("on")) {
				
				for (char c : "12345".toCharArray()) {
					try {

						driver.switchTo().defaultContent();
						webudRefreshIcon.click();
						waitForLoading(driver);
						goToFrame(driver, "ncframeOrderHistory");	
//						driver.switchTo().frame("ncframeOrderHistory");
						isLoaderSpinnerVisible(driver);	//AddedShweta
						waitForLoading(driver);
						scrollToElementAndClick(productSummary, driver);
						try {
							if(driver.findElements(By.xpath("//div[@id='refresh-order-status-button']/descendant::a")).size()>0)
							{
								scrollToElementAndClick(productSummaryRefreshLink, driver);
								waitForLoading(driver);
							}}catch (NoSuchElementException e) {System.out.println("The element is not present");}
						
						Thread.sleep(500);
//						takeScreenshot("");
						errorText = orderStatusHasError.getText();
						System.out.println(errorText);
						break;
					} catch (NoSuchElementException e) {
//						addErrorInReport("ProductSummary element not found in Overview Page. Refresh Count : "
//								+ Character.toString(c));
//						takeScreenshot("");
//						driver.get(Steps.overviewpage);
						Thread.sleep(2000);
					}
				}
			} else {
//				driver.get(Steps.overviewpage);
				productSummary.click();
//				takeScreenshot("");
				waitForLoading(driver);
				errorText = orderStatusHasError.getText();
			}
			waitForLoading(driver);
			isLoaderSpinnerVisible(driver);
			scrollToElementAndClick(productSummary, driver);
			waitForLoading(driver);
			if (errorText.toLowerCase().contains("error")) {
				orderStatusText = orderstatus.getText() + errorText;
				orderstatus.click();
				Thread.sleep(2000);
				return orderStatusText;
			} else if (orderstatus.getText().contains("Completed")) {
				return orderstatus.getText();
			}
		}

		orderstatus.click();
		return orderstatus.getText();
	}
	
	public String webUDcheckOrderCompletedStatus() throws InterruptedException, IOException {
		driver.switchTo().defaultContent();
		webudRefreshIcon.click();
		waitForLoading(driver);
		waitForLoading(driver);
		Thread.sleep(5000);
		driver.switchTo().frame("ncframeOrderHistory");
		productSummary.click();
		Thread.sleep(15000);
		waitForLoading(driver);
		return orderstatus.getText();
	}

		


	public void checkAccountSummaryOrderStatus(String ordernumber, String customerOrderType, String expectedcustomerfOrderStatus ) throws Exception {
		scrollToElementAndClick(Overviewtab, driver);
		goToFrame(driver, "ncframeOrderHistory");
		waitForLoading(driver);
		while(!(driver.findElements(By.xpath("//a[@id=\"ordersViewSelector_main\"][contains(text(),'Account Summary')] | //div[@id='summaryViewSelector']")).size()!=0))
		{
			driver.switchTo().defaultContent();
			scrollToElementAndClick(webudRefreshIcon, driver);	
		}
		goToFrame(driver, "ncframeOrderHistory");
		waitForLoading(driver);
		scrollToElementAndClick(accountSummary, driver);
		waitForLoading(driver);
		String orderStatusText;
		WebElement customerOrderLastRow = driver.findElement(By.xpath("(//table[@id='customerOrders']/descendant::*[contains(text(),'"+customerOrderType+"')])[1]/parent::tr/td[1]/a"));
		waitForLoading(driver);	
		scrollToElementAndClick(customerOrderLastRow, driver);
		isLoaderSpinnerVisible(driver);	//AddedShweta
		waitForLoading(driver);			
		scrollToElement(orderstatus, driver);
		orderStatusText = orderstatus.getText();
		switch (customerOrderType) {
		case "Suspend":
			if (orderStatusText.equalsIgnoreCase("Completed")) {Assert.assertTrue("The Suspension order is Completed as expected", orderStatusText.equalsIgnoreCase("Completed"));} 
			if (orderStatusText.equalsIgnoreCase("Processing")) {
				for(int i=0;i<5;i++)
				{
					if (orderStatusText.equalsIgnoreCase("Completed"))
						break;
					else {
						driver.switchTo().defaultContent();
						scrollToElementAndClick(webudRefreshIcon, driver);	
						isLoaderSpinnerVisible(driver);
						waitForLoading(driver);
						goToFrame(driver, "ncframeOrderHistory");	}
				}	
			}
			Assert.assertTrue("The Suspension order is Completed as expected", orderStatusText.equalsIgnoreCase("Completed")); 
			scrollToElementAndClick(accountSummary, driver);
			waitForLoading(driver);	
			WebElement customerOrderResumeLastRow = driver.findElement(By.xpath("(//table[@id='customerOrders']/descendant::*[contains(text(),'Resume')])[1]/parent::tr/td[1]/a"));
			scrollToElementAndClick(customerOrderResumeLastRow, driver);
			isLoaderSpinnerVisible(driver);	//AddedShweta
			waitForLoading(driver);			
			scrollToElement(orderstatus, driver);
			orderStatusText = orderstatus.getText();
			Assert.assertTrue("The Resume order is in Processing as expected", orderStatusText.equalsIgnoreCase("Processing")); 
		break;
		case "Resume":
			if (orderStatusText.equalsIgnoreCase("Completed")) {Assert.assertTrue("The Resume order is Completed as expected", orderStatusText.equalsIgnoreCase("In-Flight Modified"));} 
			if (orderStatusText.equalsIgnoreCase("Processing")) {
				for(int i=0;i<5;i++)
				{
					if (orderStatusText.equalsIgnoreCase("In-Flight Modified"))
						break;
					else {
						driver.switchTo().defaultContent();
						scrollToElementAndClick(webudRefreshIcon, driver);	
						isLoaderSpinnerVisible(driver);
						waitForLoading(driver);
						goToFrame(driver, "ncframeOrderHistory");	}
				}	
			}	
			Assert.assertTrue("The Resume order is Completed as expected", orderStatusText.equalsIgnoreCase("In-Flight Modified")); 
		break;
		case "Disconnect":
			if (orderStatusText.contains("Processing")) {
				if(orderStatusHasError.getText().contains("errors")) {
					orderstatus.click();
				    if(driver.findElements(By.xpath("//*[@id='erroneous-tasks-details-scroll']/descendant::*[contains(text(),'Voicemail Deactivation')]")).size()!=0)
					Assert.assertTrue("The Disconnect has HPE SA Voicemail Deactivation error task. Please check in NC", driver.findElements(By.xpath("//*[@id='erroneous-tasks-details-scroll']/descendant::*[contains(text(),'Voicemail Deactivation')]")).size()!=0);}
				for(int i=0;i<5;i++)
				{
					if (orderStatusText.equalsIgnoreCase("Completed"))
					{
						if(orderStatusHasError.getText().contains("errors")) {
							orderstatus.click();
						    if(driver.findElements(By.xpath("//*[@id='erroneous-tasks-details-scroll']/descendant::*[contains(text(),'Voicemail Deactivation')]")).size()!=0)
							Assert.assertTrue("The Disconnect has HPE SA Voicemail Deactivation error task. Please check in NC", driver.findElements(By.xpath("//*[@id='erroneous-tasks-details-scroll']/descendant::*[contains(text(),'Voicemail Deactivation')]")).size()!=0);break;}
					break;
					}
					else {
						driver.switchTo().defaultContent();
						scrollToElementAndClick(webudRefreshIcon, driver);	
						isLoaderSpinnerVisible(driver);
						waitForLoading(driver);
						goToFrame(driver, "ncframeOrderHistory");	}
				}				
			}
			else if(orderStatusText.contains("Completed"))
			{
				if(orderStatusHasError.getText().contains("errors")) {
					orderstatus.click();
				    if(driver.findElements(By.xpath("//*[@id='erroneous-tasks-details-scroll']/descendant::*[contains(text(),'Voicemail Deactivation')]")).size()!=0)
					Assert.assertTrue("The Disconnect has HPE SA Voicemail Deactivation error task. Please check in NC", driver.findElements(By.xpath("//*[@id='erroneous-tasks-details-scroll']/descendant::*[contains(text(),'Voicemail Deactivation')]")).size()!=0);}
				Assert.assertTrue("The Disconnect order is Completed as expected", orderStatusText.equalsIgnoreCase("Completed"));
			}
		break;
		case "Install":
			if (orderStatusText.contains("Processing")) {
				if(orderStatusHasError.getText().contains("errors")) {
					orderstatus.click();
				    if(driver.findElements(By.xpath("//*[@id='erroneous-tasks-details-scroll']/descendant::*[contains(text(),'NPAC Create')]")).size()!=0)
					Assert.assertTrue("The Install has NPAC Create error task. Please check in NC", driver.findElements(By.xpath("//*[@id='erroneous-tasks-details-scroll']/descendant::*[contains(text(),'NPAC Create')]")).size()!=0);}
				for(int i=0;i<5;i++)
				{
					if (orderStatusText.equalsIgnoreCase("Completed"))
					{
						if(orderStatusHasError.getText().contains("errors")) {
							orderstatus.click();
						    if(driver.findElements(By.xpath("//*[@id='erroneous-tasks-details-scroll']/descendant::*[contains(text(),'NPAC Create')]")).size()!=0)
							Assert.assertTrue("The Install has NPAC Create error task. Please check in NC", driver.findElements(By.xpath("//*[@id='erroneous-tasks-details-scroll']/descendant::*[contains(text(),'NPAC Create')]")).size()!=0);break;}
					break;
					}
					else {
						driver.switchTo().defaultContent();
						scrollToElementAndClick(webudRefreshIcon, driver);	
						isLoaderSpinnerVisible(driver);
						waitForLoading(driver);
						goToFrame(driver, "ncframeOrderHistory");	}
				}	
			}
			else if(orderStatusText.contains("Completed"))
			{
				if(orderStatusHasError.getText().contains("errors")) {
					orderstatus.click();
				    if(driver.findElements(By.xpath("//*[@id='erroneous-tasks-details-scroll']/descendant::*[contains(text(),'NPAC Create')]")).size()!=0)
					Assert.assertTrue("The Install has NPAC Create error task. Please check in NC", driver.findElements(By.xpath("//*[@id='erroneous-tasks-details-scroll']/descendant::*[contains(text(),'NPAC Create')]")).size()!=0);}
				Assert.assertTrue("The Install order is Completed as expected", orderStatusText.equalsIgnoreCase("Completed"));
			} 
		break;
		}
	}
	
	
}
