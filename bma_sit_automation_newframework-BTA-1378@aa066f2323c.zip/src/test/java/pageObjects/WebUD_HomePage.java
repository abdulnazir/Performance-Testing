package pageObjects;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;
import io.cucumber.java.Scenario;
import stepDefinitions.StepData;

public class WebUD_HomePage extends BaseUIPage
{
	private WebDriver driver;
	public BaseUIPage tb=new BaseUIPage();

	public WebUD_HomePage(WebDriver driver, Scenario scenario) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		 this.sd=new StepData();			
		sd.setScenario(scenario);		
		this.scenario=sd.getScenario();
	}

	@FindBy(xpath = "//*[starts-with(text(),'Welcome')]")
	public WebElement Welcome_Text;
		
	@FindBy(xpath = "//*[contains(@class,'applications')]")	
	public WebElement Apps_websites;	
	
	@FindBy(xpath = "//*[contains(@class,'applications')]//ancestor::div[2]/descendant::ul/li")
	public List<WebElement> Apps_websites_Options;	

	@FindBy(xpath = "//*[@tile='search']")
	public static WebElement SearchExistingAccounts;
	
	@FindBy(xpath = "//*[@id='txtscratchpad1']")
	public WebElement Scratchpad;

	@FindBy(xpath = "//*[contains(@class,'fullscreen')]")
	public WebElement CloseScratchpad;	

	@FindBy(xpath = "(//*[contains(@class,'equipment')])[1]")
	public WebElement equipmentSearch;

	@FindBy(xpath = "//*[contains(text(),'Retrieve equipment by')]/following::select")
	public WebElement retrieveEquipmentby;
	
	@FindBy(xpath = "//*[contains(text(),'Retrieve equipment by')]/following::select/following::input[1]")
	public WebElement input_equipment;

	@FindBy(xpath = "//*[contains(text(),'Latest Release Notes')]/following::*[contains(@aria-label,'Close')][1]")
	public WebElement CloseReleaseNotes;	
	
	@FindBy(xpath = "//*[contains(@class,'version')]/following::*[contains(@class,'information')]")
	public WebElement VersionReleaseNoteIcon;
	
	@FindBy(xpath = "//div/a[@class='version']")
	public WebElement VersionDisplayed;
	
	@FindBy(xpath = "//a[@class='copy']")
	public WebElement copyVersionDetails;	
	
	@FindBy(xpath = "//*[contains(text(),'Latest Release Notes')]/following::button[contains(@class,'close')][1]")
//	@FindBy(xpath = "//button[@class='close']")
	public WebElement closeVersionPopup;	
	
	@FindBy(xpath = "//div[@id=\"WarningId\"]/div[1]//span[contains(text(),'SC-')]/parent::label/text()")
	public WebElement serviceCallDisplayed;
	
	@FindBy(xpath = "//*[@class='modal-dialog modal-dialog-centered modal-lg']")
	public WebElement releaseNotePopUp;
	
	
	@FindBy(xpath = "//*[@class='pre1']")
	public WebElement releaseNoteText;	
	
	@FindBy(xpath = "//div[@class='reporttbl']/table[@class='Edit']")
	public WebElement accounthistorytable;
	
	public void validateReleaseNote() throws Exception
	{
		if(driver.findElements(By.xpath("//*[@class='modal-dialog modal-dialog-centered modal-lg']")).size()<=0)
		{
			scrollToElementAndClick(VersionReleaseNoteIcon, driver);
//			VersionReleaseNoteIcon.click();
//			Take screenshot here
		}
		
		tb.addScreenshot(driver, this.scenario, "ReleaseNote");
		String releaseNote=releaseNoteText.getText();
		ExtentCucumberAdapter.addTestStepLog("Data copied to txt file is" +"\n"+ releaseNote);
		try
		{
			//Write data to txt file
			FileWriter file = new FileWriter(System.getProperty("user.dir")+"\\src\\test\\resources\\releaseNote",false);
		    BufferedWriter BW = new BufferedWriter(file);
		    BW.flush();
		    BW.write(releaseNote);
		    BW.close();
		    
		    //Read file from txt file
		    FileReader fr=new FileReader(System.getProperty("user.dir")+"\\src\\test\\resources\\releaseNote");
		    BufferedReader br= new BufferedReader(fr);
		    String value=null;
		    ExtentCucumberAdapter.addTestStepLog("Data read from txt file is"+"\n");
		    while((value=br.readLine())!=null)
		    {
		    	ExtentCucumberAdapter.addTestStepLog(value);
		    }
		    br.close();
		}
		catch(IOException exc)
		 {
	        exc.printStackTrace();
	     }

	}
	public void closeReleaseNote()
	{
		if(driver.findElements(By.xpath("//*[@class='modal-dialog modal-dialog-centered modal-lg']")).size()>0)
		{
			closeVersionPopup.click();
		}
	}	
	
	public String getUser()
	{
		String GetUser = Welcome_Text.getText();
		String User[] = GetUser.split(" ");
		return User[1];
	}

	public void selectExistingAccounts() throws Exception
	{
		waitForVisibilityOfElement(SearchExistingAccounts,driver); 
		SearchExistingAccounts.click();
	}
	
	public void selectApplicationsandWebsites(String accessoption) throws InterruptedException {
		waitForLoading(driver);
		WebDriverWait w = new WebDriverWait(driver, 10);	
		w.until(ExpectedConditions.visibilityOf(Apps_websites));
		Apps_websites.click();
		boolean Present = false;
		for(WebElement option:Apps_websites_Options)
			if(option.getText().contains(accessoption)) {Present=true; option.click();break;}
		if(!Present) Assert.assertTrue(Present, accessoption+" should be present in dropdown when Access Applications and Websites link is clicked.");
	}	
	
	public void writenotes(String notes) throws InterruptedException {
		waitForLoading(driver);
		WebDriverWait w = new WebDriverWait(driver, 10);
		w.until(ExpectedConditions.visibilityOf(Scratchpad));
		Scratchpad.click();
		w.until(ExpectedConditions.visibilityOf(Scratchpad));
		Scratchpad.sendKeys(notes);
		driver.findElement(By.xpath("//span[contains(text(),'SCRATCHPAD')]")).click();
		waitForLoading(driver);
	}

	public String retrieveNotes() throws InterruptedException {
		waitForLoading(driver);
		WebDriverWait w = new WebDriverWait(driver, 10);
		w.until(ExpectedConditions.visibilityOf(Scratchpad));
		Scratchpad.click();
		return Scratchpad.getAttribute("value");
	}

	public void closescratchPad() throws Exception {
		waitForLoading(driver);
	//	if (driver.findElements(By.xpath("//*[contains(text(),'Latest Release Notes')]/following::*[contains(@aria-label,'Close')][1]")).size()!=0)
	//		scrollToElementAndClick(CloseReleaseNotes, driver);
	//	waitForVisibilityOfElement(CloseScratchpad,driver); 
		Thread.sleep(5000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollTo(0,0)");
		Thread.sleep(5000);
		scrollToElementAndClick(CloseScratchpad,driver);
	}

	public void selectEquipmentSearch() throws Exception {
		scrollToElementAndClick(equipmentSearch, driver);
		waitForLoading(driver);
		Assert.assertTrue(driver.findElements(By.xpath("//*[contains(text(),'Retrieve equipment by')]/following::select")).size()!=0);
	}

	public void searchEquipmentby(String strretrieveEquipmentby, String strEquipmentValue) throws Exception {
		selectElementFromDropdown(retrieveEquipmentby, driver, "Value", strretrieveEquipmentby);
		enterValueInField(input_equipment, strEquipmentValue, driver);
		input_equipment.sendKeys(Keys.ENTER);
		
	}

	public String fetchMACandMTAAddress(String strSerialNumber) throws InterruptedException {
//		Assert the below statement
		//b[contains(text(),'Converged Details')]/following::a[contains(text(),'M21EM000ACJ0000')]/following::a[contains(text(),'181051A09190')]/following::a[contains(text(),'230821A39190')]	
		waitForLoading(driver);
		isLoaderSpinnerVisible(driver);	//AddedShweta
		String MACAddress=driver.findElement(By.xpath("//*[contains(text(),'Account Number')]/following::a[contains(text(),'"+strSerialNumber+"')]/following::*[text()='MAC Address']/following::a[1]")).getText();
		String MTAAddress=driver.findElement(By.xpath("//*[contains(text(),'Account Number')]/following::a[contains(text(),'"+strSerialNumber+"')]/following::*[text()='MAC Address']/following::a[1]/following::*[text()='MTA MAC Address']/following::a[1]")).getText();
		String Address=MACAddress+","+MTAAddress;
		return Address;
	}

	public void openAccountinSTART(String accountnumber) throws Exception {
		isLoaderSpinnerVisible(driver);
		WebElement accnumber=driver.findElement(By.xpath("//*[contains(text(),'Account Number')]/span[contains(text(),'"+accountnumber+"')]"));
		Actions action=new Actions(driver);
		action.moveToElement(accnumber).perform();
		action.contextClick(accnumber).perform();
		scrollToElementAndClick(driver.findElement(By.xpath("//*[contains(text(),'Open account in START')]")), driver);
//		WebUDRoutingChange
		if(HostUrls.webUDroutingChanges.contains("Yes")) {
			if(driver.findElements(By.xpath("//title[contains(text(),'Order History')]")).size()!=0) {}
			else {switchtoWindow("| WebUD", driver);}
			}
//		ArrayList tabs = new ArrayList (driver.getWindowHandles());
//		driver.switchTo().window((String) tabs.get(2));}
		waitForLoading(driver);
		Assert.assertTrue(driver.findElements(By.xpath("//*[contains(text(),'Overview')]")).size()!=0);
	}
	
	public void viewEquipmentDetails(String strViewEquipmentDetailsin) throws Exception {
		waitForLoading(driver);
		isLoaderSpinnerVisible(driver);	//AddedShweta
		scrollToElementAndClick(driver.findElement(By.xpath("(//*[contains(text(),'"+strViewEquipmentDetailsin+"')]/following::i[1])[1]")), driver);
		scrollToElementAndClick(driver.findElement(By.xpath("(//a[contains(text(),'View Equipment Details')])[1]")), driver);
	}

	public void accounthistorytable() throws Exception {
		waitForLoading(driver);
		waitForVisibilityOfElement(accounthistorytable,driver);	
		WebDriverWait wait = new WebDriverWait(driver,20);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[@class='reporttbl']/table[@class='Edit']//tr")));
		       List<WebElement> list=driver.findElements(By.xpath("//div[@class='reporttbl']/table[@class='Edit']//tr"));
		       for (WebElement row : list) { 
		    	    List<WebElement> entities = row.findElements(By.tagName("td")); 
		    	    for (WebElement entity : entities) {       
		    	    System.out.println(entity.getText());
		    	}
		       
		    }		       
       		   int rowsize = list.size();  
       		   System.out.println(rowsize);
		       waitForLoading(driver);

//		       Wait.until(ExpectedConditions.elementToBeClickable(usernamelink);
//		       Thread.sleep(3000);
//		       usernamelink.click();
	}
	
	public void accounthistoryafterwebpagerefresh() throws Exception {
		waitForLoading(driver);
		waitForVisibilityOfElement(accounthistorytable,driver);	
		WebDriverWait wait = new WebDriverWait(driver,20);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[@class='reporttbl']/table[@class='Edit']//tr")));
		List<WebElement> list2=driver.findElements(By.xpath("//div[@class='reporttbl']/table[@class='Edit']//tr"));
		       for (WebElement row2 : list2) { 
		    	    List<WebElement> entities2 = row2.findElements(By.tagName("td")); 
		    	    for (WebElement entity2 : entities2) {       
		    	    System.out.println(entity2.getText());
		    	}
		    }
		      int Act_row_count1 = list2.size();  
		      if(Act_row_count1>=3)Assert.assertTrue(Act_row_count1>=3,"Account history is captured after webpage refresh");
		      else {
		    	  System.out.println("Account history is not captured after webpage refresh");
		      }
	}

	public void accounthistorytablevalue() throws Exception {
		waitForLoading(driver);
		waitForVisibilityOfElement(accounthistorytable,driver);	
		WebDriverWait wait = new WebDriverWait(driver,20);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[@class='reporttbl']/table[@class='Edit']//tr")));
		List<WebElement> list1=driver.findElements(By.xpath("//div[@class='reporttbl']/table[@class='Edit']//tr"));
		       for (WebElement row1 : list1) { 
		    	    List<WebElement> entities1 = row1.findElements(By.tagName("td")); 
		    	    for (WebElement entity1 : entities1) {       
		    	    System.out.println(entity1.getText());
		    	}
		    }
		      int Act_row_count = list1.size();  		   
		      if(Act_row_count>=3)Assert.assertTrue(Act_row_count>=3,"Account history is captured after webud refresh");
		      else {
		    	  System.out.println("Account history is not captured after webud refresh");
		      }
	 	    
 	} 


}	