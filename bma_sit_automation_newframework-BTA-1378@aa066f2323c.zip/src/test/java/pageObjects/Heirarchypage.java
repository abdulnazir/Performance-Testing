package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.Scenario;
import util.TestUtil;

public class Heirarchypage extends BaseUIPage {

	private WebDriver driver;
	TestUtil utils;
	public Heirarchypage(WebDriver driver,Scenario scenario) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//div[@id='hierarchy-tab']")
	WebElement heirarchytab;
	
	@FindBy(xpath = "//div[2][contains(text(),' Add Accounts to Hierarchy ')]")
	WebElement addaccounts;
	
	@FindBy(xpath = "//select[@formcontrolname='selectedOption']")
	WebElement accountdropdown;
	
	@FindBy(xpath = "//input[@formcontrolname='accountNumber']")
	WebElement accountentryfield;
	
	@FindBy(xpath = "//div[2]/button[contains(text(),'Search')]")
	WebElement search;
	
	@FindBy(xpath = "//tr/td[1]//input[@type='checkbox']")
	WebElement checkbox;
	
	@FindBy(xpath = "//div/button[contains(text(),' Link Selected Accounts ')]")
	WebElement linkaccount;
	
	@FindBy(xpath = "//button[contains(text(),'Confirm')]")
	WebElement confirmbutton;

	
	
	

	public void heirarchyTab(String tpiaaccountnumber) throws Exception {
		
	//	String tpiaaccountnumb = "43700023974";
	
		WebDriverWait w = new WebDriverWait(driver, 10);
		w.until(ExpectedConditions.elementToBeClickable(heirarchytab));
		scrollToElementAndClick(heirarchytab,driver);
		w.until(ExpectedConditions.elementToBeClickable(addaccounts));
		scrollToElementAndClick(addaccounts,driver);		
		w.until(ExpectedConditions.elementToBeClickable(accountdropdown));	
		selectElementFromDropdown(accountdropdown , driver , "VisibleText" , "Account Number");
		accountentryfield.sendKeys(tpiaaccountnumber);
		scrollToElementAndClick(search,driver);
		scrollToElementAndClick(checkbox,driver);
		driver.switchTo().activeElement();
		scrollToElementAndClick(linkaccount,driver);
		scrollToElementAndClick(confirmbutton,driver);
		
		
		
	}
	
	
}
