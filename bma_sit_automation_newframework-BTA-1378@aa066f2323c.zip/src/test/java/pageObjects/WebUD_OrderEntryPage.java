package pageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class WebUD_OrderEntryPage extends BaseUIPage {
	
	private WebDriver driver;
	public WebUD_OrderEntryPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//input[@id='user']")
	public WebElement webUD_login;
	
	@FindBy(xpath = "//input[@id='pass']")
	public WebElement webUD_password;
	
	@FindBy(xpath = "//input[@class='loginHiddenButton']")
	public WebElement loginButton;
	
	@FindBy(xpath = "//*[@id='order-tab']")
	public WebElement OrderEntrytab;
	
//	@FindBy(xpath = "//div[@id='7042756186013175480']//input")
	@FindBy(xpath = "//div[text()='Internet Product']/following::*[contains(text(),'Not selected')][1]")
	public WebElement removeInternet;
	
//	@FindBy(xpath = "//div[@id='7042756186013175481']//input")
	@FindBy(xpath = "//div[text()='Television Product']/following::*[contains(text(),'Not selected')][1]")
	public WebElement removeTV;
	
	@FindBy(xpath = "//*[text()='Fibre+ 500']")
	WebElement fibre500;
	
	@FindBy(xpath="//a[@class='UIHyperlink remove_offer']")
	WebElement Offerremove;
	
	@FindBy(xpath="//div[@class='UIShawPopup-bodyContent']//a[@class='UIShawButton']")
	WebElement Productremoval;
	
	public void webUDlogin(String webUDUserName, String webUDPassword) throws InterruptedException
	{
		
		if(webUD_login.isDisplayed())
			{webUD_login.sendKeys(webUDUserName);
		waitForLoading(driver);
		webUD_password.sendKeys(webUDPassword);
		waitForLoading(driver);
		loginButton.click();
		Thread.sleep(20000);
			}
		else
		{
			System.out.println("Navigated to Order Entry Page");
		}
	}
	
	public void navigateToOE() throws Exception
	{
		isLoaderSpinnerVisible(driver);	//AddedShweta
		driver.switchTo().defaultContent();
		isLoaderSpinnerVisible(driver);	//AddedShweta
		scrollToElementAndClick(OrderEntrytab, driver);
		driver.switchTo().parentFrame();
		goToFrame(driver, "ncOrderEntry");

	}
	
	public void deselectionOfPlansDevice() throws Exception{
		Thread.sleep(1000);
		goToFrame(driver, "ncOrderEntry");
//		driver.switchTo().frame("ncOrderEntry");
		scrollToElementAndClick(removeInternet, driver);
		scrollToElementAndClick(removeTV,driver);	
		scrollToElementAndClick(Offerremove,driver);
		scrollToElementAndClick(Productremoval,driver);
	}
	
	
}
