package pageObjects;

import java.io.IOException;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;



public class Promotions extends BaseUIPage {

	public Promotions(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);

	}

	@FindBy(xpath = "//*[@id=\"suggestionsDialogLink_main\"]")
	WebElement PromotionAndCouponSelection;

	@FindBy(xpath = "//div[@class=\"UIShawPopup-bodyContent\"]/div/table/tbody/tr[5]/td/div/table/tbody/tr[2]/td[2]/div/div/table/tbody/tr[2]/td")
	WebElement InternetPromotion;

	@FindBy(xpath = "//div[@class=\"UIShawPopup-bodyContent\"]/div/table/tbody/tr[5]/td/div/table/tbody/tr[2]/td[2]/div/div/table/tbody/tr/td/div/input")
	WebElement TwoYearValuePlan;

	@FindBy(xpath = "//*[@id=\"discount-dialog-ok-button\"]/span/span")
	WebElement PromotionOkButton;

	@FindBy(xpath = "//td[@class='UIGridLayoutRow PromInfo']/div/a")
	WebElement Twoyearvalueplanexpandbutton;

	@FindBy(xpath = "//*[@id=\"discount-popup\"]/table/tbody/tr[2]/td[2]/div/table/tbody/tr[2]/td[2]/div/div/table/tbody/tr[5]/td/div")
	WebElement promotionenddate;

	@FindBy(xpath = "//td[@class=\"UIGridLayoutRow PromInput\"]/div/input")
	WebElement Promtionremoval;

	@FindBy(xpath = "//*[@class=\"TelevisionSuggestionCategory\"]")
	WebElement TelevisionPromotionsCategory;

	@FindBy(xpath = "//div[@class=\"UIShawPopup-bodyContent\"]/div/table/tbody/tr[5]/td/div/table/tbody/tr[2]/td[2]/div/div/table/tbody/tr[4]/td/div/input")
	WebElement tvPriceGuaranteePromotion;

	@FindBy(xpath = "//a[@class=\"BundlesCategory\"]")
	WebElement bundlePromotionCategory;

	@FindBy(xpath = "//label[contains(text(),'Price')]/../../..//td[@class=\"UIGridLayoutRow PromInput\"]")
	WebElement priceGuranteePromotion;

	@FindBy(xpath = "//*[contains(@class,'Telephony')]")
	WebElement phoneCategory;

	@FindBy(xpath = "//*[contains(@class,'Television')]")
	WebElement televisionCategory;
	
	@FindBy(xpath = "//*[contains(@title,'Internet Product')]")
	WebElement internetCategory;
	
	@FindBy(xpath = "//*[contains(@class,'Bundles')]")
	WebElement bundleCategory;
	
//	@FindBy(xpath="//select[@value='General']")
	@FindBy(xpath="(//select[@value='Development & Testing'])[2]")
	WebElement selectDropdownOffers;

	@FindBy(xpath="//*[@id='suggestionsDialogLink_main']/following::a[contains(text(),'Promotions')]")
	WebElement promotionstab;

	@FindBy(xpath="//*[@id='suggestionsDialogLink_main']/following::select[contains(@class,'UserRolesList')]")
	WebElement selectUserRoleinPromotion;
//	@FindBy(xpath="//label[contains(text(),'24M 2YVP BlueCurve Total Bundle Price')]//preceding::td[@class='UIGridLayoutRow PromInput'][1]")
//	@FindBy(xpath="//label[contains(text(),'24M 2YVP Total Bundle Price Guarantee @ $169')]//preceding::td[@class='UIGridLayoutRow PromInput'][1]")
	@FindBy(xpath="//label[contains(text(),'24M 2YVP Total Bundle Price Guarantee')]//preceding::input[1]")
	WebElement promotionPlan24M2YVP;
	
	@FindBy(xpath="(//label[(text()='*2YVP Internet + TV Agreement')])[2]//preceding::input[1]")
	WebElement promotionPlan2YVPRemove;
	
	@FindBy(xpath = "//*[@id='suggestionsDialogLink_main']/following::a[contains(text(),'Promotions')]/following::input[contains(@hint,'Enter promotion search text')]")
	WebElement input_promotionsearch;
	
	@FindBy(xpath="//*[@id='suggestionsDialogLink_main']/following::a[contains(text(),'Promotions')]/following::*[contains(text(),'Search')]")
	WebElement search;	

	public void selectTVPriceGuaranteePromotions(String priceGuaranteePromotionTV) throws InterruptedException {
		waitForLoading(driver);
		TelevisionPromotionsCategory.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'" + priceGuaranteePromotionTV
				+ "')]//../../td[@class='UIGridLayoutRow PromInput']")).click();
		;

	}

	public void promotionwrench() throws InterruptedException {
		waitForLoading(driver);
		PromotionAndCouponSelection.click();
		waitForLoading(driver);
	}

	public void selectpromotion() {
		InternetPromotion.click();
	}

	public void TwoYearValuePlanSelection() throws InterruptedException {
		waitForLoading(driver);
		TwoYearValuePlan.click();
	}

	public void PriceGuaranteePromotionSelection() {
		priceGuranteePromotion.click();
	}

	public void clickpromotionokbutton() throws InterruptedException {
		waitForLoading(driver);
		PromotionOkButton.click();
	}

	public void removingpromotion() {
		Promtionremoval.click();
	}

	public void bundlePriceGuranteePromotion() throws Exception {
		wait.withMessage("methodofconfirmation button not found")
				.until(ExpectedConditions.visibilityOf(PromotionAndCouponSelection));
		Thread.sleep(5000);
		PromotionAndCouponSelection.click();
		waitForLoading(driver);
//		bundlePromotionCategory.click(); // Moved below the steps by Ashish
//		waitForLoading(driver); // Moved below the steps by Ashish
		// if(TestBase.prop.getProperty("matrix").equals("181")) {
		//priceGuranteePromotion.click();

		Select offerList = new Select(selectDropdownOffers);
		//offerList.selectByVisibleText("Base Management"); // Commented by Ashish
		waitForLoading(driver);
		offerList.selectByVisibleText("Grandfathered Solution"); // Added by Ashish
		// }
		// driver.findElement(By.xpath("//div[contains(text(),'Price')]//../../td[@class=\"UIGridLayoutRow
		// PromInput\"]")).click();
//		bundlePromotionCategory.click(); // Moved here by Ashish
		scrollToElementAndClick(bundlePromotionCategory, driver); //Added by Ashish
		waitForLoading(driver); // Moved here by Ashish
//		promotionPlan24M2YVP.click();
		scrollToElementAndClick(promotionPlan24M2YVP, driver); //Added by Ashish
		waitForLoading(driver);
		scrollToElementAndClick(PromotionOkButton, driver); //Added by Ashish
//		PromotionOkButton.click();
		waitForLoading(driver);
	}

	//Added by Ashish [Start]
	public void bundlePriceGuranteePromotionremoval() throws Exception {
		wait.withMessage("methodofconfirmation button not found")
				.until(ExpectedConditions.visibilityOf(PromotionAndCouponSelection));
		Thread.sleep(5000);
		scrollToElementAndClick(PromotionAndCouponSelection, driver);
		waitForLoading(driver);
		scrollToElementAndClick(promotionPlan2YVPRemove, driver);
		waitForLoading(driver);
		scrollToElementAndClick(PromotionOkButton, driver);
		waitForLoading(driver);
	}
	 //Added by Ashish [Finish]	

	public void selectPriceGurantee(String priceGuaranteePromotion) throws InterruptedException {
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[contains(text(),'" + priceGuaranteePromotion
				+ "')]//../../td[@class='UIGridLayoutRow PromInput']")).click();
		;
	}

	public void amazonPromotion(String amazonPromotion) throws InterruptedException {
		PromotionAndCouponSelection.click();
		Thread.sleep(2000);
		bundlePromotionCategory.click();
		Thread.sleep(2000);
		waitForLoading(driver);
		driver.findElement(By.xpath(
				"//*[contains(text(),'" + amazonPromotion + "')]//../../../td[@class=\"UIGridLayoutRow PromInput\"]"))
				.click();
		Thread.sleep(2000);
		PromotionOkButton.click();
	}

	public void internetPromotion(String internetPromo) throws InterruptedException, IOException {

		String[] eachPromo = internetPromo.split(",");
		for (int i = 0; i < eachPromo.length; i++) {
			driver.findElement(By.xpath(
					"//*[text()='" + eachPromo[i].trim() + "']//../../../td[@class='UIGridLayoutRow PromInput']"))
					.click();
			waitForLoading(driver);
		}
//		TestBase.takeScreenshot("internet_promo");
		PromotionOkButton.click();
		waitForLoading(driver);
	}

	public void tvPromotion(String tvPromo) throws InterruptedException, IOException {
		waitForLoading(driver);
		televisionCategory.click();
		Thread.sleep(2000);
		String[] eachPromo = tvPromo.split(",");
		for (int i = 0; i < eachPromo.length; i++) {
			driver.findElement(By.xpath(
					"//*[text()='" + eachPromo[i].trim() + "']//../../../td[@class=\"UIGridLayoutRow PromInput\"]"))
					.click();
			waitForLoading(driver);
		}
//		TestBase.takeScreenshot("tv_promo");
		PromotionOkButton.click();
		waitForLoading(driver);
	}

	public void phonePromotion(String phonePromo) throws InterruptedException, IOException {
		waitForLoading(driver);
		phoneCategory.click();
		Thread.sleep(2000);
		String[] eachPromo = phonePromo.split(",");
		for (int i = 0; i < eachPromo.length; i++) {
			driver.findElement(By.xpath(
					"//*[text()='" + eachPromo[i].trim() + "']//../../../td[@class=\"UIGridLayoutRow PromInput\"]"))
					.click();
			waitForLoading(driver);
		}
//		TestBase.takeScreenshot("phone_promo");
		PromotionOkButton.click();
		waitForLoading(driver);
	}

	public void bundlePromotion(String bundlePromo) throws InterruptedException, IOException {
		waitForLoading(driver);
		bundleCategory.click();
		Thread.sleep(2000);
		String[] eachPromo = bundlePromo.split(",");
		for (int i = 0; i < eachPromo.length; i++) {
			driver.findElement(By.xpath(
					"//*[text()='" + eachPromo[i].trim() + "']//../../../td[@class=\"UIGridLayoutRow PromInput\"]"))
					.click();
			waitForLoading(driver);
		}
//		TestBase.takeScreenshot("bundle_promo");
		PromotionOkButton.click();
		waitForLoading(driver);

	}

	public void select_Promotion_and_Coupon_selection() throws Exception {
		scrollToElementAndClick(PromotionAndCouponSelection, driver);
	}
	
	public void select_Promotionstab() throws Exception {
		scrollToElementAndClick(promotionstab, driver);
	}
	public void select_ConfirmPromotions() throws Exception {
		scrollToElementAndClick(PromotionOkButton, driver);
	}
	public void check_FunctionalGroup_in_Promotionandcouponselection_popup(String defaultUserRoleinOE) throws Exception {
		String defaultUserRoleinPromotion="";
		Select s= new Select(selectUserRoleinPromotion); 	
		defaultUserRoleinPromotion=s.getFirstSelectedOption().getText();	
		Assert.assertEquals(defaultUserRoleinPromotion, defaultUserRoleinOE);
		scrollToElementAndClick(PromotionOkButton, driver);
		isLoaderSpinnerVisible(driver);
	}
	public void select_internetPromotions(String internetPromo) throws Exception {
		scrollToElementAndClick(internetCategory, driver);
		String[] eachPromo = internetPromo.split(",");
		for (int i = 0; i < eachPromo.length; i++) {
			enterValueInField(input_promotionsearch, eachPromo[i].trim(), driver);
			scrollToElementAndClick(search, driver);
			scrollToElementAndClick(driver.findElement(By.xpath(
					"//*[contains(text(),'" + eachPromo[i].trim() + "')]//../../../td[@class='UIGridLayoutRow PromInput']/descendant::input")), driver);
			waitForLoading(driver);
			input_promotionsearch.clear();
			scrollToElementAndClick(search, driver);
			isLoaderSpinnerVisible(driver);	//AddedShweta
			if(driver.findElements(By.xpath("//*[contains(text(),'Price Guarantee')]//../../../td[@class='UIGridLayoutRow PromInput']")).size()!=0)
				scrollToElementAndClick(driver.findElement(By.xpath("(//*[contains(text(),'Price Guarantee')]//../../../td[@class='UIGridLayoutRow PromInput']/descendant::input)[1]")), driver);
			else
				Assert.assertTrue(!(driver.findElements(By.xpath("//*[contains(text(),'Price Guarantee')]//../../../td[@class='UIGridLayoutRow PromInput']")).size()!=0), "No Price Gaurantee exists for selected Plan");
			input_promotionsearch.clear();
			scrollToElementAndClick(search, driver);
			isLoaderSpinnerVisible(driver);	//AddedShweta
			if(driver.findElements(By.xpath("//*[contains(text(),'Promo')]//../../../td[@class='UIGridLayoutRow PromInput']")).size()!=0)
				scrollToElementAndClick(driver.findElement(By.xpath("(//*[contains(text(),'Promo')]//../../../td[@class='UIGridLayoutRow PromInput']/descendant::input)[1]")), driver);
			
		}		
	}
	
}
