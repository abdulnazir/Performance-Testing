package pageObjects;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;
import org.openqa.selenium.interactions.Actions;

import java.net.MalformedURLException;
import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;
//import com.microsoft.edge.seleniumtools.EdgeDriver;
//import com.microsoft.edge.seleniumtools.EdgeOptions;


import io.cucumber.java.Scenario;
import io.github.bonigarcia.wdm.WebDriverManager;

import org.junit.Assert;
import stepDefinitions.StepData;
import java.net.URL;
import java.net.URLConnection;
import java.io.File;
import java.io.FileWriter;

import org.apache.pdfbox.cos.COSDocument;
import org.apache.pdfbox.io.RandomAccessRead;
import org.apache.pdfbox.pdfparser.PDFParser;
import org.apache.pdfbox.pdmodel.PDDocument;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.BufferedInputStream;
import java.io.File;



import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.text.PDFTextStripperByArea;



public class WebUD_ViewBill extends BaseUIPage {
	
	public WebDriver driver;
	public BaseUIPage tb=new BaseUIPage();
	

	
	public WebUD_ViewBill(WebDriver driver, Scenario scenario) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
		 this.sd=new StepData();			
		sd.setScenario(scenario);		
		this.scenario=sd.getScenario();
	}
	
	

	
	
	@FindBy(xpath = "//*[@id=\"myTab\"]/li[10]/a/span")
	public WebElement moreoption;
	
	
//	@FindBy(xpath = "//*[@id=\"myTab\"]/li[10]/ul/li[6]/a")
//	public WebElement viewbillbutton;
	
	@FindBy(xpath = "//a[contains(text(),'View Bill')]")
	public WebElement viewbillbutton;
	
	@FindBy(xpath = "//input[@id='btnGetBill']")
	public WebElement getpdfbutton;
	
	@FindBy(xpath = "//button[@id='save']")
	public WebElement savepdf;
	
	@FindBy(xpath = "//div[@class='c01140']//span[contains(text(),'Print')]")
	public WebElement printpdf;
	
	
	
	public void viewbill() throws Exception, IOException
	{	
			WebDriverWait w = new WebDriverWait(driver, 90);

			w.until(ExpectedConditions.visibilityOf(moreoption));
			moreoption.click();
			w.until(ExpectedConditions.visibilityOf(viewbillbutton));
			viewbillbutton.click();			
			Thread.sleep(5000);
	        Set<String> windowHandles = driver.getWindowHandles();
	        List<String> windowHandlesList = new ArrayList<>(windowHandles);
	        System.out.println("Total window number: " + windowHandlesList.size() + "\n");
	        driver.switchTo().window(windowHandlesList.get(3));    
	        w.until(ExpectedConditions.visibilityOf(getpdfbutton));
			getpdfbutton.click();	
			Set<String>winHandle1=driver.getWindowHandles();
		    Iterator<String> winHandle2=winHandle1.iterator();
		    String Parent=winHandle2.next();
		    String Child=winHandle2.next();
			String pdfurl = driver.getCurrentUrl();
			driver.get(pdfurl);
			Thread.sleep(5000);
			tb.savefile();
			Thread.sleep(5000);
//		  scrollToElementAndClick(savepdf,driver);
//		  Actions actions = new Actions(driver);
//		  actions.keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).perform();
		//  driver.switchTo().frame("pdf-viewer");	
//			  String filename = "Billing.pdf";
//		  actions.sendKeys(filename).perform();
//		  actions.sendKeys(Keys.RETURN).perform();
		
	}
	
	public void saveAndValidatepdf(String billvalue) throws Exception {
		
	//		billvalue = "469.09";
			String localpdf = "file:///C:/Users/rnagaraj/Downloads/Bill%20(4).PDF";  	
		  	driver.get(localpdf);
		    URL pdfURL=new URL(localpdf);
		    URLConnection urlconnection = pdfURL.openConnection();
		    InputStream is=urlconnection.getInputStream();		  
		    BufferedInputStream bis=new BufferedInputStream(is);
		    PDDocument doc=PDDocument.load(bis);
		    int pages=doc.getNumberOfPages();		  
		    System.out.println("The total number of pages "+pages);
		    System.out.println(doc.getCurrentAccessPermission().canPrint());
		    PDFTextStripper strip=new PDFTextStripper();		 
		    strip.setStartPage(1);
		    strip.setEndPage(2);
		    String stripText=strip.getText(doc);
		    
		    try {
		    	Assert.assertTrue(stripText.contains("Your invoice"));
		    	Assert.assertTrue(stripText.contains("SUMMARY OF YOUR ACCOUNT"));
		    	Assert.assertTrue(stripText.contains("Previous Charges and Payments"));
		    //	Assert.assertTrue(stripText.contains("Amount of Previous Invoice 468.08"));		    
		  //  	Assert.assertTrue(stripText.contains(billvalue));
		    	
		    	ExtentCucumberAdapter.addTestStepLog("Your invoice");
		    	ExtentCucumberAdapter.addTestStepLog("SUMMARY OF YOUR ACCOUNT");
		    	ExtentCucumberAdapter.addTestStepLog("Previous Charges and Payments");
		    //	ExtentCucumberAdapter.addTestStepLog("Amount of Previous Invoice 468.08");
		    //	ExtentCucumberAdapter.addTestStepLog("Balance Carried Forward  Due Now  $468.08");
		    //	ExtentCucumberAdapter.addTestStepLog("TOTAL AMOUNT DUE $468.08");
		    
		    }
		    
		    catch (Exception e) {
		    	ExtentCucumberAdapter.addTestStepLog("Expected PDF content is not matched with the Actual Content");
		    }
		    
	}
	
	}
	
		



	

	

	
		
