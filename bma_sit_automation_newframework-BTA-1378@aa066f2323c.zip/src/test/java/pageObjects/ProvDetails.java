package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import util.TestUtil;

public class ProvDetails extends BaseUIPage {

	private WebDriver driver;
	TestUtil utils;
	public ProvDetails(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//*[@id='prov-tab']")
	public WebElement ProvDetailstab;
	
	@FindBy(xpath = "//*[contains(text(),'Prov.Details')]")
	public WebElement ProvDetailslink;

	@FindBy(xpath = "//*[contains(text(),'Show Provision Details')]")
	public WebElement ShowProvDetailsbtn;		
	
	public void selectProvDetailstab() throws Exception {
		waitForLoading(driver);
		isLoaderSpinnerVisible(driver);	//AddedShweta
		WebUD_OverviewPage overviewPage;
		overviewPage = new WebUD_OverviewPage(driver);
		
		if(driver.findElements(By.xpath("//*[@id='prov-tab']")).size()!=0) 
		{
		//waitForVisibilityOfElement(ProvDetailstab,driver); 
		ProvDetailstab.click();
		}else {
			overviewPage.clickThreeDots();
			ProvDetailslink.click();
		}
	}	

	public void validateprovdetails(String internetserialnumber, String tvserialnumber) throws Exception {
		selectProvDetailstab();
		waitForLoading(driver);
		scrollToElementAndClick(ShowProvDetailsbtn, driver);	
		WebDriverWait w = new WebDriverWait(driver, 60);
		w.until(ExpectedConditions.invisibilityOfAllElements(driver.findElements(By.xpath("//img[contains(@src,'spinner.gif')]"))));
		if (driver.findElements(By.xpath("//span[text()='Phone, Email and Internet Services']")).size()!=0)
		{
			Assert.assertTrue(driver.findElements(By.xpath("//span[text()='Phone, Email and Internet Services']/following-sibling::div/pre")).size()!=0);
			Assert.assertFalse(driver.findElement(By.xpath("//span[text()='Phone, Email and Internet Services']/following-sibling::div/pre")).getText().isEmpty());
		}
		if (driver.findElements(By.xpath("//span[text()='Television Packages and Services']")).size()!=0)
		{
			Assert.assertTrue(driver.findElements(By.xpath("(//span[text()='Television Packages and Services']/following-sibling::div/pre)[1]")).size()!=0);
			if(driver.findElement(By.xpath("(//span[text()='Television Packages and Services']/following-sibling::div/pre)[1]")).getText().isEmpty())
				Assert.assertTrue(driver.findElement(By.xpath("(//span[text()='Television Packages and Services']/following-sibling::div/pre)[2]")).getText().contains("No television packages provisioned to this account."));
			else
			Assert.assertFalse(driver.findElement(By.xpath("(//span[text()='Television Packages and Services']/following-sibling::div/pre)[1]")).getText().isEmpty());
		}		
		if(driver.findElements(By.xpath("//span[text()='Devices']")).size()!=0)
		{
			String hardwareserialnum[] = tvserialnumber.split(";");
			for (int i = 0; i < hardwareserialnum.length; i++) {
				if(hardwareserialnum[i]!=null)
				scrollToElement(driver.findElement(By.xpath("//span[text()='Phone, Email and Internet Services']/parent::div/parent::div")), driver);	
				Assert.assertTrue(driver.findElement(By.xpath("//span[text()='Devices']/following-sibling::div/pre")).getText().contains(hardwareserialnum[i]));
			}
			Assert.assertTrue(driver.findElement(By.xpath("//span[text()='Devices']/following-sibling::div/pre")).getText().contains(internetserialnumber));
		}
	}
}
