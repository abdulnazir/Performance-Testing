package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

//import util.TestBase;

public class OrderManagement extends BaseUIPage {

	//WebDriver driver;
	private WebDriver driver;

	@FindBy(xpath = "//*[@id='div_t2091353054013993291_0____2091641841013994123']")
	WebElement ncaccounticon;

	@FindBy(xpath = "//*[@id=\"attrIDDiv\"]/div[2]/input")
	WebElement ncacctentryfield;

	@FindBy(xpath = "//*[@id=\"fvalues\"]/li/a")
	WebElement ncacctnumlink;

	@FindBy(xpath = "//*[@id=\"t2091353054013993291_0_t\"]/tbody/tr/td[2]/a")
	WebElement timeshiftncaccountid;

	@FindBy(xpath = "//table[@class=\"mainControl\"]/tbody/tr/td[2]/a")
	WebElement ncacctid;

	@FindBy(xpath = "//input[@class=\"inputs\"]")
	WebElement accountnumberentryfield;

	@FindBy(xpath = "//*[@id=\"searchButton\"]")
	WebElement ncaccidsearchbutton;
	
	@FindBy(xpath = "//*[@id=\"fvalues\"]/li/a")
	WebElement ncaccidlink;

	public OrderManagement(WebDriver driver) {
		
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	public void AccountIconFilterBtn() throws Exception {
		Thread.sleep(8000);
		scrollToElementAndClick(ncaccounticon,driver);
	}

	public void EnterAccountNum(String accountnumber) throws InterruptedException {

		Thread.sleep(5000);
		ncacctentryfield.click();
		Thread.sleep(5000);
		ncacctentryfield.sendKeys(accountnumber);
	}

	public void AccountNumLink() {
		ncacctnumlink.click();

	}

	public String RetrieveTimeshiftAccId() throws InterruptedException {
		String accountid = timeshiftncaccountid.getText();
		Thread.sleep(3000);
		timeshiftncaccountid.click();
		return accountid;
	}

	public String RetrieveAccId() throws InterruptedException {
		String accountid = ncacctid.getText();
		Thread.sleep(3000);
		ncacctid.click();
		return accountid;
	}

	public void AccountIdLink() {
		ncacctid.click();
	}

	public void enterAccountNumber(String accountnumber) {
		accountnumberentryfield.sendKeys(accountnumber);
	}

	public void accountSearch() {
		ncaccidsearchbutton.click();
	}
	
	public void accountidapply() throws Exception{
		Thread.sleep(5000);
		scrollToElementAndClick(ncaccidlink,driver);
	}

}
