package pageObjects;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;

import util.TestUtil;



import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class AddServicesAndFeatures extends BaseUIPage {
	
	private WebDriver driver;
	TestUtil utils;
	public AddServicesAndFeatures(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//*[@id=\"addServices\"]/div/a")
	WebElement addServicesAndFeatures;

	@FindBy(xpath = "//td[@class=\"UIGridLayoutRow\"]/div")
	WebElement defaultinstallationfeebox;

	@FindBy(xpath = "//td[@class=\"UIGridLayoutRow\"]/div")
	WebElement earlycancellationfeebox;

	@FindBy(xpath = "html[1]/body[1]/div[5]/table[1]/tbody[1]/tr[2]/td[1]/div[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[2]/div[1]/table[1]/tbody[1]/tr[2]/td[2]/div[1]/div[1]/div[1]/table[1]/tbody[1]/tr[1]/td[2]/div[1]")
	WebElement earlycancellationfeemessage;

	@FindBy(xpath = "//*[@id=\"install-fee-input_main\"]")
	WebElement installationfee;
	
	@FindBy(xpath = "//div[@class='_span_ UIValue']//label[contains(text(),'Installation Fee')]")
	WebElement installationfeetext;
	

	@FindBy(xpath = "html[1]/body[1]/div[5]/table[1]/tbody[1]/tr[2]/td[1]/div[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[2]/div[1]/table[1]/tbody[1]/tr[2]/td[2]/div[1]/div[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div")
	WebElement Xi6message;

	@FindBy(xpath = "//div[@class=\"_span_ account-number-text\"]")
	WebElement accountnumber;

	@FindBy(xpath = "//label[text()='Total Bundle']")
	WebElement totalBundle;

	@FindBy(xpath = "//td[@class=\"UIGridLayoutRow\"]/div")
	WebElement toDoMessage;

	@FindBy(xpath = "//span[text()=\\\"OK\\\"]")
	WebElement OkButton;
	
	@FindBy(xpath="	//div[@id=\"bundleRadioListParent\"]//label[text()='Not selected']")
	WebElement bundleOfferNotSelected;

	@FindBy(xpath = "//*[text()='Installation Fee']")
	WebElement installationFeeText;
	
	//Vivek - Added for NGV43648 & NGV42047
	@FindBy(xpath="//label[text()='Not selected']")
	WebElement internetNotSelected;
		
	@FindBy(xpath="//label[text()='Not selected']")
	WebElement tvNotSelected;
	//Vivek -End NGV43648 & NGV42047

	@FindBy(xpath="//select[@id='user-role_main']")
	WebElement userRoleDropdown;

	@FindBy(xpath="//div[@id='internetCategory']/table/tbody/tr[2]//div/div/table[@class='UIVerticalLayout']/tbody/tr")
	List<WebElement> plansDisplayed;
	
	@FindBy(xpath="//div[@class='full-row user-info bg-white']/descendant::*[contains(@class,'Refresh')]")
	WebElement Refresh;	
	
	@FindBy(xpath = "//div[@class='_span_ account-number-text']/label")
	WebElement tpiaaccno;

	@FindBy(xpath = "//div[@id='promotionsPanel']//tr[4]//td[2]/div")
	WebElement installfee;
	
	
	public  Boolean isBulkAddressMessageVisible() throws IOException, InterruptedException {
		Boolean bulkAddressMessageVisible = driver.findElement(
				By.xpath("//table[@id='informationLayout_main']//div[contains(text(),'Bulk Address')]")).isDisplayed();
		System.out.println(bulkAddressMessageVisible);
		if (bulkAddressMessageVisible) {
//			addInfoInReport(driver.findElement(By.xpath("//table[@id='informationLayout_main']//div[contains(text(),'Bulk Address')]")).getText());
		} else {
			//addErrorInReport("Bulk Address Message not seen in To-Do list");
		}
//		takeScreenshot(driver,"bulkAddressMessage");
		return bulkAddressMessageVisible;
	}

	public  void selectBulkAddressCheckBox() {
		System.out.println("Clicking bulk addd");
		driver.findElement(By.xpath("//table[@id='informationLayout_main']//div[contains(text(),'Bulk Address')]/../..//input")).click();
	}

	public void clickAddServicesAndFeatures() throws Exception {
		waitForLoading(driver);
		isLoaderSpinnerVisible(driver);	//AddedShweta
		if(System.getProperty("environment").equalsIgnoreCase("webud"))
		{
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,-500)");
			driver.switchTo().defaultContent();
			scrollToElementAndClick(new CustomerDetails(driver).OrderEntryTab, driver);
			driver.switchTo().frame("ncOrderEntry");
		}
//		scrollToElement(addServicesAndFeatures, driver);	
//		addServicesAndFeatures.click();
		scrollToElementAndClick(addServicesAndFeatures, driver);			
		isLoaderSpinnerVisible(driver);	//AddedShweta
		waitForLoading(driver);
		if (prop.getProperty("bulkAddressCheck", "false").equalsIgnoreCase("true")) {
			isBulkAddressMessageVisible();
		}		
		wait.withMessage("NextPage").until(ExpectedConditions.visibilityOf(installationFeeText));
	}

	
	
	public void addinstallationfee() throws Exception {
		enterValueInField(installationfee, "0.00", driver);
		scrollToElementAndClick(installationfeetext,driver);
//		installationfee.sendKeys("0.00");
		Thread.sleep(5000);
				
	}
	

	public String defaultinstallationfee() throws Exception {
//		enterValueInField(installationfee, "0.00", driver);
		String defaultinstalfee = installationfee.getAttribute("value");
		return defaultinstalfee;
				
	}

	public void clickDefaultInstallationFeeCheckbox() throws InterruptedException {
		defaultinstallationfeebox.click();
		isLoaderSpinnerVisible(driver);	//AddedShweta
	}

	public void clickEarlyCancellationFeeCheckBox() {
		earlycancellationfeebox.click();
	}

	public void clickXi6Message() {
		if(Xi6message.isDisplayed()) {
			System.out.println("Xi6 Message is present");
			Xi6message.click();
		}
		else
		{
			System.out.println("Xi6 Message is not present");
		}		
	}

	public void ECFmessage() {
		String ecfmessage = earlycancellationfeemessage.getText();
		String ecffee = ecfmessage.substring(60, 63);
		int remainingmonth = 24;
		String calculatedecf = Integer.toString(remainingmonth * 15);
		Assert.assertEquals(ecffee, calculatedecf);
	}

	public String retrieveAccountNumber() {
		return accountnumber.getText();
	}

	public void selectTotalBundle() throws InterruptedException {
		wait.withMessage("TotalBundle button").until(ExpectedConditions.visibilityOf(totalBundle));
		Thread.sleep(2000);
		totalBundle.click();    // put the scroll function and remove the thread.sleep
		waitForLoading(driver); // Added by Ashish
		isLoaderSpinnerVisible(driver); // Added by Ashish
		if (driver.findElements(By.xpath("//span[text()=\"OK\"]")).size() > 0)

		{
			driver.findElement(By.xpath("//span[text()=\"OK\"]")).click();
		}

	}

	public void checkTODOMessage() throws Exception {
		System.out.println("Trying to check ");
		scrollToElementAndClick(addServicesAndFeatures, driver);
		Thread.sleep(7000);
		if (driver.findElements(By.xpath("//td[@class=\"UIGridLayoutRow\"]/div")).size() > 0) {
			if (prop.getProperty("bulkAddressCheck", "false").equalsIgnoreCase("true")) {
				System.out.println("Trying to check inside if");
				driver.findElement(By.xpath(
						"//table[@id='informationLayout_main']//div[contains(text(),'customer switching')]/../..//input"))
								.click();
			} else {
				System.out.println("Trying to check inside else ");
				int todoitems = driver.findElements(By.xpath("//div[@id='promotionsPanel']//input")).size();
				System.out.println(todoitems);
				for (int i = 0; i++ < todoitems;) {
					//addInfoInReport("Acknowledging To-do list item : "+  driver.findElement(By.xpath("//div[@id='promotionsPanel']//div[@class='_span_ UIValue']")).getText());
					Thread.sleep(3000);
					driver.findElement(By.xpath("//div[@id='promotionsPanel']//input")).click();
					Thread.sleep(2000);
				}
			}
		}
	}
		
	

	public void bundleOfferNotSelected() {
		bundleOfferNotSelected.click();
	}
	
	//Vivek Added for NGV43648 & NGV42047
	public void internetNotSelected() throws Exception {
		WebUD_OrderEntryPage oePage1= new WebUD_OrderEntryPage(driver);
		scrollToElementAndClick(oePage1.removeInternet, driver);
//		internetNotSelected.click();
	}
		
	public void tvNotSelected() throws Exception {
		WebUD_OrderEntryPage oePage2= new WebUD_OrderEntryPage(driver);
		scrollToElementAndClick(oePage2.removeTV, driver);
//		tvNotSelected.click();
	}
	// Vivek -End for NGV43648 & NGV42047 
	
	 public void selectPlan(String internetservice) throws Exception {
		  JavascriptExecutor js = (JavascriptExecutor) driver;
		  if (System.getProperty("environment").equalsIgnoreCase("webud"))
		  {
			 driver.switchTo().parentFrame();
			 List<WebElement> iframes = driver.findElements(By.tagName("iframe"));
			 for(WebElement iframe : iframes)
	  				{
		  				if (iframe.getAttribute("id").equals("ncOrderEntry"))
	  					 {
		  					driver.switchTo().frame("ncOrderEntry");
		  					break;
	  					 }
	  				}
			  }
			isLoaderSpinnerVisible(driver);	//AddedShweta
			WebDriverWait w = new WebDriverWait(driver,90);
			w.withMessage("Checking visiblity of element").until(ExpectedConditions.presenceOfElementLocated(By.xpath("//select[@id='user-role_main']")));
			if(!(driver.findElements(By.xpath("//div[@id='internetCategory']/table/tbody/tr[2]//div/div/table[@class='UIVerticalLayout']/tbody/tr/descendant::label[contains(text(),'"+internetservice+"')]")).size()==0))
			{
				selectElementFromDropdown(userRoleDropdown, driver, "VisibleText", "Base Management");
				waitForLoading(driver);
				isLoaderSpinnerVisible(driver);
			}
			if(!(driver.findElement(By.xpath("//div[@id='internetCategory']/table/tbody/tr[2]//div/div/table[@class='UIVerticalLayout']/tbody/tr/descendant::label[contains(text(),'"+internetservice+"')]")).isDisplayed()))
			{
				selectElementFromDropdown(userRoleDropdown, driver, "VisibleText", "Development & Testing");
				isLoaderSpinnerVisible(driver);
			}
		waitForLoading(driver);		  
		}
	 
	 public void selectProducts(String internetservice, String tvproduct) throws Exception {
			 tvproduct= tvproduct.trim();
			 internetservice=internetservice.trim();
			  JavascriptExecutor js = (JavascriptExecutor) driver;
			  if (System.getProperty("environment").equalsIgnoreCase("webud"))
			  {
				 driver.switchTo().parentFrame();
				 List<WebElement> iframes = driver.findElements(By.tagName("iframe"));
				 for(WebElement iframe : iframes)
		  				{
			  				if (iframe.getAttribute("id").equals("ncOrderEntry"))
		  					 {
			  					driver.switchTo().frame("ncOrderEntry");
			  					break;
		  					 }
		  				}
				  }
				isLoaderSpinnerVisible(driver);	//AddedShweta
				WebDriverWait w = new WebDriverWait(driver,90);
				w.withMessage("Checking visiblity of element").until(ExpectedConditions.presenceOfElementLocated(By.xpath("//select[@id='user-role_main']")));
				Select s= new Select(userRoleDropdown); 	
				int userRoles=itemCountFromDropdown(userRoleDropdown, driver);
				boolean present = false;
///Check it Shweta
				//Added by Ashish [Start]
////				System.out.println("Value of userRoles : " + userRoles);
//				selectElementFromDropdown(userRoleDropdown, driver, "VisibleText", "Base Management");
//				waitForLoading(driver); 
//				isLoaderSpinnerVisible(driver);
				//Added by Ashish [Finish]
				if (!internetservice.isEmpty() && !tvproduct.isEmpty())
				{
					for(int i=0;i<userRoles;i++)
					{
						if(!(driver.findElements(By.xpath("//div[@id='internetCategory']/table/tbody/tr[2]//div/div/table[@class='UIVerticalLayout']/tbody/tr/descendant::label[contains(text(),'"+internetservice+"')]")).size()!=0 && driver.findElements(By.xpath("//div[@id='tvCategory']//label[text() = '" + tvproduct + "']/preceding-sibling::input")).size()!=0)) 	
							{selectElementFromDropdown(this.userRoleDropdown, driver, "VisibleText",s.getOptions().get(i).getText());	
							isLoaderSpinnerVisible(driver);
							waitForLoading(driver);
							}
						else if((driver.findElements(By.xpath("//div[@id='internetCategory']/table/tbody/tr[2]//div/div/table[@class='UIVerticalLayout']/tbody/tr/descendant::label[contains(text(),'"+internetservice+"')]")).size()!=0 && driver.findElements(By.xpath("//div[@id='tvCategory']//label[text() = '" + tvproduct + "']/preceding-sibling::input")).size()!=0))
							{present = true; break;}
						else
							Assert.assertTrue(present);
					}					
				}
				else if (internetservice.isEmpty() && !tvproduct.isEmpty() )
				{
					for(int i=0;i<userRoles;i++)
					{
						if(!(driver.findElements(By.xpath("//div[@id='tvCategory']//label[text() = '" + tvproduct + "']/preceding-sibling::input")).size()!=0)) 	
							{selectElementFromDropdown(this.userRoleDropdown, driver, "VisibleText",s.getOptions().get(i).getText());	
							isLoaderSpinnerVisible(driver);
							waitForLoading(driver);
							}
						else if( driver.findElements(By.xpath("//div[@id='tvCategory']//label[text() = '" + tvproduct + "']/preceding-sibling::input")).size()!=0)
							{present = true; break;}
						else
							Assert.assertTrue(present);
					}					
				}
				else if (tvproduct.isEmpty() && !internetservice.isEmpty() )
				{
					for(int i=0;i<userRoles;i++)
					{
						if(!(driver.findElements(By.xpath("//div[@id='internetCategory']/table/tbody/tr[2]//div/div/table[@class='UIVerticalLayout']/tbody/tr/descendant::label[contains(text(),'"+internetservice+"')]")).size()!=0)) 	
							{selectElementFromDropdown(this.userRoleDropdown, driver, "VisibleText",s.getOptions().get(i).getText());	
							isLoaderSpinnerVisible(driver);
							waitForLoading(driver);
							}
						else if((driver.findElements(By.xpath("//div[@id='internetCategory']/table/tbody/tr[2]//div/div/table[@class='UIVerticalLayout']/tbody/tr/descendant::label[contains(text(),'"+internetservice+"')]")).size()!=0))
							{present = true; break;}
						else
							Assert.assertTrue(present);
					}	
				}
					
				if(present==false)
				Assert.assertTrue("TV Product + Internet Product combination not present", present);		  
		 }

	public ArrayList<String> check_default_offerings_with_UserRole() throws InterruptedException {
		goToFrame(driver, "ncOrderEntry");
		List <WebElement> labels = driver.findElements(By.xpath("//div[@id='internetCategory']/table/tbody/tr[2]//div/div/table[@class='UIVerticalLayout']/tbody/tr/descendant::label[contains(@class,'UICheckBox')]"));
		ArrayList<String> Options = new ArrayList<String>();		
		for(int j=0;j<=labels.size()-1;j++) Options.add(labels.get(j).getText());
		return Options;
	}

	public String fetch_default_UserRole() throws InterruptedException {
		String defaultUserRole="";
		goToFrame(driver, "ncOrderEntry");
		Select s= new Select(userRoleDropdown); 	
		defaultUserRole=s.getFirstSelectedOption().getText();	
		return defaultUserRole;
	}

	public void select_UserRole(String functionalGroup) throws Exception {
		selectElementFromDropdown(userRoleDropdown, driver, "VisibleText",functionalGroup);	
		isLoaderSpinnerVisible(driver);
//		waitForLoading(driver);
	}

	public void verifyOfferingsinFunctionalGroups(ArrayList<String> userRole_Offerings) {
		boolean Present=false;
		List <WebElement> labels = driver.findElements(By.xpath("//div[@id='internetCategory']/table/tbody/tr[2]//div/div/table[@class='UIVerticalLayout']/tbody/tr/descendant::label[contains(@class,'UICheckBox')]"));		
		for(int j=0;j<=labels.size()-1;j++) {
			for(int i=0;i<userRole_Offerings.size();i++) {
				if(labels.get(j).getText().equals(userRole_Offerings.get(i))) {Present=true;}
			}	
			if(!Present) Assert.assertFalse(Present);
		}
	}

	public void verify_default_UserRole(String functionalGroup) throws InterruptedException {
		String defaultUserRolePostAccountCreation="";
		defaultUserRolePostAccountCreation=fetch_default_UserRole();
		Assert.assertEquals(defaultUserRolePostAccountCreation, functionalGroup);		
	}
	
	public String retrievtpiaacc() throws Exception {
	//	isLoaderSpinnerVisible(driver);	//AddedShweta
		waitForLoading(driver);	
	//	driver.switchTo().defaultContent();
		scrollToElement(tpiaaccno, driver);
		String tpiaccnumber = tpiaaccno.getText();
//		reviewtab.click();  //CommentedbyShweta on 14/9/2023
		return tpiaccnumber;
	}
		 	
	
	public void verifyinstalfee() throws Exception {
		WebDriverWait w = new WebDriverWait(driver, 90);
		Thread.sleep(7000);
		List<WebElement> checkboxes = driver.findElements(By.xpath("//input[@class='UICheckBox']"));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		
	
	}		
	}
	
	


