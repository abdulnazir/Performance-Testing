package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import util.TestUtil;

public class LDAPQueryTool extends BaseUIPage {

	private WebDriver driver;
	TestUtil utils;
	AddServicesAndFeatures as;
	public LDAPQueryTool(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	public String getAltId(String queryValue, String type, String suffix, String env, String server, String port)
			throws InterruptedException {
		//driver.get(TestBase.prop.getProperty("ldapQueryTool"));
		
		driver.get("http://10.63.116.88/IDCLDAPQueryTool/LDAPQueryTool.php?state=1");
		driver.findElement(By.xpath("//input[@id='QueryTypeValue']")).sendKeys(queryValue);
		Thread.sleep(2000);
		new Select(driver.findElement(By.name("QueryType"))).selectByValue(type);
		Thread.sleep(2000);
		new Select(driver.findElement(By.name("QuerySuffix"))).selectByValue(suffix);
		Thread.sleep(2000);
		new Select(driver.findElement(By.name("QueryEnv"))).selectByValue(env);
		Thread.sleep(2000);
		//new Select(driver.findElement(By.name("QueryPort"))).selectByValue(port);
		//new Select(driver.findElement(By.id("QueryServer"))).selectByVisibleText(server);
		driver.findElement(By.xpath("//div[@id='detailsubmitbutton']")).click();
		Thread.sleep(5000);
		String ltext = driver.findElement(By.xpath("//pre")).getText();
		String altId = ltext.split("=")[1].split(",")[0];
//		addInfoInReport("Response = " + ltext);
//		addInfoInReport("AltId = " + altId);
		return altId;
	}
}
