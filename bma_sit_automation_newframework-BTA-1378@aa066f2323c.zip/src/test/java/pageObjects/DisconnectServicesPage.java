package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import static com.codeborne.selenide.Selenide.*;

import util.TestUtil;

public class DisconnectServicesPage extends BaseUIPage {
	private WebDriver driver;
	TestUtil utils;
	public DisconnectServicesPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//*[@id='telephonyCategory']//tr[2]//a/span/span")
	WebElement phoneselectiondropdown;

//	@FindBy(xpath = "//*[@class='offerSelector']//select/option[contains(text(),'Not selected')]")
//	@FindBy(xpath = "(//*[contains(text(),'Phone Product')]/following::td[contains(@class,'offerSelector')]/descendant::select)[1]/option[contains(text(),'Not selected')]")
	@FindBy(xpath = "(//*[contains(text(),'Phone Product')]/following::td[contains(@class,'offerSelector')]/descendant::select)[1]")
	WebElement disconnectphone;

	@FindBy(xpath = "//div[@id=\"internetCategory\"]/table/tbody/tr[2]/td[2]/div/div/table/tbody/tr/td/div/table/tbody/tr/td/div/table/tbody/tr/td/div/input")
	WebElement disconnectinternet;

	@FindBy(xpath = "//td[@class=\" ThirdCategory\"]/div/table/tbody/tr[2]/td[2]/div/div/table/tbody/tr/td/div/table/tbody/tr/td/div/table/tbody/tr/td/div/input\r\n")
	WebElement disconnectv;
	
    String disconnectTVXPath="//td[@class=\" ThirdCategory\"]/div/table/tbody/tr[2]/td[2]/div/div/table/tbody/tr/td/div/table/tbody/tr/td/div/table/tbody/tr/td/div/input\r\n";

	@FindBy(xpath = "//table[@id=\"promotion-list_main\"]/tbody//a[contains(text(),'removed numbers ported')]")
	WebElement portnumberwarningmessage;
	
	@FindBy(xpath="//*[text()=' OK ']")
	WebElement portoutnumberokbutton;
	
	@FindBy(xpath="//*[@class=\" FourthCategory\"]//*[@class=\"offerRemove\"]/div/a")
	WebElement deleteXB6;
	
	@FindBy(xpath="//table[@class='UIShawPopup-9box']//span[text()='Yes']")
	WebElement productRemoval;

	public void disconnectInternet() throws Exception {
		scrollToElementAndClick(disconnectinternet, driver);
		isLoaderSpinnerVisible(driver);
//		disconnectinternet.click();
	}

	public void disconnectTv() throws Exception {
		//disconnectv.click();
		waitForLoading(driver);	
		isLoaderSpinnerVisible(driver);	//AddedShweta
		scrollToElementAndClick(driver.findElement(By.xpath(disconnectTVXPath)), driver);
		isLoaderSpinnerVisible(driver);
//		driver.findElement(By.xpath(disconnectTVXPath)).click();
		
	}
	
	public void deleteXB6() throws InterruptedException,Exception {
		//waitForLoading();
		Thread.sleep(5000);
		scrollToElementAndClick(deleteXB6,driver);
	}
	
	public void productRemovalConfirm() throws InterruptedException,Exception {
		//waitForLoading();
		scrollToElementAndClick(productRemoval,driver);
	}


	public void disconnectPhone() throws Exception {
//		scrollToElementAndClick(disconnectphone, driver);
		selectElementFromDropdown(disconnectphone, driver, "VisibleText", "Not selected");
		isLoaderSpinnerVisible(driver);
//		disconnectphone.click();
	}
	public void selectPortNumberWarningMessage() throws Exception
	{
		Thread.sleep(3000);
		
//		if(driver.findElements(By.xpath("//table[@id=\"promotion-list_main\"]/tbody//a[contains(text(),'removed numbers ported')]")).size()!=0)
//		{
		goToFrame(driver, "ncOrderEntry");
		waitForLoading(driver);
		scrollToElementAndClick(portnumberwarningmessage, driver);
		scrollToElement(driver.findElement(By.xpath("//*[@id='portOutListComp']")), driver);
		driver.findElement(By.xpath("//*[@id='portOutListComp']")).click();
		scrollToElementAndClick(portoutnumberokbutton, driver);
//		}
//		portnumberwarningmessage.click();
//		waitForLoading();
//		portoutnumberokbutton.click();
	}
	
}
