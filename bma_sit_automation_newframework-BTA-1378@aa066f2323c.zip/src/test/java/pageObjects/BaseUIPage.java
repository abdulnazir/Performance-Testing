package pageObjects;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.openqa.selenium.Alert;
//import org.joda.time.Seconds;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebDriver.Timeouts;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
//import org.openqa.selenium.edge.EdgeDriverService;
//import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
//import org.openqa.selenium.firefox.FirefoxOptions;
//import org.openqa.selenium.remote.BrowserType;
//import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
//import org.openqa.selenium.support.ui.Duration;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.yaml.snakeyaml.Yaml;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
//import com.google.common.collect.ImmutableList;
//import com.lmax.disruptor.TimeoutBlockingWaitStrategy;
import com.google.common.collect.ImmutableList;

import io.cucumber.java.Scenario;
import io.github.bonigarcia.wdm.WebDriverManager;
import stepDefinitions.Hooks;
import stepDefinitions.StepData;


/**
 * Base class for all UI functionality
 *
 */
public class BaseUIPage {

	WebDriver driver;
	//Property file object
	public static Properties prop;
	//Property FileInputStream object
	FileInputStream file;
	//Browser value retrieved from Maven Goal
	public static String browser = System.getProperty("browser");
	//Environment value retrieved from Maven Goal
	public static String environment = System.getProperty("environment");
	//DesiredCapabilities object creation
	public DesiredCapabilities desiredCapability = new DesiredCapabilities();
	
	public static Properties configprop;
	public static Map<String, Object> data;
	Scenario scenario;
	StepData sd;
	
	public static WebDriverWait wait;

	/**
	 * Read the property file mentioned
	 * @param filename Property file path with name
	 */
	public void readPropertyFile() {
//		try {
//			prop = new Properties();
//			file = new FileInputStream(filename);
//			prop.load(file);
//		} catch (IOException e) {
//			System.out.println("File not found");
//		}
		
		ExtentSparkReporter spark = new ExtentSparkReporter("sparkreport");
		spark.config().setTheme(com.aventstack.extentreports.reporter.configuration.Theme.DARK);
		ExtentReports extent = new ExtentReports();
		extent.attachReporter(spark);

		FileInputStream fis = null;
		FileInputStream fmatrix = null;
		prop = new Properties();
		configprop = new Properties();
		System.out.println();

		try {
			
			fmatrix = new FileInputStream(System.getProperty("user.dir")+"\\src\\test\\resources\\matrix");
			prop.load(fmatrix);
			//yamlreadinglocal(System.getProperty("user.dir")+"\\src\\test\\resources\\test.yaml");
			//System.out.println("YAML reading Start");
			//yamlreading();
			//System.out.println("YAML reading finished");
			
			try {
				if(System.getProperty("environment").equalsIgnoreCase("webud"))
				{
					fis = new FileInputStream(
							System.getProperty("user.dir")+"\\src\\test\\resources\\properties\\config_" + System.getProperty("environment")+ System.getProperty("webUdMatrix")+ ".properties");
				}
				else
				{
				fis = new FileInputStream(
						System.getProperty("user.dir")+"\\src\\test\\resources\\properties\\config_" + System.getProperty("environment")+ ".properties");
				}
				configprop.load(fis);
				System.out.println(prop.getProperty("browser"));
			} catch (Exception e) {
				System.out.println("\n\n ERROR: ################     Config file not loaded ################ \n\n ");
				System.exit(1);
			}
//			fmatrix = new FileInputStream("D:\\BDDCucumberFramework\\src\\test\\resources\\matrix");
//			prop.load(fmatrix);
		} catch (Exception e) {
			System.out.println("\n\n ERROR: ################     Matrix file not loaded     ################ \n\n ");
			System.exit(1);
		}	
	}


	/**
	 * Initialize the driver based on the browser parameter from Maven goal
	 * Read the AppUrls.properties file based on the Environment provided in Maven goal
	 * @throws MalformedURLException 
	 */
//	@SuppressWarnings("deprecation")
	@SuppressWarnings("deprecation")
	public void driverInit() throws MalformedURLException {
		switch (browser) {
		case "chrome":
			ChromeOptions option = new ChromeOptions();
			option.addArguments("incognito");
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver(option);
			break;
		case "firefox":
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
			break;
		case "edgeprivate":
			WebDriverManager.edgedriver().setup();
			DesiredCapabilities dc = new DesiredCapabilities();
			Map<String, Object> edgeOptions = new HashMap<>();
			edgeOptions.put("args", ImmutableList.of("-inprivate", "-start-maximized", "-browser-test", "—disk-cache-size=0","-remote-allow-origins=*"));
			dc.setCapability("ms:edgeOptions", edgeOptions);
			driver = new EdgeDriver(dc);
			break;
		case "edge":
			WebDriverManager.edgedriver().setup();
			driver = new EdgeDriver();
			break;
		case "selGrid-chrome":
			desiredCapability.setBrowserName("chrome");
			try {
				driver = new RemoteWebDriver(new URL("http://10.197.128.24:4444/wd/hub"), desiredCapability);
			} catch (MalformedURLException e) {
				e.printStackTrace();
			}
			break;
		case "selGrid-edge":
			desiredCapability.setBrowserName("edge");
			try {
				driver = new RemoteWebDriver(new URL("http://10.197.131.134:4444/wd/hub"), desiredCapability);
			} catch (MalformedURLException e) {
				e.printStackTrace();
			}
			break;
		case "selGrid-firefox":
			desiredCapability.setBrowserName("firefox");
			try {
				WebDriverManager.firefoxdriver().setup();
				driver = new RemoteWebDriver(new URL("http://10.197.131.134:4444/wd/hub"), desiredCapability);
			} catch (MalformedURLException e) {
				e.printStackTrace();
			}
			break;

		case "docker-chrome":
			desiredCapability.setCapability("browserName", "chrome");
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--no-sandbox");
			options.addArguments("--disable-dev-shm-usage");
			desiredCapability.setCapability(ChromeOptions.CAPABILITY, options);
			try {
				driver = new RemoteWebDriver(new URL("http://3.139.237.80:4444/wd/hub"), desiredCapability);
			} catch (MalformedURLException e) {
				e.printStackTrace();
			}
			break;

		case "docker-firefox":
			desiredCapability.setBrowserName("firefox");
			try {
				WebDriverManager.firefoxdriver().setup();
				driver = new RemoteWebDriver(new URL("http://3.139.237.80:4444/wd/hub"), desiredCapability);
			} catch (MalformedURLException e) {
				e.printStackTrace();
			}

			break;
		case "docker-edge":
			desiredCapability.setBrowserName("edge");
			try {
				WebDriverManager.edgedriver().setup();
				driver = new RemoteWebDriver(new URL("http://3.139.237.80:4444/wd/hub"), desiredCapability);
			} catch (MalformedURLException e) {
				e.printStackTrace();
			}

			break;

		default:
			System.out.println("Give Proper browser name");
			break;
		}
		readPropertyFile();
		
	}

	/**
	 * Launch the Application URL based on the Environment provided in Maven goal
	 * @return WebDriver Object
	 */
	public WebDriver launchApplication() {
		System.out.println(HostUrls.getNCUrl());
		wait = new WebDriverWait(driver, 180);
		driver.manage().window().maximize();
		driver.get(HostUrls.getNCUrl());	
		return driver;
	}
	
	public void waitForLoading() throws InterruptedException {
		
		 WebDriverWait lwait = new WebDriverWait(driver,1);
		for (int x = 0; x++ < 2;) {
			try {
				lwait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//div[@id='LOADER_DIV']"))));
				break;
			} catch (WebDriverException e) {
				Thread.sleep(509);
			}
			
		}
		for (int x = 0; x++ < 90;) {
			try {
				lwait.until(ExpectedConditions.invisibilityOf(driver.findElement(By.xpath("//div[@id='LOADER_DIV']"))));
				break;
			} catch (WebDriverException e) {
				Thread.sleep(9);
			}
		}
		Thread.sleep(2000);
	}
	
	public void yamlreading() throws IOException
    {
        
          URL u = new URL("https://bitbucket.sjrb.ad/projects/CODO/repos/environment_config/browse/matrix-181.yml"); 
//          https://bitbucket.sjrb.ad/projects/CODO/repos/environment_config/browse/matrix-181.yml
        //  BufferedReader inputStream = new BufferedReader(
        //            new InputStreamReader(u.openStream()));
          System.out.println(u);
          
          InputStreamReader inputStream = new InputStreamReader(u.openStream());
         
    //      System.out.println(inputStream);
          
          System.out.println(IOUtils.toString(inputStream));

}
	
	public void yamlreadinglocal(String filename) throws FileNotFoundException {
	
		InputStream inputStream = new FileInputStream(new File(filename));
		Yaml yaml = new Yaml();
        data = yaml.load(inputStream);
        System.out.println(data);
	}
	
//	public String yamlDataReader(String application, String valuesKey) {
//        Map<String, Object> applicationData=(Map<String, Object>)
//                data.get("applications"); 
//        System.out.println("Application Data" +applicationData);
//        Map<String, Object> appSpecificData=(Map<String, Object>)
//                applicationData.get(application);
//        System.out.println("AppspecificData" +appSpecificData);
//        Map<String, Object> valuesData=(Map<String,Object>) appSpecificData.get("values");
//        System.out.println("ValuesData"+ valuesData);
//	return valuesData.get(valuesKey).toString();
//	}
//	
//	public String yamlDataReaderLevel1(String application, String valuesKey) {
//        Map<String, Object> applicationData=(Map<String, Object>)
//                data.get("applications"); 
//        System.out.println("Application Data" +applicationData);
//        Map<String, Object> appSpecificData=(Map<String, Object>)
//                applicationData.get(application);
//        System.out.println("AppspecificData" +appSpecificData);
//      //  Map<String, Object> valuesData=(Map<String,Object>) appSpecificData.get("valuesKey");
//       // System.out.println("ValuesData"+ valuesData);
//	return appSpecificData.get(valuesKey).toString();
//	}
	
	public void waitForLoading(WebDriver driver) throws InterruptedException {

		WebDriverWait lwait = new WebDriverWait(driver,1);
		for (int x = 0; x++ < 2;)
		{
			try
			{
				lwait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//div[@id='LOADER_DIV']"))));
				break;
			} 
			catch (WebDriverException e)
			{
				Thread.sleep(509);
			}
		
		}
		
	}		

	/**
	 * This function is used to scroll to the particular WebElement on the page and clicks on it
	 * Created By: ShwetaP
	 */
	public void scrollToElementAndClick(WebElement e, WebDriver driver) throws Exception
	{
		try {
			isLoaderSpinnerVisible(driver);	//AddedShweta
			WebDriverWait w = new WebDriverWait(driver, 120);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			scrollToElement(e, driver);
			try {
				if(e.isEnabled())
				{
				w.until(ExpectedConditions.refreshed(ExpectedConditions.elementToBeClickable(e)));
				isLoaderSpinnerVisible(driver);	//AddedShweta
				js.executeScript("arguments[0].click();", e);
				}
			}catch (Exception exc) {
			exc.printStackTrace();
			throw new Exception(exc + "Exception on clicking the webelement");	
			}
//			isLoaderSpinnerVisible(driver);	//AddedShweta 6 Pass
//			w.until(ExpectedConditions.invisibilityOfAllElements(driver.findElements(By.xpath("//img[contains(@src,'spinner.gif')]"))));		
			waitForLoading(driver);		//Commented23/5
		}catch(UnhandledAlertException exc) {try{
			Alert alert = driver.switchTo().alert();
			String alerttext= alert.getText();
			System.out.println("Alert is: "+alerttext);
			alert.accept();}catch (NoAlertPresentException f) {f.printStackTrace();}
		}	
	}
	
	/**
	 * This function is used to scroll to the particular WebElement on the page to further perform action on the object
	 * Created By: ShwetaP
	 */
	public void scrollToElement(WebElement e, WebDriver driver) throws Exception
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		WebDriverWait w = new WebDriverWait(driver, 120);
//		isLoaderSpinnerVisible(driver);	//AddedShweta
		w.until(ExpectedConditions.invisibilityOfAllElements(driver.findElements(By.xpath("//img[contains(@src,'spinner.gif')][1]"))));
//		waitForLoading(driver);   Commented23/5
//		w.until(ExpectedConditions.refreshed(ExpectedConditions.visibilityOf(e)));
//		w.until(ExpectedConditions.not(ExpectedConditions.refreshed(ExpectedConditions.stalenessOf(e))));
//		w.until(ExpectedConditions.visibilityOf(e));
		w.until(ExpectedConditions.refreshed(ExpectedConditions.or(
				ExpectedConditions.visibilityOf(e)
//				ExpectedConditions.elementToBeClickable(e),
//				ExpectedConditions.elementToBeSelected(e)
				)));
//		w.until(ExpectedConditions.visibilityOf(e));
			try {				
				js.executeScript("arguments[0].scrollIntoView();", e);
			}catch (Exception exc) {
			exc.printStackTrace();
//			wait.until(ExpectedConditions.refreshed(ExpectedConditions.stalenessOf(e)));
	//		throw new Exception(exc + "Exception on scrolling the webelement");	
			}
		isLoaderSpinnerVisible(driver);
	}	

	/**
	 * This function is used to switch to the desired window with provided title
	 * Created By: ShwetaP
	 */	
	public void switchtoWindow(String title, WebDriver driver) throws Exception
	{	  
		for(String winHandle : driver.getWindowHandles()){
		   if (driver.switchTo().window(winHandle).getTitle().contains(title)|driver.switchTo().window(winHandle).getCurrentUrl().contains(title)) {
		     break;
		   } 
		}
	}	
	
	/**
	 * This function is used to wait till the WebElement is visible
	 */	
	public void waitForVisibilityOfElement(WebElement e,WebDriver driver) throws Exception {
			try {
			WebDriverWait waitSelenium = new WebDriverWait(driver, 100, 500);
			waitSelenium.until(ExpectedConditions.visibilityOf(e));
			} catch (Exception exc) {
			exc.printStackTrace();
			throw new Exception(exc + "Exception on waiting for webelement");
			}
	}

	/**
	 * This function is used for entering the value in the Input Box for a particular field
	 * Created By: ShwetaP
	 */	
	public void enterValueInField(WebElement e, String value, WebDriver driver) throws Exception
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		scrollToElementAndClick(e, driver);
		try {
			js.executeScript("arguments[0].value ='';", e);
			//js.executeScript("arguments[0].value='"+value+"';", e);
			e.sendKeys(value);
		}catch (Exception exc) {
		exc.printStackTrace();
		throw new Exception(exc + "Exception on entering the value in field");	
		}
	}

	/**
	 * This function is used for selecting the value from the drop-down for a particular field
	 * Created By: ShwetaP
	 */	
	public void selectElementFromDropdown(WebElement e,WebDriver driver, String selectby, String selectoption1) throws Exception
	{
		WebDriverWait w = (WebDriverWait) new WebDriverWait(driver, 120).ignoring(StaleElementReferenceException.class);
		String selectoption = (selectoption1.replace("\"", "")).trim();
//		waitForLoading(driver);		Commented23/5
		isLoaderSpinnerVisible(driver);	//AddedShweta
		Select s= new Select(e); 	
		try {
			switch (selectby) {
			case "VisibleText":
				scrollToElementAndClick(e, driver);
				w.until(ExpectedConditions.textToBePresentInElement(e, selectoption));	
				s.selectByVisibleText(selectoption);
				Assert.assertEquals(s.getFirstSelectedOption().getText(), selectoption);
				break;
			case "Value":
				scrollToElement(e, driver);
				s.selectByValue(selectoption);
				//enhance later if needed
				break;
			case "Index":
				scrollToElement(e, driver);
				int option =Integer.parseInt(selectoption);
				s.selectByIndex(option);
				//enhance later if needed
				break;			
			}	
		}
		catch (Exception exc) {
//			exc.printStackTrace();
			selectElementFromDropdown( e, driver,  selectby,  selectoption1);
//			throw new Exception(exc + "Exception on selecting the option from dropdown");
			}
	}
	
	/**
	 * This function is used for getting the number options from the drop-down for a particular field
	 * Created By: ShwetaP
	 */	
	public int itemCountFromDropdown(WebElement e,WebDriver driver) throws Exception
	{
		int count;
		waitForLoading(driver);
		isLoaderSpinnerVisible(driver);	//AddedShweta
		Select s= new Select(e); 
		try {
			List<WebElement> options = s.getOptions();
			count = options.size();
		}
		catch (Exception exc) {
			exc.printStackTrace();
			throw new Exception(exc + "Exception on getting the option count from dropdown");
			}
		return count;
	}	
	
	/**
	 * This function is used for selecting the value from the drop-down for a particular field
	 * Created By: ShwetaP
	 */	
	public void selectCheckbox(WebElement ele,WebDriver driver) throws Exception {
//		waitForLoading(driver);			Commented23/5
		waitForVisibilityOfElement(ele,driver); 
		WebDriverWait w = new WebDriverWait(driver, 120);
		//w.until(ExpectedConditions.visibilityOf(ele));
		w.until(ExpectedConditions.elementToBeClickable(ele));
		scrollToElementAndClick(ele, driver);
		Assert.assertTrue(ele.isSelected());	
	}
	
	/**
	 * This function is used for waiting till the Loading and spinners disappear in the web application
	 * Created By: ShwetaP
	 * @throws InterruptedException 
	 */	
	public void isLoaderSpinnerVisible(WebDriver driver) throws InterruptedException {
		WebDriverWait w = new WebDriverWait(driver, 280);
		while((driver.findElements(By.xpath("(//img[contains(@src,'spinner.gif')])")).size()!=0|driver.findElements(By.xpath("//*[contains(text(),'Loading')]")).size()!=0|driver.findElements(By.xpath("(//*[@id='progress'])[1]|(//*[@id='hourglass'])|(//*[contains(text(),'Loading...')])")).size()!=0|driver.findElements(By.xpath("(//img[contains(@src,'spinner.gif')])[1]")).size()!=0)) {
		if(driver.findElements(By.xpath("(//img[contains(@src,'spinner.gif')])")).size()!=0) {
			Thread.sleep(100);
			w.until(ExpectedConditions.or(
					ExpectedConditions.invisibilityOfElementLocated(By.xpath("//img[contains(@src,'spinner.gif')]")),
					ExpectedConditions.invisibilityOfAllElements(driver.findElements(By.xpath("//img[contains(@src,'spinner.gif')]"))),
					ExpectedConditions.invisibilityOf(driver.findElement(By.xpath("(//img[contains(@src,'spinner.gif')])"))),
					ExpectedConditions.invisibilityOfAllElements(driver.findElements(By.xpath("//img[contains(@src,'spinner.gif')]")))
					));}
//			w.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//img[contains(@src,'spinner.gif')]")));} 
		else if(driver.findElements(By.xpath("//*[contains(text(),'Loading')]")).size()!=0)
		{Thread.sleep(100);
			w.until(ExpectedConditions.invisibilityOfAllElements(driver.findElements(By.xpath("//*[contains(text(),'Loading')]"))));} 
		else if(driver.findElements(By.xpath("(//*[@id='progress'])[1]|(//*[@id='hourglass'])|(//*[contains(text(),'Loading...')])")).size()!=0)
		{Thread.sleep(100);
//			w.until(ExpectedConditions.invisibilityOfAllElements(driver.findElements(By.xpath("//*[contains(text(),'Loading')]"))));} 
		w.until(ExpectedConditions.or(
				ExpectedConditions.invisibilityOfElementLocated(By.xpath("(//*[@id='progress'])[1]|(//*[@id='hourglass'])|(//*[contains(text(),'Loading...')])")),
				ExpectedConditions.invisibilityOfAllElements(driver.findElements(By.xpath("(//*[@id='progress'])[1]|(//*[@id='hourglass'])|(//*[contains(text(),'Loading...')])"))),
				ExpectedConditions.invisibilityOf(driver.findElement(By.xpath("(//*[@id='progress'])[1]|(//*[@id='hourglass'])|(//*[contains(text(),'Loading...')])"))),
				ExpectedConditions.invisibilityOfAllElements(driver.findElement(By.xpath("(//*[@id='progress'])[1]|(//*[@id='hourglass'])|(//*[contains(text(),'Loading...')])")))
				));}
		else if(driver.findElements(By.xpath("(//img[contains(@src,'spinner.gif')])[1]")).size()!=0) {
			Thread.sleep(100);
			w.until(ExpectedConditions.or(
					ExpectedConditions.invisibilityOfElementLocated(By.xpath("(//img[contains(@src,'spinner.gif')])[1]")),
					ExpectedConditions.invisibilityOfAllElements(driver.findElements(By.xpath("(//img[contains(@src,'spinner.gif')])[1]"))),
					ExpectedConditions.invisibilityOf(driver.findElement(By.xpath("(//img[contains(@src,'spinner.gif')])[1]")))
					));}
		try {
		if((driver.findElement(By.xpath("(//img[contains(@src,'spinner.gif')])")).isDisplayed()|driver.findElement(By.xpath("(//*[@id='progress'])[1]|(//*[@id='hourglass'])|(//*[contains(text(),'Loading...')])")).isDisplayed()|driver.findElement(By.xpath("(//img[contains(@src,'spinner.gif')])[1]")).isDisplayed())==false) 
		{System.out.println("Expected");}}
		catch(NoSuchElementException e) {
			break;
		}
		}
	}
	
	/**
	 * This function is used for clicking the upArrow button in Order entry page
	 * Created By: ShwetaP
	 */	
	public void upArrowClick(WebDriver driver)
	{
		if(driver.findElement(By.xpath("//button[contains(@class,'Chevron')]")).getAttribute("class").equalsIgnoreCase("ChevronDown"))
		{
			WebElement upArrow=driver.findElement(By.xpath("//button[contains(@class,'Chevron')]"));
			upArrow.click();
		}
	}
	
	/**
	 * This function is used for clicking the downArrow button in Order entry page
	 */	
	public void downArrowClick(WebDriver driver)
	{
		if(driver.findElement(By.xpath("//button[contains(@class,'Chevron')]")).getAttribute("class").equalsIgnoreCase("ChevronUp"))
		{
			WebElement downArrow=driver.findElement(By.xpath("//button[contains(@class,'Chevron')]"));
			downArrow.click();
		}
	}
	
	/**
	 * This function is used for application login using AutoIT
	 * Created By: ShwetaP
	 */	
	public void applicationlogin(WebDriver driver, String UserName, String Password, String checkURL) throws Exception {
		UserName=UserName+"{TAB}";
		Password=Password+"{ENTER}";
			for(int i=0;i<3;i++)
			{
				if(checkURL.contains("ffmweb"))
				{
					String autoexec= System.getProperty("user.dir")+"\\src\\test\\resources\\AutoIt_SignintoAccessSite.exe"+" "+UserName+" "+Password;
					Runtime.getRuntime().exec(autoexec);
					Thread.sleep(2000);
				}else {
				if(!driver.getCurrentUrl().contains(checkURL))
				{	
					String autoexec= System.getProperty("user.dir")+"\\src\\test\\resources\\AutoIt_WindowSecurityLogin.exe"+" "+UserName+" "+Password;
					Runtime.getRuntime().exec(autoexec);
					Thread.sleep(2000);
				}}	
			}
			if(!(checkURL.contains("ffmweb"))) {
			if(driver.getCurrentUrl().contains(checkURL))
			{	
				System.out.println("Logged in");
				switchtoWindow("https://adfs.sjrb.ca/", driver);
			}	}	
	}
	
	/**
	 * This function is used to format date
	 * Created By: ShwetaP
	 */	
	public String FormatDate(String dateformat) throws InterruptedException
	{	
		SimpleDateFormat df = new SimpleDateFormat(dateformat);
		Date date = new Date();
		TimeZone MT=TimeZone.getTimeZone("MST");		
		df.setTimeZone(MT);
		String formatedDate = df.format(date);
		return formatedDate;
	}

	/**
	 * This function is used to go to frame
	 * Created By: ShwetaP
	 */	
	public void goToFrame(WebDriver driver, String frame) throws InterruptedException
	{	
		WebDriverWait w = new WebDriverWait(driver, 120);
		List <WebElement> iframes = driver.findElements(By.tagName("iframe"));	
		for(WebElement iframe: iframes)
		{
			if (iframe.getAttribute("id").equals(frame))
			{
				w.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(frame));
//				driver.switchTo().frame(frame);
				break;
			}
		}
	}


	public static void addURLInReport(String url, String pagetext) {
		addURLAsTestLog(url, pagetext);
	}
	
	public static void addURLInReport(String pagetext) {
		addURLAsTestLog(pagetext);
	}
	
	private static void addURLAsTestLog(String url, String pagetext) {
		String page_links = String.format(
				"</br><div><span class='label green darken-4'><a href=' %s ' style='color:white'> Order Management Page </a></span> &nbsp&nbsp&nbsp&nbsp<span class='label green darken-4'>"
						+ "<a href=' %s ' style='color:white'> Order Entry Page </a></span> &nbsp&nbsp&nbsp&nbsp<span class='label green darken-4'>"
						+ "<a href=' %s ' style='color:white'> %s </a></span></div></br>",
				HostUrls.getNCUrl(), HostUrls.getOEUrl(), url, pagetext);
		ExtentCucumberAdapter.addTestStepLog(page_links);
	}
	
	private static void addURLAsTestLog(String pagetext) {
		
	//	addURLAsTestLog(driver.getCurrentUrl(), pagetext);
	}
		
	//	public void takeScreenshot(Scenario scenario) throws IOException {
	//        File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	//        byte[] fileContent = FileUtils.readFileToByteArray(src);
	//        ExtentCucumberAdapter.addTestStepScreenCaptureFromPath(browser);
	//        scenario.attach(fileContent, "image/png", "screenshot name"); 
	//	}
			
	public static void takeScreenshot(WebDriver driver, String name) throws IOException, InterruptedException {
		System.out.println("TakeScreenshot Method");
		addDebugInReport("Counter = " + String.valueOf(Hooks.example_count));
		TakesScreenshot ts =  (TakesScreenshot) driver;
		if (prop.getProperty("screenshottype", "base64").equalsIgnoreCase("base64")) {
			System.out.println("For EmbeddedScreenshot Loop");
			BaseUIPage.embedScreenshotInReport(driver);
		} else {
			System.out.println("EmbeddedScreenshot Loop else Loop");
			boolean screenshotFlag = getScreenshotFlag();
			if (screenshotFlag == true) {
				if (prop.getProperty("waitForLoadingInScreenshot", "false").equalsIgnoreCase("true")) {
	//				waitForLoading(driver);
					Thread.sleep(5000);
				}
	//          byte[] fileContent = FileUtils.readFileToByteArray(src);
	//          scenario.attach(fileContent, "image/png", "screenshot name"); 
				File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	//			File src = ts.getScreenshotAs(OutputType.FILE);
				String dest = "test-output\\ScreenShots\\" + Hooks.scenarioName.replaceAll(" ", "_") + "\\" + name + "_"
						+ Hooks.example_count++ + ".png";
				File target = new File(dest);
				FileUtils.copyFile(src, target);
				ExtentCucumberAdapter.addTestStepScreenCaptureFromPath(target.getAbsolutePath());
			}
		}
	}
	
	
	public void addScreenshot(WebDriver driver,Scenario scenario,String msg)
	{
	//	try
	//	{
			final byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
			scenario.attach(screenshot, "image/png", msg);
	//		}
	//	catch(NoSuchSessionException exc)
	//	{
	//		exc.printStackTrace();
	//	}
	}
	//public static void takeScreenshot(Webdriver screenshotdriver,String name) throws IOException, InterruptedException {
	//	System.out.println("TakeScreenshot Method");
	//	addDebugInReport("Counter = " + String.valueOf(Hooks.example_count));
	////	TakesScreenshot ts =  (TakesScreenshot) driver;
	//	if (prop.getProperty("screenshottype", "base64").equalsIgnoreCase("base64")) {
	//		System.out.println("For EmbeddedScreenshot Loop");
	//		try {
	//			embedScreenshotInReport(screenshotdriver);
	//		} catch (InterruptedException e) {
	//			// TODO Auto-generated catch block
	//			e.printStackTrace();
	//		}
	//	} else {
	//		System.out.println("EmbeddedScreenshot Loop else Loop");
	//		boolean screenshotFlag = getScreenshotFlag();
	//		if (screenshotFlag == true) {
	//			if (prop.getProperty("waitForLoadingInScreenshot", "false").equalsIgnoreCase("true")) {
	////				waitForLoading(driver);
	//				Thread.sleep(5000);
	//			}
	////          byte[] fileContent = FileUtils.readFileToByteArray(src);
	////          scenario.attach(fileContent, "image/png", "screenshot name"); 
	////			File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	////			File src = ts.getScreenshotAs(OutputType.FILE);
	//			String dest = "test-output\\ScreenShots\\" + Hooks.scenarioName.replaceAll(" ", "_") + "\\" + name + "_"
	//					+ Hooks.example_count++ + ".png";
	//			File target = new File(dest);
	////			FileUtils.copyFile(src, target);
	//			ExtentCucumberAdapter.addTestStepScreenCaptureFromPath(target.getAbsolutePath());
	//		}
	//	}
	//}
	
	
	public static void addDebugInReport(String message) {
		if (prop.getProperty("enableDebugStatements", "false").equalsIgnoreCase("true")) {
			ExtentCucumberAdapter.addTestStepLog("</br><span class='label blue darken-4'> "
					+ LocalDateTime.now().toString() + " : " + message + "</span></br>");
		}
	}
	
	public static boolean getScreenshotFlag() {
		boolean screenshotFlag = true;
		screenshotFlag = Boolean.parseBoolean(prop.getProperty("screenshotFlag"));
		return screenshotFlag;
	
	}
	
	public static void embedScreenshotInReport(WebDriver driver2) throws InterruptedException {
		try {
			if (prop.getProperty("waitForLoadingInScreenshot", "false").equalsIgnoreCase("true")) {
	//			waitForLoading();
				Thread.sleep(5000);
				 System.out.println("Inside if Loop");
			}
			System.out.println("Outside if Loop");
			TakesScreenshot ts = (TakesScreenshot) driver2;
			String base64_image = "data:image/png;base64, " + ts.getScreenshotAs(OutputType.BASE64);
	//		String base64_image = ts.getScreenshotAs(OutputType.BASE64);
			 System.out.println("Base 64 Path" + base64_image);
			 ExtentCucumberAdapter.addTestStepScreenCaptureFromPath(base64_image);
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}
	
	public void savefile() throws AWTException {
		
		  Robot robot = new Robot();
		  robot.delay(2000);
		  robot.keyPress(KeyEvent.VK_CONTROL);
		  robot.keyPress(KeyEvent.VK_S);
		  robot.delay(2000);		  
		  robot.keyPress(KeyEvent.VK_DOWN);
		  robot.keyPress(KeyEvent.VK_ENTER);
		}
	
}



