package pageObjects;

import java.time.LocalDateTime;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

//import stepdefinitions.Hooks;
//import util.TestBase;
import util.TestUtil;

public class SnowbirdSuspendResumePage extends BaseUIPage {
	private WebDriver driver;
	TestUtil utils;
	public SnowbirdSuspendResumePage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//*[@id=\"operationsMenuItem_span\"]")
	WebElement operationstab;

	@FindBy(xpath = "//*[@id=\"openSnowbirdOptions_span\"]")
	WebElement snowbird;

	@FindBy(xpath = "//*[@id=\"enable-snowbird-checkbox_main\"]")
	WebElement tcischeckbox;

	@FindBy(xpath = "//*[@id=\"snowbird-start-date_dateSelector\"]/a")
	WebElement snowbirdstartdatecalendar;

//	@FindBy(xpath = "//td[contains(@class, ' day false selected')]")
	@FindBy(xpath = "//*[contains(@class,'today')]") 
	WebElement snowbirdsuspendstartdate;

	@FindBy(xpath = "//*[@id=\"snowbird-end-date_dateSelector\"]/a")
	WebElement snowbirdenddatecalendar;

	@FindBy(xpath = "//*[contains(@id,'NextMonthButtonStatus')]")
	WebElement nextmonth;

	@FindBy(xpath = "//*[contains(@id,'PrevMonthButtonStatus')]")
	WebElement previousmonth;

	@FindBy(xpath = "//div[@class='calendar']/table/tbody/tr[3]/td[7]")
	WebElement snowbirdsuspendenddate;

	@FindBy(xpath = "//*[contains(@class,'today')]") 
	WebElement snowbirdresumedate;
	
//	@FindBy(xpath = "//*[@id=\"zpCal2TodayButtonStatus\"]") 
//	WebElement snowbirdresumedate; /html/body/div[18]/table/tbody/tr[2]/td[2]/div/div/div/table/tbody/tr[2]/td[2]/div/div[2]/table/tbody/tr[2]/td/div/table/tbody/tr/td[2]/div
	
//	/html/body/div[23]/table/thead[1]/tr[2]/td[3]

	@FindBy(xpath = "//*[@id=\"submit-snowbird-button\"]/span/span")
	WebElement snowbirdokbutton;

	//added by raj
	@FindBy(xpath = "//*[text()='Ignite Temporary Suspension - Internet']")
	WebElement temporarysuspendinternet;

	//added by raj
	@FindBy(xpath = "//*[text()='Temporary Suspension - TV']")
	WebElement temporarysuspendTv;

	@FindBy(xpath = "//*[@id='telephonyCategory']//tr[2]//a/span/span")
	WebElement phoneselectiondropdown;

	@FindBy(xpath = "//*[@class='offerSelector']//select/option[contains(text(),'Temporary Suspend Phone')]")
	WebElement temporarysuspendphone;
	
	@FindBy(xpath="//*[@class=\"calendar\"]")
	WebElement calendar;

	@FindBy(xpath="//*[@id='zpCal0Title']")
	WebElement currentMonthDisplayed;

	public void clickOperationsTab() throws Exception {
		scrollToElementAndClick(operationstab, driver);
//		operationstab.click();
//		Thread.sleep(2000);
	}

	public void selectSnowBird() throws Exception {
//		snowbird.click();
		scrollToElementAndClick(snowbird, driver);
	}

	public void selectTcisCheckbox() throws Exception {
//		tcischeckbox.click();
		waitForLoading(driver);
		Thread.sleep(5000);
		if(!tcischeckbox.isSelected())
		scrollToElementAndClick(tcischeckbox, driver);
	}

	public void selectSuspendStartDateCalendar() throws Exception {
//		Thread.sleep(3000);
		scrollToElementAndClick(snowbirdstartdatecalendar, driver);
//		snowbirdstartdatecalendar.click();
	}

	public void selectSuspendStartDate() throws Exception {
//		scrollToElementAndClick(snowbirdsuspendstartdate, driver);
		snowbirdsuspendstartdate.click();
	}
	
	public void selectFutureSuspendDate(String dayOfMonth) throws InterruptedException {
		Thread.sleep(3000);
		
		snowbirdenddatecalendar.click();
		Thread.sleep(2000);

		String dateSelection = dayOfMonth.split(":")[1];
		String monthSelection = dayOfMonth.split(":")[0].toUpperCase();
		WebElement nextMonthLink = driver.findElement(By.xpath("//*[@id=\"zpCal1NextMonthButtonStatus\"]"));

		if (monthSelection.equals("MONTHPLUSONE")) {
			nextMonthLink.click();
			Thread.sleep(1000);
		}
		else if (monthSelection.equals("MONTHPLUSTWO")) {
			nextMonthLink.click();
			Thread.sleep(1000);
			nextMonthLink.click();
		}
		
                driver.findElement(By.xpath("//td[text() = " + dateSelection + " and contains(@id, 'Date')]")).click(); 
                //Hooks.setFileWriter("Date " + dateSelection);

		}
	
		
	

	public void selectSuspendEndDateCalendar() {
		snowbirdenddatecalendar.click();
	}

	public void selectNextMonth() throws Exception {
		Thread.sleep(2000);
		scrollToElementAndClick(nextmonth, driver);
		Thread.sleep(2000);
		scrollToElementAndClick(nextmonth, driver);
	}

	public void selectPreviousMonth() throws Exception {
//		scrollToElementAndClick(previousmonth, driver);
		waitForLoading(driver);
		Thread.sleep(2000);
		scrollToElementAndClick(previousmonth, driver);
		waitForLoading(driver);
	}

	public void selectSuspendEndDate() throws Exception {
		scrollToElementAndClick(snowbirdsuspendenddate, driver);
	//	snowbirdsuspendenddate.click();
	}

	public void selectResumeDate() throws Exception {
//		 DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd");  
//		   LocalDateTime now = LocalDateTime.now();  
//		   System.out.println(dtf.format(now));  
//		   org.joda.time.format.DateTimeFormatter format = DateTimeFormat.forPattern("MMM");
//		    DateTime instance        = format.withLocale(Locale.ENGLISH).parseDateTime("August");  
//
//		    int month_number         = instance.getMonthOfYear();
//		    String month_text        = instance.monthOfYear().getAsText(Locale.ENGLISH);
//
//		    System.out.println( "Month Number: " + month_number );
//		    System.out.println( "Month Text:   " + month_text   );
		    String monthDisplayed=currentMonthDisplayed.getText();
		    System.out.println( "Month Displayed: " + monthDisplayed );
		    String[] MonthArray=monthDisplayed.split(",");
		    String MonthDisplayed=MonthArray[0];
		   
	         int MonthDisplayedinAppliation=Month.valueOf(MonthDisplayed.toUpperCase()).getValue();
	         System.out.println( "Month Displayed: " + MonthDisplayedinAppliation );
		    
//	        Code to fetch the current month as per Calendar
	         Calendar c = Calendar.getInstance();		
		    int month = c.get(Calendar.MONTH)+1;		    
//	        Month m = Month.of(month);
	        System.out.println( "Current Month: " + month );
	        
	        while(MonthDisplayedinAppliation != month)
	        {
	        	if(MonthDisplayedinAppliation>month)
	        	{
	        		previousmonth.click();
	        	}
	        	else
	        	{
	        		nextmonth.click();
	        	}
	        	monthDisplayed=currentMonthDisplayed.getText();
	        	MonthArray=monthDisplayed.split(",");
	        	MonthDisplayed=MonthArray[0];
	        	System.out.println( "Month Displayed in String: " + MonthDisplayed );
	        	MonthDisplayedinAppliation=Month.valueOf(MonthDisplayed.toUpperCase()).getValue();
	        	System.out.println( "Month Displayed in integer: " + MonthDisplayedinAppliation );
	        }
	        
		
		//String currentDate = 
		//String dateSelection = suspendDate.substring(0, 2);
		//driver.findElement(By.xpath("//td[text() = " + dateSelection + " and contains(@id, 'Date')]")).click();
	        scrollToElementAndClick(snowbirdresumedate, driver);
	        snowbirdresumedate.click();
//		Thread.sleep(20000);
		//TestBase.takeScreenshot("futuredateResume");
	}

	public void clickSuspendOkButton() throws Exception {
//		snowbirdokbutton.click();
		scrollToElementAndClick(snowbirdokbutton, driver);
		//waitForLoading();
//		Thread.sleep(2000);
	}

	public void selectSuspendInternet() throws Exception {
		//temporarysuspendinternet.click();
		scrollToElementAndClick(temporarysuspendinternet, driver);
		//waitForLoading();
		Thread.sleep(2000);
	}

	public void selectSuspendTv() throws Exception {
//		temporarysuspendTv.click();
		scrollToElementAndClick(temporarysuspendTv, driver);
		//waitForLoading();
		Thread.sleep(2000);
	}

	public void selectsuspendphone() throws Exception {
		//phoneselectiondropdown.click();
//		Thread.sleep(2000);
		scrollToElementAndClick(temporarysuspendphone, driver);
//		temporarysuspendphone.click();
		//waitForLoading();
//		Thread.sleep(2000);
	}

}

