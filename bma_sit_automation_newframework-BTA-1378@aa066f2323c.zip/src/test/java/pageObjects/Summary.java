package pageObjects;

import java.util.List;


import org.apache.commons.lang.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import util.TestUtil;

public class Summary extends BaseUIPage {
	//public String partnerAccountNumber;
	private WebDriver driver;
	TestUtil utils;
	public Summary(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	
	}
	@FindBy(xpath="(//*[contains(text(),'Search\\Update Partner Account')])[1]")
	WebElement updatepartneraccount;

	@FindBy(xpath="//span[@class='bg-popup_arrow']/parent::span[contains(text(),'Partner Account Audit History ')]")
	WebElement partnerhistory;
	
	@FindBy(xpath="//*[contains(text(),'Run Report')]")
	WebElement PartnerHistoryRunReport;
	
	@FindBy(xpath = "//*[contains(text(),'Partner:')]/parent::div/descendant::select[1]")
	public WebElement Partner;
	
	@FindBy(xpath = "//label[contains(text(),'Discount Status:')]//following-sibling::span/select")
	public WebElement DiscountStatus;
	
	@FindBy(xpath="//label[contains(text(),'Node Id:')]/following-sibling::input[1]")
	WebElement NodeId;
	
	@FindBy(xpath="//label[contains(text(),'Bill Cycle:')]/following-sibling::input[1]")
	WebElement BillCycle;
	
	@FindBy(xpath="//label[contains(text(),'Account')]/following-sibling::input[1]")
	WebElement updateaccount;

	@FindBy(xpath="//label[contains(text(),'Enter New Partner Account')]/following::input[3]")
	WebElement updatepartneraccount_Freedom;
	
	@FindBy(xpath="//button[contains(text(),'Add Account')]")
	WebElement addaccountbtn;

	@FindBy(xpath="//button[contains(text(),'Submit')]")
	WebElement Submitbtn;
	
	@FindBy(xpath="//*[contains(text(),'Please confirm the values')]/following::*[contains(text(),'Ok')]")
	WebElement confirmvaluesbtn;
	
	@FindBy(xpath="//*[contains(@class,'GarbageCan')]")
	WebElement deassociate;

	@FindBy(xpath="//b[contains(text(),'Associated Partner Account')]//parent::div/descendant::span")
	public List<WebElement> updatedaccountnumber;
	
	@FindBy(xpath="//*[contains(text(),'Associated Partner Account Number')]/following::span[1]")
	WebElement associatedaccountnumber;	

	@FindBy(xpath="//button[@id='closepopupupdatepartener']")
	WebElement closepopupupdatepartener;
	
	@FindBy(xpath="//span[contains(@class,'Shaw_Mobile')]")
	WebElement ShawMobileimg;

	@FindBy(xpath="//table[@class='tblPartnerAssociations']//following::img[contains(@src,'Freedom')]")
	WebElement Freedomimg;

	@FindBy(xpath="//*[@id='summarypartneraccModalLabel']//parent::div/descendant::button[@aria-label='Close']")
	WebElement closesummarypartneraccModal;	

	@FindBy(xpath="//*[contains(text(),'Warning')]/following::*[text()='Are you sure you would like to DeAssociate']")
	public List<WebElement> DeassociateWarning;
	
	@FindBy(xpath="//*[contains(text(),'Warning')]/following::*[text()='Are you sure you would like to DeAssociate']/following::button[text()='Yes']")
	WebElement DeassociateWarningYes;	
	
	@FindBy(xpath="//div[@class='full-row user-info bg-white']/descendant::*[contains(@class,'Refresh')]")
	WebElement Refresh;	
	
	@FindBy(xpath = "//div[@role='tablist']//span[contains(text(),'Summary')]")
	public WebElement Summary_tab;
	
	public void updatePartnerAccountNumber(String partner,String partnerAccountNumber,String notedId,String discountstatus, String billcycle) throws Exception
	{
		scrollToElementAndClick(Summary_tab, driver);
//		scrollToElementAndClick(updatepartneraccount, driver);
//		waitForLoading(driver);
		scrollToElementAndClick(updatepartneraccount, driver);
		waitForLoading(driver);
		waitForVisibilityOfElement(Partner,driver); 
		Select s1= new Select(Partner); 	
		WebDriverWait w = new WebDriverWait(driver, 90);
		selectElementFromDropdown(Partner, driver, "Value", partner);
		switch (partner) {
		case "ShawMobile":
			w.until(ExpectedConditions.elementToBeClickable(updateaccount));
			updateaccount.sendKeys(partnerAccountNumber);
			NodeId.sendKeys(notedId);
			if(billcycle.length()==1)
				billcycle="0"+billcycle;
			BillCycle.sendKeys(billcycle);
			Select s= new Select(DiscountStatus); 	
			w.until(ExpectedConditions.textToBePresentInElement(DiscountStatus, discountstatus));
			s.selectByVisibleText(discountstatus);	
			scrollToElementAndClick(addaccountbtn, driver);
			scrollToElementAndClick(confirmvaluesbtn, driver);
			w.until(ExpectedConditions.invisibilityOfAllElements(driver.findElements(By.xpath("//*[contains(text(),'Please confirm the values')]"))));
			w.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'Associated Partner Account Number')]/following::*[contains(@class,'GarbageCan')]")));
			w.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),'Associated Partner Account Number')]/following::*[contains(text(),'"+partnerAccountNumber+"')]")));
			scrollToElement(driver.findElement(By.xpath("//*[contains(text(),'Associated Partner Account Number')]/following::*[contains(text(),'"+partnerAccountNumber+"')]")), driver);
			Assert.assertEquals(associatedaccountnumber.getText().trim(), partnerAccountNumber.trim());
			scrollToElementAndClick(closepopupupdatepartener, driver);	
			waitForLoading(driver);		
			waitForVisibilityOfElement(ShawMobileimg,driver); 
			Assert.assertTrue(ShawMobileimg.isDisplayed());
			waitForLoading(driver);			
			break;
		case "Freedom":
			updatepartneraccount_Freedom.sendKeys(partnerAccountNumber);
			Submitbtn.click();
			//Assert.assertEquals(ele.getText(), partnerAccountNumber);	//check if this scenario is tested in future
			closepopupupdatepartener.click();
			waitForLoading(driver);		//pop up didn't come automatically
			//Assert.assertTrue((Boolean)((JavascriptExecutor)driver).executeScript("return arguments[0].complete && typeof arguments[0].naturalwidth !=\"undefined\" && arguments[0].naturalWidth > 0", Freedomimg));
			waitForLoading(driver);				
			break;		
		}

	}
	public void checkPartnerAccountAuditHistory(String action,String partner, String partnerAccountNumber) throws Exception
	{
		WebUD_HomePage webudHomePage = new WebUD_HomePage(driver,this.scenario);
		String User= webudHomePage.getUser();	
		WebDriverWait w = new WebDriverWait(driver, 60);
		scrollToElement(partnerhistory, driver);
		partnerhistory.click();
		scrollToElementAndClick(PartnerHistoryRunReport, driver);			
		waitForLoading(driver);
		switch (action){
		case "associated":
			w.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//td[contains(text(),'"+partnerAccountNumber+"')]"))));
			driver.findElement(By.xpath("//td[contains(text(),'"+User+"')]/following-sibling::td[contains(text(),'"+partnerAccountNumber+"')]/following-sibling::td[contains(text(),'"+partner+"')]")).isDisplayed();
			w.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath("//td[contains(text(),'"+User+"')]/following-sibling::td[contains(text(),'"+partnerAccountNumber+"')]/following-sibling::td[contains(text(),'"+partner+"')]"))));
			Assert.assertTrue(driver.findElements(By.xpath("//td[contains(text(),'"+User+"')]/following-sibling::td[contains(text(),'"+partnerAccountNumber+"')]/following-sibling::td[contains(text(),'"+partner+"')]")).size()!=0);
			break;
		case "deassociated":
			w.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(By.xpath("//td[contains(text(),'Delete')]/following-sibling::td[contains(text(),'"+User+"')]/following-sibling::td[contains(text(),'"+partnerAccountNumber+"')]/following-sibling::td[contains(text(),'"+partner+"')]"))));
			Assert.assertTrue(driver.findElements(By.xpath("//td[contains(text(),'Delete')]/following-sibling::td[contains(text(),'"+User+"')]/following-sibling::td[contains(text(),'"+partnerAccountNumber+"')]/following-sibling::td[contains(text(),'"+partner+"')]")).size()!=0);
			break;
		}
		closesummarypartneraccModal.click();
		waitForLoading(driver);
	}
	
	public void deassociatePartnerAccountNumber(String partner, String partnerAccountNumber) throws Exception {
		waitForLoading(driver);
		Refresh.click();
		waitForLoading(driver);
		scrollToElementAndClick(Summary_tab, driver);
		scrollToElementAndClick(updatepartneraccount, driver);
//		updatepartneraccount.click();
		waitForVisibilityOfElement(Partner,driver);
		Select s1= new Select(Partner); 
		s1.selectByVisibleText(partner);
		waitForVisibilityOfElement(deassociate,driver); 
		Assert.assertEquals(associatedaccountnumber.getText(), partnerAccountNumber);
		deassociate.click();
		Assert.assertTrue(DeassociateWarning.size()!=0);
		DeassociateWarningYes.click();
		waitForLoading(driver);
		WebDriverWait w = new WebDriverWait(driver, 60);
		w.until(ExpectedConditions.invisibilityOfAllElements(updatedaccountnumber));	
		waitForVisibilityOfElement(closepopupupdatepartener,driver);
		closepopupupdatepartener.click();
		waitForLoading(driver);	
		try {
			Assert.assertFalse(ShawMobileimg.isDisplayed());
		}catch(NoSuchElementException e)
		{
			System.out.println("No Element present which is expected.");
		}
	}
}