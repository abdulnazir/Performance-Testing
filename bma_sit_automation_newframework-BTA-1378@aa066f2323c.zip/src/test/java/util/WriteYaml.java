package util;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringWriter;
import java.util.LinkedHashMap;
import java.util.Map;

//import org.yaml.snakeyaml.Yaml;

public class WriteYaml {
    
   // public void whenDumpMap_thenGenerateCorrectYAML() throws IOException {
    public static void main(String args[]) throws IOException{
	    Map<String, Object> data = new LinkedHashMap<String, Object>();
	    
	    data.put("name", "Anand Subhramanian");
	    data.put("race", "Human");
	    data.put("interests", new String[] { "Coffee", "Sweets", "All in one", "Tim Hortons"});
	   // Yaml yaml = new Yaml();
	    BufferedWriter writer = new BufferedWriter(new FileWriter("target\\test.yml"));
	  //  yaml.dump(data, writer);
	    writer.close();
	    
	}

}
