package util;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import pageObjects.BaseUIPage;

public class WaitTime extends BaseUIPage {

	public static int IMPLICIT_WAIT=3;
	
	
        public WaitTime(WebDriver driver)
        {
	     PageFactory.initElements(driver, this);
        }
 
       public void setimplicitwaittime()
       {
	   //   driver.manage().timeouts().implicitlyWait(IMPLICIT_WAIT, TimeUnit.SECONDS);
       }
      
 }


