package util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcelValue {

	private static XSSFSheet ExcelWSheet;
    private static XSSFWorkbook ExcelWBook;
    private static XSSFCell Cell;
    private static XSSFRow Row;
    static File fileName = new File("C:\\Automation_Project\\SourceFiles\\test.xlsx");

	public static void main(String[] args) throws Exception {
		
		setExcelFile(fileName, "XB6");
    	String data = getCellData(0,0);
    	 System.out.println(data);
	}
		  public static void setExcelFile(File Path, String sheetName) throws IOException 
	     {

	        FileInputStream ExcelFile = new FileInputStream(Path);
	        ExcelWBook = new XSSFWorkbook(ExcelFile);
	        ExcelWSheet = ExcelWBook.getSheet(sheetName);
	   
	}

	      public static String getCellData(int RowNum, int ColNum) throws Exception {

	    try {
	        Cell = ExcelWSheet.getRow(RowNum).getCell(ColNum);
	        String CellData = Cell.getStringCellValue();
	        return CellData;
	       
	    } catch (Exception e) {
              System.out.println(e);
	        return "";

	    }

	}

	}

