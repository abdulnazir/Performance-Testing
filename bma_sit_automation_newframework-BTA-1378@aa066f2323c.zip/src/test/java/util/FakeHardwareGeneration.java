package util;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.lang.RandomStringUtils;
import org.xml.sax.SAXException;

import util.MacAddress;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import pageObjects.BaseUIPage;



public class FakeHardwareGeneration extends BaseUIPage {

                public static String generateSerialNum(String deviceType)
                                                throws IOException, SAXException, ParserConfigurationException {

                                String responseString = "";
                                String serialNumber = "";
                                String host = "http://testtools/api/hardware/DeviceGeneration";
      //String host =http://devcoreappw005/api/hardware/DeviceGeneration;
                                RestAssured.baseURI = host;
                                Map<String, String> qParam = new HashMap<String, String>();

                                if (prop.getProperty("stubbedSerialNumber", "NO").equalsIgnoreCase("YES")) {
                                                //addInfoInReport("Using Stubbed Serial Number for matrix " + TestBase.prop.getProperty("matrix"));
                                                return generateStubbedSerialNum499(deviceType);
                                } else {
                                                switch (deviceType.toUpperCase()) {
                                                case "XB6":
                                                                qParam.put("id", "160");
                                                                break;
                                                case "XG1V4":
                                                                qParam.put("id", "161");
                                                                break;
                                                case "XID":
                                                                qParam.put("id", "151");
                                                                break;
                                                case "DCT700":
                                                                qParam.put("id", "1");
                                                                break;
                                                case "XI6":
                                                                qParam.put("id", "173");
                                                                break;
                                                case "DCX 3510":
                                                                qParam.put("id", "131");
                                                                break;
                                                case "DCX3200":
                                                                qParam.put("id", "55");
                                                                break;
                                                case "DCX3400":
                                                                qParam.put("id", "60");
                                                                break;
                                                case "HITRON":
                                                case "GRANDFATHERED_HITRON":
                                                                qParam.put("id", "136");
                                                                break;
                                                case "XG1V3":
                                                                qParam.put("id", "153");
                                                                break;
                                                case "HITRONXPOD":
                                                                qParam.put("id", "181");
                                                                break;
                                                case "SAGEMCOMXPOD":
                                                                qParam.put("id", "176");
                                                                break;
                                                case "COMMSCOPEA":
                                                                qParam.put("id", "165");
                                                                break;
                                                case "COMMSCOPEB":
                                                                qParam.put("id", "164");
                                                                break;
                                                case "DPT":
                                                                qParam.put("id", "99");
                                                                break;
                                                case "SHAWMOXIGATEWAY":
                                                                qParam.put("id", "158");
                                                                break;
                                                case "XB7":
                                                                qParam.put("id", "190");
                                                                break;
                                                case "XB8":
                                                    qParam.put("id", "208");
                                                    break;                
                                                case "DCX3400250GB":
                                                                qParam.put("id", "64");
                                                                break;
                                                case "DCX 3200 P2 M":
                                                                qParam.put("id", "57");
                                                                break;
                                                case "DCX3200HDGUIDE":
                                                                qParam.put("id", "127");
                                                                break;
                                                case "CISCODPC3848V":
                                                case "GRANDFATHERED_CISCODPC3848V":
                                                        qParam.put("id", "138");
                                                                break;
                                                case "CISCODPC3825":
                                                case "GRANDFATHERED_CISCODPC3825":
                                                        qParam.put("id", "94");
                                                                break;
                                                case "ARRISSBG6782":
                                                case "GRANDFATHERED_ARRISSBG6782":
                                                        qParam.put("id", "124");
                                                                break;
                                                case "XIONE":
                                                                                qParam.put("id", "205");
                                                                break;
                                                case "LEGACYFIBREMODEM":
                                                                qParam.put("id","165");
                                                                break;
                                                //Vivek Ewan-43435        
                                                case "WIFIROUTER":
                                                                qParam.put("id","170");
                                                                break;
                                                //Vivek Ewan-43435   
                                          //Security device                      
                                                case "DOORBELL":
                                                				qParam.put("id","226");
                                                				break;    
                                                							
                                                case "XCAM":
                                    						qParam.put("id","227");
                                    						break; 
                                                
                                                case "TPIAMODEM":
                            								qParam.put("id","90");
                            								break; 		
                                                				
                                                }
                                                String matrixNum = configprop.getProperty("matrix");
                                                System.out.println(matrixNum);
                                                String matx = "matrix-" + matrixNum;
                                                qParam.put("status", "3");
                                                qParam.put("comm", "3");
                                                qParam.put("branch", "QAC");
                                                if (matrixNum.equalsIgnoreCase("preprod")) {
                                                                qParam.put("erpUrl", "http://ociuatwls.sjrb.ca");
                                                                matx = matrixNum;
                                                } else {
                                                                qParam.put("erpUrl", "http://ocisitwls.sjrb.ca/");
                                                }
                                                qParam.put("isStubbedEnvironment", "false");
                                                qParam.put("isCpeOnly", "true");
                                                qParam.put("cpeEnv", matx);

                                                RequestSpecification request = RestAssured.given().queryParams(qParam);

                                                Response response = request.get();
                                                serialNumber = response.jsonPath().getString("serialNumber");
                                                System.out.println(serialNumber);
                                                //Vivek Ewan-43435 added wifirouter condition
                                                //Commentedon 18/9/2023
//                                                if (configprop.getProperty("skipBackendValidations", "false").equalsIgnoreCase("false") && !deviceType.equalsIgnoreCase("DCT700") && !deviceType.equalsIgnoreCase("WIFIROUTER"))  {
//                                                                String macString = deviceType.toUpperCase() + " MACAddress " + generateMacAddress(serialNumber, "estb")
//                                                                                                + " SerialNumber " + serialNumber;
//                                                                //addInfoInReport(macString);
//                                                                //Hooks.setFileWriter(macString);
//                                                }
                                                return serialNumber;
                                }
                }

                public static String generateMacAddress(String serialNum, String macAddressType)
                                                throws IOException, SAXException, ParserConfigurationException {
                                // String baseHost =
                                // http://129.150.77.106/oracle-erp-inventory/inventory/serialnumber/;
                                String macAddress = "";
                                // String host = baseHost + serialNum;
                                // RestAssured.baseURI = host;
                                // RequestSpecification request = RestAssured.given();
                                // Response response = request.get();
                                // String respStatus = Integer.toString(response.getStatusCode());
                                // if (response.getStatusCode() != 200)
                                // return respStatus;
                                if (macAddressType.equals("estb")) {
                                                macAddress = MacAddress.getMacAddress(serialNum);
                                                return convertMacAddress(macAddress);
                                } else {
                                                macAddress = MacAddress.getMacAddress(serialNum);
                                                System.out.println(macAddress);
                                                return macAddress;
                                }
                }

                public static String convertMacAddress(String macAddress) {
                                String estbMacAddress = macAddress.substring(0, 2) + ":" + macAddress.substring(2, 4) + ":"
                                                                + macAddress.substring(4, 6) + ":" + macAddress.substring(6, 8) + ":" + macAddress.substring(8, 10)
                                                                + ":" + macAddress.substring(10, 12);

                                return estbMacAddress;
                }

                public static String generateStubbedSerialNum499(String deviceType) {
                                String serialNumber = "";
                                switch (deviceType.toUpperCase()) {
                                case "XB6":
                                                serialNumber = RandomStringUtils.randomNumeric(3) + "Xb6converged" + RandomStringUtils.randomNumeric(3);
                                                break;
                                case "XG1V4":
                                                serialNumber = "5xgteway" + RandomStringUtils.randomNumeric(3);
                                                break;
                                case "XI6":
                                                serialNumber = "8xgateway" + RandomStringUtils.randomNumeric(3);
                                                break;
                                case "DCX3400":
                                                serialNumber = "Aut3400DigitalCableTerminal" + RandomStringUtils.randomNumeric(3);
                                                break;
                                case "HITRON":
                                                serialNumber = "Aut3NACmodem" + RandomStringUtils.randomNumeric(3) + "Hitron";
                                                break;
                                case "XG1V3":
                                                serialNumber = "5xgteway" + RandomStringUtils.randomNumeric(3);
                                                break;
                                case "DPT":
                                                serialNumber = "dpt" + RandomStringUtils.randomNumeric(3);
                                                break;
                                }
                                return serialNumber;
                }
}
