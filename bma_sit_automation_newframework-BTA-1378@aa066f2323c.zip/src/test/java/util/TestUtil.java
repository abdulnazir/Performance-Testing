package util;


import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import pageObjects.BaseUIPage;

public class TestUtil extends BaseUIPage{
	private WebDriver driver;
	public static int PAGE_LOAD_TIME=100;
	public TestUtil(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	
	//public static int IMPLICIT_WAIT=100;
	

	public void openUrlNewTab(String url) throws InterruptedException
	{
		((JavascriptExecutor)driver).executeScript("window.open()");
		//JavascriptExecutor js = (JavascriptExecutor) driver;
	   // js.executeScript("window.open();");

		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		int newTab = tabs.size();
		driver.switchTo().window(tabs.get(newTab-1));
		driver.get(url);
		waitForLoading(driver);
		isLoaderSpinnerVisible(driver);
	}
}
