package util;

import pageObjects.BaseUIPage;


public class HostUrls extends BaseUIPage {

	static String locationId = prop.getProperty("locationId");

	static String ncHost;
	static String hostDomain = ".matrix.sjrb.ad:9001";
	static String hostPrefix;
	public static String webUDroutingChanges=System.getProperty("webUDroutingChanges");	
	static String matrixEnv = System.getProperty("environment");
	public static String matrix = (matrixEnv != null) ? matrixEnv : prop.getProperty("matrix").toLowerCase();

	static {
		// TODO handle for PreProd
		switch (matrix) {
		case "130":
	        hostPrefix = "http://tstcoreoeml130";
	        matrix = "";
	        break;
		case "132":
	        hostPrefix = "http://tstcoreoeml132";
	        matrix = "";
	        break;
		case "133":
		        hostPrefix = "http://tstcoreoeml133";
		        matrix = "";
		        break;
                case "128":
		case "135":
		case "137":
			hostPrefix = "http://tstcoreoeml";
			break;
		case "499":
			hostPrefix = "http://dpdcoreoeml";
			break;
		case "311":
			hostPrefix = "http://devcoreoeml";
			break;
		case "460":
		case "461":
		case "462":
		case "463":
		case "464":
		case "465":
		case "470":
		case "471":
		case "472":
		case "473":
		case "474":
		case "475":
		case "476":
		case "477":
		case "488":
		case "489":
		case "453":
		case "466":
			hostPrefix = "http://dtscoreoeml";
			break;
		case "181":
			hostPrefix = "https://tclcooeml181-01";
			matrix = "";
			break;
		case "182":
			hostPrefix = "https://tclcooeml";
			matrix = "182-01";
			break;
		case "183":
			hostPrefix = "https://tclcooeml";
			matrix = "183-01";
			break;			
		case "preprod":
			hostPrefix = " http://oeservice.oss.lab/";
			matrix = "";
			hostDomain = "";
			break;
		case "webud" :
			hostPrefix = "https://lruser002:eGXE9AwG6.pHNQByTWTsi8MG@matrix-";
			matrix = "";
			hostDomain="181-udgfweb.matrix.sjrb.ad/";
		    break;

		}
		ncHost = hostPrefix + matrix + hostDomain;
		System.out.println("Nc host is "+ ncHost);
		if (matrixEnv != null) {
			//addInfoInReport("ncHost overriden by env variable to " + ncHost);
		}
	}

	public static String getOEUrl() {
		String oeUrl = ncHost + "/oe.newCustomerDesktop.nc?locationId=" + locationId;
		prop.setProperty("oeurl", oeUrl);
		//Hooks.setFileWriter("LocationId: " + locationId);
		return oeUrl;

	}

	public static String getNCUrl() {
		prop.setProperty("ncurl", ncHost);
		return ncHost;
	}

	public static String getOverviewPageUrl() {
		String overviewPageUrl = ncHost + "/oe.customerOrderHistory.nc?locationId=" + locationId;
		prop.setProperty("overviewpageurl", overviewPageUrl);
		return overviewPageUrl;
	}

	public static String getOMUrl(String type) {
		String omUrl = "";
		if (type.equalsIgnoreCase("stub"))
			omUrl = ncHost + "/common/uobject.jsp?object=7022760707013150025";
		else if (type.equalsIgnoreCase("integrated"))
		// {omUrl = ncHost
		// +
		// "/common/search.jsp?explorer_mode=disable&object=9154991340813334203&return=%2Fcommon%2Fuobject.jsp%3Fid%3D9156428878713105789%26tab%3D_COM%2BOrders%26object%3D9156428878713105789&o=9156428878713105789&project=7022760707013150024";
		{
			omUrl = ncHost
					+ "/common/search.jsp?explorer_mode=disable&object=9158687844913673321&return=%2Fcommon%2Fuobject.jsp%3Fobject%3D1000&o=1000";
		} else if (type.equalsIgnoreCase("preprod")) {
			omUrl = ncHost
					+ "common/search.jsp?explorer_mode=disable&object=9147484818413092375&return=%2Fcommon%2Fuobject.jsp%3Fobject%3D1000&o=1000";
		} else {
			System.out.println("wrong input");
		}
		prop.setProperty("omurl", omUrl);
		return omUrl;
	}

	public static String getMOEUrl() {
		String moeUrl = ncHost + "/oe.newCustomerDesktop.nc?locationId=" + locationId;
		prop.setProperty("moeurl", moeUrl);
		return moeUrl;
	}

	public static String getImmediateChangesUrl() {

		String immediateChangesUrl = ncHost + "/oe.immediateChanges.nc?locationId=" + locationId;
		prop.setProperty("immediatechangesurl", immediateChangesUrl);
		return immediateChangesUrl;

	}

	public static String getServiceCallUrl() {
		String serviceCallUrl;
		if (prop.getProperty("matrix").equalsIgnoreCase("preprod")) {
			serviceCallUrl = "http://pre-ffm-servicecalls.sjrb.ad//servicecall/home?LocationId=" + locationId
					+ "&accountId=";
		} else if (prop.getProperty("matrix").equalsIgnoreCase("181")) {
			serviceCallUrl = "http://matrix-181" + "-ffmweb.matrix.sjrb.ad/servicecall/home?LocationId=" + locationId
					+ "&accountId=";
		} else {
			serviceCallUrl = "http://matrix-" + matrix + "-ffmweb.matrix.sjrb.ad/servicecall/home?LocationId="
					+ locationId + "&accountId=";
		}
		prop.setProperty("servicecallurl", serviceCallUrl);
		return serviceCallUrl;
	}

	public static String getNetcrackerDocumentDfUrl() {
		String netcrackerDocumentDfUrl = ncHost
				+ "/common/uobject.jsp?tab=_Active+Shipping+Tasks&object=9137754422113767327";
		return netcrackerDocumentDfUrl;
	}

	public static String getFDBUrl() {
		String FDBUrl = configprop.getProperty("FDBUrl");
		System.out.println("FDBUrl"+FDBUrl);
		return FDBUrl;
	}

	public static String getXRAYUrl() {
		String XRAYUrl = configprop.getProperty("XRAYUrl");
		return XRAYUrl;

	}

	public static String getPremiseMoveOverviewUrl() {
		String premiseMoveOverviewUrl = ncHost + "/oe.customerOrderHistory.nc?locationId=";
		return premiseMoveOverviewUrl;
	}

	public static String getReturnHardwareURL() {
		return ncHost + "/services/omservice/hardwareReturned/disconnectedDevices";
	}

	public static String getOfferSegmentUrl() {
		return ncHost + "/common/uobject.jsp?tab=_Segment+Mapping&object=9152345600313574780";
	}
	
}
