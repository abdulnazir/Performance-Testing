package util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriverException;


public class WriteExcel {
	//public static void main(String[] args)  {
       
           
		
			// TODO Auto-generated method stub
		   //getLastRow("XB6");
		//writeDataToExcel("serialnum" , "macAdd" , 4 , "Sheet1");
		//}
		/*public static int getLastRow(String sheetName) throws IOException{
			File src = new File("C:\\FakeHardware\\test.xlsx");
				FileInputStream fis = new FileInputStream(src);
				XSSFWorkbook workbook = new XSSFWorkbook(fis);
				XSSFSheet sh1= workbook.getSheet(sheetName);;
				int LastRow = sh1.getLastRowNum();
				return LastRow;
			}*/
			
				public static void writeDataToExcel(String accountnumber, String accountid, int rowCount,String sheetName ){
					
			try{
				 
				File src = new File("C:\\FakeHardware\\hardware.xlsx");
				
			FileInputStream fis = new FileInputStream(src);
			XSSFWorkbook workbook = new XSSFWorkbook(fis);
			XSSFSheet sh1= workbook.getSheet(sheetName);
			Cell cell = null;
			Row row = sh1.createRow(rowCount);
			cell = row.createCell(0);
			cell.setCellValue(accountnumber);
			cell = row.createCell(1);
			cell.setCellValue(accountid);
			;
			fis.close();
			FileOutputStream fout=new FileOutputStream(new File("C:\\FakeHardware\\hardware.xlsx"));

			workbook.write(fout);
			fout.close();

			}
			catch(IOException e){
				 System.out.println(e.getMessage());
			}
				}
			public static void writeAccountNumber(String sheetName, String accountnumber, int rowCount){
				
				try{
					 
					File src = new File("C:\\FakeHardware\\RaoAccounts.xlsx");
					
				FileInputStream fis = new FileInputStream(src);
				XSSFWorkbook workbook = new XSSFWorkbook(fis);
				XSSFSheet sh1= workbook.getSheet(sheetName);
				Cell cell = null;
				Row row = sh1.createRow(rowCount);
				cell = row.createCell(0);
				cell.setCellValue(accountnumber);
				
				;
				fis.close();
				FileOutputStream fout=new FileOutputStream(new File("C:\\FakeHardware\\RaoAccounts.xlsx"));

				workbook.write(fout);
				fout.close();

				}
				catch(IOException e){
					 System.out.println(e.getMessage());
				}
			
				}
}
