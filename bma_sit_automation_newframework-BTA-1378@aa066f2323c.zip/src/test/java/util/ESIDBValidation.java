package util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


//import util.StreamingCsvResultSetExtractor;



import oracle.jdbc.pool.OracleDataSource;

public class ESIDBValidation  {
   // public static void main(String args[]) {
    public static String dbextract(String id) {
	try {
	   // String id = "Id-d976c55f9d9b981be314da49";
	    OracleDataSource ds = new OracleDataSource();
	    ds.setDriverType("thin");
	     String hostName = "tclcogodbl181v.matrix.sjrb.ad";
	  // String hostName = "tstcoreorcl706.matrix.sjrb.ad";
	    ds.setServerName(hostName);
	     ds.setPortNumber(1521);
	    //ds.setPortNumber(1527);
	    ds.setServiceName("tcl1int");
	 //  ds.setServiceName("tst1esi");
	  // ds.setUser("ESI_TESTER");
	    ds.setUser("cdi");
	   // ds.setPassword("esitester");
	   ds.setPassword("cdi");
	    Connection con = ds.getConnection();
	    Statement stmt = con.createStatement();
	  //  String query = "select * from tstc01l22_esiuser.esi_log\r\n" + "where SERVICE_ORCHESTRATION_ID = '" + id
		  //  + "' and component_identifier in ('PCS_NetCracker','VS_AccountQualifiesForPartnerServiceDiscount_verify_v1')\r\n" + "order by esi_log_id desc";
	 //   String query = "select * from tstc01l22_esiuser.esi_log\r\n" + 
	   // 	"where SERVICE_ORCHESTRATION_ID ='" + id +"' order by esi_log_id desc";
	   String query = "select account_no, wireless_credit_cluster from account where account_no = '"+id+"'";
	    System.out.println(query);
	  //  String query = "select * from tstc01l22_esiuser.esi_log";
	 //   String query1 = "select * from tstc01l22_esiuser.esi_log\r\n" + 
	    //	"where SERVICE_ORCHESTRATION_ID = '" + id + "' and component_identifier in ('PCS_NetCracker','VS_AccountQualifiesForPartnerServiceDiscount_verify_v1') \r\n" + 
	    	//"and operation_identifier = 'getAccount'";
	  //  String query2 = "select * from tstc01l22_esiuser.esi_log\r\n" + 
		    //	"where SERVICE_ORCHESTRATION_ID = '" + id + "' and component_identifier in ('PCS_NetCracker','VS_AccountQualifiesForPartnerServiceDiscount_verify_v1') \r\n" + 
		    //	"and operation_identifier = 'getPlannedOrders'";
	    ResultSet rs = stmt.executeQuery(query);
	   //ResultSet rs1 = stmt.executeQuery(query1);
	  //  ResultSet rs2 = stmt.executeQuery(query2);
//	    while(rs1.next())
//	    {
//	    }
//	    while(rs2.next())
//	    {
//	    }
	    
	   // rs.next();
	   // System.out.println("Table contains "+rs1.getRow()+" rows");
	   String wcc = "";
	    while (rs.next()) {
                wcc = String.valueOf(rs.getString(2));
}
	    FileOutputStream fout=new FileOutputStream(new File("test-output\\esi_log.csv"));
	   // StreamingCsvResultSetExtractor sc = new StreamingCsvResultSetExtractor(fout);
	   // sc.extractData(rs);
//	    if (rs1.getRow()>1)
//		addInfoInReport("getAccount is duplicate");
//	  //  Assert.assertEquals(rs1.getRow(), 1);
//	    if (rs2.getRow()>1)
//		addInfoInReport("getPlannedOrders is duplicate");
	   // Assert.assertEquals(rs2.getRow(), 1);
	    //return(rs1.getRow());
	    return wcc;

	} catch (Exception e) {
	    System.out.println(e);
	    return "";
	}
    }
    
    
}
