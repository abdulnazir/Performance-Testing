package util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;

public class AccountInfo {

	public static void addTextToFile(ArrayList<String> text, String filename, String lineType) throws IOException {
		System.out.println("\n***********************    Writing into file    ***********************\n\n########\n");
		String path = "test-output\\" + filename.replace(" ", "_") + ".txt";
		File fout = new File(path);
		FileOutputStream fos = new FileOutputStream(fout);
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		for (int i = 0; i < text.size(); i++) {
			bw.write(text.get(i));
			if(lineType.equals("nLine"))
			bw.newLine();
		}

		bw.close();
	}

	public static void storePageSourceOfLastPage(String pagesource) {
		try {
			// Create file
			FileWriter fstream = new FileWriter("test-output\\lastPageSource.html");
			BufferedWriter out = new BufferedWriter(fstream);
			out.write(pagesource);
			// Close the output stream
			out.close();
		} catch (Exception e) {// Catch exception if any
			System.err.println("Error: " + e.getMessage());
		}
	}
}
