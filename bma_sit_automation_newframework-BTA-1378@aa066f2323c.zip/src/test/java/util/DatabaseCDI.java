package util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import org.apache.commons.lang.RandomStringUtils;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;

import oracle.jdbc.pool.OracleDataSource;
import pageObjects.BaseUIPage;


public class DatabaseCDI extends BaseUIPage {
	
	
     public static String retrieveAccountId(String accountnumber) 
	{
	try {
		
        String accountIdFromCDI = "";
        OracleDataSource ds = new OracleDataSource();
        ds.setDriverType("thin");
        String hostName = configprop.getProperty("cdiHostName");
        ds.setServerName(hostName);
        ds.setPortNumber(Integer.parseInt(configprop.getProperty("port")));
        ds.setServiceName(configprop.getProperty("servicename"));
        ds.setUser(configprop.getProperty("username"));
        ds.setPassword(configprop.getProperty("password"));
        Connection con = ds.getConnection();
        Statement stmt = con.createStatement();
        System.out.println(accountnumber);
        String query = "select ID from account where account_no = '" + accountnumber+ "'";
        		
        ResultSet rs = stmt.executeQuery(query);
        //System.out.println(rs);
        while (rs.next()) {
                        accountIdFromCDI = String.valueOf(rs.getLong(1));
        }
        con.close();
        System.out.println(accountIdFromCDI);
        return accountIdFromCDI;
} catch (Exception e) {
       System.out.println(e);
       return "Id not found";
}
	}	//return accountnumber;

     public static String checkPronounID(String accountnumber) 
	{
	try {
		
        String accountIdFromCDI = "";
        String pronounIdFromCDI = "";
        OracleDataSource ds = new OracleDataSource();
        ds.setDriverType("thin");
        String hostName = configprop.getProperty("cdiHostName");
        ds.setServerName(hostName);
        ds.setPortNumber(Integer.parseInt(configprop.getProperty("port")));
        ds.setServiceName(configprop.getProperty("servicename"));
        ds.setUser(configprop.getProperty("username"));
        ds.setPassword(configprop.getProperty("password"));
        Connection con = ds.getConnection();
        Statement stmt = con.createStatement();
        System.out.println(accountnumber);
        String query = "select ID from account where account_no = '" + accountnumber+ "'";       
        ResultSet rs = stmt.executeQuery(query);
        while (rs.next()) {
                        accountIdFromCDI = String.valueOf(rs.getLong(1));
        }
        String query1 = "select ID, PRONOUN_ID, last_name, first_name from PARTY where ID=' "+accountIdFromCDI+"'";
        ResultSet rs1 = stmt.executeQuery(query1);
        while (rs1.next()) {
                        pronounIdFromCDI = String.valueOf(rs1.getLong(2));
        }
        con.close();
        System.out.println(accountIdFromCDI);
        return accountIdFromCDI;
} catch (Exception e) {
       System.out.println(e);
       return "Id not found";
}
	}	//return accountnumber;

	
	public static String retrieveObjectId(String accountId) 
	{
	try {
		
        String accountIdFromCDI = "";
        OracleDataSource ds = new OracleDataSource();
        ds.setDriverType("thin");
        String hostName = prop.getProperty("cdiHostName");
        ds.setServerName(hostName);
        ds.setPortNumber(Integer.parseInt(prop.getProperty("port")));
        ds.setServiceName(prop.getProperty("servicename"));
        ds.setUser(prop.getProperty("username"));
        ds.setPassword(prop.getProperty("password"));
        Connection con = ds.getConnection();
        Statement stmt = con.createStatement();
        String query = "select  from account where account_no = '" + accountId+ "'";
        		
        ResultSet rs = stmt.executeQuery(query);
        //System.out.println(rs);
        while (rs.next()) {
                        accountIdFromCDI = String.valueOf(rs.getLong(1));
        }
        con.close();
        
        return accountIdFromCDI;
} catch (Exception e) {
       System.out.println(e);
       return "Id not found";
}

}
	public static void updateAccountType(String accountnumber)
	{
		try {
			
        String accountIdFromCDI = "";
        OracleDataSource ds = new OracleDataSource();
        ds.setDriverType("thin");
        String hostName = prop.getProperty("cdiHostName");
        ds.setServerName(hostName);
        ds.setPortNumber(Integer.parseInt(prop.getProperty("port")));
        ds.setServiceName(prop.getProperty("servicename"));
        ds.setUser(prop.getProperty("username"));
        ds.setPassword(prop.getProperty("password"));
        Connection con = ds.getConnection();
        Statement stmt = con.createStatement();
        //System.out.println("accountNumber" + accountnumber);
        String partnerID=RandomStringUtils.randomAlphanumeric(4);
        String partnerAccountNumber = RandomStringUtils.randomNumeric(6);
    //    String query = "Update ACCOUNT SET SUBTYPE='Freedom', PARTNER_SERVICE_ID='"+partnerID +"',PARTNER_ACCOUNT_NUMBER='" + partnerAccountNumber + "'where ACCOUNT_NO='" + accountnumber +"'";
        
       String query ="UPDATE account set PARTNER_ACCOUNT_NUMBER='PS054',\r\n" + 
        	"PARTNER_NODE_ID='', PARTNER_BILL_CYCLE='' , PARTNER_ASSOC_STATUS='2',ASSOC_AUTH_STATUS='1' ,SUBTYPE='ShawMobile'\r\n" + 
        	"where account_no='"+accountnumber+"'";
        
        String query1 = "UPDATE account set PARTNER_ASSOC_STATUS='2' where account_no='"+accountnumber+"'";
        		
        ResultSet rs = stmt.executeQuery(query1);
        ResultSet rs1 = stmt.executeQuery(query);
        //System.out.println(rs);
        //while (rs.next()) {
                    //    accountIdFromCDI = String.valueOf(rs.getLong(0));
        //}
        con.close();
	}
		catch (Exception e) {
		       System.out.println(e);
}
	}
	
	
	  public static String devicerecord(String serialnumber) 
			{
			try {
				
		        String proptypeFromCPE = "";
		        String transactFromCPE= "";
		        String statetypeFromCPE= "";
		        
		        OracleDataSource ds = new OracleDataSource();
		        ds.setDriverType("thin");
		        String hostName = configprop.getProperty("cdiHostName");
		        ds.setServerName(hostName);
		        ds.setPortNumber(Integer.parseInt(configprop.getProperty("port")));
		        ds.setServiceName(configprop.getProperty("servicename"));
		        ds.setUser(configprop.getProperty("username"));
		        ds.setPassword(configprop.getProperty("password"));
		        Connection con = ds.getConnection();
		  //      Statement stmt = con.createStatement();
		  //      PreparedStatement prepstmt = connection.prepareStatement
		        System.out.println(serialnumber);	        
		        String query = "select d.device_id, d.DEVICE_MODEL_ID,d.serial_number,d.last_account,pt.name PROPRIETOR_TYPE,st.name STATE_TYPE, d.TRANSACTION_TYPE\n"
		        		+ "from device d, EQUIPMENT_PROPRIETOR ep, state_type st, proprietor_type pt\n"
		        		+ "where d.serial_number =('M2BDMAAJ0000')\n"
		        		+ "and d.EQUIPMENT_PROPRIETOR_ID = ep.EQUIPMENT_PROPRIETOR_ID\n"
		        		+ "and ep.PROPRIETOR_TYPE_ID=pt.PROPRIETOR_TYPE_ID\n"
		        		+ "and d.STATE_TYPE_ID = st.STATE_TYPE_ID";
		        
		        PreparedStatement prepstmt = con.prepareStatement(query);
		  //      prepstmt.setString(1,"M29HM000UAT0000");
		        ResultSet rs = prepstmt.executeQuery(query);
		        
		        //System.out.println(rs);
		        while (rs.next()) {
		        	proptypeFromCPE = String.valueOf(rs.getObject(5));	        	
		        	statetypeFromCPE= String.valueOf(rs.getObject(6));
		        	transactFromCPE = String.valueOf(rs.getObject(7));
		        }
		        con.close();
		        System.out.println("proptype :" + proptypeFromCPE);
		        System.out.println("statetype :" + statetypeFromCPE);
		        System.out.println("transacttype: " +transactFromCPE);
		        
		
		        ExtentCucumberAdapter.addTestStepLog("statetype :" + statetypeFromCPE);
		        ExtentCucumberAdapter.addTestStepLog("transacttype: " +transactFromCPE);
		        
		        return proptypeFromCPE;
		} catch (Exception e) {
		       System.out.println(e);
		       return "Id not found";
		}
			}
	  
	  
	  public static String equipedevicetable(String serialnumber) 
		{
		try {
			
	        String audittypeFromCPE = "";
	        String statetypeFromCPE= "";
	        String serailnumFromCPE="";
	        
	        OracleDataSource ds = new OracleDataSource();
	        ds.setDriverType("thin");
	        String hostName = configprop.getProperty("cdiHostName");
	        ds.setServerName(hostName);
	        ds.setPortNumber(Integer.parseInt(configprop.getProperty("port")));
	        ds.setServiceName(configprop.getProperty("servicename"));
	        ds.setUser(configprop.getProperty("username"));
	        ds.setPassword(configprop.getProperty("password"));
	        Connection con = ds.getConnection();
	  //      Statement stmt = con.createStatement();
	  //      PreparedStatement prepstmt = connection.prepareStatement
	        System.out.println(serialnumber);	        
	        String query = "select  audit_type,State_type_id,Device_ID,serial_number,create_by,create_tms FROM Device_history where serial_number = ('M29JMZ8E0000') and audit_type = 'UPDATE'";
	        
	        PreparedStatement prepstmt = con.prepareStatement(query);
	  //      prepstmt.setString(1,"M29HM000UAT0000");
	        ResultSet rs = prepstmt.executeQuery(query);
	        
	        //System.out.println(rs);
	        while (rs.next()) {
	        	audittypeFromCPE = String.valueOf(rs.getObject(1));	        	
	        	statetypeFromCPE= String.valueOf(rs.getObject(2));
	        	serailnumFromCPE= String.valueOf(rs.getObject(4));
	        }
	        con.close();
	        System.out.println("proptype :" + audittypeFromCPE);
	        System.out.println("statetype :" + statetypeFromCPE);
	        System.out.println("serialnum :" + serailnumFromCPE);

	        
	
	        ExtentCucumberAdapter.addTestStepLog("statetype :" + statetypeFromCPE);
	        ExtentCucumberAdapter.addTestStepLog("audittype : " +audittypeFromCPE);
	        ExtentCucumberAdapter.addTestStepLog("serialnum : " +serailnumFromCPE);
	        return audittypeFromCPE;
	} catch (Exception e) {
	       System.out.println(e);
	       return "Id not found";
	}
		}
}
