package util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class ReadHardware   {

	public ReadHardware(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}
		private static XSSFSheet ExcelWSheet;
	    private static XSSFWorkbook ExcelWBook;
	    private static XSSFCell Cell;
	    private static XSSFRow Row;
	    static File fileName = new File("C:\\FakeHardware\\test.xlsx");
	    static File fileName2 = new File("D:\\Automation_Project\\SourceFiles\\Accountid.xlsx");

		//public static void main(String[] args) throws Exception {
			
			/*setExcelFile(fileName, "XB6");
	    	String data = getCellData(0,0);
	    	 System.out.println(data);*/
		
			  public static String ReadHardware_Excel( String sheetName , int RowNum , int ColNum) throws IOException 
		     {

		        FileInputStream ExcelFile = new FileInputStream(fileName);
		        ExcelWBook = new XSSFWorkbook(ExcelFile);
		        ExcelWSheet = ExcelWBook.getSheet(sheetName);

		    try {
		        Cell = ExcelWSheet.getRow(RowNum).getCell(ColNum);
		        String CellData = Cell.getStringCellValue();
		        ExcelWBook.close();
		        return CellData;
		        
		       
		     
		     } catch (Exception e) {
	              System.out.println(e);
		        return "";
		        }

		    }
		    
		    public static String ReadAccountID_Excel( String sheetName , int RowNum , int ColNum) throws IOException 
		     {

		        FileInputStream ExcelFile = new FileInputStream(fileName2);
		        ExcelWBook = new XSSFWorkbook(ExcelFile);
		        ExcelWSheet = ExcelWBook.getSheet(sheetName);

		    try {
		        Cell = ExcelWSheet.getRow(RowNum).getCell(ColNum);
		        String CellData = Cell.getStringCellValue();
		        return CellData;
		       
		    } catch (Exception e) {
	              System.out.println(e);
		        return "";

		    }

		}
	}


