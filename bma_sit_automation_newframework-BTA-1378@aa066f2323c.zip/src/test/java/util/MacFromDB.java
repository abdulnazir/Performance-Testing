package util;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import org.apache.commons.lang.RandomStringUtils;

import oracle.jdbc.pool.OracleDataSource;


public class MacFromDB   {
	
	
     public static String retrieveAccountId(String serialNumber) 
	{
	try {
		
        String docMac = "";
        OracleDataSource ds = new OracleDataSource();
        ds.setDriverType("thin");
      //  String hostName = "tclcogodbl181v.matrix.sjrb.ad";
        String hostName = "tstcoreorcl133.matrix.sjrb.ad";
        ds.setServerName(hostName);
       // ds.setPortNumber(Integer.parseInt(prop.getProperty("port")));
        ds.setPortNumber(1521);
      //  ds.setServiceName(prop.getProperty("servicename"));
       // ds.setServiceName("tcl1int");
        ds.setServiceName("tst1int");
       // ds.setUser(prop.getProperty("username"));
        ds.setUser("cpe_app");
        ds.setPassword("cpe_app");
        //ds.setPassword(prop.getProperty("password"));
        Connection con = ds.getConnection();
        Statement stmt = con.createStatement();
        String query = "select value from network_interface where device_id = (select device_id from device where serial_number = '"+serialNumber+"') and name = 'docsisMacAddress'";
        		
        ResultSet rs = stmt.executeQuery(query);
        //System.out.println(rs);
        while (rs.next()) {
                        docMac = String.valueOf(rs.getString(1));
        }
        con.close();
        
        return docMac;
} catch (Exception e) {
       System.out.println(e);
       return "Id not found";
}
	}
}
