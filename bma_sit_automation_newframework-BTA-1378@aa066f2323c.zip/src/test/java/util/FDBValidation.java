package util;


	import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.support.FindBy;
	import org.openqa.selenium.support.PageFactory;
	import static com.codeborne.selenide.Selenide.$;
import pageObjects.BaseUIPage;
import util.TestUtil;

	public class FDBValidation extends BaseUIPage {
		
		private WebDriver driver;
		public static int PAGE_LOAD_TIME=100;
		public FDBValidation(WebDriver driver) {
			this.driver=driver;
			PageFactory.initElements(driver, this);
		}
		
			@FindBy(xpath="//*[@id=\"grdView\"]/tbody/tr[2]/td[6]")
			WebElement fdbdeviceStatus;
			
			@FindBy(xpath="//*[@id=\"txtUserName\"]")
			WebElement userName;
			
			@FindBy(xpath="//*[@id=\"txtPassword\"]")
			WebElement password;
		   
			@FindBy(xpath="//*[@id=\"btnLogin\"]")
			WebElement loginbutton;
			
			public void loginToFDB() throws InterruptedException {
				Thread.sleep(10000);
				if (driver.findElements(By.xpath("//*[@id=\"txtUserName\"]")).size() > 0) {
					userName.sendKeys("trainer");
					Thread.sleep(2000);
					password.sendKeys("trainer");
					Thread.sleep(2000);
					loginbutton.click();
				}
			}
//		public String getdeviceStatus() {
//			
//			userName.sendKeys("trainer");
//			password.sendKeys("trainer");
//			loginbutton.click();
//			String deviceStatus = fdbdeviceStatus.getText();
//			return deviceStatus;
//			//System.out.println(deviceStatus);
//		}
			
			public String getdeviceStatus() throws InterruptedException {
				
				String fdbTableContent = "//td[contains(text(),'ENABLED')]";
			
				for (char c : "123456".toCharArray()) {
					Thread.sleep(9999);
					if (driver.findElement(By.xpath(fdbTableContent)).isDisplayed())
						break;
					driver.navigate().refresh();
				}
				return fdbdeviceStatus.getText();
			}
	}
	
