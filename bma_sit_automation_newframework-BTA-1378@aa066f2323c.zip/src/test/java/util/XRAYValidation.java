package util;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


import pageObjects.BaseUIPage;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.*;

public class XRAYValidation extends BaseUIPage {
	
	private WebDriver driver;
	public static int PAGE_LOAD_TIME=100;
	public XRAYValidation(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//*[@id=\"AccountNumber\"]")
	WebElement accountInput;

	@FindBy(xpath = "//*[@id=\"searchAccount\"]/div/div[2]/div/button")
	WebElement accountSearch;

	@FindBy(xpath = "//select[@id='partnerId']")
	WebElement selectPartner;

	@FindBy(xpath = "//option[@value='shaw-dev']")
	WebElement shawIntegartion;

	@FindBy(xpath = "//input[@id='hp-btn']")
	WebElement loginButton;

	@FindBy(xpath = "//*[@id=\"userNameInput\"]")
	WebElement userName;

	@FindBy(xpath = "//*[@id=\"passwordInput\"]")
	WebElement userPassword;

	@FindBy(xpath = "//*[@id=\"submitButton\"]")
	WebElement signInButton;

	@FindBy(xpath = "//*[@id=\"preActive\"]")
	WebElement networkLookup;

	public void selectShawIntegartion() throws InterruptedException {
		Thread.sleep(2000);
		$(By.xpath("//select[@id='partnerId']")).waitUntil(visible, 5000).click();
		// selectPartner.click();
		Thread.sleep(2000);
		shawIntegartion.click();
		Thread.sleep(2000);
		loginButton.click();
	}

	public void signIn() throws InterruptedException {
		/*
		 * if (prop.getProperty("matrix").equalsIgnoreCase("preprod")) { return; }
		 */
//		String xray_user = prop.getProperty("validation_email", "xray_user_not_set");
//		String xray_password = prop.getProperty("validation_password", "xray_password_not_set");
//		userName.sendKeys(xray_user);
//		Thread.sleep(1000);
//		userPassword.sendKeys(xray_password);
		Thread.sleep(1000);
		signInButton.click();
	}

	public void accountNumberInput(String accountNumber) {

		accountInput.sendKeys(accountNumber);
		accountSearch.click();
	}

	public String validateDeviceStatus() {
		return $(By.xpath("//td[@aria-describedby='devices_status']")).waitUntil(visible, 30000).getText();
	}

	public void validatingXRAY(String accountNumber) throws InterruptedException {
		Thread.sleep(5000);
		this.accountNumberInput(accountNumber);
		this.selectShawIntegartion();
		for (char c : "12".toCharArray()) {
			if ($(By.xpath("//*[@id='userNameInput']")).exists()) {
				this.signIn();
				break;
			}
			Thread.sleep(2000);
		}
		Thread.sleep(4000);
	}
}