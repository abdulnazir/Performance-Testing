package util;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.sl.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class DeleteHardware  {
	
	public DeleteHardware(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
         deleteExcelRow("Sheet1",  1 );
		
	}
		public static void deleteExcelRow(String sheetName, int rowNo) throws IOException {

		    XSSFWorkbook workbook = null;
		    XSSFSheet sheet = null;
              String excelPath = "C:\\FakeHardware\\test.xlsx";
		   
		        FileInputStream file = new FileInputStream(new File(excelPath));
		    	
		        workbook = new XSSFWorkbook(file);
		        sheet = workbook.getSheet(sheetName);
		        int lastRowNum = sheet.getLastRowNum();
		        System.out.println("the lastrownum is " + lastRowNum);
		        if (rowNo >= 1 && rowNo < lastRowNum) {
		            sheet.shiftRows(rowNo+1, lastRowNum, -1);
		        }
		        if (rowNo == lastRowNum) {
		           XSSFRow removingRow=sheet.getRow(rowNo);
		            if(removingRow != null) {
		                sheet.removeRow(removingRow);
		            }
		        }
		        file.close();
		        FileOutputStream outFile = new FileOutputStream(new File(excelPath));
		        workbook.write(outFile);
		        outFile.close();


		    
		        if(workbook != null)
		            workbook.close();
		    
				//return "";
		            }
}
		