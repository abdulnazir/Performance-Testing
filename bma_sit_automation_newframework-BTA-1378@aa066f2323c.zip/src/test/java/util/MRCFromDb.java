package util;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import org.apache.commons.lang.RandomStringUtils;

import oracle.jdbc.pool.OracleDataSource;

public class MRCFromDb  {
   

//    public static String retrieveBRMMRCAmount(String accountNumber) {
//   // public static void main(String args[]) { 
//	try {
//	    //String accountNumber = "12800002064";
//	    
//	    String mrcAmount = "";
//	    OracleDataSource ds = new OracleDataSource();
//	    ds.setDriverType("thin");
//	    String hostName=prop.getProperty("brmdbhostname");
//	    ds.setServerName(hostName);
//	    ds.setPortNumber(Integer.parseInt(prop.getProperty("brmdbport")));
//	    ds.setServiceName(prop.getProperty("brmdbservicename"));
//	    ds.setUser(prop.getProperty("brmdbusername"));
//	    ds.setPassword(prop.getProperty("brmdbpassword"));
//	    Connection con = ds.getConnection();
//	    Statement stmt = con.createStatement();
//	    String query = "SELECT\r\n" + 
//	    	"     sum(ebi.amount) as total_amount\r\n" + 
//	    	"FROM\r\n" + 
//	    	"    pin.event_t e, account_t a,\r\n" + 
//	    	"    pin.event_bal_impacts_t ebi\r\n" + 
//	    	"WHERE e.poid_type like '%/cycle_forward_monthly%'\r\n" + 
//	    	"    and a.poid_id0=e.account_obj_id0\r\n" + 
//	    	"    and a.account_no = '"+accountNumber+"'\r\n" + 
//	    	"    AND e.poid_id0 = ebi.obj_id0\r\n" + 
//	    	"ORDER BY\r\n" + 
//	    	"    e.created_t DESC";
//
//	    ResultSet rs = stmt.executeQuery(query);
//	    // System.out.println(rs);
//	    while (rs.next()) {
//		mrcAmount = String.valueOf(rs.getString(1));
//	    }
//	    con.close();
//	    System.out.println(mrcAmount);
//	    return mrcAmount;
//	} catch (Exception e) {
//	    System.out.println(e);
//	    return "BRM MRC not found";
//	}
//    }
    
//    public static String retrieveNCMRCAmount(String orderID) {
//	   // public static void main(String args[]) { 
//		try {
//		    //String accountNumber = "12800002064";
//		    
//		    String mrcAmount = "";
//		    OracleDataSource ds = new OracleDataSource();
//		    ds.setDriverType("thin");
//		    String hostName=prop.getProperty("ncdbhostname");
//		    ds.setServerName(hostName);
//		    ds.setPortNumber(Integer.parseInt(prop.getProperty("ncdbport")));
//		    ds.setServiceName(prop.getProperty("ncdbservicename"));
//		    ds.setUser(prop.getProperty("ncdbusername"));
//		    ds.setPassword(prop.getProperty("ncdbpassword"));
//		    Connection con = ds.getConnection();
//		    Statement stmt = con.createStatement();
//		    String query = "select pr2.value from nc_params pr1\r\n" + 
//		    	"inner join nc_params pr2\r\n" + 
//		    	"on pr1.object_id = pr2.object_id and pr2.attr_id = 7030760366013158523\r\n" + 
//		    	"where pr1.attr_id = 8111728766013898172\r\n" + 
//		    	"and pr1.value ="+ orderID;
//
//		    ResultSet rs = stmt.executeQuery(query);
//		    // System.out.println(rs);
//		    while (rs.next()) {
//			mrcAmount = String.valueOf(rs.getString(1));
//		    }
//		    con.close();
//		    System.out.println(mrcAmount);
//		    return mrcAmount;
//		} catch (Exception e) {
//		    System.out.println(e);
//		    return "NC MRC not found";
//		}
//	    }
}
