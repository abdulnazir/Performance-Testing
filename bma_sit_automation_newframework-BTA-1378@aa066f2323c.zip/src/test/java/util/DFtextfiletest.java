package util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;



public class DFtextfiletest {

	
	
		public void dftextfile(String accountnumber, String modelname[], String serialnumber[], String shippingtasknumber) throws IOException
		{
			
			
			 String path = "C:\\FakeHardware\\dftextfile.txt";
             for (int i=0; i<modelname.length ; i++)
             {
			   File fout = new File(path);
			   FileOutputStream fos = new FileOutputStream(fout);
			   BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
			   bw.write("\"" +accountnumber +"\" "+ "," + " \"" +  modelname[i] + "\" "+ ","+ "\""+ serialnumber +"\" " +","  + "\""+ shippingtasknumber +"\" ");
			   
			   bw.newLine();
			   bw.write("\"" +accountnumber +"\" "+ "," + " \"" +  modelname[i] + "\" "+ ","+ "\""+ serialnumber +"\" " +","  + "\""+ shippingtasknumber +"\" ");
				bw.close();
				}
			   
		
				
		
				
			
	}
	
}
