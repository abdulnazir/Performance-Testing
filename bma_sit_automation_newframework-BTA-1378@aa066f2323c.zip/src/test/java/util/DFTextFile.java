package util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;

import org.apache.commons.lang.RandomStringUtils;

import pageObjects.BaseUIPage;

public  class DFTextFile extends BaseUIPage {

	public void dftextfile(String accountnumber, String modelname[], String serialnumber[], String shippingtasknumber)
			throws IOException {
		String deviceName[] = new String[modelname.length];
		String trackingnumber[];
		String path = System.getProperty("user.home")+ "\\dftextfile.txt";
		File fout = new File(path);
		FileOutputStream fos = new FileOutputStream(fout);
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));

		for (int i = 0; i < modelname.length; i++) {
			switch (modelname[i].toUpperCase()) {
			case "HITRON":
				deviceName[i] = "Hitron CGNM-2250";
				break;
			case "DCX3510":
				deviceName[i] = "Motorola DCX3510/F080/032/500";
				break;
			case "DCX3400":
				deviceName[i] = "Motorola DCX3400/A380/010/500";
				break;
			case "XI6":
				deviceName[i] = "ARRIS XI6/AM00/080D";
				break;
			case "XB6":
				deviceName[i] = "Arris TG3482G";
				break;

			case "XG1V4":
				deviceName[i] = "ARRIS XG1V4/2710/092D/0500";
				break;
			case "XG1V3":
				deviceName[i] = "ARRIS XG1V3/1580/0933/0500";
				break;
			case "SAGEMCOMXPOD":
				deviceName[i] = "SAGEMCOM SC1-A";
				break;
			case "DCX3200":
				deviceName[i] = "Motorola DCX3200/7380/003";
				break;
			case "SHAWMOXIGATEWAY":
				deviceName[i] = "MOTOROLA XG1V3/1580/0533/0500";
				break;
			case "XID":
				deviceName[i] = "ARRIS PXD01ANI";
				break;
			case "DCT700":
        		 deviceName[i]="Motorola DCT700/US";
        		 break;
			}

			bw.write("\"" + accountnumber + "\" " + "," + " \"" + deviceName[i] + "\" " + "," + "\"" + serialnumber[i]
					+ "\" " + "," + "\"" + shippingtasknumber + "\" ");
			bw.newLine();

		}
		bw.close();
	}
}
