$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([
  {
    "id": "7847107d-05a5-4463-b15e-9e72fe8623f8",
    "feature": "WebUD Regression Sceanrios",
    "scenario": "NGV-52344 - To verify and validate Non-Controllable Reason for Full Disconnect New Customer for the Internet LOB.",
    "start": 1718057600136,
    "group": 21,
    "content": "",
    "tags": "@webud,@ngv-52344,@nophone,@newreg,",
    "end": 1718057910451,
    "className": "failed"
  }
]);
CucumberHTML.timelineGroups.pushArray([
  {
    "id": 21,
    "content": "Thread[TestNG-PoolService-0,5,main]"
  }
]);
});